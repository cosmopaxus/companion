import React, { useId, useLayoutEffect, useRef, useState } from 'react';
import { GestureResponderEvent, Platform, StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { CHECKIN_SCALES, CheckInDimension, LEVEL_MAX, LEVEL_MIN, levelBand, levelWord } from '../../domain/scales';
import { color, isNight, radius, sans, space, type } from '../../theme/tokens';
import { tapFeedback } from '../../platform/haptics';
import { feelEnd, feelMove, feelNudge, primeSound } from '../../platform/feelSound';
import { FEEL_CARD_TINT, FEEL_STOPS, FEEL_TEXT, feelColor, mix, withAlpha } from './palette';
import { FeelGlyph } from './FeelGlyph';

const THUMB = 32;
const PAD = THUMB / 2;
const TRACK_H = 14;
const SURFACE_H = 48;

// Web only: let vertical swipes scroll the page, and show a pointer.
const WEB_SURFACE: any = { touchAction: 'pan-y', cursor: 'pointer', userSelect: 'none' };

const clamp = (v: number) => Math.max(LEVEL_MIN, Math.min(LEVEL_MAX, v));

interface Props {
  dim: CheckInDimension;
  value?: number;
  onChange: (v: number) => void;
  testID?: string;
}

/**
 * A 0–100 slider for one check-in feeling. Its picture, color and (on web) sound follow the value.
 * Touch: drag sideways, or tap the line; a vertical swipe scrolls the page instead of changing it.
 * Keyboard: arrows ±1, Shift+arrows or Page Up/Down ±10, Home/End. Screen readers: adjustable, ±5.
 * The value is always shown as a number and a word, never by color alone.
 */
export function FeelSlider({ dim, value, onChange, testID }: Props) {
  const info = CHECKIN_SCALES[dim];
  const gid = `feel-${dim}-${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const [width, setWidth] = useState(0);
  const [dragging, setDragging] = useState(false);

  // Gesture handlers are created once, so they read the latest props through a ref.
  const latest = useRef({ value, onChange, width });
  useLayoutEffect(() => {
    latest.current = { value, onChange, width };
  });
  const gesture = useRef({ originX: 0, startX: 0, startY: 0, dragging: false });

  const apply = (v: number, how: 'drag' | 'tap' | 'step') => {
    const prev = latest.current.value;
    if (v !== prev) {
      if (prev === undefined || levelBand(prev) !== levelBand(v)) tapFeedback();
      latest.current.value = v;
      latest.current.onChange(v);
    }
    if (how === 'drag') feelMove(dim, v);
    else feelNudge(dim, v);
  };

  const valueAt = (pageX: number) => {
    const span = Math.max(1, latest.current.width - 2 * PAD);
    return clamp(Math.round(((pageX - gesture.current.originX - PAD) / span) * 100));
  };

  // Plain responder props (what PanResponder wraps), so every handler sees the current render.
  const responder = {
    onStartShouldSetResponder: () => true,
    onMoveShouldSetResponder: () => true,
    onResponderTerminationRequest: () => !gesture.current.dragging,
    onResponderGrant: (e: GestureResponderEvent) => {
      const n = e.nativeEvent;
      gesture.current = { originX: n.pageX - n.locationX, startX: n.pageX, startY: n.pageY, dragging: false };
      primeSound();
    },
    onResponderMove: (e: GestureResponderEvent) => {
      const n = e.nativeEvent;
      const g = gesture.current;
      if (!g.dragging) {
        const dx = Math.abs(n.pageX - g.startX);
        if (dx < 4 || dx < Math.abs(n.pageY - g.startY)) return;
        g.dragging = true;
        setDragging(true);
      }
      apply(valueAt(n.pageX), 'drag');
    },
    onResponderRelease: (e: GestureResponderEvent) => {
      const n = e.nativeEvent;
      const g = gesture.current;
      if (g.dragging) feelEnd();
      else if (Math.abs(n.pageY - g.startY) < 12) apply(valueAt(n.pageX), 'tap');
      g.dragging = false;
      setDragging(false);
    },
    onResponderTerminate: () => {
      if (gesture.current.dragging) feelEnd();
      gesture.current.dragging = false;
      setDragging(false);
    },
  };

  const step = (delta: number | 'min' | 'max') => {
    const cur = latest.current.value;
    let next: number;
    if (delta === 'min') next = LEVEL_MIN;
    else if (delta === 'max') next = LEVEL_MAX;
    else next = cur === undefined ? 50 : clamp(cur + delta);
    apply(next, 'step');
  };

  const webKeys =
    Platform.OS === 'web'
      ? {
          tabIndex: 0 as const,
          onKeyDown: (e: any) => {
            const big = e.shiftKey ? 10 : 1;
            const map: Record<string, number | 'min' | 'max'> = {
              ArrowRight: big,
              ArrowUp: big,
              ArrowLeft: -big,
              ArrowDown: -big,
              PageUp: 10,
              PageDown: -10,
              Home: 'min',
              End: 'max',
            };
            const d = map[e.key];
            if (d === undefined) return;
            e.preventDefault();
            primeSound();
            step(d);
          },
        }
      : {};

  const set = value !== undefined;
  const lv = value ?? 50;
  const c = set ? feelColor(dim, lv) : color.controlBorder;
  const word = set ? levelWord(dim, lv) : 'Not chosen';
  const x = PAD + (lv / 100) * Math.max(0, width - 2 * PAD);
  const [lo, mid, hi] = FEEL_STOPS[dim];

  const ink = FEEL_TEXT[dim][isNight ? 'night' : 'day'];
  return (
    <View style={[st.block, set && { borderColor: withAlpha(c, 0.35), backgroundColor: mix(color.paperStrong, c, FEEL_CARD_TINT) }]} testID={testID ? `${testID}-block` : undefined}>
      <View style={st.header}>
        <View style={[st.glyph, { backgroundColor: set ? withAlpha(c, 0.16) : color.canvas }]}>
          <FeelGlyph dim={dim} level={value} size={36} />
        </View>
        <View style={{ flex: 1, gap: 1 }}>
          <Text style={st.label}>{info.label}</Text>
          <Text style={[type.small, { fontSize: 13, lineHeight: 17 }]}>{info.question}</Text>
        </View>
        <Text style={[st.readout, { color: set ? ink : color.inkSoft }]} aria-hidden testID={testID ? `${testID}-value` : undefined}>
          {set ? `${word} · ${value}` : 'Not chosen'}
        </Text>
      </View>

      <View
        {...responder}
        {...webKeys}
        role="slider"
        aria-label={info.label}
        aria-valuemin={LEVEL_MIN}
        aria-valuemax={LEVEL_MAX}
        aria-valuenow={set ? value : undefined}
        aria-valuetext={set ? `${value} of 100, ${word}` : `Not chosen. From ${info.anchors[1]} to ${info.anchors[5]}.`}
        accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
        onAccessibilityAction={(e) => step(e.nativeEvent.actionName === 'increment' ? 5 : -5)}
        onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
        testID={testID}
        style={[st.surface, Platform.OS === 'web' && WEB_SURFACE]}
      >
        <View pointerEvents="none" style={StyleSheet.absoluteFill}>
          {width > 0 ? (
            <Svg width={width} height={SURFACE_H}>
              <Defs>
                <LinearGradient id={gid} x1="0" y1="0" x2="1" y2="0">
                  <Stop offset="0" stopColor={lo} />
                  <Stop offset="0.5" stopColor={mid} />
                  <Stop offset="1" stopColor={hi} />
                </LinearGradient>
              </Defs>
              <Rect
                x={PAD - TRACK_H / 2}
                y={(SURFACE_H - TRACK_H) / 2}
                width={Math.max(0, width - 2 * PAD + TRACK_H)}
                height={TRACK_H}
                rx={TRACK_H / 2}
                fill={`url(#${gid})`}
                opacity={set ? 1 : 0.38}
                stroke={set ? 'none' : color.controlBorder}
                strokeWidth={1}
              />
            </Svg>
          ) : null}
          <View
            style={[
              st.thumb,
              { left: x - THUMB / 2, transform: [{ scale: dragging ? 1.12 : 1 }] },
              set ? { borderColor: color.action, borderWidth: 4.5 } : { borderColor: color.controlBorder, borderStyle: 'dashed' },
            ]}
          />
        </View>
      </View>

      <View style={st.anchors} aria-hidden>
        <Text style={st.anchor}>{info.anchors[1]}</Text>
        <Text style={[st.anchor, { textAlign: 'right' }]}>{info.anchors[5]}</Text>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  // Mockup 05: each feeling on its own glass card with a chunky lip; the value in the feeling's ink.
  block: { borderRadius: 20, borderWidth: 1, borderColor: color.cardEdge, borderBottomWidth: 3, borderBottomColor: color.lip, backgroundColor: color.paperStrong, paddingHorizontal: space.md + 2, paddingTop: space.md, paddingBottom: space.sm, gap: 2 },
  header: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  glyph: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  label: { fontFamily: sans, fontSize: 17, lineHeight: 22, fontWeight: '800', color: color.ink },
  readout: { fontFamily: sans, fontSize: 16, lineHeight: 20, fontWeight: '800', textAlign: 'right', fontVariant: ['tabular-nums'], maxWidth: 130 },
  surface: { height: SURFACE_H, justifyContent: 'center', borderRadius: radius.md },
  thumb: {
    position: 'absolute',
    top: (SURFACE_H - THUMB) / 2,
    width: THUMB,
    height: THUMB,
    borderRadius: THUMB / 2,
    borderWidth: 2,
    backgroundColor: color.paperStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  anchors: { flexDirection: 'row', justifyContent: 'space-between' },
  anchor: { fontFamily: sans, fontSize: 13, lineHeight: 18, color: color.inkSoft, flex: 1 },
});
