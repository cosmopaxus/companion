// Painted academy, piece 3: full-screen art for low-text moments (rest, invitations, the path map).
// The painting fills the screen with slow motion; text sits only on dark-glass chips at the top and
// on a near-solid panel (PANEL_ALPHA) at the bottom, never on the raw art (tests/painted.test.ts).

import React, { useEffect, useState } from 'react';
import { Animated, Easing, LayoutChangeEvent, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useReducedMotion } from '../../state/motion';
import { color, isNight, radius, space } from '../../theme/tokens';
import { CHIP_GLASS, chipBackground, coverRect, NIGHT_VEIL, PANEL_ALPHA, PaintingId, PAINTINGS } from '../../theme/paintings';
import { Icon, IconName } from '../Icon';
import { SHARP } from './paintingSources';
import { useRise } from './Motion';

const native = Platform.OS !== 'web';
const hidden = { 'aria-hidden': true, accessible: false, importantForAccessibility: 'no-hide-descendants' as const };

/** The painting covering a box, with a slow zoom and a few rising motes (all of it stops under reduced motion). */
export function ArtFill({ painting, children, motes = 5, testID }: { painting: PaintingId; children?: React.ReactNode; motes?: number; testID?: string }) {
  const [box, setBox] = useState({ w: 0, h: 0 });
  const reduce = useReducedMotion();
  const [v] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (reduce) {
      v.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 30000, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
        Animated.timing(v, { toValue: 0, duration: 30000, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [reduce, v]);
  const r = box.w ? coverRect(box.w, box.h, painting) : null;
  const p = PAINTINGS[painting];
  return (
    <View style={StyleSheet.absoluteFill} onLayout={(e: LayoutChangeEvent) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })} testID={testID}>
      <View style={[StyleSheet.absoluteFill, { overflow: 'hidden', backgroundColor: '#2A2340' }]} {...hidden}>
        {r ? (
          <Animated.Image
            source={SHARP[painting]}
            resizeMode="cover"
            fadeDuration={0}
            testID="painting"
            style={{ position: 'absolute', left: r.left, top: r.top, width: r.width, height: r.height, transformOrigin: `${p.origin[0] * 100}% ${p.origin[1] * 100}%`, transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, 1.06] }) }] }}
          />
        ) : null}
        {isNight ? <View style={[StyleSheet.absoluteFill, { backgroundColor: NIGHT_VEIL.rgb, opacity: NIGHT_VEIL.alpha }]} /> : null}
        {!reduce && box.w ? (
          <View style={StyleSheet.absoluteFill} pointerEvents="none" testID="art-ambience">
            {Array.from({ length: motes }, (_, i) => (
              <Mote key={i} x={((i * 0.618) % 1) * 0.84 + 0.08} y={0.35 + ((i * 0.37) % 1) * 0.45} d={6500 + i * 900} delay={i * 1300} h={box.h} />
            ))}
          </View>
        ) : null}
      </View>
      {children}
    </View>
  );
}

function Mote({ x, y, d, delay, h }: { x: number; y: number; d: number; delay: number; h: number }) {
  const v = useRise(d, true, delay);
  return (
    <Animated.View
      style={{
        position: 'absolute',
        left: `${x * 100}%`,
        top: y * h,
        width: 12,
        height: 12,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: v.interpolate({ inputRange: [0, 0.15, 0.8, 1], outputRange: [0, 1, 0.6, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, -110] }) }],
      }}
    >
      <View style={{ position: 'absolute', width: 12, height: 12, borderRadius: 6, backgroundColor: '#FFE8A0', opacity: 0.35 }} />
      <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: '#FFF6D6' }} />
    </Animated.View>
  );
}

/** A dark-glass chip for full-art screens (place name, with an icon). */
export function ArtChip({ icon, label, testID }: { icon: IconName; label: string; testID?: string }) {
  return (
    <View style={st.chip}>
      <Icon name={icon} size={17} color="#F3D88E" strokeWidth={2} />
      <Text style={st.chipText} testID={testID}>
        {label}
      </Text>
    </View>
  );
}

/** A round dark-glass button (back or close) for full-art screens. */
export function ArtButton({ icon, label, onPress, testID }: { icon: IconName; label: string; onPress: () => void; testID?: string }) {
  return (
    <Pressable role="button" aria-label={label} onPress={onPress} hitSlop={6} style={(s: any) => [st.chip, st.round, (s.hovered || s.pressed) && { backgroundColor: 'rgba(24,17,46,0.85)' }]} testID={testID}>
      <Icon name={icon} size={20} color={CHIP_GLASS.text} strokeWidth={2.4} />
    </Pressable>
  );
}

/**
 * A full-art screen: the painting behind everything, a chip row at the top, an optional middle
 * (the breath orb, say) and a near-solid panel at the bottom holding all the reading.
 */
export function FullArtScreen({ painting, top, middle, children, testID }: { painting: PaintingId; top: React.ReactNode; middle?: React.ReactNode; children: React.ReactNode; testID?: string }) {
  return (
    <View style={{ flex: 1 }} testID={testID}>
      <ArtFill painting={painting}>
        <ScrollView style={{ flex: 1 }} contentContainerStyle={st.scroll} keyboardShouldPersistTaps="handled">
          <View style={st.top}>{top}</View>
          <View style={st.middle}>{middle}</View>
          <View style={st.panel}>{children}</View>
        </ScrollView>
      </ArtFill>
    </View>
  );
}

const panelBg = isNight ? `rgba(18,25,21,${PANEL_ALPHA})` : `rgba(251,247,238,${PANEL_ALPHA})`;

const st = StyleSheet.create({
  scroll: { flexGrow: 1, paddingHorizontal: space.lg, paddingTop: space.lg, paddingBottom: space.xl, width: '100%', maxWidth: 620, alignSelf: 'center' },
  top: { flexDirection: 'row', alignItems: 'center', gap: space.sm, flexWrap: 'wrap', minHeight: 44 },
  middle: { flexGrow: 1, minHeight: 180, alignItems: 'center', justifyContent: 'center', paddingVertical: space.xl },
  panel: { backgroundColor: panelBg, borderRadius: 28, padding: space.xl, gap: space.md, borderWidth: 1, borderColor: color.cardEdge, borderBottomWidth: 4, borderBottomColor: color.lip },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 7, minHeight: 36, paddingLeft: 10, paddingRight: 13, borderRadius: radius.pill, backgroundColor: chipBackground(), borderWidth: 1, borderColor: CHIP_GLASS.edge },
  round: { width: 44, height: 44, paddingLeft: 0, paddingRight: 0, justifyContent: 'center' },
  chipText: { color: CHIP_GLASS.text, fontSize: 13.5, lineHeight: 18, fontWeight: '700' },
});
