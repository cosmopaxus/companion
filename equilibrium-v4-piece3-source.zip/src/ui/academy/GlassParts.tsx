// Painted academy, piece 2: small pieces shared by the check-in, lesson, Compass and Journal
// (mockups 05–08). Colors come from tested pairs in theme/paintings.ts.

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import type { ElementId } from '../../domain/types';
import { ELEMENTS } from '../../domain/harmony';
import { color, isNight, sans, serif, space, type } from '../../theme/tokens';
import { HALLS, HallId } from '../../theme/academy';
import { HALL_INK, HALL_TINT } from '../../theme/paintings';
import { HallMark } from '../Icon';
import { useHall } from './hall';

const mode = isNight ? 'night' : 'day';

/** Text and tint colors that belong to a hall (the current one by default). */
export function hallInk(h: HallId): string {
  return HALL_INK[h][mode];
}
export function hallTint(h: HallId): string {
  return HALL_TINT[h][mode];
}
export function useHallInk(): { hall: HallId; ink: string; tint: string } {
  const { hall } = useHall();
  return { hall, ink: hallInk(hall), tint: hallTint(hall) };
}

let gid = 0;

/**
 * Days of a lesson as pips (mockup 06): filled in the hall's colors for days done, a ring for the
 * next one, plain for the rest. A record, not a score. Falls back to nothing over 21 days.
 */
export function HallPips({ count, target, hall, label, testID }: { count: number; target: number; hall: HallId; label: string; testID?: string }) {
  const [id] = React.useState(() => `pip-${++gid}`);
  const [, mid, light] = HALLS[hall].day;
  const deep = HALLS[hall].day[0];
  const done = Math.min(count, target);
  return (
    <View role="progressbar" aria-valuemin={0} aria-valuemax={target} aria-valuenow={done} aria-label={label} testID={testID} style={st.pips}>
      {Array.from({ length: target }, (_, i) => {
        const filled = i < done;
        const next = i === done && done < target;
        return (
          <View key={i} style={[st.pip, next && { borderWidth: 2.5, borderColor: hallInk(hall), backgroundColor: color.paperStrong }, !filled && !next && { backgroundColor: isNight ? color.paperStrong : '#EFE7D6' }]}>
            {filled ? (
              <Svg width="100%" height="100%" style={StyleSheet.absoluteFill}>
                <Defs>
                  <LinearGradient id={`${id}-${i}`} x1="0" y1="0" x2="0" y2="1">
                    <Stop offset={0} stopColor={mixHex(mid, light, 0.35)} />
                    <Stop offset={1} stopColor={mixHex(mid, deep, 0.25)} />
                  </LinearGradient>
                </Defs>
                <Rect x={0} y={0} width="100%" height="100%" rx={9} fill={`url(#${id}-${i})`} />
              </Svg>
            ) : null}
          </View>
        );
      })}
    </View>
  );
}

/**
 * The four elements as bars (mockup 07): each fills to its value, with a gold tick at even (50).
 * The number is always written, so color never carries the meaning alone.
 */
export function ElementBars({ values, testID }: { values: Record<ElementId, number>; testID?: string }) {
  const order: ElementId[] = ['fire', 'air', 'water', 'earth'];
  return (
    <View style={{ gap: space.md }} testID={testID}>
      {order.map((e) => {
        const v = Math.max(0, Math.min(100, Math.round(values[e])));
        const [deep, mid, light] = HALLS[e].day;
        return (
          <View key={e} style={st.barRow} testID={`${testID}-${e}`}>
            <View style={[st.seal, { backgroundColor: hallTint(e), borderColor: mixHex(mid, light, 0.3) }]} aria-hidden>
              <HallMark element={e} size={22} color={hallInk(e)} />
            </View>
            <View style={{ flex: 1, gap: 6 }}>
              <View style={st.barHead}>
                <Text style={st.barName}>
                  {ELEMENTS[e].name} <Text style={st.barLens}>· {ELEMENTS[e].lens}</Text>
                </Text>
                <Text style={[st.barValue, { color: hallInk(e) }]}>{v}</Text>
              </View>
              <View style={st.track} role="img" aria-label={`${ELEMENTS[e].name}: ${v} of 100. Even is 50.`}>
                <View style={[st.fill, { width: `${v}%`, backgroundColor: mid, borderRightColor: mixHex(mid, light, 0.4) }]}>
                  <View style={[StyleSheet.absoluteFill, { backgroundColor: deep, opacity: 0.18, borderRadius: 7 }]} />
                </View>
                <View style={st.even} />
              </View>
            </View>
          </View>
        );
      })}
      <Text style={[type.small, { fontSize: 12.5 }]}>Gold line: even (50).</Text>
    </View>
  );
}

/** A small date tile (mockup 08): the month over the day, tinted by the hall. */
export function DateTile({ iso, hall }: { iso: string; hall: HallId }) {
  const d = new Date(iso);
  const month = d.toLocaleString('en-US', { month: 'short' }).toUpperCase();
  return (
    <View style={[st.tile, { backgroundColor: hallTint(hall) }]} aria-hidden>
      <Text style={[st.tileMonth, { color: hallInk(hall) }]}>{month}</Text>
      <Text style={[st.tileDay, { color: hallInk(hall) }]}>{d.getDate()}</Text>
    </View>
  );
}

function mixHex(a: string, b: string, t: number): string {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const x = p(a);
  const y = p(b);
  return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, '0')).join('');
}

const st = StyleSheet.create({
  pips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  pip: { width: 22, height: 18, borderRadius: 9, overflow: 'hidden' },
  barRow: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  seal: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center', borderWidth: 2 },
  barHead: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' },
  barName: { fontFamily: sans, fontSize: 15.5, lineHeight: 20, fontWeight: '700', color: color.ink },
  barLens: { fontWeight: '500', color: color.inkSoft },
  barValue: { fontFamily: sans, fontSize: 16, lineHeight: 20, fontWeight: '800', fontVariant: ['tabular-nums'] },
  track: { height: 12, borderRadius: 7, backgroundColor: isNight ? color.paperStrong : '#EFE7D6', overflow: 'visible' },
  fill: { height: 12, borderRadius: 7, overflow: 'hidden' },
  even: { position: 'absolute', left: '50%', top: -4, width: 2.5, height: 20, marginLeft: -1.25, borderRadius: 1, backgroundColor: color.goldDeco },
  tile: { width: 50, minHeight: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center', paddingVertical: 4 },
  tileMonth: { fontFamily: sans, fontSize: 11.5, lineHeight: 14, fontWeight: '800', letterSpacing: 0.6 },
  tileDay: { fontFamily: serif, fontSize: 20, lineHeight: 24, fontWeight: '700' },
});
