// A 2-minute rest in the Healing Sanctuary (painted academy, mockup 10). Full-screen art; the
// breath orb grows on the in-breath (4 s) and settles on the out-breath (6 s). Nothing is recorded:
// it is a pause, not a practice log. Under reduced motion the orb holds still and only its words change.

import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Platform, StyleSheet, Text, View } from 'react-native';
import { useNav } from '../state/nav';
import { useReducedMotion } from '../state/motion';
import { color, isNight, serif, space, type } from '../theme/tokens';
import { ORB_ALPHA } from '../theme/paintings';
import { ArtButton, ArtChip, FullArtScreen } from '../ui/academy/FullArt';
import { Button } from '../ui/primitives';
import { ProgressBar } from '../ui/game';

export const REST_SECONDS = 120;
const IN_MS = 4000;
const OUT_MS = 6000;
const native = Platform.OS !== 'web';

function clock(s: number): string {
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

export function RestScreen() {
  const nav = useNav();
  const reduce = useReducedMotion();
  const [left, setLeft] = useState(REST_SECONDS);
  const [paused, setPaused] = useState(false);
  const [phase, setPhase] = useState<'in' | 'out'>('in');
  const done = left <= 0;
  const [scale] = useState(() => new Animated.Value(0));
  const phaseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // The countdown.
  useEffect(() => {
    if (paused || done) return;
    const t = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [paused, done]);

  // The breath: in for four, out for six.
  useEffect(() => {
    if (paused || done) return;
    const ms = phase === 'in' ? IN_MS : OUT_MS;
    if (!reduce) Animated.timing(scale, { toValue: phase === 'in' ? 1 : 0, duration: ms, easing: Easing.inOut(Easing.sin), useNativeDriver: native }).start();
    phaseTimer.current = setTimeout(() => setPhase((p) => (p === 'in' ? 'out' : 'in')), ms);
    return () => {
      if (phaseTimer.current) clearTimeout(phaseTimer.current);
      scale.stopAnimation();
    };
  }, [phase, paused, done, reduce, scale]);

  const word = done ? 'Well rested' : paused ? 'Paused' : phase === 'in' ? 'Breathe in' : 'Breathe out';

  const orb = (
    <Animated.View
      style={[st.orb, { transform: [{ scale: reduce ? 1 : scale.interpolate({ inputRange: [0, 1], outputRange: [0.86, 1.08] }) }] }]}
      testID="rest-orb"
    >
      <Text style={st.orbText} aria-live="polite" testID="rest-cue">
        {word}
      </Text>
    </Animated.View>
  );

  return (
    <FullArtScreen
      painting="healing-sanctuary"
      testID="screen-rest"
      top={
        <>
          <ArtButton icon="back" label="Back" onPress={nav.pop} testID="back-chip" />
          <ArtChip icon="heart" label="The Sanctuary · rest" testID="rest-place" />
        </>
      }
      middle={orb}
    >
      <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', gap: space.sm }}>
        <Text role="heading" aria-level={1} style={type.display}>
          2-minute rest
        </Text>
        <Text style={st.left} testID="rest-left">
          {done ? 'Done' : `${clock(left)} left`}
        </Text>
      </View>
      <ProgressBar value={REST_SECONDS - left} max={REST_SECONDS} height={10} tone={color.sage} label={`${clock(REST_SECONDS - left)} of 2 minutes`} />
      <Text style={type.body}>{done ? 'Two minutes, just for you. Carry the slower breath into whatever comes next.' : 'In for four, out for six. Let your shoulders drop on each out-breath.'}</Text>
      <View style={{ flexDirection: 'row', gap: space.sm }}>
        {!done ? <Button label={paused ? 'Resume' : 'Pause'} kind="secondary" onPress={() => setPaused((p) => !p)} style={{ flex: 1 }} testID="rest-pause" /> : null}
        <Button label={done ? 'Back to Home' : 'Finish'} onPress={nav.pop} style={{ flex: 1 }} testID="rest-finish" />
      </View>
    </FullArtScreen>
  );
}

const st = StyleSheet.create({
  orb: {
    width: 190,
    height: 190,
    borderRadius: 95,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `rgba(251,247,238,${ORB_ALPHA})`,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.95)',
  },
  orbText: { fontFamily: serif, fontSize: 22, lineHeight: 28, fontWeight: '700', color: isNight ? '#29452F' : color.sage, textAlign: 'center', paddingHorizontal: space.md },
  left: { fontSize: 16, fontWeight: '800', color: color.sage, fontVariant: ['tabular-nums'] },
});
