// The path you're walking, drawn on the academy grounds painting (painted academy, mockup 09).
// Each lesson sits on one of the painting's seven stone platforms, climbing from the gate. Mastered
// lessons are gold coins, "you are here" glows, the next path waits further up, and the Sanctuary
// offers a rest at any time. Text sits only on dark-glass pills; every node is a real, named button.

import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import type { Journey, TierId } from '../../domain/types';
import { isMastered, isPracticable, isTierOpen, lessonProgress, PathLesson, tierState, TIERS } from '../../domain/paths';
import { ART_STATS } from '../../theme/artStats';
import { CHIP_GLASS, GROUNDS_SPOTS, NIGHT_VEIL } from '../../theme/paintings';
import { isNight } from '../../theme/tokens';
import { NodeState } from '../../ui/game';
import { Icon } from '../../ui/Icon';
import { focusRing } from '../../ui/primitives';
import { HerePulse } from '../../ui/academy/Motion';
import { SHARP } from '../../ui/academy/paintingSources';

const MAX_W = 560;
const PILL = 'rgba(24,17,46,0.86)';
const GOLD = '#E3B755';
const GOLD_LIGHT = '#F6DE9A';

function nodeState(j: Journey, l: PathLesson, here: string | null): NodeState {
  if (!isPracticable(l)) return 'outline';
  if (!isTierOpen(j, l.tier)) return 'locked';
  if (isMastered(j, l)) return 'done';
  if (l.id === here) return 'now';
  return 'open';
}

export function canDrawGrounds(lessons: PathLesson[]): boolean {
  return lessons.length > 0 && lessons.length <= GROUNDS_SPOTS.lessons.length;
}

export function GroundsMap({
  journey,
  lessons,
  tier,
  here,
  openGoals,
  today,
  width,
  onLesson,
  onTier,
  onInvite,
  onRest,
}: {
  journey: Journey;
  lessons: PathLesson[];
  tier: TierId;
  here: string | null;
  openGoals: number;
  today: string;
  width: number;
  onLesson: (id: string) => void;
  onTier: (t: TierId) => void;
  onInvite: (t: TierId) => void;
  onRest: () => void;
}) {
  const W = Math.min(width, MAX_W);
  const s = ART_STATS['path-map-academy-grounds'];
  const H = (W * s.height) / s.width;
  const at = ([u, v]: [number, number]) => ({ x: u * W, y: v * H });
  const states = lessons.map((l) => nodeState(journey, l, here));
  const pts = lessons.map((_, i) => at(GROUNDS_SPOTS.lessons[i]));
  const nextIdx = states.findIndex((st2, i) => i > states.indexOf('now') && st2 === 'open');
  const next = TIERS[tier] ? nextTierOf(tier) : null;
  const nextState = next ? tierState(journey, next, today) : null;
  const after = next ? nextTierOf(next) : null;

  return (
    <View style={{ width: W, height: H, alignSelf: 'center', borderRadius: 18, overflow: 'hidden' }} testID="grounds-map">
      <Image source={SHARP['path-map-academy-grounds']} style={{ position: 'absolute', left: 0, top: 0, width: W, height: H }} resizeMode="cover" aria-hidden accessible={false} />
      <View style={[StyleSheet.absoluteFill, isNight ? { backgroundColor: NIGHT_VEIL.rgb, opacity: NIGHT_VEIL.alpha } : { backgroundColor: 'rgba(20,14,40,0.10)' }]} aria-hidden />
      {/* The trail between the platforms: walked in gold, ahead in dots. */}
      <Svg width={W} height={H} style={StyleSheet.absoluteFill} pointerEvents="none" aria-hidden accessible={false}>
        {pts.slice(0, -1).map((p, i) => {
          const q = pts[i + 1];
          const walked = states[i] === 'done' && (states[i + 1] === 'done' || states[i + 1] === 'now');
          const mx = (p.x + q.x) / 2;
          return <Path key={i} d={`M ${p.x} ${p.y} Q ${mx + (i % 2 ? 18 : -18)} ${(p.y + q.y) / 2} ${q.x} ${q.y}`} stroke={walked ? GOLD_LIGHT : 'rgba(255,255,255,0.85)'} strokeWidth={walked ? 4 : 3} strokeDasharray={walked ? undefined : '2 8'} strokeLinecap="round" fill="none" />;
        })}
      </Svg>

      {/* The Sanctuary: rest at any time. */}
      <Node pos={at(GROUNDS_SPOTS.sanctuary)} size={44} label="The Sanctuary. Take a 2-minute rest" onPress={onRest} testID="map-sanctuary" style={{ backgroundColor: '#1D8F75', borderColor: '#BFF2E3' }}>
        <Icon name="heart" size={22} color="#FFFFFF" strokeWidth={2.2} />
      </Node>
      <Pill pos={at(GROUNDS_SPOTS.sanctuary)} dy={32} align="right" W={W} edge>
        Sanctuary · rest anytime
      </Pill>

      {/* The next path, and the one after it at the top of the climb. */}
      {next ? (
        <>
          <Node
            pos={at(GROUNDS_SPOTS.next)}
            size={40}
            dashed={nextState !== 'invited'}
            label={`${TIERS[next].name} path. ${nextState === 'invited' ? 'Your teacher is offering it. See your invitation' : nextState === 'preparing' ? 'In preparation' : 'Offered when you’re ready. Open path'}`}
            onPress={() => (nextState === 'invited' ? onInvite(next) : onTier(next))}
            testID="map-next-tier"
          >
            <Icon name={nextState === 'invited' ? 'sparkle' : 'lock'} size={18} color={GOLD_LIGHT} strokeWidth={2} />
          </Node>
          <Pill pos={at(GROUNDS_SPOTS.next)} dy={30} align="right" W={W} edge tone={nextState === 'invited' ? 'gold' : undefined}>
            {TIERS[next].name} · {nextState === 'invited' ? 'ready for you' : nextState === 'preparing' ? 'in preparation' : 'when ready'}
          </Pill>
        </>
      ) : null}
      {after ? (
        <>
          <Node pos={at(GROUNDS_SPOTS.ascension)} size={38} dashed label={`Hall of Ascension: the ${TIERS[after].name} path, further on. Open path`} onPress={() => onTier(after)} testID="map-ascension">
            <Icon name="star" size={17} color="#E6DDFA" strokeWidth={2} />
          </Node>
          <Pill pos={at(GROUNDS_SPOTS.ascension)} dx={-28} align="left" W={W}>
            Hall of Ascension
          </Pill>
        </>
      ) : null}

      {/* The lessons. */}
      {lessons.map((l, i) => {
        const st2 = states[i];
        const p = lessonProgress(journey, l);
        const pos = pts[i];
        const now = st2 === 'now';
        const label = `${l.title}. ${st2 === 'done' ? 'Mastered' : now ? `You are here. ${p.label}` : st2 === 'outline' ? 'In preparation' : st2 === 'locked' ? 'Not open yet' : p.label}. Open lesson`;
        return (
          <React.Fragment key={l.id}>
            {now ? (
              <View pointerEvents="none" style={{ position: 'absolute', left: pos.x - 50, top: pos.y - 50, width: 100, height: 100, alignItems: 'center', justifyContent: 'center' }}>
                <View style={{ position: 'absolute', width: 92, height: 92, borderRadius: 46, backgroundColor: 'rgba(255,226,150,0.35)' }} />
                <HerePulse size={96} color={GOLD_LIGHT} />
              </View>
            ) : null}
            <Node
              pos={pos}
              size={now ? 58 : 42}
              dashed={st2 === 'outline' || st2 === 'locked'}
              label={label}
              onPress={() => onLesson(l.id)}
              testID={`map-lesson-${l.id}`}
              style={st2 === 'done' ? { backgroundColor: GOLD, borderColor: GOLD_LIGHT } : now ? { backgroundColor: '#FFF6E0', borderColor: '#E8C46B', borderWidth: 3 } : undefined}
            >
              {st2 === 'done' ? <Icon name="check" size={20} color="#4A3206" strokeWidth={3} /> : <Icon name={l.icon ?? 'star'} size={now ? 26 : 18} color={now ? '#5A3E08' : GOLD_LIGHT} strokeWidth={2.2} />}
            </Node>
            {now ? (
              <View pointerEvents="none" style={[st.hereCard, pos.x > W / 2 ? { right: W - pos.x + 38 } : { left: pos.x + 38 }, { top: pos.y - 44 }]} aria-hidden>
                <Text style={st.hereEyebrow}>You are here</Text>
                <Text style={st.hereTitle} numberOfLines={2}>
                  {l.title}
                </Text>
                <Text style={st.hereSub}>
                  {p.label}
                  {openGoals > 0 ? ` · ${openGoals} quest${openGoals === 1 ? '' : 's'} open` : ''}
                </Text>
              </View>
            ) : i === nextIdx ? (
              <Pill pos={pos} dx={pos.x > W / 2 ? -30 : 30} align={pos.x > W / 2 ? 'left' : 'right'} W={W}>
                Next · {l.title}
              </Pill>
            ) : null}
          </React.Fragment>
        );
      })}
    </View>
  );
}

function nextTierOf(t: TierId): TierId | null {
  const order: TierId[] = ['foundation', 'acolyte', 'initiate', 'adept'];
  const i = order.indexOf(t);
  return i >= 0 && i < order.length - 1 ? order[i + 1] : null;
}

function Node({ pos, size, label, onPress, testID, dashed, style, children }: { pos: { x: number; y: number }; size: number; label: string; onPress: () => void; testID: string; dashed?: boolean; style?: object; children: React.ReactNode }) {
  return (
    <Pressable
      role="button"
      aria-label={label}
      onPress={onPress}
      hitSlop={8}
      testID={testID}
      style={(s: any) => [
        st.node,
        { left: pos.x - size / 2, top: pos.y - size / 2, width: size, height: size, borderRadius: size / 2 },
        dashed && { borderStyle: 'dashed' },
        style,
        (s.hovered || s.pressed) && { transform: [{ scale: 1.08 }] },
        focusRing(s),
      ]}
    >
      {children}
    </Pressable>
  );
}

function Pill({ pos, dx = 0, dy = 0, align, W, tone, edge, children }: { pos: { x: number; y: number }; dx?: number; dy?: number; align: 'left' | 'right'; W: number; tone?: 'gold'; edge?: boolean; children: React.ReactNode }) {
  // 'left': the pill ends just left of the point; 'right': it starts just right of it. If the text
  // won't fit on that side, it goes on the other, and it never runs off the map.
  const text = React.Children.toArray(children).join('');
  const need = Math.min(220, text.length * 7.4 + 24);
  const gap = Math.abs(dx);
  const roomLeft = pos.x - gap - 6;
  const roomRight = W - pos.x - gap - 6;
  const side = align === 'left' ? (roomLeft >= need || roomLeft >= roomRight ? 'left' : 'right') : roomRight >= need || roomRight >= roomLeft ? 'right' : 'left';
  const room = side === 'left' ? roomLeft : roomRight;
  // edge: a label under its node, set against the map's right edge (mockup 09), clear of the trail.
  const place = edge ? { right: 6 } : side === 'left' ? { right: W - (pos.x - gap) } : { left: pos.x + gap };
  return (
    <View pointerEvents="none" aria-hidden style={[st.pill, place, { top: pos.y + dy - 13, maxWidth: edge ? 220 : Math.max(80, Math.min(220, room)) }, tone === 'gold' && { borderColor: GOLD_LIGHT }]}>
      <Text style={[st.pillText, tone === 'gold' && { color: '#FBE7BE' }]} numberOfLines={1}>
        {children}
      </Text>
    </View>
  );
}

const st = StyleSheet.create({
  node: { position: 'absolute', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(20,14,40,0.85)', borderWidth: 2, borderColor: '#FBE7BE' },
  pill: { position: 'absolute', maxWidth: 220, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: PILL, borderWidth: 1, borderColor: 'rgba(243,216,142,0.35)' },
  pillText: { color: CHIP_GLASS.text, fontSize: 12.5, lineHeight: 17, fontWeight: '800' },
  hereCard: { position: 'absolute', maxWidth: 200, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16, backgroundColor: PILL, borderWidth: 1, borderColor: 'rgba(243,216,142,0.45)', gap: 1 },
  hereEyebrow: { color: '#F3D88E', fontSize: 11, lineHeight: 14, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  hereTitle: { color: '#FFFFFF', fontSize: 16, lineHeight: 20, fontWeight: '800' },
  hereSub: { color: '#F3D88E', fontSize: 12.5, lineHeight: 16, fontWeight: '700' },
});
