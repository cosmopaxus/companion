// Journey → Path: the teacher's next step, the path map, the character sheet and inventory,
// and open quests (goals).

import React from 'react';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import type { Goal, Journey, TierId } from '../../domain/types';
import { ELEMENTS } from '../../domain/harmony';
import { deferInvitation, openTier } from '../../domain/ops';
import { Readiness, teacherNote, TIERS, todayKey } from '../../domain/paths';
import { GEM_AMOUNTS } from '../../domain/gems';
import { characterStats, inventory } from '../../domain/character';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { useToast } from '../../state/toast';
import { successFeedback } from '../../platform/haptics';
import { color, elementText, radius, space, type } from '../../theme/tokens';
import { Button, Card, Eyebrow, focusRing, Notice } from '../../ui/primitives';
import { ElementGlyph, Gem, Icon } from '../../ui/Icon';
import { ProgressBar, RankMark } from '../../ui/game';
import { PathMap } from './PathMap';
import { WingProvider } from '../../ui/academy/hall';

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;

export function PathView() {
  const store = useStore();
  const nav = useNav();
  const j = store.journey;
  const today = todayKey();
  const open = (j.goals ?? []).filter((g) => alive(g) && g.status === 'open').sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  const { width } = useWindowDimensions();

  return (
    <WingProvider wing="academy">
    <View style={{ gap: space.xl }} testID="journey-path">
      <TeacherCard />
      <PathMap journey={j} today={today} openGoals={open.length} onLesson={(id) => nav.push({ name: 'lesson', id })} onTier={(t) => nav.push({ name: 'tier', id: t })} onInvite={(t) => nav.push({ name: 'invitation', tier: t })} onRest={() => nav.push({ name: 'rest' })} />
      <View style={{ flexDirection: width < 520 ? 'column' : 'row', gap: space.md }}>
        <CharacterPreview journey={j} />
        <InventoryPreview journey={j} />
      </View>
      <QuestList goals={open} />
    </View>
    </WingProvider>
  );
}

export function ReadinessList({ r, testID }: { r: Readiness; testID?: string }) {
  const rows = [
    { ok: r.lessons.ok, text: `${TIERS[r.tier].name} lessons mastered: ${r.lessons.done} of ${r.lessons.total}` },
    { ok: r.days.ok, text: `Practiced on ${r.days.count} of the last ${r.days.window} days (${r.days.need} needed)` },
    { ok: r.goals.ok, text: `Goals reached on this path: ${r.goals.count} of ${r.goals.need}` },
  ];
  return (
    <View style={{ gap: 6 }} testID={testID}>
      {rows.map((row) => (
        <View key={row.text} role="img" style={{ flexDirection: 'row', gap: space.sm, alignItems: 'center' }} aria-label={`${row.ok ? 'Done' : 'Not yet'}: ${row.text}`}>
          <View style={[st.tick, row.ok ? { backgroundColor: color.sage, borderColor: color.sage } : null]}>{row.ok ? <Icon name="check" size={13} color={color.onSage} strokeWidth={2.8} /> : null}</View>
          <Text style={[type.small, { flex: 1, color: row.ok ? color.ink : color.inkSoft }]}>{row.text}</Text>
        </View>
      ))}
    </View>
  );
}

export function TeacherCard({ compact }: { compact?: boolean }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const today = todayKey();
  const note = teacherNote(store.journey, today);
  const begin = (t: TierId) => {
    const r = store.apply((j) => openTier(j, t, 'invited', undefined, today));
    if (!r.ok) return toast.show(r.error, { tone: 'caution' });
    successFeedback();
    toast.show(`The ${TIERS[t].name} path is open`);
  };

  // Home shows a compact copy of this card, so its test ids carry a prefix.
  const tid = (id: string) => (compact ? `home-${id}` : id);
  return (
    <Card tone="gold" style={{ gap: space.md }} testID={tid('teacher-card')}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <Icon name="path" size={18} color={color.gold} strokeWidth={2} />
        <Eyebrow>From your teacher</Eyebrow>
      </View>
      {note.kind === 'lesson' ? (
        <>
          <View style={{ gap: 4 }}>
            <Text style={type.title}>{note.lesson.title}</Text>
            <Text style={type.bodySoft}>{note.lesson.summary}</Text>
          </View>
          {note.progress.target > 1 ? (
            <View style={{ gap: 4 }}>
              <ProgressBar value={note.progress.count} max={note.progress.target} tone={color.gold} label={note.progress.label} />
              <Text style={[type.small, { fontSize: 13 }]}>{note.progress.label}</Text>
            </View>
          ) : null}
          <Button label={compact ? 'Open lesson' : 'Open this lesson'} kind="gold" small icon="path" onPress={() => nav.push({ name: 'lesson', id: note.lesson.id })} testID={tid('teacher-open-lesson')} />
        </>
      ) : note.kind === 'invite' || note.kind === 'resting' ? (
        <>
          <View style={{ gap: 4 }}>
            <Text style={type.title} testID={tid('teacher-invite')}>
              {note.kind === 'invite' ? `You’re ready for the ${TIERS[note.tier].name} path.` : `The ${TIERS[note.tier].name} path is ready when you are.`}
            </Text>
            <Text style={type.bodySoft}>
              {note.kind === 'invite'
                ? `You’ve practiced steadily, reached your goals and mastered every ${TIERS[note.readiness.tier].name} lesson. Next: ${TIERS[note.tier].theme.toLowerCase()}.`
                : 'No hurry. Keep practicing; begin whenever you choose.'}
            </Text>
          </View>
          {!compact && note.kind === 'invite' ? <ReadinessList r={note.readiness} /> : null}
          <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
            <Button label="See your invitation" icon="sparkle" small onPress={() => nav.push({ name: 'invitation', tier: note.tier })} testID={tid('teacher-invitation')} />
            <Button label={`Begin the ${TIERS[note.tier].name} path`} kind="gold" small onPress={() => begin(note.tier)} testID={tid('teacher-begin')} />
            <Button label="About this path" kind="quiet" small onPress={() => nav.push({ name: 'tier', id: note.tier })} />
            {note.kind === 'invite' ? <Button label="Not yet" kind="quiet" small onPress={() => store.apply((j) => deferInvitation(j, note.tier))} testID={tid('teacher-not-yet')} /> : null}
          </View>
        </>
      ) : note.kind === 'consistency' ? (
        <>
          <View style={{ gap: 4 }}>
            <Text style={type.title}>Keep showing up.</Text>
            <Text style={type.bodySoft}>{note.readiness.next ? `You’ve walked this path’s lessons. The ${TIERS[note.readiness.next].name} path is offered when your practice is steady and your goals are met.` : 'You’ve walked every lesson here. Keep the practices that serve you.'}</Text>
          </View>
          {note.readiness.next ? <ReadinessList r={note.readiness} testID={tid('teacher-readiness')} /> : null}
          {note.readiness.next ? <Button label={`About the ${TIERS[note.readiness.next].name} path`} kind="quiet" small onPress={() => nav.push({ name: 'tier', id: note.readiness.next! })} /> : null}
        </>
      ) : (
        <View style={{ gap: 4 }} testID={tid('teacher-preparing')}>
          <Text style={type.title}>You’ve walked every {TIERS[note.after].name} lesson.</Text>
          <Text style={type.bodySoft}>The {TIERS[note.tier].name} lessons are being prepared. Keep the practices that serve you; your teacher will open the next path here when it’s ready.</Text>
        </View>
      )}
    </Card>
  );
}

function CharacterPreview({ journey }: { journey: Journey }) {
  const nav = useNav();
  const s = characterStats(journey);
  const name = journey.profile?.name ?? '';
  return (
    <Pressable role="button" aria-label={`Character sheet. ${name}, ${s.rank}. ${s.daysPracticed} days practiced, ${s.goalsReached} goals reached, ${s.lessonsMastered} lessons mastered. Open`} onPress={() => nav.push({ name: 'character' })} style={(p: any) => [{ flex: 1, borderRadius: radius.lg }, focusRing(p)]} testID="open-character">
      {({ hovered }: any) => (
        <Card style={[{ gap: space.md, flex: 1 }, hovered && { borderColor: color.controlBorder }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <RankMark initial={name.slice(0, 1).toUpperCase() || '·'} size={48} />
            <View style={{ flex: 1 }}>
              <Eyebrow>Character sheet</Eyebrow>
              <Text style={type.heading}>{s.rank}</Text>
            </View>
            <Icon name="chevron" size={18} color={color.inkSoft} />
          </View>
          <Text style={type.small}>
            {s.daysPracticed} day{s.daysPracticed === 1 ? '' : 's'} practiced · {s.goalsReached} goal{s.goalsReached === 1 ? '' : 's'} reached · {s.lessonsMastered} lesson{s.lessonsMastered === 1 ? '' : 's'} mastered
          </Text>
        </Card>
      )}
    </Pressable>
  );
}

function InventoryPreview({ journey }: { journey: Journey }) {
  const nav = useNav();
  const items = inventory(journey);
  const rare = items.filter((i) => i.rare).length;
  return (
    <Pressable role="button" aria-label={`Inventory. ${items.length} items${rare ? `, ${rare} rare` : ''}. Open`} onPress={() => nav.push({ name: 'inventory' })} style={(p: any) => [{ flex: 1, borderRadius: radius.lg }, focusRing(p)]} testID="open-inventory">
      {({ hovered }: any) => (
        <Card style={[{ gap: space.md, flex: 1 }, hovered && { borderColor: color.controlBorder }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <View style={st.invIcon}>
              <Icon name="badge" size={26} color={color.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Eyebrow>Inventory</Eyebrow>
              <Text style={type.heading} testID="inventory-count">
                {items.length} item{items.length === 1 ? '' : 's'}
                {rare ? ` · ${rare} rare` : ''}
              </Text>
            </View>
            <Icon name="chevron" size={18} color={color.inkSoft} />
          </View>
          <Text style={type.small} numberOfLines={2}>
            {items.length ? `Latest: ${items[0].name}` : 'Goals you reach and badges you earn are kept here.'}
          </Text>
        </Card>
      )}
    </Pressable>
  );
}

/** Whether this goal's gem has already been earned (reaching it again earns nothing more). */
export function goalGemEarned(j: Journey, goalId: string): boolean {
  return j.gems.some((g) => g.reason === 'goal' && g.sourceId === goalId);
}

function QuestList({ goals }: { goals: Goal[] }) {
  const nav = useNav();
  const j = useStore().journey;
  return (
    <View style={{ gap: space.sm }} testID="quests">
      <Eyebrow heading>Open quests · {goals.length}</Eyebrow>
      {goals.length === 0 ? (
        <Notice icon="flag" action={<Button label="Set a goal" small kind="secondary" icon="plus" onPress={() => nav.openSheet({ name: 'goal' })} testID="quest-add" />}>
          No open quests. A goal turns a wish into a direction: keep it small enough to reach in a few weeks.
        </Notice>
      ) : (
        <Card padded={false}>
          {goals.map((g, i) => (
            <Pressable key={g.id} role="button" aria-label={`Quest: ${g.title}${g.element ? `. ${ELEMENTS[g.element].name}` : ''}. Open`} onPress={() => nav.openSheet({ name: 'goal', goalId: g.id })} style={(s: any) => [st.quest, i < goals.length - 1 && st.rowBorder, (s.hovered || s.pressed) && { backgroundColor: color.canvas }, focusRing(s)]} testID={`quest-${i}`}>
              <View style={st.flag}>{g.element ? <ElementGlyph element={g.element} size={18} color={elementText[g.element]} /> : <Icon name="flag" size={18} color={color.gold} strokeWidth={2} />}</View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={type.label}>{g.title}</Text>
                {g.why ? (
                  <Text style={type.small} numberOfLines={2}>
                    {g.why}
                  </Text>
                ) : null}
              </View>
              {!goalGemEarned(j, g.id) ? (
                <View style={st.reward} aria-label={`Reaching it earns ${GEM_AMOUNTS.goal} gems`}>
                  <Text style={[type.small, { color: color.gold, fontWeight: '700' }]}>+{GEM_AMOUNTS.goal}</Text>
                  <Gem size={14} />
                </View>
              ) : null}
            </Pressable>
          ))}
        </Card>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  tick: { width: 20, height: 20, borderRadius: 10, borderWidth: 1.5, borderColor: color.controlBorder, alignItems: 'center', justifyContent: 'center' },
  invIcon: { width: 48, height: 48, borderRadius: 24, backgroundColor: color.goldWash, borderWidth: 1.5, borderColor: color.goldDeco, alignItems: 'center', justifyContent: 'center' },
  quest: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 14, minHeight: 60 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  flag: { width: 36, height: 36, borderRadius: 18, backgroundColor: color.goldWash, alignItems: 'center', justifyContent: 'center' },
  reward: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill, backgroundColor: color.goldWash, borderWidth: 1, borderColor: color.goldBorder },
});
