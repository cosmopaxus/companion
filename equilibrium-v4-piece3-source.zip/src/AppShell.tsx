import React, { useEffect, useRef, useState } from 'react';
import { useInsets } from './ui/insets';
import { Keyboard, Platform, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useStore } from './state/store';
import { Route, TabId, TABS, useNav } from './state/nav';
import { ToastProvider } from './state/toast';
import { gemBalance } from './domain/selectors';
import { recordMilestones } from './domain/ops';
import { badges, newMilestones } from './domain/character';
import { LESSON_BY_ID } from './domain/paths';
import { Celebration, CelebrationMsg } from './ui/academy/Motion';
import { SPACE_NAME } from './domain/spaces';
import { setHapticsEnabled } from './platform/haptics';
import { setSoundEnabled } from './platform/feelSound';
import { ProtocolScreen } from './screens/Protocol';
import { applyUpdate, useUpdateReady } from './platform/updates';
import { EquilibriumScreen } from './screens/Equilibrium';
import { isAdult } from './domain/age';
import { color, radius, space, TAB_BAR_HEIGHT, type, WIDE_BREAKPOINT } from './theme/tokens';
import { LayoutCtx } from './ui/layout';
import { focusRing } from './ui/primitives';
import { Gem, Icon, IconName } from './ui/Icon';
import { Wordmark } from './ui/Wordmark';
import { Onboarding } from './screens/Onboarding';
import { Today } from './screens/Today';
import { Journey } from './screens/Journey';
import { Connect } from './screens/Connect';
import { Journal } from './screens/Journal';
import { You } from './screens/You';
import { AreaDetail } from './screens/AreaDetail';
import { AreaEditorSheet } from './screens/AreaEditor';
import { Harmony, HarmonyReading } from './screens/Harmony';
import { AboutScreen, DirectionsScreen, GemsScreen, IntakeScreen, ProfileScreen, SpaceSheet, SupportScreen } from './screens/YouScreens';
import { AccountScreen, DataScreen } from './screens/DataAccount';
import { CheckInHistory } from './screens/CheckInHistory';
import { CheckInScreen } from './screens/CheckIn';
import { RestScreen } from './screens/Rest';
import { InvitationScreen } from './screens/path/Invitation';
import { Guide } from './screens/guide/Guide';
import { LessonScreen } from './screens/path/LessonScreen';
import { TierScreen } from './screens/path/TierScreen';
import { CharacterScreen, InventoryScreen } from './screens/path/CharacterScreens';
import { GoalSheet } from './screens/path/GoalSheet';
import { LookBackScreen } from './screens/LookBack';

const TAB_LABEL: Record<TabId, string> = { today: 'Home', journey: 'Journey', connect: 'Connect', journal: 'Journal', you: 'You' };
const TAB_ICON: Record<TabId, IconName> = { today: 'home', journey: 'journey', connect: 'connect', journal: 'journal', you: 'you' };

function RouteView({ route }: { route: Route }) {
  switch (route.name) {
    case 'area':
      return <AreaDetail key={route.id + (route.compose ?? '') + (route.focus ? 'f' : '')} id={route.id} compose={route.compose} focus={route.focus} />;
    case 'checkins':
      return <CheckInHistory />;
    case 'checkin':
      return <CheckInScreen />;
    case 'rest':
      return <RestScreen />;
    case 'invitation':
      return <InvitationScreen key={route.tier} tier={route.tier} />;
    case 'harmony':
      return <Harmony />;
    case 'harmonyReading':
      return <HarmonyReading key={route.id} id={route.id} />;
    case 'gems':
      return <GemsScreen />;
    case 'directions':
      return <DirectionsScreen />;
    case 'data':
      return <DataScreen />;
    case 'account':
      return <AccountScreen />;
    case 'intake':
      return <IntakeScreen />;
    case 'protocol':
      return <ProtocolScreen />;
    case 'equilibrium':
      return <EquilibriumScreen />;
    case 'support':
      return <SupportScreen />;
    case 'about':
      return <AboutScreen />;
    case 'profile':
      return <ProfileScreen />;
    case 'lesson':
      return <LessonScreen key={route.id} id={route.id} />;
    case 'tier':
      return <TierScreen key={route.id} id={route.id} />;
    case 'character':
      return <CharacterScreen />;
    case 'inventory':
      return <InventoryScreen />;
    case 'lookback':
      return <LookBackScreen />;
  }
}

function TabScreen({ tab }: { tab: TabId }) {
  switch (tab) {
    case 'today':
      return <Today />;
    case 'journey':
      return <Journey />;
    case 'connect':
      return <Connect />;
    case 'journal':
      return <Journal />;
    case 'you':
      return <You />;
  }
}

export function AppShell() {
  const store = useStore();
  const nav = useNav();
  const insets = useInsets('page');
  const { width } = useWindowDimensions();
  const wide = width >= WIDE_BREAKPOINT;
  const [keyboard, setKeyboard] = useState(false);
  const updateReady = useUpdateReady();
  const [updateDismissed, setUpdateDismissed] = useState(false);
  const [visited, setVisited] = useState<TabId[]>(['today']);

  useEffect(() => setHapticsEnabled(store.journey.prefs.haptics), [store.journey.prefs.haptics]);
  useEffect(() => setSoundEnabled(store.journey.prefs.sound), [store.journey.prefs.sound]);
  // Keep milestones: the first time a lesson is mastered or a badge earned, it's recorded for good.
  // v3: a new milestone earned while the app is open gets a celebration (not ones found on load).
  const [celebration, setCelebration] = useState<CelebrationMsg | null>(null);
  const armed = useRef(false);
  useEffect(() => {
    if (!(store.ready && store.journey.profile)) return;
    const fresh = newMilestones(store.journey);
    if (fresh.lessons.length || fresh.badges.length) {
      if (armed.current) {
        const lesson = fresh.lessons.map((id) => LESSON_BY_ID[id]).find(Boolean);
        const badge = fresh.badges.length ? badges(store.journey).find((b) => b.id === fresh.badges[0].id) : undefined;
        const next: CelebrationMsg | null = lesson ? { id: Date.now(), kind: 'lesson', title: lesson.title } : badge ? { id: Date.now(), kind: 'badge', title: badge.name } : null;
        if (next) setTimeout(() => setCelebration(next), 0);
      }
      store.apply((j) => recordMilestones(j));
    }
    armed.current = true;
  }, [store.ready, store.journey.revision]); // eslint-disable-line react-hooks/exhaustive-deps
  // Tabs mount on first visit and then stay mounted (drafts and scroll survive tab switches).
  if (!visited.includes(nav.tab)) setVisited([...visited, nav.tab]);
  useEffect(() => {
    if (Platform.OS === 'web') return;
    const a = Keyboard.addListener('keyboardDidShow', () => setKeyboard(true));
    const b = Keyboard.addListener('keyboardDidHide', () => setKeyboard(false));
    return () => {
      a.remove();
      b.remove();
    };
  }, []);

  // Whenever there's no profile (fresh start, erase, or switching to an account without one), start from Today.
  const hasProfile = !!store.journey.profile;
  useEffect(() => {
    if (!hasProfile) nav.reset('today');
  }, [hasProfile]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!store.ready) {
    return (
      <View style={[st.fill, st.center]} aria-busy>
        <Wordmark size={26} />
        <Text style={[type.small, { marginTop: space.md }]}>Opening your journey…</Text>
      </View>
    );
  }

  if (!store.journey.profile) {
    return <Onboarding />;
  }

  const showTabBar = !wide && !keyboard;
  const bottomBar = showTabBar ? TAB_BAR_HEIGHT + Math.max(insets.bottom, 8) : 0;
  const bottomClearance = bottomBar + space.xxl + 24;
  const top = nav.stack[nav.stack.length - 1];
  const sp = store.journey.activeSpaceId;
  const gems = gemBalance(store.journey, sp);

  // Under 18 stays in Personal (the Be Well Space is for adults), so there's nothing to switch.
  const spacePill = !isAdult(store.journey) ? null : (
    <Pressable role="button" aria-label={`Space: ${SPACE_NAME[sp]}. Change Space`} onPress={() => nav.openSheet({ name: 'space' })} style={(s: any) => [st.pill, (s.hovered || s.pressed) && { backgroundColor: color.sageWash }, focusRing(s)]} testID="space-pill">
      <View style={[st.spaceDot, { backgroundColor: sp === 'personal' ? color.sage : color.gold }]} />
      <Text style={st.pillText}>{SPACE_NAME[sp]}</Text>
      <Icon name="chevronDown" size={14} color={color.inkSoft} strokeWidth={2.2} />
    </Pressable>
  );
  const gemPill = (
    <Pressable role="button" aria-label={`${gems} gem${gems === 1 ? '' : 's'} in ${SPACE_NAME[sp]}. Open gem ledger`} onPress={() => nav.push({ name: 'gems' })} style={(s: any) => [st.pill, (s.hovered || s.pressed) && { backgroundColor: color.goldWash }, focusRing(s)]} testID="gem-pill">
      <Gem size={16} />
      <Text style={st.pillText} testID="gem-pill-count">
        {gems}
      </Text>
    </Pressable>
  );

  const updateBanner = updateReady && !updateDismissed ? (
    <View style={[st.banner, { backgroundColor: color.sageWash }]} role="status" testID="update-banner">
      <Icon name="sparkle" size={16} color={color.sage} strokeWidth={2.2} />
      <Text style={[type.small, { color: color.sage, flex: 1, fontWeight: '600' }]}>A new version of Equilibrium is ready. Your entries stay as they are.</Text>
      <Text role="button" style={[type.small, st.bannerAction, { color: color.sage }]} onPress={applyUpdate} testID="update-refresh">
        Refresh
      </Text>
      <Text role="button" style={[type.small, st.bannerAction, { color: color.inkSoft }]} onPress={() => setUpdateDismissed(true)} testID="update-later">
        Later
      </Text>
    </View>
  ) : null;

  const persistBanner = store.recoveryNotice ? (
    <View style={[st.banner, { alignItems: 'flex-start' }]} role="alert" testID="recovery-banner">
      <Icon name="info" size={16} color={color.caution} strokeWidth={2.2} />
      <View style={{ flex: 1, gap: 6 }}>
        <Text style={[type.small, { color: color.caution }]}>{store.recoveryNotice}</Text>
        <View style={{ flexDirection: 'row', gap: space.md }}>
          <Text role="button" style={[type.small, st.bannerAction]} onPress={() => nav.push({ name: 'data' })}>
            Your data
          </Text>
          <Text role="button" style={[type.small, st.bannerAction]} onPress={store.dismissRecovery}>
            Dismiss
          </Text>
        </View>
      </View>
    </View>
  ) : store.persist.kind === 'memory' || store.persist.kind === 'error' ? (
      <Pressable role="button" onPress={() => nav.push({ name: 'data' })} style={st.banner} testID="persist-banner">
        <Icon name="info" size={16} color={color.caution} strokeWidth={2.2} />
        <Text style={[type.small, { color: color.caution, flex: 1 }]} numberOfLines={2}>
          {store.persist.kind === 'memory' ? "This browser isn't letting Equilibrium save. Tap to export a backup." : 'Latest changes not saved. Tap for details.'}
        </Text>
      </Pressable>
    ) : null;

  const content = (
    <View style={st.fill}>
      {visited.map((t) => (
        <View key={t} style={[st.fill, (t !== nav.tab || !!top) && st.hidden]} aria-hidden={t !== nav.tab || !!top} importantForAccessibility={t !== nav.tab || top ? 'no-hide-descendants' : 'auto'}>
          <TabScreen tab={t} />
        </View>
      ))}
      {top ? (
        <View style={[StyleSheet.absoluteFill, { backgroundColor: color.canvas }]}>
          <RouteView route={top} />
        </View>
      ) : null}
    </View>
  );

  return (
    <LayoutCtx.Provider value={{ wide, bottomClearance }}>
      <ToastProvider bottomOffset={bottomBar + space.lg}>
        <View style={[st.fill, { backgroundColor: color.canvas }]}>
          {wide ? (
            <View style={[st.fill, { flexDirection: 'row' }]}>
              <View style={st.rail} role="navigation" aria-label="Main">
                <View style={{ paddingHorizontal: space.sm, paddingTop: space.xl, paddingBottom: space.xl }}>
                  <Wordmark size={24} />
                </View>
                <View style={{ gap: 4 }}>
                  {TABS.map((t) => {
                    const on = nav.tab === t;
                    return (
                      <Pressable key={t} role="link" aria-current={on ? 'page' : undefined} aria-label={TAB_LABEL[t]} onPress={() => nav.setTab(t)} style={(s: any) => [st.railItem, on && st.railItemOn, !on && (s.hovered || s.pressed) && { backgroundColor: color.paper }, focusRing(s)]} testID={`tab-${t}`}>
                        <Icon name={TAB_ICON[t]} size={22} color={on ? color.actionText : color.inkSoft} filled={on} strokeWidth={on ? 2 : 1.75} />
                        <Text style={[st.railText, on && { color: color.actionText, fontWeight: '700' }]}>{TAB_LABEL[t]}</Text>
                      </Pressable>
                    );
                  })}
                </View>
                <View style={{ flex: 1 }} />
                <View style={{ gap: space.sm, paddingBottom: space.xl }}>
                  {spacePill}
                  {gemPill}
                  <Text style={[type.small, { paddingHorizontal: space.sm, fontSize: 12.5 }]}>
                    {store.persist.kind === 'saved' ? 'Saved on this device' : store.persist.kind === 'error' ? 'Not saved — see Your data' : store.persist.kind === 'memory' ? 'Not saving in this browser' : 'Saving…'}
                  </Text>
                </View>
              </View>
              <View style={st.fill}>
                {updateBanner}
                {persistBanner}
                {content}
              </View>
            </View>
          ) : (
            <View style={st.fill}>
              <View style={[st.topBar, { paddingTop: insets.top + 6 }]}>
                <Wordmark size={20} />
                <View style={{ flexDirection: 'row', gap: space.sm }}>
                  {spacePill}
                  {gemPill}
                </View>
              </View>
              {updateBanner}
              {persistBanner}
              {content}
              {showTabBar ? (
                <View style={[st.tabBar, { paddingBottom: Math.max(insets.bottom, 8), height: bottomBar }]} role="tablist" aria-label="Main">
                  {TABS.map((t) => {
                    const on = nav.tab === t && !top;
                    const current = nav.tab === t;
                    return (
                      <Pressable key={t} role="tab" aria-selected={current} aria-label={TAB_LABEL[t]} onPress={() => nav.setTab(t)} style={(s: any) => [st.tab, focusRing(s)]} testID={`tab-${t}`}>
                        <View style={[st.tabIcon, current && st.tabIconOn]}>
                          <Icon name={TAB_ICON[t]} size={22} color={current ? color.actionText : color.inkSoft} filled={current} strokeWidth={current ? 2 : 1.75} />
                        </View>
                        <Text style={[st.tabText, current && { color: color.actionText, fontWeight: '700' }, on && { textDecorationLine: 'none' }]}>{TAB_LABEL[t]}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              ) : null}
            </View>
          )}
          <AreaEditorSheet />
          <GoalSheet />
          <SpaceSheet />
          <Guide />
          <Celebration msg={celebration} top={(insets.top ?? 0) + space.xl} />
        </View>
      </ToastProvider>
    </LayoutCtx.Provider>
  );
}

const st = StyleSheet.create({
  fill: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center', backgroundColor: color.canvas },
  hidden: { display: 'none' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: space.lg, paddingBottom: 8, backgroundColor: color.canvas, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44, paddingHorizontal: 12, borderRadius: radius.pill, borderWidth: 1, borderColor: color.border, backgroundColor: color.paper },
  pillText: { fontSize: 14.5, fontWeight: '600', color: color.ink },
  spaceDot: { width: 8, height: 8, borderRadius: 4 },
  bannerAction: { color: color.caution, fontWeight: '700', textDecorationLine: 'underline', paddingVertical: 4 },
  banner: { flexDirection: 'row', gap: space.sm, alignItems: 'center', paddingHorizontal: space.lg, paddingVertical: 8, backgroundColor: color.cautionWash },
  tabBar: { flexDirection: 'row', backgroundColor: color.paper, borderTopWidth: 1, borderTopColor: color.border, paddingTop: 6, paddingHorizontal: 4 },
  tab: { flex: 1, alignItems: 'center', justifyContent: 'flex-start', gap: 2, minHeight: 52 },
  tabIcon: { width: 56, height: 30, borderRadius: radius.pill, alignItems: 'center', justifyContent: 'center' },
  tabIconOn: { backgroundColor: color.actionWash },
  tabText: { fontSize: 12, color: color.inkSoft, fontWeight: '500' },
  rail: { width: 248, paddingHorizontal: space.lg, borderRightWidth: 1, borderRightColor: color.border, backgroundColor: color.canvas },
  railItem: { flexDirection: 'row', alignItems: 'center', gap: space.md, minHeight: 48, paddingHorizontal: space.md, borderRadius: radius.md },
  railItemOn: { backgroundColor: color.actionWash },
  railText: { fontSize: 16, color: color.inkSoft, fontWeight: '500' },
});
