import { describe, expect, it } from 'vitest';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
import { checkBackup, makeBackup } from '../src/domain/backup';
import { mergeJourneys } from '../src/domain/merge';
import { palettes } from '../src/theme/palettes';
import {
  BUILDINGS,
  colorAt,
  contrast,
  CHIP_SHADE,
  DEFAULT_HALL,
  GLASS,
  glassArtStops,
  glassWash,
  HALO_CORE,
  HALO_PLATEAU,
  HALO_SCALE,
  frostStops,
  duskStops,
  groundsRoad,
  groundsWash,
  HALL_CHOICES,
  HALL_IDS,
  HALLS,
  HERO_ART,
  heroStops,
  isHallChoice,
  luminance,
  mix,
  ON_HALL,
  oklabMix,
  resolveHall,
  WINGS,
} from '../src/theme/academy';

const T0 = new Date('2026-06-01T16:00:00.000Z');
const onboarded = (): Journey => ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_v3'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, T0);

describe('v3 · hall gradients', () => {
  it('uses the four gradients exactly as chosen, dark → mid → light', () => {
    expect(HALLS.fire.day).toEqual(['#4A1B0C', '#D85A30', '#FAC775']);
    expect(HALLS.air.day).toEqual(['#042C53', '#378ADD', '#E6F1FB']);
    expect(HALLS.water.day).toEqual(['#04342C', '#1D9E75', '#E1F5EE']);
    expect(HALLS.earth.day).toEqual(['#412402', '#BA7517', '#C0DD97']);
    for (const h of HALL_IDS) {
      const [d, m, l] = HALLS[h].day;
      expect(luminance(d)).toBeLessThan(luminance(m));
      expect(luminance(m)).toBeLessThan(luminance(l));
    }
  });

  it('keeps Night the same hues but dimmer, so the light end never glares', () => {
    for (const h of HALL_IDS) {
      for (let i = 0; i < 3; i++) expect(luminance(HALLS[h].night[i])).toBeLessThan(luminance(HALLS[h].day[i]));
      expect(luminance(HALLS[h].night[2])).toBeLessThan(0.3);
    }
  });

  // The rule from the halls board: no single text color can pass across a whole dark-to-light
  // gradient, so text only ever sits in the dark zone. This proves it for every hall, both themes.
  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: every text color on a hall passes 4.5:1 behind the whole text block, for any text height`, () => {
      for (const h of HALL_IDS) {
        // From a one-line header to a long name wrapping onto several lines.
        for (let textPx = 80; textPx <= 520; textPx += 20) {
          const stops = heroStops(h, mode, textPx);
          const end = textPx / (textPx + HERO_ART);
          let worst = Infinity;
          for (let t = 0; t <= end + 1e-9; t += 0.004) {
            const bg = colorAt(stops, t);
            for (const fg of Object.values(ON_HALL)) worst = Math.min(worst, contrast(fg, bg));
          }
          expect([h, mode, textPx, worst >= 4.5]).toEqual([h, mode, textPx, true]);
        }
      }
    });

    it(`${mode}: a dusk band (card tops) is safe for text from edge to edge`, () => {
      for (const h of HALL_IDS) {
        const stops = duskStops(h, mode);
        for (let t = 0; t <= 1; t += 0.01) for (const fg of Object.values(ON_HALL)) expect(contrast(fg, colorAt(stops, t))).toBeGreaterThanOrEqual(4.5);
      }
    });

    it(`${mode}: an on-hall button shade (22% black) keeps its white icon readable`, () => {
      for (const h of HALL_IDS) {
        const stops = duskStops(h, mode);
        for (let t = 0; t <= 1; t += 0.1) expect(contrast(ON_HALL.title, mix(colorAt(stops, t), '#000000', 0.22))).toBeGreaterThanOrEqual(4.5);
      }
    });

    it(`${mode}: gradients are smooth (many small steps, no visible bands)`, () => {
      for (const h of HALL_IDS) {
        const stops = heroStops(h, mode);
        expect(stops.length).toBeGreaterThanOrEqual(17);
        for (let i = 1; i < stops.length; i++) {
          expect(stops[i].offset).toBeGreaterThanOrEqual(stops[i - 1].offset);
          // Neighboring stops are close in lightness: no jump a viewer would read as a band.
          expect(contrast(stops[i].color, stops[i - 1].color)).toBeLessThan(1.45);
        }
        expect(stops[0].color).toBe(HALLS[h][mode][0]);
        expect(stops[stops.length - 1].color).toBe(HALLS[h][mode][2]);
      }
    });
  }

  it('shows that the light end can never carry light text (why the zone rule exists)', () => {
    for (const h of HALL_IDS) expect(contrast(ON_HALL.title, HALLS[h].day[2])).toBeLessThan(2);
  });

  it('keeps the light end for the art strip, below the text', () => {
    for (const h of HALL_IDS) {
      const stops = heroStops(h, 'day', 200);
      expect(colorAt(stops, 1)).toBe(HALLS[h].day[2]);
      expect(colorAt(stops, 0.3)).toBe(HALLS[h].day[0]);
    }
  });

  it('blends in OKLab and returns the ends exactly', () => {
    expect(oklabMix('#4A1B0C', '#D85A30', 0)).toBe('#4A1B0C');
    expect(oklabMix('#4A1B0C', '#D85A30', 1)).toBe('#D85A30');
  });
});

describe('v3 · the frame stays readable', () => {
  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: solid buttons keep their text contrast and sit on a darker or distinct lip`, () => {
      const c = palettes[mode];
      expect(contrast(c.onSage, c.sage)).toBeGreaterThanOrEqual(4.5);
      expect(contrast(c.paperStrong, c.gold)).toBeGreaterThanOrEqual(4.5);
      for (const [face, lip] of [[c.sage, c.sageLip], [c.gold, c.goldLip], [c.caution, c.cautionLip]]) expect(contrast(face, lip)).toBeGreaterThan(1.3);
      expect(contrast(c.paper, c.lip)).toBeGreaterThan(1.1);
    });
  }
});

describe('v3 · halls, buildings and wings', () => {
  it('follows the lesson by default, and rests in the Herb Garden when the lesson has no element', () => {
    expect(DEFAULT_HALL).toBe('earth');
    expect(resolveHall(undefined, undefined)).toBe('earth');
    expect(resolveHall('lesson', undefined)).toBe('earth');
    expect(resolveHall('lesson', 'water')).toBe('water');
    expect(resolveHall(undefined, 'air')).toBe('air');
  });

  it('keeps a hall the person chose, whatever the lesson', () => {
    expect(resolveHall('fire', 'water')).toBe('fire');
    expect(resolveHall('air', undefined)).toBe('air');
  });

  it('pairs every lore name with a plain label', () => {
    for (const h of HALL_IDS) expect([HALLS[h].element, HALLS[h].name].every((s) => s.length > 2)).toBe(true);
    for (const b of Object.values(BUILDINGS)) expect([b.tier, b.name].every((s) => s.length > 2)).toBe(true);
    for (const w of Object.values(WINGS)) expect(w.displayFamily).toMatch(/serif$/);
  });

  it('recognizes only real hall choices', () => {
    for (const c of HALL_CHOICES) expect(isHallChoice(c)).toBe(true);
    for (const bad of ['', 'aether', 'Fire', 3, null]) expect(isHallChoice(bad)).toBe(false);
  });
});

describe('v3 · the hall choice is saved with the journey', () => {
  it('survives a backup round-trip and merges like other preferences', () => {
    let j = onboarded();
    expect(j.prefs.hall).toBeUndefined();
    j = ops.setPrefs(j, { hall: 'water' }, new Date(T0.getTime() + 60000));
    const r = checkBackup(JSON.parse(JSON.stringify(makeBackup(j, new Date(T0.getTime() + 120000)))));
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.journey.prefs.hall).toBe('water');
    const later = ops.setPrefs(j, { hall: 'fire' }, new Date(T0.getTime() + 180000));
    expect(mergeJourneys(j, later).prefs.hall).toBe('fire');
  });

  it('drops an unknown hall from a backup instead of failing the restore', () => {
    const j = onboarded();
    const file = JSON.parse(JSON.stringify(makeBackup(j, new Date(T0.getTime() + 60000))));
    file.journey.prefs.hall = 'aether';
    const r = checkBackup(file);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.journey.prefs.hall).toBeUndefined();
  });

  it('restores v2 backups (no hall) untouched', () => {
    const file = JSON.parse(JSON.stringify(makeBackup(onboarded(), new Date(T0.getTime() + 60000))));
    delete file.journey.prefs.hall;
    const r = checkBackup(file);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.journey.prefs.hall).toBeUndefined();
  });
});

describe('v3 · the academy grounds (path map)', () => {
  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: lesson names, progress, "You are here" and quests stay readable on every hall's grounds`, () => {
      const c = palettes[mode];
      for (const h of HALL_IDS) {
        const wash = groundsWash(h, mode, c.paper);
        for (const fg of [c.ink, c.inkSoft, c.sage, c.gold]) expect([h, mode, fg, contrast(fg, wash) >= 4.5]).toEqual([h, mode, fg, true]);
        // The road is decoration, but it should read as a path against the grounds.
        expect(contrast(groundsRoad(h, mode, c.paper), wash)).toBeGreaterThan(1.05);
      }
    });
  }
});

describe('v3 · new names: Equilibrium (the app) and Compass (the reading)', () => {
  // Code names, storage keys and file formats keep "companion" on purpose; this checks only what a
  // person can see: the app's own words, its page title and its install name.
  const fs = require('node:fs') as typeof import('node:fs');
  const path = require('node:path') as typeof import('node:path');
  const walk = (d: string): string[] => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : /\.tsx?$/.test(e.name) ? [path.join(d, e.name)] : []));

  it('never says "Companion" to a person, except where it explains the rename', () => {
    const hits: string[] = [];
    for (const f of walk('src')) {
      fs.readFileSync(f, 'utf8').split('\n').forEach((line, i) => {
        const t = line.trim();
        if (t.startsWith('//') || t.startsWith('*') || t.startsWith('/*')) return;
        if (/\bCompanion\b/.test(line) && !/Companion is now Equilibrium/.test(line)) hits.push(`${f}:${i + 1}`);
      });
    }
    expect(hits).toEqual([]);
  });

  it('installs and titles itself as Equilibrium', () => {
    const manifest = JSON.parse(fs.readFileSync('public/manifest.webmanifest', 'utf8'));
    expect(manifest.name).toBe('Equilibrium v3 · Graphics & Interface');
    expect(manifest.short_name).toBe('Equilibrium');
    const app = JSON.parse(fs.readFileSync('app.json', 'utf8')).expo;
    expect(app.name).toBe('Equilibrium');
    expect(app.web.name).toMatch(/^Equilibrium/);
    // Store ids stay until a store build is planned (changing them makes a different app).
    expect(app.ios.bundleIdentifier).toBe('org.evokemagic.companion.alpha');
  });
});

describe('v3 · today\'s look: window into glass, indigo controls (Oct 14 art treatment)', () => {
  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: indigo buttons, links, chips and tabs pass contrast`, () => {
      const c = palettes[mode];
      expect(c.action).toBe('#4B3A8F');
      expect(contrast(c.onAction, c.action)).toBeGreaterThanOrEqual(4.5);
      expect(contrast(c.onAction, c.actionPressed)).toBeGreaterThanOrEqual(4.5);
      for (const bg of [c.paper, c.canvas, c.actionWash]) expect([bg, contrast(c.actionText, bg) >= 4.5]).toEqual([bg, true]);
      expect(contrast(c.action, c.actionLip)).toBeGreaterThan(1.3);
    });

    it(`${mode}: the title halo keeps the eyebrow, heading and subtitle readable over every part of every hall's art`, () => {
      const c = palettes[mode];
      for (const h of HALL_IDS) {
        const art = glassArtStops(h, mode);
        // The title block never starts above GLASS.titleTop (the chip row and spacer sit above it).
        for (let t = (GLASS.titleTop - 10) / GLASS.art; t <= 1; t += 0.01) {
          const behind = mix(colorAt(art, t), c.canvas, HALO_CORE);
          // The eyebrow on a glass screen uses the deeper gold (goldPressed).
          for (const fg of [c.ink, c.inkSoft, c.goldPressed]) expect([h, mode, t, fg, contrast(fg, behind) >= 4.5]).toEqual([h, mode, t, fg, true]);
        }
      }
    });

    it(`${mode}: dark-glass chips (hall name, back) keep white text readable where they sit on the art`, () => {
      for (const h of HALL_IDS) {
        const art = glassArtStops(h, mode);
        for (let y = 0; y <= GLASS.chipZone; y += 2) expect(contrast('#FFFFFF', mix(colorAt(art, y / GLASS.art), '#000000', CHIP_SHADE))).toBeGreaterThanOrEqual(4.5);
      }
    });

    it(`${mode}: everything on the frosted page stays readable in every hall`, () => {
      const c = palettes[mode];
      for (const h of HALL_IDS) {
        const wash = glassWash(h, mode, c.canvas);
        for (const fg of [c.ink, c.inkSoft, c.gold, c.sage, c.actionText]) expect([h, mode, fg, contrast(fg, wash) >= 4.5]).toEqual([h, mode, fg, true]);
      }
    });
  }

  it('melts from clear art to frost: clear above GLASS.clear, 60% by GLASS.soft, fully frosted at the bottom', () => {
    const f = frostStops();
    expect(f[1].offset).toBeCloseTo(GLASS.clear / GLASS.art, 3);
    expect(f[1].opacity).toBe(0);
    expect(f[2].opacity).toBe(0.6);
    expect(f[f.length - 1]).toEqual({ offset: 1, opacity: 1 });
    for (let i = 1; i < f.length; i++) expect(f[i].opacity).toBeGreaterThanOrEqual(f[i - 1].opacity);
  });

  it('keeps the whole title block inside the halo\'s solid core', () => {
    expect(Math.SQRT2 / HALO_SCALE).toBeLessThan(HALO_PLATEAU);
  });

  it('uses one heading font everywhere: Cinzel', () => {
    for (const w of Object.values(WINGS)) expect(w.displayFamily.startsWith('Cinzel')).toBe(true);
  });
});
