// After `expo export --platform web`: stamp the service worker with this build's id and the files
// it should precache (the shell, the hashed bundle, the manifest and icons).
import fs from 'node:fs';
import path from 'node:path';

const dist = path.resolve(process.argv[2] ?? 'dist');
const html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script[^>]+src="([^"]+)"/g)].map((m) => m[1]);
const base = (process.env.COMPANION_BASE_URL ?? '').replace(/\/$/, '');
// Service-worker paths are relative to its own location (the site root or base path).
const rel = (p) => (p.startsWith(base + '/') ? '.' + p.slice(base.length) : p.startsWith('/') ? '.' + p : p);
const precache = ['./', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png', './fonts/cinzel-700.woff2', './fonts/nunito-400.woff2', './fonts/nunito-600.woff2', './fonts/nunito-700.woff2', ...scripts.map(rel)];
const build = Date.now().toString(36);
const swPath = path.join(dist, 'sw.js');
const sw = fs.readFileSync(swPath, 'utf8').replace('__BUILD__', build).replace('__PRECACHE__', JSON.stringify(precache));
fs.writeFileSync(swPath, sw);
console.log(`sw.js stamped: build ${build}, precache ${precache.length} files`);
