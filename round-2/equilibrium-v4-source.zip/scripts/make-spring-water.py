"""Makes public/audio/spring-water.mp3: an original, seamless 24-second spring-water loop.

Built from nothing but numbers (no recordings): soft filtered noise for the running water, plus
hundreds of tiny "bubbles" — short sine chirps whose pitch rises as they fade, which is how a real
bubble sounds. The end is cross-faded into the start, so the loop has no seam.
Run: python3 scripts/make-spring-water.py   (needs numpy and ffmpeg)
"""
import subprocess, wave, os
import numpy as np

SR = 44100
LOOP = 24.0
XF = 2.0
rng = np.random.default_rng(7)
n = int((LOOP + XF) * SR)
t = np.arange(n) / SR

def bandpass(x, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    g = np.clip((f - lo * 0.7) / (lo * 0.3), 0, 1) * np.clip((hi * 1.4 - f) / (hi * 0.4), 0, 1)
    return np.fft.irfft(X * g / np.sqrt(np.maximum(f, 20) / 200), len(x))

# Running water: two layers of band-limited noise that swell slowly.
bed = bandpass(rng.standard_normal(n), 250, 2600)
bed /= np.abs(bed).max()
hiss = bandpass(rng.standard_normal(n), 2500, 7000)
hiss /= np.abs(hiss).max()
swell = 0.75 + 0.25 * np.sin(2 * np.pi * t / 6.0) * np.sin(2 * np.pi * t / 9.7 + 1)
out = 0.32 * bed * swell + 0.05 * hiss

# Bubbles.
count = int(42 * (LOOP + XF))
for _ in range(count):
    start = rng.uniform(0, LOOP + XF - 0.2)
    f0 = rng.uniform(450, 2200)
    dur = rng.uniform(0.02, 0.09)
    rise = rng.uniform(4, 14)
    amp = rng.uniform(0.04, 0.16) * (1.0 if f0 > 700 else 0.7)
    m = int(dur * SR)
    tt = np.arange(m) / SR
    phase = 2 * np.pi * f0 * (tt + rise * tt * tt / 2)
    env = np.exp(-tt / (dur / 4)) * np.minimum(1, tt / 0.002)
    i = int(start * SR)
    out[i:i + m] += amp * np.sin(phase) * env

# Seamless loop: fade the extra tail into the head.
L, X = int(LOOP * SR), int(XF * SR)
w = np.linspace(0, 1, X)
loop = out[:L].copy()
loop[:X] = out[:X] * np.sqrt(w) + out[L:L + X] * np.sqrt(1 - w)
loop = loop / np.abs(loop).max() * 0.6
# A touch of stereo width: right channel is slightly delayed.
right = np.roll(loop, int(0.011 * SR))
pcm = (np.stack([loop, right], 1) * 32767).astype(np.int16)

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tmp = os.path.join(root, 'public/audio/_spring.wav')
with wave.open(tmp, 'wb') as f:
    f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes(pcm.tobytes())
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-codec:a', 'libmp3lame', '-b:a', '96k',
                os.path.join(root, 'public/audio/spring-water.mp3')], check=True)
os.remove(tmp)
print('wrote public/audio/spring-water.mp3')
