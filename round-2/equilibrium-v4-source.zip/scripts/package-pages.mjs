// Package a web build for GitHub Pages, or any static host, so it works at ANY address: the site
// root, /companion/, or a folder inside a repository. All paths become relative, and because GitHub
// Pages (Jekyll) ignores folders starting with "_", `_expo/` becomes `app/`; a .nojekyll marker is
// added as a second guard.
// Usage: npm run build:web && node scripts/package-pages.mjs dist dist-pages
import fs from 'node:fs';
import path from 'node:path';

const [src = 'dist', out = 'dist-pages'] = process.argv.slice(2);
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(src, out, { recursive: true });
fs.rmSync(path.join(out, 'metadata.json'), { force: true });
if (fs.existsSync(path.join(out, '_expo'))) fs.renameSync(path.join(out, '_expo'), path.join(out, 'app'));

const rewrite = (file, pairs) => {
  const p = path.join(out, file);
  let s = fs.readFileSync(p, 'utf8');
  for (const [a, b] of pairs) s = s.replaceAll(a, b);
  fs.writeFileSync(p, s);
  return s;
};
const html = rewrite('index.html', [
  ['src="/_expo/', 'src="./app/'],
  ['href="/favicon.ico"', 'href="./favicon.ico"'],
]);
const sw = rewrite('sw.js', [['"./_expo/', '"./app/']]);

// Nothing may point at the host root, or the app breaks when it isn't served from there.
const absolute = [...html.matchAll(/(?:src|href)="\/(?!\/)[^"]*"/g)].map((m) => m[0]);
if (absolute.length) throw new Error(`index.html still has root-absolute paths: ${absolute.join(', ')}`);
if (sw.includes('_expo')) throw new Error('sw.js still refers to _expo/');
for (const f of fs.readdirSync(path.join(out, 'app/static/js/web'))) {
  const js = fs.readFileSync(path.join(out, 'app/static/js/web', f), 'utf8');
  if (/["'`]\/(_expo|assets)\//.test(js)) throw new Error(`${f} refers to a root-absolute asset path`);
}
fs.writeFileSync(path.join(out, '.nojekyll'), '');
console.log(`packaged ${out}: relative paths, _expo → app, .nojekyll`);
