// Renders Companion's app icons from one SVG mark (sprout in a gold ring on field-journal cream).
// Usage: node scripts/make-icons.mjs   → writes public/icons/*.png and assets/*.png
import { chromium } from 'playwright';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CREAM = '#F7F0E5', SAGE = '#29452F', SAGE2 = '#49654D', GOLD = '#C5A24A';

// The 24-unit mark from src/ui/Wordmark.tsx, drawn larger with lighter relative strokes.
const mark = (color = { ring: GOLD, stem: SAGE, leaf: SAGE, leaf2: SAGE2 }) => `
  <circle cx="12" cy="12" r="10.2" fill="none" stroke="${color.ring}" stroke-width="0.85"/>
  <path d="M12 18.5v-6.2" stroke="${color.stem}" stroke-width="1.7" stroke-linecap="round"/>
  <path d="M12 12.6c0-3.1 2.1-5 5.2-5 0 3.1-2.1 5-5.2 5z" fill="${color.leaf}"/>
  <path d="M12 14.4c0-2.3-1.6-3.8-4-3.8 0 2.3 1.6 3.8 4 3.8z" fill="${color.leaf2}"/>`;

// scale: how much of the canvas the 24-unit mark spans.
const svg = ({ size, bg, rounded, span, colors }) => {
  const s = (size * span) / 24;
  const off = (size - 24 * s) / 2;
  const back = bg ? `<rect width="${size}" height="${size}" rx="${rounded ? size * 0.22 : 0}" fill="${bg}"/>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${back}<g transform="translate(${off} ${off}) scale(${s})">${mark(colors)}</g></svg>`;
};

const jobs = [
  // Web / PWA
  { out: 'public/icons/icon-192.png', size: 192, bg: CREAM, rounded: true, span: 0.78 },
  { out: 'public/icons/icon-512.png', size: 512, bg: CREAM, rounded: true, span: 0.78 },
  { out: 'public/icons/maskable-512.png', size: 512, bg: CREAM, rounded: false, span: 0.62 }, // inside the 80% safe zone
  { out: 'public/icons/apple-touch-icon.png', size: 180, bg: CREAM, rounded: false, span: 0.74 },
  { out: 'assets/favicon.png', size: 48, bg: CREAM, rounded: true, span: 0.9 },
  // Native (Expo)
  { out: 'assets/icon.png', size: 1024, bg: CREAM, rounded: false, span: 0.72 },
  { out: 'assets/splash-icon.png', size: 1024, bg: null, span: 0.9 },
  { out: 'assets/android-icon-foreground.png', size: 1024, bg: null, span: 0.5 },
  { out: 'assets/android-icon-background.png', size: 1024, bg: CREAM, rounded: false, span: 0, empty: true },
  { out: 'assets/android-icon-monochrome.png', size: 1024, bg: null, span: 0.5, colors: { ring: '#fff', stem: '#fff', leaf: '#fff', leaf2: '#fff' } },
];

const browser = await chromium.launch();
const page = await browser.newPage({ deviceScaleFactor: 1 });
for (const j of jobs) {
  const inner = j.empty ? `<svg xmlns="http://www.w3.org/2000/svg" width="${j.size}" height="${j.size}"><rect width="${j.size}" height="${j.size}" fill="${j.bg}"/></svg>` : svg(j);
  await page.setViewportSize({ width: j.size, height: j.size });
  await page.setContent(`<html><body style="margin:0;background:transparent">${inner}</body></html>`);
  await page.locator('svg').screenshot({ path: path.join(root, j.out), omitBackground: true });
  console.log('wrote', j.out);
}
await browser.close();
