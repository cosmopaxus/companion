// Revision-checked sync with event merging by id.
//
// 1. Fetch the account's document.
// 2. Nothing remote yet → create it from local.
// 3. Neither side changed since the last sync → done.
// 4. Otherwise merge (by id; tombstones kept; gems deduplicated) and write back,
//    conditional on the remote revision we merged against. A concurrent write from
//    another device makes the write fail with a conflict → refetch, re-merge, retry.
// Offline or errors leave local data untouched; the caller retries later.

import type { Journey } from '../domain/types';
import { mergeJourneys } from '../domain/merge';
import type { RemoteStore } from './remote';

export interface SyncMeta {
  /** Remote revision last seen after a successful sync. */
  remoteRevision: number | null;
  /** Local journey revision that was last written to / merged from the remote. */
  localRevision: number;
  lastSyncedAt?: string;
}

export const emptyMeta = (): SyncMeta => ({ remoteRevision: null, localRevision: -1 });

export type SyncOutcome =
  | { status: 'synced'; journey: Journey; meta: SyncMeta; changedLocal: boolean }
  | { status: 'offline'; message: string }
  | { status: 'error'; message: string };

export async function syncOnce(local: Journey, meta: SyncMeta, remote: RemoteStore, now: () => Date = () => new Date()): Promise<SyncOutcome> {
  let current = local;
  for (let attempt = 0; attempt < 4; attempt++) {
    const f = await remote.fetch();
    if (!f.ok) return f.offline ? { status: 'offline', message: f.error } : { status: 'error', message: f.error };
    const doc = f.doc;

    if (!doc) {
      const w = await remote.write(current, null);
      if (w.ok) return { status: 'synced', journey: current, meta: { remoteRevision: w.revision, localRevision: current.revision, lastSyncedAt: now().toISOString() }, changedLocal: current !== local };
      if ('conflict' in w && w.conflict) continue;
      return (w as any).offline ? { status: 'offline', message: (w as any).error } : { status: 'error', message: (w as any).error };
    }

    const remoteChanged = doc.revision !== meta.remoteRevision;
    const localChanged = current.revision !== meta.localRevision;
    if (!remoteChanged && !localChanged) {
      return { status: 'synced', journey: current, meta: { ...meta, lastSyncedAt: now().toISOString() }, changedLocal: current !== local };
    }

    const merged = remoteChanged ? mergeJourneys(current, doc.journey) : current;
    const w = await remote.write(merged, doc.revision);
    if (w.ok) {
      return { status: 'synced', journey: merged, meta: { remoteRevision: w.revision, localRevision: merged.revision, lastSyncedAt: now().toISOString() }, changedLocal: merged !== local };
    }
    if ('conflict' in w && w.conflict) {
      current = merged; // keep what we merged so far, then try again against the newer remote
      meta = { ...meta, remoteRevision: doc.revision };
      continue;
    }
    return (w as any).offline ? { status: 'offline', message: (w as any).error } : { status: 'error', message: (w as any).error };
  }
  return { status: 'error', message: 'Another device kept changing this journey. Equilibrium will try again shortly.' };
}
