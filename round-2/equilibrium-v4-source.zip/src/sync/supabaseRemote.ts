// Supabase adapter over plain fetch (no SDK): email one-time-code auth (GoTrue) and a single
// row per user in `public.journeys`, protected by row-level security (see supabase/schema.sql).
// Writes go through the `save_journey` RPC, which checks the expected revision atomically.
//
// STATUS: written against Supabase's documented REST endpoints but NOT yet run against a live
// project — no credentials were available for this build. Treat as untested until verified.

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Journey } from '../domain/types';
import { checkBackup } from '../domain/backup';
import type { RemoteDoc, RemoteStore, RemoteUser, Result, WriteResult } from './remote';
import { NS } from '../state/storage';

interface Session {
  access_token: string;
  refresh_token: string;
  expires_at: number; // seconds
  user: RemoteUser;
}

const SESSION_KEY = `${NS}.auth`;

export class SupabaseRemote implements RemoteStore {
  kind = 'supabase' as const;
  private session: Session | null = null;
  constructor(private url: string, private anonKey: string) {}

  private headers(auth = true): Record<string, string> {
    const h: Record<string, string> = { apikey: this.anonKey, 'Content-Type': 'application/json' };
    if (auth && this.session) h.Authorization = `Bearer ${this.session.access_token}`;
    return h;
  }

  private async call(path: string, init: RequestInit): Promise<{ ok: true; status: number; body: any } | { ok: false; error: string; offline?: boolean; status?: number }> {
    try {
      const res = await fetch(`${this.url}${path}`, init);
      const text = await res.text();
      let body: any = null;
      try {
        body = text ? JSON.parse(text) : null;
      } catch {
        body = text;
      }
      if (!res.ok) return { ok: false, status: res.status, error: body?.msg ?? body?.message ?? body?.error_description ?? `Request failed (${res.status}).` };
      return { ok: true, status: res.status, body };
    } catch {
      return { ok: false, error: "Can't reach the account service. You may be offline.", offline: true };
    }
  }

  private async saveSession(s: Session | null) {
    this.session = s;
    try {
      if (s) await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(s));
      else await AsyncStorage.removeItem(SESSION_KEY);
    } catch {}
  }

  private fromAuth(body: any): Session | null {
    if (!body?.access_token || !body?.user?.id) return null;
    return {
      access_token: body.access_token,
      refresh_token: body.refresh_token,
      expires_at: body.expires_at ?? Math.floor(Date.now() / 1000) + (body.expires_in ?? 3600),
      user: { userId: body.user.id, email: body.user.email ?? '' },
    };
  }

  private async ensureFresh(): Promise<boolean> {
    if (!this.session) return false;
    if (this.session.expires_at - 60 > Date.now() / 1000) return true;
    const r = await this.call('/auth/v1/token?grant_type=refresh_token', { method: 'POST', headers: this.headers(false), body: JSON.stringify({ refresh_token: this.session.refresh_token }) });
    if (!r.ok) {
      if (!r.offline) await this.saveSession(null);
      return false;
    }
    const s = this.fromAuth(r.body);
    await this.saveSession(s);
    return !!s;
  }

  async sendCode(email: string): Promise<Result> {
    const r = await this.call('/auth/v1/otp', { method: 'POST', headers: this.headers(false), body: JSON.stringify({ email: email.trim(), create_user: true }) });
    return r.ok ? { ok: true } : { ok: false, error: r.error, offline: r.offline };
  }

  async verifyCode(email: string, code: string): Promise<Result<{ user: RemoteUser }>> {
    const r = await this.call('/auth/v1/verify', { method: 'POST', headers: this.headers(false), body: JSON.stringify({ type: 'email', email: email.trim(), token: code.trim() }) });
    if (!r.ok) return { ok: false, error: r.status === 403 || r.status === 400 ? "That code didn't work. Check it, or send a new one." : r.error, offline: r.offline };
    const s = this.fromAuth(r.body);
    if (!s) return { ok: false, error: 'Sign-in response was incomplete.' };
    await this.saveSession(s);
    return { ok: true, user: s.user };
  }

  async restoreSession(): Promise<RemoteUser | null> {
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      this.session = raw ? (JSON.parse(raw) as Session) : null;
    } catch {
      this.session = null;
    }
    return this.session?.user ?? null;
  }

  async signOut(): Promise<void> {
    if (this.session) await this.call('/auth/v1/logout', { method: 'POST', headers: this.headers() });
    await this.saveSession(null);
  }

  async fetch(): Promise<Result<{ doc: RemoteDoc | null }>> {
    if (!(await this.ensureFresh())) return { ok: false, error: 'Please sign in again.' };
    const uid = encodeURIComponent(this.session!.user.userId);
    const r = await this.call(`/rest/v1/journeys?user_id=eq.${uid}&select=doc,revision,updated_at`, { method: 'GET', headers: this.headers() });
    if (!r.ok) return { ok: false, error: r.error, offline: r.offline };
    const row = Array.isArray(r.body) ? r.body[0] : null;
    if (!row) return { ok: true, doc: null };
    // Read the synced copy through the same checks as a device load, so older records (e.g. 1–5 check-ins) are converted.
    const check = checkBackup(row.doc, { lenient: true });
    if (!check.ok) return { ok: false, error: "The synced journey couldn't be read. Nothing on this device was changed." };
    return { ok: true, doc: { journey: check.journey, revision: row.revision as number, updatedAt: row.updated_at as string } };
  }

  async write(journey: Journey, expectedRevision: number | null): Promise<WriteResult> {
    if (!(await this.ensureFresh())) return { ok: false, error: 'Please sign in again.' };
    const r = await this.call('/rest/v1/rpc/save_journey', { method: 'POST', headers: this.headers(), body: JSON.stringify({ expected_revision: expectedRevision, new_doc: journey }) });
    if (!r.ok) {
      if (r.status === 409 || /revision_conflict/.test(r.error)) return { ok: false, conflict: true };
      return { ok: false, error: r.error, offline: r.offline };
    }
    return { ok: true, revision: Number(r.body) };
  }
}
