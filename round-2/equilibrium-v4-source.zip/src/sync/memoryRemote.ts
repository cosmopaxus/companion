// In-memory backend used by tests. Models the parts of the real backend that matter for
// data integrity: per-user isolation (like row-level security), revision-checked writes,
// and an offline switch. It is not a production backend.

import type { Journey } from '../domain/types';
import type { RemoteDoc, RemoteStore, RemoteUser } from './remote';

export class MemoryServer {
  docs = new Map<string, RemoteDoc>();
  users = new Map<string, RemoteUser>();
  writes = 0;
  code = '123456';
  userFor(email: string): RemoteUser {
    const e = email.trim().toLowerCase();
    let u = this.users.get(e);
    if (!u) {
      u = { userId: `u_${this.users.size + 1}`, email: e };
      this.users.set(e, u);
    }
    return u;
  }
}

export class MemoryRemote implements RemoteStore {
  kind = 'memory' as const;
  offline = false;
  private user: RemoteUser | null = null;
  /** Hook to simulate another device writing between our fetch and our write. */
  beforeWrite?: () => Promise<void> | void;

  constructor(private server: MemoryServer) {}

  async sendCode(email: string) {
    if (this.offline) return { ok: false as const, error: 'offline', offline: true };
    if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false as const, error: 'Enter a valid email address.' };
    return { ok: true as const };
  }

  async verifyCode(email: string, code: string) {
    if (this.offline) return { ok: false as const, error: 'offline', offline: true };
    if (code.trim() !== this.server.code) return { ok: false as const, error: "That code didn't match." };
    this.user = this.server.userFor(email);
    return { ok: true as const, user: this.user };
  }

  async restoreSession() {
    return this.user;
  }

  async signOut() {
    this.user = null;
  }

  async fetch() {
    if (this.offline) return { ok: false as const, error: "You're offline.", offline: true };
    if (!this.user) return { ok: false as const, error: 'Not signed in.' };
    const d = this.server.docs.get(this.user.userId);
    return { ok: true as const, doc: d ? (JSON.parse(JSON.stringify(d)) as RemoteDoc) : null };
  }

  async write(journey: Journey, expectedRevision: number | null) {
    if (this.offline) return { ok: false as const, error: "You're offline.", offline: true };
    if (!this.user) return { ok: false as const, error: 'Not signed in.' };
    if (this.beforeWrite) {
      const hook = this.beforeWrite;
      this.beforeWrite = undefined;
      await hook();
    }
    const cur = this.server.docs.get(this.user.userId);
    const curRev = cur ? cur.revision : null;
    if (curRev !== expectedRevision) return { ok: false as const, conflict: true as const };
    const revision = (curRev ?? 0) + 1;
    this.server.docs.set(this.user.userId, { journey: JSON.parse(JSON.stringify(journey)), revision, updatedAt: new Date().toISOString() });
    this.server.writes++;
    return { ok: true as const, revision };
  }
}
