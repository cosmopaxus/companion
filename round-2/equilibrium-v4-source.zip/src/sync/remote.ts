import type { Journey } from '../domain/types';

export interface RemoteUser {
  userId: string;
  email: string;
}

export interface RemoteDoc {
  journey: Journey;
  revision: number;
  updatedAt: string;
}

// eslint-disable-next-line @typescript-eslint/no-empty-object-type -- "no extra fields" default
export type Result<T = {}> = ({ ok: true } & T) | { ok: false; error: string; offline?: boolean };

export type WriteResult = { ok: true; revision: number } | { ok: false; conflict: true } | { ok: false; conflict?: false; error: string; offline?: boolean };

/**
 * The backend contract Equilibrium needs. Implemented for Supabase (supabaseRemote.ts) and
 * by an in-memory fake used in tests. Every data call is scoped to the signed-in user; the
 * backend must enforce that (Supabase: row-level security on user_id = auth.uid()).
 */
export interface RemoteStore {
  kind: 'supabase' | 'memory';
  sendCode(email: string): Promise<Result>;
  verifyCode(email: string, code: string): Promise<Result<{ user: RemoteUser }>>;
  restoreSession(): Promise<RemoteUser | null>;
  signOut(): Promise<void>;
  /** Fetch the signed-in user's journey document, or null if they have none yet. */
  fetch(): Promise<Result<{ doc: RemoteDoc | null }>>;
  /** Conditional write: succeeds only if the stored revision equals `expectedRevision` (null = must not exist yet). */
  write(journey: Journey, expectedRevision: number | null): Promise<WriteResult>;
}
