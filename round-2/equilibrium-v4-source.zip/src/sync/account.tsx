import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import type { Journey } from '../domain/types';
import { mergeJourneys } from '../domain/merge';
import { useStore } from '../state/store';
import { AccountKey, keys, readJSON, remove, writeJSON } from '../state/storage';
import { formatTime } from '../domain/time';
import type { RemoteStore, RemoteUser } from './remote';
import { emptyMeta, SyncMeta, syncOnce } from './engine';
import { SupabaseRemote } from './supabaseRemote';
import { MemoryRemote, MemoryServer } from './memoryRemote';

// ——— Backend selection (build-time) ———
// EXPO_PUBLIC_SUPABASE_URL + EXPO_PUBLIC_SUPABASE_ANON_KEY → Supabase (anon key is public by design; RLS protects rows).
// EXPO_PUBLIC_COMPANION_DEMO_BACKEND=1 → in-memory demo backend for automated UI tests only. Never ship this.
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
const DEMO = process.env.EXPO_PUBLIC_COMPANION_DEMO_BACKEND === '1';

function createRemote(): RemoteStore | null {
  if (SUPABASE_URL && SUPABASE_KEY) return new SupabaseRemote(SUPABASE_URL.replace(/\/$/, ''), SUPABASE_KEY);
  if (DEMO) return new MemoryRemote(new MemoryServer());
  return null;
}

export type SyncStatus = { kind: 'idle' } | { kind: 'syncing' } | { kind: 'synced'; at: string } | { kind: 'offline'; message: string } | { kind: 'error'; message: string };

interface AccountValue {
  configured: boolean;
  backend: 'none' | 'supabase' | 'demo';
  signedIn: boolean;
  user: RemoteUser | null;
  sync: SyncStatus;
  online: boolean;
  summary: string;
  /** Set after a successful code check when this device has a guest journey: the person must choose. */
  pendingImport: RemoteUser | null;
  sendCode: (email: string) => Promise<{ ok: boolean; error?: string }>;
  verifyCode: (email: string, code: string) => Promise<{ ok: boolean; error?: string; needsChoice?: boolean }>;
  completeSignIn: (importGuest: boolean) => Promise<void>;
  cancelPending: () => void;
  signOut: () => Promise<void>;
  syncNow: () => Promise<void>;
}

const Ctx = createContext<AccountValue | null>(null);

function hasContent(j: Journey): boolean {
  return !!j.profile || j.checkins.length > 0 || j.journal.length > 0 || j.areas.length > 0 || j.harmony.length > 0;
}

export function AccountProvider({ children }: { children: React.ReactNode }) {
  const store = useStore();
  const [remote] = useState<RemoteStore | null>(createRemote);
  const [user, setUser] = useState<RemoteUser | null>(null);
  const [pendingImport, setPendingImport] = useState<RemoteUser | null>(null);
  const [sync, setSync] = useState<SyncStatus>({ kind: 'idle' });
  const [online, setOnline] = useState(() => (Platform.OS === 'web' && typeof navigator !== 'undefined' ? navigator.onLine !== false : true));
  const meta = useRef<SyncMeta>(emptyMeta());
  const syncing = useRef(false);
  const again = useRef(false);
  const retryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const backoff = useRef(0);
  const storeRef = useRef(store);
  useEffect(() => {
    storeRef.current = store;
  });

  const acctKey = (u: RemoteUser): AccountKey => `user:${u.userId}`;

  const loadMeta = async (k: AccountKey) => {
    const r = await readJSON<SyncMeta>(keys.sync(k));
    meta.current = r.ok && r.value ? r.value : emptyMeta();
  };

  const syncNowRef = useRef<(() => Promise<void>) | null>(null);
  const syncNow = useCallback(async () => {
    if (!remote || !user) return;
    if (syncing.current) {
      again.current = true;
      return;
    }
    syncing.current = true;
    setSync({ kind: 'syncing' });
    const k = acctKey(user);
    const started = storeRef.current.current();
    const res = await syncOnce(started, meta.current, remote);
    if (res.status === 'synced') {
      const latest = storeRef.current.current();
      // Local edits made while the network call was in flight are merged, never dropped.
      const final = latest.revision === started.revision ? res.journey : mergeJourneys(latest, res.journey);
      if (final !== latest) storeRef.current.setJourneyFromSync(final);
      meta.current = res.meta;
      await writeJSON(keys.sync(k), meta.current);
      setSync({ kind: 'synced', at: res.meta.lastSyncedAt! });
      backoff.current = 0;
      if (final !== res.journey) again.current = true;
    } else {
      setSync(res.status === 'offline' ? { kind: 'offline', message: 'Offline — changes are saved on this device and will sync when you reconnect.' } : { kind: 'error', message: res.message });
      const delay = [5000, 15000, 60000, 120000][Math.min(backoff.current, 3)];
      backoff.current += 1;
      if (retryTimer.current) clearTimeout(retryTimer.current);
      retryTimer.current = setTimeout(() => void syncNowRef.current?.(), delay);
    }
    syncing.current = false;
    if (again.current) {
      again.current = false;
      void syncNowRef.current?.();
    }
  }, [remote, user]);
  useEffect(() => {
    syncNowRef.current = syncNow;
  }, [syncNow]);

  // Restore a saved session on launch.
  useEffect(() => {
    if (!remote) return;
    (async () => {
      const u = await remote.restoreSession();
      if (u) {
        await loadMeta(acctKey(u));
        await storeRef.current.switchAccount(acctKey(u));
        setUser(u);
      }
    })();
  }, [remote]);

  // Sync after local changes (debounced), on foreground, and when the network returns.
  const rev = store.journey.revision;
  useEffect(() => {
    if (!user) return;
    const t = setTimeout(() => void syncNow(), 1500);
    return () => clearTimeout(t);
  }, [rev, user, syncNow]);

  useEffect(() => {
    if (!user) return;
    const sub = AppState.addEventListener('change', (s) => s === 'active' && void syncNow());
    return () => sub.remove();
  }, [user, syncNow]);

  useEffect(() => {
    if (Platform.OS !== 'web' || typeof window === 'undefined') return;
    const up = () => {
      setOnline(true);
      void syncNow();
    };
    const down = () => setOnline(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    return () => {
      window.removeEventListener('online', up);
      window.removeEventListener('offline', down);
    };
  }, [syncNow]);

  const sendCode = useCallback(
    async (email: string) => {
      if (!remote) return { ok: false, error: "Accounts aren't connected in this build." };
      const r = await remote.sendCode(email);
      return r.ok ? { ok: true } : { ok: false, error: r.offline ? "You're offline. Try again when you're connected." : r.error };
    },
    [remote],
  );

  const finish = useCallback(async (u: RemoteUser, importGuest: boolean) => {
    const s = storeRef.current;
    const guest = s.accountKey === 'guest' ? s.current() : null;
    await loadMeta(acctKey(u));
    // Importing passes the guest journey in so it is merged during the switch (no empty flash in between).
    await s.switchAccount(acctKey(u), importGuest && guest ? guest : undefined);
    if (importGuest && guest) {
      // The guest journey now lives in the account; remove the separate guest copy from this device.
      await remove(keys.journey('guest'));
      await remove(keys.drafts('guest'));
      await remove(keys.preRestore('guest'));
    }
    setUser(u);
    setPendingImport(null);
  }, []);

  const verifyCode = useCallback(
    async (email: string, code: string) => {
      if (!remote) return { ok: false, error: "Accounts aren't connected in this build." };
      const r = await remote.verifyCode(email, code);
      if (!r.ok) return { ok: false, error: r.offline ? "You're offline. Try again when you're connected." : r.error };
      const s = storeRef.current;
      if (s.accountKey === 'guest' && hasContent(s.current())) {
        setPendingImport(r.user);
        return { ok: true, needsChoice: true };
      }
      await finish(r.user, false);
      return { ok: true };
    },
    [remote, finish],
  );

  const completeSignIn = useCallback(
    async (importGuest: boolean) => {
      if (pendingImport) await finish(pendingImport, importGuest);
    },
    [pendingImport, finish],
  );

  const signOut = useCallback(async () => {
    if (!remote) return;
    await remote.signOut();
    if (retryTimer.current) clearTimeout(retryTimer.current);
    setUser(null);
    setSync({ kind: 'idle' });
    meta.current = emptyMeta();
    await storeRef.current.switchAccount('guest');
  }, [remote]);

  const backend = remote ? (remote.kind === 'supabase' ? 'supabase' : 'demo') : 'none';
  const summary = !remote
    ? 'Guest · saved on this device only · accounts not connected in this build'
    : !user
      ? 'Guest · saved on this device only'
      : sync.kind === 'synced'
        ? `${user.email} · synced ${formatTime(sync.at)}`
        : sync.kind === 'syncing'
          ? `${user.email} · syncing…`
          : sync.kind === 'offline'
            ? `${user.email} · offline, will sync later`
            : sync.kind === 'error'
              ? `${user.email} · sync needs attention`
              : `${user.email}`;

  const value = useMemo<AccountValue>(
    () => ({
      configured: !!remote,
      backend,
      signedIn: !!user,
      user,
      sync,
      online,
      summary,
      pendingImport,
      sendCode,
      verifyCode,
      completeSignIn,
      cancelPending: () => {
        setPendingImport(null);
        void remote?.signOut();
      },
      signOut,
      syncNow,
    }),
    [remote, backend, user, sync, online, summary, pendingImport, sendCode, verifyCode, completeSignIn, signOut, syncNow],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAccount(): AccountValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAccount outside AccountProvider');
  return v;
}
