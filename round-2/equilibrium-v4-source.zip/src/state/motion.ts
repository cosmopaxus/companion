import { useEffect, useState } from 'react';
import { AccessibilityInfo } from 'react-native';
import { useStore } from './store';

/** True when the OS asks for reduced motion, or the person turned it on in You → Preferences. */
export function useReducedMotion(): boolean {
  const { journey } = useStore();
  const [system, setSystem] = useState(false);
  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled()
      .then((v) => alive && setSystem(!!v))
      .catch(() => {});
    const sub = AccessibilityInfo.addEventListener?.('reduceMotionChanged', (v: boolean) => setSystem(!!v));
    return () => {
      alive = false;
      sub?.remove?.();
    };
  }, []);
  return system || journey.prefs.reduceMotion === 'reduce';
}
