// Painted academy (decided Oct 14): on phones, screens that open on art have no solid top bar. The
// painting runs to the top and the Space switch and gems float over it as dark-glass chips. Each
// screen says whether it opens on art; the shell asks only about the screen being shown.
import React, { createContext, useContext, useEffect } from 'react';

type Mark = (on: boolean) => void;
const Ctx = createContext<{ mark: Mark; overlay: boolean }>({ mark: () => {}, overlay: false });

export function ArtChromeScope({ mark, overlay, children }: { mark: Mark; overlay: boolean; children: React.ReactNode }) {
  return <Ctx.Provider value={{ mark, overlay }}>{children}</Ctx.Provider>;
}

/** Call from a screen that opens on art (true) or not (false, the default). */
export function useArtScreen(on: boolean) {
  const { mark } = useContext(Ctx);
  useEffect(() => {
    mark(on);
    return () => mark(false);
  }, [on, mark]);
}

/** True when the top bar floats over this screen's art (phones), so the screen leaves room for it. */
export function useArtOverlay(): boolean {
  return useContext(Ctx).overlay;
}

/** Room the floating Space and gem chips take at the top right (px). */
export const OVERLAY_RIGHT = 122;
