import { useStore } from './store';
import { useAccount } from '../sync/account';

/**
 * Honest wording for where things are kept, built from the real save and account state —
 * never a fixed "saved" that stays true when storage is blocked or sync is on.
 */
export function useSaveLabel() {
  const { persist } = useStore();
  const account = useAccount();
  const notSaving = persist.kind === 'memory';
  const failing = persist.kind === 'error';
  const where = notSaving
    ? 'not saved — this browser is blocking storage'
    : failing
      ? 'not saved yet — see Your data'
      : account.signedIn
        ? 'saved on this device and synced to your account'
        : 'saved on this device';
  /** Toast verb: "Journal entry saved" vs "Journal entry added (not saved)". */
  const done = (noun: string) => (notSaving || failing ? `${noun} added — not saved` : `${noun} saved`);
  return { where, done, notSaving: notSaving || failing };
}
