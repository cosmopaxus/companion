import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { BackHandler, Platform } from 'react-native';
import type { DirectionId, EvidenceKind, LessonId, TierId } from '../domain/types';
import { sheetsOpen } from './sheets';

// State-driven navigation. One static bundle runs anywhere — including hosted previews
// whose URL path we don't control — with no router config. (Deep links: a next step.)

export type TabId = 'today' | 'journey' | 'connect' | 'journal' | 'you';
export const TABS: TabId[] = ['today', 'journey', 'connect', 'journal', 'you'];

export type Route =
  | { name: 'harmony' }
  | { name: 'harmonyReading'; id: string }
  | { name: 'area'; id: string; compose?: EvidenceKind; focus?: boolean }
  | { name: 'checkins' }
  /** The check-in itself (painted academy, decided Oct 14: its own screen, opened from Home's card). */
  | { name: 'checkin' }
  /** Full-art screens (painted academy, piece 3): a rest in the Sanctuary, an invitation to a path. */
  | { name: 'rest' }
  | { name: 'invitation'; tier: TierId }
  | { name: 'gems' }
  | { name: 'directions' }
  | { name: 'data' }
  | { name: 'account' }
  | { name: 'intake' }
  | { name: 'protocol' }
  | { name: 'equilibrium' }
  | { name: 'support' }
  | { name: 'about' }
  | { name: 'profile' }
  | { name: 'lesson'; id: string }
  | { name: 'tier'; id: TierId }
  | { name: 'character' }
  | { name: 'inventory' }
  | { name: 'lookback' };

export type SheetState =
  | { name: 'space' }
  | { name: 'areaEditor'; areaId?: string; presetName?: string; presetDirection?: DirectionId }
  /** Add a goal (no id), or open one to edit, reach, let go or reopen. */
  | { name: 'goal'; goalId?: string }
  | null;

interface NavValue {
  tab: TabId;
  stack: Route[];
  sheet: SheetState;
  guide: { open: boolean; lesson?: LessonId };
  setTab: (t: TabId) => void;
  push: (r: Route) => void;
  pop: () => void;
  reset: (t?: TabId) => void;
  openSheet: (s: SheetState) => void;
  closeSheet: () => void;
  openGuide: (lesson?: LessonId) => void;
  closeGuide: () => void;
  /** Bumped when a tab is re-selected so screens can scroll to top. */
  tabTick: number;
  /** Screens can request focus on a target after navigation (e.g. the check-in). */
  focusTarget: string | null;
  requestFocus: (target: string | null) => void;
}

const Ctx = createContext<NavValue | null>(null);

export function NavProvider({ children }: { children: React.ReactNode }) {
  const [tab, setTabState] = useState<TabId>('today');
  const [stack, setStack] = useState<Route[]>([]);
  const [sheet, setSheet] = useState<SheetState>(null);
  const [guide, setGuide] = useState<{ open: boolean; lesson?: LessonId }>({ open: false });
  const [tabTick, setTabTick] = useState(0);
  const [focusTarget, setFocusTarget] = useState<string | null>(null);

  const setTab = useCallback((t: TabId) => {
    openers.current = [];
    setStack([]);
    setTabState((prev) => {
      if (prev === t) setTabTick((x) => x + 1);
      return t;
    });
  }, []);
  // Web focus management: remember what opened a screen, and give focus back to it on return.
  const openers = useRef<any[]>([]);
  const rememberOpener = () => {
    if (Platform.OS === 'web' && typeof document !== 'undefined') openers.current.push(document.activeElement);
  };
  const restoreOpener = () => {
    if (Platform.OS !== 'web' || typeof document === 'undefined') return;
    const el = openers.current.pop();
    setTimeout(() => {
      if (el && typeof el.focus === 'function' && document.contains(el)) el.focus();
    }, 60);
  };
  const push = useCallback((r: Route) => {
    rememberOpener();
    setStack((s) => [...s, r]);
  }, []);
  const pop = useCallback(() => {
    restoreOpener();
    setStack((s) => s.slice(0, -1));
  }, []);
  const reset = useCallback((t?: TabId) => {
    setStack([]);
    setSheet(null);
    if (t) setTabState(t);
  }, []);

  const state = useRef({ sheet, guide, stack });
  useEffect(() => {
    state.current = { sheet, guide, stack };
  }, [sheet, guide, stack]);

  const back = useCallback((): boolean => {
    const { sheet: sh, guide: g, stack: st } = state.current;
    if (sh) {
      setSheet(null);
      return true;
    }
    if (g.open) {
      setGuide({ open: false });
      return true;
    }
    if (st.length) {
      restoreOpener();
      setStack((s) => s.slice(0, -1));
      return true;
    }
    return false;
  }, []);

  useEffect(() => {
    if (Platform.OS === 'android') {
      const sub = BackHandler.addEventListener('hardwareBackPress', back);
      return () => sub.remove();
    }
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const onKey = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          // An open sheet handles its own Escape (see ui/layout Sheet).
          if (sheetsOpen()) return;
          if (back()) e.preventDefault();
        }
      };
      window.addEventListener('keydown', onKey);
      return () => window.removeEventListener('keydown', onKey);
    }
  }, [back]);

  const value = useMemo<NavValue>(
    () => ({
      tab,
      stack,
      sheet,
      guide,
      setTab,
      push,
      pop,
      reset,
      openSheet: setSheet,
      closeSheet: () => setSheet(null),
      openGuide: (lesson) => setGuide({ open: true, lesson }),
      closeGuide: () => setGuide({ open: false }),
      tabTick,
      focusTarget,
      requestFocus: setFocusTarget,
    }),
    [tab, stack, sheet, guide, setTab, push, pop, reset, tabTick, focusTarget],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useNav(): NavValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useNav outside NavProvider');
  return v;
}
