import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import type { Journey } from '../domain/types';
import { emptyJourney, OpError } from '../domain/ops';
import { checkBackup } from '../domain/backup';
import { mergeJourneys } from '../domain/merge';
import { AccountKey, keys, probeStorage, readJSON, remove, writeJSON, writeRaw } from './storage';
import { requestPersistentStorage } from '../platform/install';

export type PersistStatus =
  | { kind: 'loading' }
  | { kind: 'saved'; at?: string }
  | { kind: 'saving' }
  | { kind: 'error'; message: string }
  | { kind: 'memory'; message: string };

export type ApplyResult = { ok: true } | { ok: false; error: string };

export interface Drafts {
  [key: string]: string | undefined;
}

interface StoreValue {
  ready: boolean;
  journey: Journey;
  accountKey: AccountKey;
  persist: PersistStatus;
  recoveryNotice?: string;
  dismissRecovery: () => void;
  /** Run a pure journey operation. Validation errors come back as a message; nothing changes on failure. */
  apply: (fn: (j: Journey) => Journey) => ApplyResult;
  /** Replace the whole journey (restore). Keeps the previous one for a single undo. */
  replaceJourney: (next: Journey) => Promise<ApplyResult>;
  canUndoRestore: boolean;
  undoRestore: () => Promise<ApplyResult>;
  eraseDevice: () => Promise<void>;
  retrySave: () => void;
  drafts: Drafts;
  setDraft: (key: string, value: string | undefined) => void;
  /** Switch the local cache to another account (used by sync). */
  switchAccount: (key: AccountKey, initial?: Journey) => Promise<void>;
  /** Replace the journey from a trusted source (sync merge) without creating an undo point. */
  setJourneyFromSync: (next: Journey) => void;
  /** Read the latest journey synchronously (for async flows that must not use a stale render). */
  current: () => Journey;
  /** Merge another journey into the current one by id (guest import). */
  mergeIntoCurrent: (other: Journey) => void;
}

const Ctx = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [journey, setJourney] = useState<Journey>(() => emptyJourney());
  const [accountKey, setAccountKey] = useState<AccountKey>('guest');
  const [persist, setPersist] = useState<PersistStatus>({ kind: 'loading' });
  const [recoveryNotice, setRecoveryNotice] = useState<string | undefined>();
  const [canUndoRestore, setCanUndoRestore] = useState(false);
  const [drafts, setDrafts] = useState<Drafts>({});

  const journeyRef = useRef(journey);
  const accountRef = useRef<AccountKey>('guest');
  const storageOk = useRef(true);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const draftTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const draftsRef = useRef<Drafts>({});
  const dirty = useRef(false);

  const flush = useCallback(async () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    if (!dirty.current || !storageOk.current) return;
    dirty.current = false;
    setPersist({ kind: 'saving' });
    const res = await writeJSON(keys.journey(accountRef.current), journeyRef.current);
    if (res.ok) {
      setPersist({ kind: 'saved', at: new Date().toISOString() });
      requestPersistentStorage();
    }
    else {
      dirty.current = true;
      setPersist({ kind: 'error', message: `${res.error} Your latest changes are still here while the app is open.` });
    }
  }, []);

  const load = useCallback(async (acct: AccountKey, initial?: Journey) => {
    const ok = await probeStorage();
    storageOk.current = ok;
    accountRef.current = acct;
    setAccountKey(acct);
    if (!ok) {
      const j = initial ?? emptyJourney();
      journeyRef.current = j;
      setJourney(j);
      setPersist({ kind: 'memory', message: "This browser isn't letting Equilibrium save. Your entries last only while this page is open — export a backup to keep them." });
      setReady(true);
      return;
    }
    const res = await readJSON<unknown>(keys.journey(acct));
    let j: Journey;
    if (res.ok && res.value) {
      const check = checkBackup(res.value, { lenient: true });
      if (check.ok) {
        // `initial` (e.g. a guest journey being imported) is merged in by id, never replacing what's stored.
        j = initial ? mergeJourneys(check.journey, initial) : check.journey;
        if (check.dropped > 0) {
          // Keep the original, untouched, before the cleaned journey is ever saved over it.
          await writeJSON(keys.quarantine(acct), res.value);
          setRecoveryNotice(
            `${check.dropped} saved record${check.dropped === 1 ? '' : 's'} on this device couldn't be read and ${check.dropped === 1 ? 'was' : 'were'} set aside. Everything else is here. A copy of the original data was kept on this device.`,
          );
        }
      } else {
        await writeJSON(keys.quarantine(acct), res.value);
        j = initial ?? emptyJourney();
        setRecoveryNotice("The journey saved on this device couldn't be read, so Equilibrium started fresh. A copy of the original data was kept on this device and was not overwritten. If you have a backup, you can restore it.");
      }
    } else if (!res.ok) {
      if (res.raw != null) await writeRaw(keys.quarantine(acct), res.raw);
      j = initial ?? emptyJourney();
      setRecoveryNotice("The journey saved on this device couldn't be read, so Equilibrium started fresh. A copy of the original data was kept on this device and was not overwritten. If you have a backup, you can restore it.");
    } else {
      j = initial ?? emptyJourney();
    }
    journeyRef.current = j;
    setJourney(j);
    const pre = await readJSON<unknown>(keys.preRestore(acct));
    setCanUndoRestore(!!(pre.ok && pre.value));
    const d = await readJSON<Drafts>(keys.drafts(acct));
    draftsRef.current = d.ok && d.value ? d.value : {};
    setDrafts(draftsRef.current);
    if (initial) {
      dirty.current = true;
      await flush();
    }
    setPersist({ kind: 'saved', at: j.updatedAt });
    setReady(true);
  }, [flush]);

  const schedule = useCallback(() => {
    dirty.current = true;
    if (!storageOk.current) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => void flush(), 120);
  }, [flush]);

  useEffect(() => {
    // Reading the device's saved journey on mount is synchronizing with an external system — an effect's job.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load('guest');
  }, [load]);

  // Flush before the app is backgrounded or the page is hidden.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') void flush();
    });
    let onHide: (() => void) | undefined;
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      onHide = () => void flush();
      window.addEventListener('pagehide', onHide);
      document.addEventListener('visibilitychange', onHide);
    }
    return () => {
      sub.remove();
      if (onHide) {
        window.removeEventListener('pagehide', onHide);
        document.removeEventListener('visibilitychange', onHide);
      }
    };
  }, [flush]);

  const apply = useCallback(
    (fn: (j: Journey) => Journey): ApplyResult => {
      try {
        const next = fn(journeyRef.current);
        if (next === journeyRef.current) return { ok: true };
        journeyRef.current = next;
        setJourney(next);
        schedule();
        return { ok: true };
      } catch (e: any) {
        if (e instanceof OpError) return { ok: false, error: e.message };
        console.error(e);
        return { ok: false, error: 'Something went wrong. Nothing was changed.' };
      }
    },
    [schedule],
  );

  const setJourneyFromSync = useCallback(
    (next: Journey) => {
      journeyRef.current = next;
      setJourney(next);
      schedule();
    },
    [schedule],
  );

  const mergeIntoCurrent = useCallback(
    (other: Journey) => {
      const next = mergeJourneys(journeyRef.current, other);
      journeyRef.current = next;
      setJourney(next);
      schedule();
    },
    [schedule],
  );

  const replaceJourney = useCallback(
    async (next: Journey): Promise<ApplyResult> => {
      if (storageOk.current) {
        const snap = await writeJSON(keys.preRestore(accountRef.current), journeyRef.current);
        if (!snap.ok) return { ok: false, error: `Restore stopped before changing anything: ${snap.error}` };
        setCanUndoRestore(true);
      }
      journeyRef.current = next;
      setJourney(next);
      dirty.current = true;
      await flush();
      return { ok: true };
    },
    [flush],
  );

  const undoRestore = useCallback(async (): Promise<ApplyResult> => {
    const pre = await readJSON<unknown>(keys.preRestore(accountRef.current));
    if (!pre.ok || !pre.value) return { ok: false, error: 'There is no earlier journey to go back to.' };
    const check = checkBackup(pre.value);
    if (!check.ok) return { ok: false, error: 'The earlier journey could not be read.' };
    journeyRef.current = check.journey;
    setJourney(check.journey);
    dirty.current = true;
    await flush();
    await remove(keys.preRestore(accountRef.current));
    setCanUndoRestore(false);
    return { ok: true };
  }, [flush]);

  const eraseDevice = useCallback(async () => {
    const acct = accountRef.current;
    await remove(keys.journey(acct));
    await remove(keys.preRestore(acct));
    await remove(keys.drafts(acct));
    await remove(keys.sync(acct));
    const j = emptyJourney();
    journeyRef.current = j;
    setJourney(j);
    draftsRef.current = {};
    setDrafts({});
    setCanUndoRestore(false);
    setRecoveryNotice(undefined);
    dirty.current = false;
    setPersist(storageOk.current ? { kind: 'saved' } : persist);
  }, [persist]);

  const setDraft = useCallback((key: string, value: string | undefined) => {
    const next = { ...draftsRef.current };
    if (value && value.length) next[key] = value;
    else delete next[key];
    draftsRef.current = next;
    setDrafts(next);
    if (!storageOk.current) return;
    if (draftTimer.current) clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => void writeJSON(keys.drafts(accountRef.current), draftsRef.current), 400);
  }, []);

  const switchAccount = useCallback(
    async (key: AccountKey, initial?: Journey) => {
      await flush();
      setReady(false);
      setPersist({ kind: 'loading' });
      await load(key, initial);
    },
    [flush, load],
  );

  const value = useMemo<StoreValue>(
    () => ({
      ready,
      journey,
      accountKey,
      persist,
      recoveryNotice,
      dismissRecovery: () => setRecoveryNotice(undefined),
      apply,
      replaceJourney,
      canUndoRestore,
      undoRestore,
      eraseDevice,
      retrySave: () => {
        dirty.current = true;
        void flush();
      },
      drafts,
      setDraft,
      switchAccount,
      setJourneyFromSync,
      current: () => journeyRef.current,
      mergeIntoCurrent,
    }),
    [ready, journey, accountKey, persist, recoveryNotice, apply, replaceJourney, canUndoRestore, undoRestore, eraseDevice, flush, drafts, setDraft, switchAccount, setJourneyFromSync, mergeIntoCurrent],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): StoreValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore outside StoreProvider');
  return v;
}

export function useJourney(): Journey {
  return useStore().journey;
}
