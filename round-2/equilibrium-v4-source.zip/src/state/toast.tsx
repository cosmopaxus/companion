import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { color, radius, sans, space } from '../theme/tokens';
import { withAlpha } from '../ui/feel/palette';
import { Icon } from '../ui/Icon';
import { GemPop } from '../ui/academy/Motion';
import { useReducedMotion } from './motion';

export interface ToastMsg {
  id: number;
  text: string;
  gems?: number;
  tone?: 'default' | 'caution';
}

const Ctx = createContext<{ show: (text: string, opts?: { gems?: number; tone?: 'default' | 'caution' }) => void } | null>(null);

export function ToastProvider({ children, bottomOffset }: { children: React.ReactNode; bottomOffset: number }) {
  const [msg, setMsg] = useState<ToastMsg | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [opacity] = useState(() => new Animated.Value(0));
  const reduce = useReducedMotion();

  const show = useCallback(
    (text: string, opts?: { gems?: number; tone?: 'default' | 'caution' }) => {
      if (timer.current) clearTimeout(timer.current);
      setMsg({ id: Date.now(), text, gems: opts?.gems, tone: opts?.tone });
      timer.current = setTimeout(() => setMsg(null), opts?.tone === 'caution' ? 5000 : 3200);
    },
    [],
  );

  useEffect(() => {
    if (!msg) {
      opacity.setValue(0);
      return;
    }
    if (reduce) opacity.setValue(1);
    else Animated.timing(opacity, { toValue: 1, duration: 180, useNativeDriver: false }).start();
  }, [msg, reduce, opacity]);

  return (
    <Ctx.Provider value={{ show }}>
      {children}
      <View pointerEvents="none" style={[st.wrap, { bottom: bottomOffset }]} aria-live="polite" role="status">
        {msg ? (
          <Animated.View style={[st.toast, msg.tone === 'caution' && { backgroundColor: color.caution }, { opacity }]} testID="toast">
            <Icon name={msg.tone === 'caution' ? 'info' : 'check'} size={18} color={color.onSage} strokeWidth={2.4} />
            <Text style={st.text}>{msg.text}</Text>
            {msg.gems ? (
              <View style={st.gems}>
                <GemPop size={15} trigger={msg.id} />
                <Text style={st.gemText}>+{msg.gems}</Text>
              </View>
            ) : null}
          </Animated.View>
        ) : null}
      </View>
    </Ctx.Provider>
  );
}

export function useToast() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useToast outside ToastProvider');
  return v;
}

const st = StyleSheet.create({
  wrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center', paddingHorizontal: space.lg },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.sm,
    backgroundColor: color.ink,
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: radius.pill,
    maxWidth: 520,
  },
  text: { color: color.onSage, fontFamily: sans, fontSize: 15, fontWeight: '600', flexShrink: 1 },
  gems: { flexDirection: 'row', alignItems: 'center', gap: 4, marginLeft: 4, paddingLeft: 10, borderLeftWidth: 1, borderLeftColor: withAlpha(color.onSage, 0.25) },
  gemText: { color: color.toastGem, fontFamily: sans, fontSize: 15, fontWeight: '700' },
});
