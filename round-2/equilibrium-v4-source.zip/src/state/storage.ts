// Device storage. AsyncStorage on iOS/Android; on web it is backed by localStorage.
// Every call is guarded: storage can be unavailable (private windows, blocked site data,
// embedded previews). When it is, the app keeps working in memory and says so plainly.

import AsyncStorage from '@react-native-async-storage/async-storage';

// v2 keeps its own storage so it can share a web address with the first build without either
// one ever reading or overwriting the other's journey. The first build's journey can be brought
// in by choice (a copy: see V1_JOURNEY_KEY and the welcome screen).
export const NS = 'companion.v2';
/** Where the first build kept a guest journey on this device. Read-only to v2. */
export const V1_JOURNEY_KEY = 'companion.v1.journey.guest';

/** Each account gets its own cache so signing out never exposes one person's entries to another. */
export type AccountKey = 'guest' | `user:${string}`;

export const keys = {
  session: `${NS}.session`,
  journey: (a: AccountKey) => `${NS}.journey.${a}`,
  preRestore: (a: AccountKey) => `${NS}.prerestore.${a}`,
  drafts: (a: AccountKey) => `${NS}.drafts.${a}`,
  sync: (a: AccountKey) => `${NS}.sync.${a}`,
  /** Unreadable data is copied here before anything could overwrite it. Never deleted by the app. */
  quarantine: (a: AccountKey) => `${NS}.quarantine.${a}.${Date.now()}`,
};

export async function writeRaw(key: string, raw: string): Promise<boolean> {
  try {
    await AsyncStorage.setItem(key, raw);
    return true;
  } catch {
    return false;
  }
}

export async function probeStorage(): Promise<boolean> {
  const k = `${NS}.probe`;
  try {
    await AsyncStorage.setItem(k, '1');
    const v = await AsyncStorage.getItem(k);
    await AsyncStorage.removeItem(k);
    return v === '1';
  } catch {
    return false;
  }
}

export async function readJSON<T>(key: string): Promise<{ ok: true; value: T | null } | { ok: false; error: string; raw?: string }> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw == null) return { ok: true, value: null };
    try {
      return { ok: true, value: JSON.parse(raw) as T };
    } catch {
      return { ok: false, error: 'Saved data on this device could not be read.', raw };
    }
  } catch (e: any) {
    return { ok: false, error: e?.message ?? 'Storage is unavailable.' };
  }
}

export async function writeJSON(key: string, value: unknown): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
    return { ok: true };
  } catch (e: any) {
    const msg = String(e?.message ?? e ?? '');
    return { ok: false, error: /quota/i.test(msg) ? 'This device is out of storage space for Equilibrium.' : 'Could not write to device storage.' };
  }
}

export async function remove(key: string): Promise<boolean> {
  try {
    await AsyncStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
