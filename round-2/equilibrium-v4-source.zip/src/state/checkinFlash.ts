// The "Checked in at …" confirmation, shared between the check-in screen (which saves and closes)
// and Home's check-in card (which shows it). Held in memory only: nothing here is stored.
import { useSyncExternalStore } from 'react';
import type { Level } from '../domain/types';

export interface CheckinFlash {
  at: string;
  count: number;
  mood: Level;
  energy: Level;
  connection: Level;
  note?: string;
  spaceId: string;
}

let current: CheckinFlash | null = null;
const listeners = new Set<() => void>();

export function setCheckinFlash(v: CheckinFlash | null) {
  current = v;
  listeners.forEach((l) => l());
}

export function useCheckinFlash(): CheckinFlash | null {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => current,
    () => current,
  );
}
