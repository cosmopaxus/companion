// Open sheets register here so global Escape handling (nav) defers to the top-most sheet.
let openSheets = 0;
export const sheetsOpen = () => openSheets > 0;
export const registerSheet = () => {
  openSheets += 1;
  return () => {
    openSheets -= 1;
  };
};
