import { Appearance, Platform } from 'react-native';
import type { ElementId } from '../domain/types';
import { day, elementWashes as washes, night, Palette } from './palettes';

export { palettes, elementWashes } from './palettes';
export type { Palette } from './palettes';

// ——— Day and Night ———
// The palette is chosen once, when the app starts, from the person's choice on this device
// (Day, Night, or Match device). Styles are built from it at load, so changing the choice
// reloads the app (see platform/theme). Every pair used for text was checked for contrast
// in both palettes (tests/v2.test.ts): body text ≥ 4.5:1, control borders ≥ 3:1.

export type ThemeChoice = 'day' | 'night' | 'system';
export const THEME_CHOICES: ThemeChoice[] = ['day', 'night', 'system'];
/** Device-level, not part of the journey: each device can look its own way. */
export const THEME_KEY = 'companion.v2.theme';

export function isThemeChoice(v: unknown): v is ThemeChoice {
  return v === 'day' || v === 'night' || v === 'system';
}

function readChoice(): ThemeChoice {
  // Phones have no synchronous store at startup yet, so they follow the phone's own setting.
  if (Platform.OS !== 'web') return 'system';
  try {
    const v = (globalThis as any).localStorage?.getItem(THEME_KEY);
    return isThemeChoice(v) ? v : 'day';
  } catch {
    return 'day';
  }
}

function systemIsDark(): boolean {
  try {
    if (Platform.OS === 'web') return !!(globalThis as any).matchMedia?.('(prefers-color-scheme: dark)')?.matches;
    return Appearance.getColorScheme() === 'dark';
  } catch {
    return false;
  }
}

export const themeChoice: ThemeChoice = readChoice();
export const isNight: boolean = themeChoice === 'night' || (themeChoice === 'system' && systemIsDark());

export const color: Palette = isNight ? night : day;

export const elementColor: Record<ElementId, string> = {
  fire: color.fire,
  air: color.air,
  water: color.water,
  earth: color.earth,
};

export const elementText: Record<ElementId, string> = {
  fire: color.fireText,
  air: color.airText,
  water: color.water,
  earth: color.earthText,
};

export const elementWash: Record<ElementId, string> = isNight ? washes.night : washes.day;

export const space = { xs: 4, sm: 8, md: 12, lg: 18, xl: 24, xxl: 32 } as const;
export const radius = { sm: 10, md: 16, lg: 24, xl: 32, pill: 999 } as const;

// The fixed frame's type (Oct 14 art treatment): Cinzel for headings, Nunito for everything else.
// Web serves them from public/fonts; phones embed them at build time (expo-font plugin in app.json),
// so Expo Go shows the system fonts until a development build is made.
export const serif = Platform.select({
  ios: 'Cinzel',
  android: 'Cinzel',
  default: 'Cinzel, Georgia, "Iowan Old Style", serif',
});

export const sans = Platform.select({
  ios: 'Nunito',
  android: 'Nunito',
  default: 'Nunito, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
});

export const type = {
  display: { fontFamily: serif, fontSize: 28, lineHeight: 36, color: color.ink, fontWeight: '700' as const },
  title: { fontFamily: serif, fontSize: 21, lineHeight: 28, color: color.ink, fontWeight: '700' as const },
  heading: { fontFamily: serif, fontSize: 17, lineHeight: 24, color: color.ink, fontWeight: '700' as const },
  body: { fontFamily: sans, fontSize: 16, lineHeight: 24, color: color.ink },
  bodySoft: { fontFamily: sans, fontSize: 16, lineHeight: 24, color: color.inkSoft },
  label: { fontFamily: sans, fontSize: 15, lineHeight: 20, color: color.ink, fontWeight: '600' as const },
  small: { fontFamily: sans, fontSize: 14, lineHeight: 20, color: color.inkSoft },
  eyebrow: { fontFamily: sans, fontSize: 12, lineHeight: 16, color: color.gold, fontWeight: '700' as const, letterSpacing: 1.2, textTransform: 'uppercase' as const },
};

export const shadow = Platform.select({
  web: { boxShadow: isNight ? '0 1px 2px rgba(0,0,0,0.3), 0 10px 28px -12px rgba(0,0,0,0.5)' : '0 1px 2px rgba(27,37,28,0.04), 0 10px 28px -12px rgba(27,37,28,0.12)' } as any,
  ios: { shadowColor: isNight ? '#000000' : '#1B251C', shadowOpacity: isNight ? 0.3 : 0.06, shadowRadius: 14, shadowOffset: { width: 0, height: 6 } },
  default: { elevation: 1 },
});

/** Minimum comfortable touch target. */
export const TOUCH = 48;

export const TAB_BAR_HEIGHT = 64;
export const WIDE_BREAKPOINT = 960;
export const CONTENT_MAX = 700;
