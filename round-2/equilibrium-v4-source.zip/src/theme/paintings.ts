// The painted academy (Oct 14 art treatment, "window into glass"), as pure data and math (no
// React Native), so the crop, the frost and every text pair over the art can be unit-tested.
//
// A glass screen stacks, from the back:
//   1. the pre-blurred painting, filling the page (phones have no backdrop blur, so the blur is
//      baked into a small copy of each painting — no new library),
//   2. the clear painting in a window at the top, with slow ambient motion,
//   3. the blurred copy again, in thin strips that fade in over FADE px, so the clear painting
//      melts into the frosted one,
//   4. the cream (or night) wash: none at the top, 60% FROST_SOFT px into the frost, then the
//      reading wash (at least 78%, more where a painting needs it for 4.5:1 text),
//   5. a soft dark shade at the very top, under the chips.
// Text never sits on the clear painting itself: only on dark-glass chips, the title halo, the
// reading wash, or nearly solid glass cards (tests/painted.test.ts).

import type { HallId, Mode } from './academy';
import { contrast, mix } from './academy';
import { ART_STATS } from './artStats';

export type PaintingId = keyof typeof ART_STATS;

export interface Painting {
  id: PaintingId;
  /** Describes the art for screen readers where it is shown on its own (it is decoration on glass screens). */
  alt: string;
  /** Where the crop sits: fx across (0 = left edge, 1 = right); cy = the point of the painting (0 = top, 1 = bottom) kept in the middle of the clear window. */
  fx: number;
  cy: number;
  /** How much wider than the window the painting is drawn (1 = exactly the window's width). */
  zoom: number;
  /** The point the slow zoom grows from, as fractions of the painting. */
  origin: [number, number];
}

// Crops follow the mockups (05–08): on a 390 px phone the hall paintings are drawn 390 × 695 and
// shifted up by 40 / 247 / 73 / 60 px (cy = (shift + 85) / 695, 85 being the window's middle).
// Home is drawn a little wider (mockup 04), with the domes in the window.
export const PAINTINGS: Record<PaintingId, Painting> = {
  'academy-at-sunrise': { id: 'academy-at-sunrise', alt: 'The academy at sunrise: gold domes, gardens and a stream', fx: 0.62, cy: 0.2, zoom: 1.2, origin: [0.72, 0.26] },
  'hall-fire-the-forge': { id: 'hall-fire-the-forge', alt: 'The Forge: a sunlit hall around a round hearth of golden flame', fx: 0.5, cy: (247 + 85) / 695, zoom: 1, origin: [0.46, 0.64] },
  'hall-air-the-observatory': { id: 'hall-air-the-observatory', alt: 'The Observatory: a marble tower room with a brass telescope under a twilight dome', fx: 0.5, cy: (73 + 85) / 695, zoom: 1, origin: [0.5, 0.3] },
  'hall-water-the-moon-pool': { id: 'hall-water-the-moon-pool', alt: 'The Moon Pool: a moonlit courtyard pool with lilies and lanterns', fx: 0.5, cy: (40 + 85) / 695, zoom: 1, origin: [0.6, 0.25] },
  'hall-earth-the-herb-garden': { id: 'hall-earth-the-herb-garden', alt: 'The Herb Garden: a sunlit glasshouse with hanging herbs and stone beds', fx: 0.5, cy: (60 + 85) / 695, zoom: 1, origin: [0.55, 0.3] },
  'healing-sanctuary': { id: 'healing-sanctuary', alt: 'The Healing Sanctuary: a calm pool under arches, with cushions and soft light', fx: 0.5, cy: 0.45, zoom: 1, origin: [0.5, 0.5] },
  'hall-of-ascension': { id: 'hall-of-ascension', alt: 'The Hall of Ascension: a tall bright hall with four element spheres', fx: 0.5, cy: 0.4, zoom: 1, origin: [0.5, 0.4] },
  'path-map-academy-grounds': { id: 'path-map-academy-grounds', alt: 'The academy grounds from above, with stone platforms along a path', fx: 0.5, cy: 0.5, zoom: 1, origin: [0.5, 0.5] },
};

/** Each hall's painting (the element of the lesson you're on, or the hall you keep). */
export const HALL_PAINTING: Record<HallId, PaintingId> = {
  fire: 'hall-fire-the-forge',
  air: 'hall-air-the-observatory',
  water: 'hall-water-the-moon-pool',
  earth: 'hall-earth-the-herb-garden',
};

/** Home is the academy itself, at sunrise (mockup 04). */
export const HOME_PAINTING: PaintingId = 'academy-at-sunrise';

export type WindowKind = 'home' | 'hall';

/**
 * The window, in px from the top of the page (under the app bar). `clear`: where the frost begins.
 * `titleTop`: where the screen title starts (on its halo). Home's window is taller (mockup 04).
 */
export const WINDOW: Record<WindowKind, { clear: number; titleTop: number }> = {
  home: { clear: 190, titleTop: 240 },
  hall: { clear: 170, titleTop: 220 },
};

/** The clear painting melts into the frosted one over this many px. */
export const FADE = 130;
/** How many strips draw that melt (each a small step; the blurred art is smooth, so no bands show). */
export const FADE_STRIPS = 13;
/** The wash reaches 60% this far into the frost (spec: 110 px). */
export const FROST_SOFT = 110;
/** …and the reading wash this far in, where the content below the title begins. */
export const FROST_READ = 140;
/** The spec's least wash where text may sit on the page (78%). */
export const READING_FLOOR = 0.78;
/** The clear painting is never drawn wider than this; on wide screens its sides melt into the frosted copy. */
export const ART_MAX_W = 640;
/** …over this many px on each side, into its own frosted twin (mirrored beyond the window, so it never seams). */
export const SIDE_FEATHER = 96;
/** Dark glass under the chips on the art (mockup: rgba(24,17,46,.62)), with a gold edge. */
export const CHIP_GLASS = { rgb: '#18112E', alpha: 0.62, edge: 'rgba(243,216,142,0.45)', text: '#FFF8E8' } as const;
/** A soft shade at the top of the art, behind the chips (mockup: rgba(28,20,52,.55) → 0 over 110 px). */
export const TOP_SHADE = { rgb: '#1C1434', alpha: 0.55, height: 110 } as const;
/** At Night the clear painting is dimmed a little so it never glares beside the dark page. */
export const NIGHT_VEIL = { rgb: '#0A0C18', alpha: 0.32 } as const;

export interface Rect {
  left: number;
  top: number;
  width: number;
  height: number;
}

export interface ArtGeometry {
  /** The clear painting's box (it clips the painting): centered, at most ART_MAX_W wide. */
  box: Rect;
  /** The clear painting inside the page. */
  sharp: Rect;
  /**
   * Its frosted twin behind the whole page: the same crop, with a mirrored copy on each side, so the
   * frost lines up with the painting everywhere and the page is covered on any screen up to 3× the window.
   */
  blur: Rect;
}

function place(p: Painting, boxLeft: number, boxW: number, mid: number, minBottom: number): Rect {
  const s = ART_STATS[p.id];
  const width = boxW * p.zoom;
  const height = (width * s.height) / s.width;
  // Keep cy in the window's middle, but never leave a gap above, and on narrow phones never end too soon.
  const top = Math.min(0, Math.max(mid - p.cy * height, minBottom - height));
  return { left: boxLeft - (width - boxW) * p.fx, top, width, height };
}

/** Where everything is drawn for a page `pageW` px wide. */
export function artGeometry(pageW: number, id: PaintingId, kind: WindowKind): ArtGeometry {
  const p = PAINTINGS[id];
  const boxW = Math.min(pageW, ART_MAX_W);
  const boxLeft = (pageW - boxW) / 2;
  const clear = WINDOW[kind].clear;
  const box = { left: boxLeft, top: 0, width: boxW, height: clear + FADE };
  const sharp = place(p, boxLeft, boxW, clear / 2, clear + FROST_READ + 40);
  return { box, sharp, blur: { ...sharp } };
}

/** The opacity of the frosted copy over the clear painting in strip `i` (the last strip is fully frosted). */
export function fadeStripOpacity(i: number, n = FADE_STRIPS): number {
  return Math.min(1, Math.round(((i + 1) / n) * 1000) / 1000);
}

// ——— Contrast over the art ———

const DAY_TEXT_ON_PAGE = ['ink', 'inkSoft', 'gold', 'goldPressed', 'sage', 'actionText'] as const;
export type PageTextKey = (typeof DAY_TEXT_ON_PAGE)[number];
export const PAGE_TEXT: readonly PageTextKey[] = DAY_TEXT_ON_PAGE;

/** The lightest and darkest pixels of a painting's frosted copy from `fromV` (0 = its top, 1 = its bottom) down. */
export function blurExtremes(id: PaintingId, fromV = 0): string[] {
  const bands = ART_STATS[id].bands;
  const first = Math.max(0, Math.min(bands.length - 1, Math.floor(fromV * bands.length)));
  return bands.slice(first).flat();
}

/** Where the reading wash begins, as a fraction down the frosted copy (text can sit anywhere below it). */
export function readingFromV(g: ArtGeometry, kind: WindowKind): number {
  return (WINDOW[kind].clear + FROST_READ - g.blur.top) / g.blur.height;
}

/**
 * The reading wash for a painting: the least opacity (≥ READING_FLOOR) at which every page text
 * color passes 4.5:1 over the part of its frosted copy that can sit behind text (from `fromV` down).
 */
export function readingWash(id: PaintingId, canvas: string, texts: string[], fromV = 0): number {
  const pixels = blurExtremes(id, fromV);
  for (let a = READING_FLOOR; a < 1; a = Math.round((a + 0.01) * 100) / 100) {
    const ok = pixels.every((px) => {
      const bg = mix(px, canvas, a);
      return texts.every((t) => contrast(t, bg) >= 4.5);
    });
    if (ok) return a;
  }
  return 1;
}

/** The wash opacity at `y` px into the frost (0 = where it begins). */
export function washAt(y: number, reading: number): number {
  if (y <= 0) return 0;
  if (y <= FROST_SOFT) return (0.6 * y) / FROST_SOFT;
  if (y <= FROST_READ) return 0.6 + ((reading - 0.6) * (y - FROST_SOFT)) / (FROST_READ - FROST_SOFT);
  return reading;
}

/** The title's veil starts fading in this many px above the title and is solid at its top. */
export const TITLE_VEIL_LEAD = 50;

/**
 * The wash behind a glass screen at `y` px into the frost, with the title's veil: a full-width band
 * of the canvas at HALO_CORE from the title's top, easing into the reading wash where it begins.
 * (A full-width band, not a round halo, so no edge shows against the frost on either side.)
 */
export function pageWashAt(y: number, reading: number, kind: WindowKind, haloCore: number): number {
  if (y >= FROST_READ) return reading;
  const titleY = WINDOW[kind].titleTop - WINDOW[kind].clear;
  const veilAt = (v: number) => (v >= titleY ? haloCore : v > titleY - TITLE_VEIL_LEAD ? (haloCore * (v - titleY + TITLE_VEIL_LEAD)) / TITLE_VEIL_LEAD : 0);
  const at = (v: number) => Math.max(washAt(v, reading), veilAt(v));
  // Hold while any of the clear painting still shows (above FADE), then ease into the reading wash.
  const e = FADE;
  if (y <= e) return at(y);
  return at(e) + ((reading - at(e)) * (y - e)) / (FROST_READ - e);
}

export function chipBackground(): string {
  return `rgba(24,17,46,${CHIP_GLASS.alpha})`;
}

/**
 * Each hall's own ink, for small text that belongs to the hall: the eyebrow on a glass screen,
 * values and accents on cards (mockups 05–08). Tested at 4.5:1 on cards and on the page.
 */
export const HALL_INK: Record<HallId, { day: string; night: string }> = {
  fire: { day: '#93360F', night: '#F2A27A' },
  air: { day: '#1B4F93', night: '#9CC0F0' },
  water: { day: '#0B5E4E', night: '#7FD8C0' },
  earth: { day: '#3F6512', night: '#B5D98A' },
};

/** A soft wash of each hall's color for chips and tiles on cards (decoration behind HALL_INK text). */
export const HALL_TINT: Record<HallId, { day: string; night: string }> = {
  fire: { day: '#FBE7DC', night: '#3A2219' },
  air: { day: '#E3ECF8', night: '#1C2A3D' },
  water: { day: '#DDF3EC', night: '#16332C' },
  earth: { day: '#E8F1D8', night: '#24301A' },
};

// ——— Full-art screens (piece 3) ———

/** The near-solid panel that holds all the reading on a full-art screen (rest, invitations). */
export const PANEL_ALPHA = 0.95;
/** The breath orb on the rest screen: cream glass over the painting, its words in deep green. */
export const ORB_ALPHA = 0.86;

/** The painting covering a w × h box, its focus (fx, cy) kept in view. */
export function coverRect(w: number, h: number, id: PaintingId): Rect {
  const p = PAINTINGS[id];
  const s = ART_STATS[id];
  const k = Math.max(w / s.width, h / s.height);
  const width = s.width * k;
  const height = s.height * k;
  const left = Math.min(0, Math.max(w - width, w / 2 - p.fx * width));
  const top = Math.min(0, Math.max(h - height, h / 2 - p.cy * height));
  return { left, top, width, height };
}

/**
 * Where each lesson sits on the academy grounds painting (mockup 09), as fractions of the painting:
 * seven stone platforms climbing from the gate, then the next path and the Hall of Ascension.
 */
export const GROUNDS_SPOTS: { lessons: [number, number][]; next: [number, number]; ascension: [number, number]; sanctuary: [number, number] } = {
  lessons: [
    [0.416, 0.806],
    [0.563, 0.697],
    [0.302, 0.565],
    [0.506, 0.492],
    [0.363, 0.415],
    [0.557, 0.348],
    [0.631, 0.268],
  ],
  next: [0.77, 0.398],
  ascension: [0.635, 0.164],
  sanctuary: [0.738, 0.55],
};

/** The dark header over the full-screen path map (mockup 09): this strong at the top, still `mid` 62% down. */
export const HEADER_SHADE = { rgb: '#16102C', top: 0.92, mid: 0.78, height: 120 } as const;

export type { Mode };
