// v3 · Graphics & Interface — the academy look, as pure data (no React Native), so every
// gradient and text pair can be unit-tested.
//
// Three layers sit on top of a fixed frame (tab bar, buttons, body text, sizes and layout,
// which never change):
//   • Section → wing: material, heading font, texture (Academy, Manuscript, Observatory).
//   • Tier → building: the silhouette and light level (Courtyard, Library, Tower, Sanctum).
//   • Element → hall: gradient, accent, illustration props, ambient sound.
//
// Gradients carry text only in their dark zone. No single text color can pass contrast across a
// whole dark-to-light gradient, so the light end is for illustration only (tests/v3.test.ts).

import type { ElementId } from '../domain/types';

export type Mode = 'day' | 'night';
export type HallId = ElementId;
export type BuildingId = 'foundation' | 'acolyte' | 'initiate' | 'adept';
export type WingId = 'academy' | 'manuscript' | 'observatory';
/** A person's hall choice: follow the lesson they're on, or keep one hall. */
export type HallChoice = 'lesson' | HallId;
export const HALL_CHOICES: HallChoice[] = ['lesson', 'fire', 'air', 'water', 'earth'];

export interface Hall {
  id: HallId;
  /** Plain label always shown with the lore name. */
  element: string;
  name: string;
  mood: string;
  /** Dark → mid → light, as chosen by Cosmo (Oct 14, 2026). */
  day: [string, string, string];
  /** The same hues, dimmed so the light end never glares at night. */
  night: [string, string, string];
}

const NIGHT_GROUND = '#0A0F0C';

export const HALLS: Record<HallId, Hall> = {
  fire: { id: 'fire', element: 'Fire', name: 'The Forge', mood: 'Ember light, iron, will', day: ['#4A1B0C', '#D85A30', '#FAC775'], night: ['#4A1B0C', '#D85A30', '#FAC775'].map((c, i) => mix(c, NIGHT_GROUND, i === 2 ? 0.55 : 0.35)) as [string, string, string] },
  air: { id: 'air', element: 'Air', name: 'The Observatory', mood: 'Stars, open sky, mind', day: ['#042C53', '#378ADD', '#E6F1FB'], night: ['#042C53', '#378ADD', '#E6F1FB'].map((c, i) => mix(c, NIGHT_GROUND, i === 2 ? 0.55 : 0.35)) as [string, string, string] },
  water: { id: 'water', element: 'Water', name: 'The Moon Pool', mood: 'Moonlight, ripples, feeling', day: ['#04342C', '#1D9E75', '#E1F5EE'], night: ['#04342C', '#1D9E75', '#E1F5EE'].map((c, i) => mix(c, NIGHT_GROUND, i === 2 ? 0.55 : 0.35)) as [string, string, string] },
  earth: { id: 'earth', element: 'Earth', name: 'The Herb Garden', mood: 'Stone, roots, form', day: ['#412402', '#BA7517', '#C0DD97'], night: ['#412402', '#BA7517', '#C0DD97'].map((c, i) => mix(c, NIGHT_GROUND, i === 2 ? 0.55 : 0.35)) as [string, string, string] },
};
export const HALL_IDS: HallId[] = ['fire', 'air', 'water', 'earth'];

export interface Building {
  id: BuildingId;
  tier: string;
  name: string;
  detail: string;
}

export const BUILDINGS: Record<BuildingId, Building> = {
  foundation: { id: 'foundation', tier: 'Foundation', name: 'The Courtyard', detail: 'Open arches, morning light' },
  acolyte: { id: 'acolyte', tier: 'Acolyte', name: 'The Library', detail: 'Tall shelves, lamplight' },
  initiate: { id: 'initiate', tier: 'Initiate', name: 'The Tower', detail: 'Narrow windows, dusk' },
  adept: { id: 'adept', tier: 'Adept', name: 'The Sanctum', detail: 'A vaulted dome, starlight' },
};

export interface Wing {
  id: WingId;
  name: string;
  /** Web font family for headings in this wing, with fallbacks. Body text never changes. */
  displayFamily: string;
  /** Card edge: the Academy's cards sit on a solid lip, like a game tile. */
  cardLip: number;
  cardRadius: number;
}

export const WINGS: Record<WingId, Wing> = {
  academy: { id: 'academy', name: 'Bright Academy', displayFamily: 'Cinzel, Georgia, "Iowan Old Style", serif', cardLip: 3, cardRadius: 22 },
  // Phase 2+: the Manuscript and Observatory wings get their own heading fonts once approved.
  manuscript: { id: 'manuscript', name: 'Lamplit Manuscript', displayFamily: 'Cinzel, Georgia, "Iowan Old Style", serif', cardLip: 0, cardRadius: 24 },
  observatory: { id: 'observatory', name: 'Night Observatory', displayFamily: 'Cinzel, Georgia, "Iowan Old Style", serif', cardLip: 0, cardRadius: 24 },
};

// ——— Choosing the hall ———

/**
 * The hall someone stands in: their own choice, or (by default) the element of the lesson they're
 * on. Foundation lessons train no single element, so they rest in the Herb Garden (Earth: form,
 * roots, the ground everything grows from).
 */
export const DEFAULT_HALL: HallId = 'earth';

export function resolveHall(choice: HallChoice | undefined, lessonElement: ElementId | undefined): HallId {
  if (choice && choice !== 'lesson') return choice;
  return lessonElement ?? DEFAULT_HALL;
}

export function isHallChoice(v: unknown): v is HallChoice {
  return typeof v === 'string' && (HALL_CHOICES as string[]).includes(v);
}

// ——— Gradients ———

/**
 * A header is its text block plus a fixed art strip below it, so its height never depends on a
 * measurement (no layout jump). The gradient is laid out around the text: the dark color holds
 * through the first 55% of the text block, eases toward the mid color, reaches it a little way
 * into the art strip, and reaches the light color at the bottom edge, behind the building.
 */
export const HERO_ART = 104;
export const HERO_HOLD = 0.55;
export const HERO_MID_INTO_ART = 0.55;
/** However tall the text block, the ramp under it is at most this many px, so its lower lines stay dark enough. */
export const HERO_RAMP_UNDER_TEXT = 96;
/** How far a dusk band travels from the dark color toward the mid color (it never reaches the light end). */
export const DUSK_REACH = 0.6;
/** Text colors allowed on a hall gradient. */
export const ON_HALL = { title: '#FFFFFF', soft: '#FFF4E6' } as const;

export interface Stop {
  offset: number;
  color: string;
}

/**
 * The header gradient, with in-between stops blended in OKLab so each step is tiny (no visible
 * bands) and hues stay rich through the middle instead of going muddy.
 */
export function heroStops(hall: HallId, mode: Mode, textPx = 200, artPx = HERO_ART, steps = 8): Stop[] {
  const [dark, mid, light] = HALLS[hall][mode];
  const H = textPx + artPx;
  const anchors: Stop[] = [
    { offset: 0, color: dark },
    { offset: round(Math.max(HERO_HOLD * textPx, textPx - HERO_RAMP_UNDER_TEXT) / H), color: dark },
    { offset: round((textPx + HERO_MID_INTO_ART * artPx) / H), color: mid },
    { offset: 1, color: light },
  ];
  const out: Stop[] = [anchors[0]];
  for (let i = 1; i < anchors.length; i++) {
    const a = anchors[i - 1];
    const b = anchors[i];
    const n = a.color === b.color ? 1 : steps;
    for (let k = 1; k <= n; k++) {
      const t = k / n;
      out.push({ offset: round(a.offset + (b.offset - a.offset) * t), color: oklabMix(a.color, b.color, t) });
    }
  }
  return out;
}

/**
 * A dusk band for the top of a card: the hall's dark color easing toward its mid color, never
 * reaching the light end, so light text passes contrast anywhere on it, at any height.
 */
export function duskStops(hall: HallId, mode: Mode, steps = 8): Stop[] {
  const [dark, mid] = HALLS[hall][mode];
  const end = oklabMix(dark, mid, DUSK_REACH);
  return Array.from({ length: steps + 1 }, (_, k) => ({ offset: round(k / steps), color: oklabMix(dark, end, k / steps) }));
}

/** The color a renderer paints at `t` (0 = top), interpolating linearly in sRGB between stops, as SVG does. */
export function colorAt(stops: Stop[], t: number): string {
  if (t <= stops[0].offset) return stops[0].color;
  for (let i = 1; i < stops.length; i++) {
    const a = stops[i - 1];
    const b = stops[i];
    if (t <= b.offset) return mix(a.color, b.color, b.offset === a.offset ? 1 : (t - a.offset) / (b.offset - a.offset));
  }
  return stops[stops.length - 1].color;
}

/**
 * The academy grounds (the path map's regions): the card color with a whisper of the hall's mid
 * color, so ordinary ink, soft ink, sage and gold text all keep 4.5:1 on it (tests/v3.test.ts).
 */
export function groundsWash(hall: HallId, mode: Mode, paper: string): string {
  return mix(paper, HALLS[hall].day[1], mode === 'day' ? 0.1 : 0.12);
}

/** The road the trail walks on, one step deeper than the grounds. */
export function groundsRoad(hall: HallId, mode: Mode, paper: string): string {
  return mix(groundsWash(hall, mode, paper), HALLS[hall].day[mode === 'day' ? 1 : 2], mode === 'day' ? 0.18 : 0.14);
}

// ——— Window into glass (Oct 14 art treatment) ———
// The top of a text-heavy screen is a clear window onto the hall's art; from GLASS.clear px down
// it melts into frosted glass. The page below is the frost color: the canvas with a whisper of the
// hall's mid color, standing in for the blurred painting until the painted art ships.

/** Art height, where the frost starts, and where it reaches 60% (px from the top of the screen). */
export const GLASS = { art: 300, clear: 170, soft: 280, titleTop: 150, chipZone: 64 } as const;
/** Text block height the art's gradient is laid out around (dark behind the chips, light below). */
export const GLASS_TEXT = 140;
/** The cream (or night) halo behind a screen's title: this opaque across its core (tested: 4.5:1 over the darkest and lightest pixel of every painting). */
export const HALO_CORE = 0.92;
/** The halo is drawn HALO_SCALE times the title block's size and holds HALO_CORE out to HALO_PLATEAU of its
 *  radius, then fades softly; the block's corners sit at √2 / HALO_SCALE, inside the plateau. */
export const HALO_SCALE = 2;
export const HALO_PLATEAU = 0.74;
/** Dark-glass chips on the art (hall name, back): black at this strength under white text. */
export const CHIP_SHADE = 0.45;

export function glassWash(hall: HallId, mode: Mode, canvas: string): string {
  return mix(canvas, HALLS[hall].day[1], mode === 'day' ? 0.08 : 0.1);
}

/** How opaque the frost (glassWash) is down the art, as offsets of GLASS.art. */
export function frostStops(art: number = GLASS.art): { offset: number; opacity: number }[] {
  return [
    { offset: 0, opacity: 0 },
    { offset: round(GLASS.clear / art), opacity: 0 },
    { offset: round(GLASS.soft / art), opacity: 0.6 },
    { offset: round((art - 30) / art), opacity: 0.86 },
    { offset: 1, opacity: 1 },
  ];
}

/** The art behind a glass screen: the hall gradient laid out around GLASS_TEXT. */
export function glassArtStops(hall: HallId, mode: Mode): Stop[] {
  return heroStops(hall, mode, GLASS_TEXT, GLASS.art - GLASS_TEXT);
}

/** A soft wash of the hall for small accents (the gem pill border, a progress fill) on paper. */
export function hallAccent(hall: HallId, mode: Mode): string {
  return mode === 'day' ? HALLS[hall].day[0] : mix(HALLS[hall].day[2], '#FFFFFF', 0.15);
}

// ——— Color math (pure) ———

function rgb(hex: string): [number, number, number] {
  const n = parseInt(hex.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function hex([r, g, b]: number[]): string {
  return '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
}

function round(n: number): number {
  return Math.round(n * 10000) / 10000;
}

/** Linear sRGB mix: `t` = 0 gives `a`, 1 gives `b`. */
export function mix(a: string, b: string, t: number): string {
  const x = rgb(a);
  const y = rgb(b);
  return hex(x.map((v, i) => v + (y[i] - v) * t));
}

const toLinear = (v: number) => {
  const x = v / 255;
  return x <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
};
const fromLinear = (x: number) => 255 * (x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055);

function toOklab(hexc: string): [number, number, number] {
  const [r, g, b] = rgb(hexc).map(toLinear);
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  return [0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s, 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s];
}

function fromOklab([L, A, B]: [number, number, number]): string {
  const l = (L + 0.3963377774 * A + 0.2158037573 * B) ** 3;
  const m = (L - 0.1055613458 * A - 0.0638541728 * B) ** 3;
  const s = (L - 0.0894841775 * A - 1.291485548 * B) ** 3;
  return hex([4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s, -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s].map(fromLinear));
}

export function oklabMix(a: string, b: string, t: number): string {
  const x = toOklab(a);
  const y = toOklab(b);
  return fromOklab([x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t]);
}

export function luminance(hexc: string): number {
  const [r, g, b] = rgb(hexc).map(toLinear);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrast(a: string, b: string): number {
  const x = luminance(a);
  const y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
