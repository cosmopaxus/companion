// The weekly look-back: what changed, in the person's own words. It quotes their evidence and
// lists what they did. There are no scores, no feelings averaged, nothing rated.

import type { Evidence, Goal, Journey, SpaceId } from './types';
import { addDays } from './protocols';
import { localDayKey } from './time';
import { LESSON_BY_ID, PathLesson, practiceDays } from './paths';

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;

export interface LookBack {
  /** First and last local day of the seven-day window (inclusive). */
  from: string;
  to: string;
  daysShownUp: number;
  wins: (Evidence & { areaName: string })[];
  observations: (Evidence & { areaName: string })[];
  setbacks: (Evidence & { areaName: string })[];
  goalsReached: Goal[];
  goalsSet: Goal[];
  lessons: { lesson: PathLesson; days: number }[];
  checkins: number;
  journal: number;
  readings: number;
  empty: boolean;
}

/** The seven days ending on `endDay`. Check-ins, journal and readings follow the Space; the rest is account-wide. */
export function lookBack(j: Journey, space: SpaceId, endDay: string): LookBack {
  const from = addDays(endDay, -6);
  const inWeek = (iso?: string) => {
    if (!iso) return false;
    const d = localDayKey(iso);
    return d >= from && d <= endDay;
  };
  const days = Array.from(practiceDays(j)).filter((d) => d >= from && d <= endDay).length;
  const areaName = new Map(j.areas.filter(alive).map((a) => [a.id, a.name]));
  const ev = j.evidence
    .filter((e) => alive(e) && areaName.has(e.areaId) && inWeek(e.createdAt))
    .sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1))
    .map((e) => ({ ...e, areaName: areaName.get(e.areaId)! }));
  const goals = (j.goals ?? []).filter(alive);
  const lessonDays = new Map<string, number>();
  for (const p of j.practiceLogs ?? []) {
    if (!alive(p) || p.day < from || p.day > endDay) continue;
    lessonDays.set(p.lessonId, (lessonDays.get(p.lessonId) ?? 0) + 1);
  }
  const lessons = Array.from(lessonDays.entries())
    .filter(([id]) => !!LESSON_BY_ID[id])
    .map(([id, n]) => ({ lesson: LESSON_BY_ID[id], days: n }));
  const out: LookBack = {
    from,
    to: endDay,
    daysShownUp: days,
    wins: ev.filter((e) => e.kind === 'win'),
    observations: ev.filter((e) => e.kind === 'observation'),
    setbacks: ev.filter((e) => e.kind === 'setback'),
    goalsReached: goals.filter((g) => g.status === 'reached' && inWeek(g.reachedAt)),
    goalsSet: goals.filter((g) => inWeek(g.createdAt)),
    lessons,
    checkins: j.checkins.filter((c) => alive(c) && c.spaceId === space && inWeek(c.createdAt)).length,
    journal: j.journal.filter((e) => alive(e) && e.spaceId === space && inWeek(e.createdAt)).length,
    readings: j.harmony.filter((h) => alive(h) && h.spaceId === space && inWeek(h.createdAt)).length,
    empty: false,
  };
  out.empty = days === 0;
  return out;
}

export const LOOKBACK_PROMPT = 'Looking back on this week, what changed?';
