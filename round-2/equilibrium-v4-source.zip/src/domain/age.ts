// Age brackets. Equilibrium is open to everyone for reflection; microdosing-related features
// (Safety & Path, protocols, dose notes, rhythm reminders, əvōke offerings, the Be Well Space)
// are for adults 18 and over. Under 18 is "reflection mode": everything else stays.

import type { AgeBracket, Journey, Profile } from './types';

export const AGE_BRACKETS: { id: Exclude<AgeBracket, 'adult'>; label: string }[] = [
  { id: 'under18', label: 'Under 18' },
  { id: '18-24', label: '18–24' },
  { id: '25-34', label: '25–34' },
  { id: '35-44', label: '35–44' },
  { id: '45-54', label: '45–54' },
  { id: '55-64', label: '55–64' },
  { id: '65plus', label: '65+' },
];

export const AGE_BRACKET_IDS: AgeBracket[] = [...AGE_BRACKETS.map((b) => b.id), 'adult'];

export function isAgeBracket(v: unknown): v is AgeBracket {
  return typeof v === 'string' && (AGE_BRACKET_IDS as string[]).includes(v);
}

export function ageLabel(b: AgeBracket): string {
  if (b === 'adult') return '18 or older';
  return AGE_BRACKETS.find((x) => x.id === b)!.label;
}

export function isAdultProfile(p: Profile | null | undefined): boolean {
  return !!p && p.ageBracket !== 'under18';
}

/** Adults see everything. Under 18 sees reflection features only. */
export function isAdult(j: Journey): boolean {
  return isAdultProfile(j.profile);
}

export const REFLECTION_MODE_NOTE =
  "Equilibrium's microdosing tools are for adults 18 and over, so they stay hidden. Check-ins, Journey, Compass, Journal and support are all yours.";
