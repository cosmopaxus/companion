import type { Area, CheckIn, Evidence, GemTx, HarmonySnapshot, Journey, JournalEntry, LessonId, SpaceId } from './types';
import { LESSON_IDS } from './types';
import { isSameLocalDay } from './time';
import { balanceFor } from './gems';

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;
const newestFirst = (a: { createdAt: string }, b: { createdAt: string }) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0);

export function checkinsFor(j: Journey, space: SpaceId): CheckIn[] {
  return j.checkins.filter((c) => alive(c) && c.spaceId === space).sort(newestFirst);
}

export function todaysCheckins(j: Journey, space: SpaceId, now: Date = new Date()): CheckIn[] {
  return checkinsFor(j, space).filter((c) => isSameLocalDay(c.createdAt, now));
}

export function journalFor(j: Journey, space: SpaceId): JournalEntry[] {
  return j.journal.filter((e) => alive(e) && e.spaceId === space).sort(newestFirst);
}

export function harmonyFor(j: Journey, space: SpaceId): HarmonySnapshot[] {
  return j.harmony.filter((h) => alive(h) && h.spaceId === space).sort(newestFirst);
}

export function latestHarmony(j: Journey, space: SpaceId): HarmonySnapshot | undefined {
  return harmonyFor(j, space)[0];
}

export function activeAreas(j: Journey): Area[] {
  return j.areas.filter(alive);
}

/**
 * Transparent prioritization aid: impact high → low, then difficulty low → high,
 * then oldest first so the order is stable. Not a clinical recommendation.
 */
export function rankAreas(areas: Area[]): Area[] {
  return [...areas].sort(
    (a, b) => b.impact - a.impact || a.difficulty - b.difficulty || (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0),
  );
}

export function rankedAreas(j: Journey): Area[] {
  return rankAreas(activeAreas(j));
}

export function isEasyWin(a: Pick<Area, 'difficulty'>): boolean {
  return a.difficulty <= 2;
}

export function evidenceFor(j: Journey, areaId: string): Evidence[] {
  return j.evidence.filter((e) => alive(e) && e.areaId === areaId).sort(newestFirst);
}

export interface AreaStats {
  wins: number;
  observations: number;
  setbacks: number;
  total: number;
  last?: Evidence;
}

export function areaStats(j: Journey, areaId: string): AreaStats {
  const ev = evidenceFor(j, areaId);
  return {
    wins: ev.filter((e) => e.kind === 'win').length,
    observations: ev.filter((e) => e.kind === 'observation').length,
    setbacks: ev.filter((e) => e.kind === 'setback').length,
    total: ev.length,
    last: ev[0],
  };
}

export function gemsFor(j: Journey, space: SpaceId | 'all'): GemTx[] {
  const list = space === 'all' ? j.gems : j.gems.filter((g) => g.spaceId === space);
  return [...list].sort(newestFirst);
}

export function gemBalance(j: Journey, space: SpaceId): number {
  return balanceFor(j.gems, space);
}

export function guideProgress(j: Journey): { done: number; total: number; complete: boolean; next: LessonId | null } {
  const done = LESSON_IDS.filter((l) => !!j.guide.completed[l]).length;
  const next = LESSON_IDS.find((l) => !j.guide.completed[l]) ?? null;
  return { done, total: LESSON_IDS.length, complete: done === LESSON_IDS.length, next };
}

export interface JourneyCounts {
  checkins: number;
  journal: number;
  areas: number;
  evidence: number;
  harmony: number;
  gems: number;
}

export function counts(j: Journey): JourneyCounts {
  return {
    checkins: j.checkins.filter(alive).length,
    journal: j.journal.filter(alive).length,
    areas: j.areas.filter(alive).length,
    evidence: j.evidence.filter(alive).length,
    harmony: j.harmony.filter(alive).length,
    gems: j.gems.reduce((s, g) => s + g.amount, 0),
  };
}
