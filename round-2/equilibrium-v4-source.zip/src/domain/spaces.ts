import type { SpaceId } from './types';

export interface SpaceInfo {
  id: SpaceId;
  name: string;
  blurb: string;
}

export const SPACES: SpaceInfo[] = [
  { id: 'personal', name: 'Personal', blurb: 'Your own practice. Private to you.' },
  {
    id: 'bewell',
    name: 'Be Well',
    blurb: "A separate home for entries related to Be Well. In this alpha it doesn't join or share anything with the organization.",
  },
];

export const SPACE_NAME: Record<SpaceId, string> = { personal: 'Personal', bewell: 'Be Well' };

export const SPACE_SCOPE_NOTE =
  'Check-ins, journal entries, Compass readings and gems belong to the Space you are in. Journey areas are shared across your whole journey. Switching Spaces never publishes, submits or shares anything.';
