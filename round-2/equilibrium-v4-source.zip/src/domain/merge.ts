// Merge two versions of the same person's journey without losing or duplicating events.
// Used for account restore (merge) and cloud sync (local ⟷ remote).
//
// Rules:
// • Event collections merge by id. When both sides have an id, the later updatedAt wins;
//   on a tie a tombstone wins (a delete is never silently undone), then a stable comparison.
// • Gem transactions are immutable and keyed by deterministic ids, so they union cleanly.
// • Guide completion unions per lesson and keeps the earliest time; the reward is kept once.
// • Profile, intake and prefs: the later updatedAt wins.
// • activeSpaceId is a per-device view choice and always comes from `local`.

import type { GemTx, GuideState, Journey, LessonId, PathsState, RecordBase, TierId } from './types';
import { LESSON_IDS, TIER_IDS } from './types';

function pickRecord<T extends RecordBase>(a: T, b: T): T {
  if (a.updatedAt !== b.updatedAt) return a.updatedAt > b.updatedAt ? a : b;
  if (!!a.deletedAt !== !!b.deletedAt) return a.deletedAt ? a : b;
  return JSON.stringify(a) >= JSON.stringify(b) ? a : b;
}

export function mergeById<T extends RecordBase>(a: T[], b: T[]): T[] {
  const map = new Map<string, T>();
  for (const r of a) map.set(r.id, map.has(r.id) ? pickRecord(map.get(r.id)!, r) : r);
  for (const r of b) map.set(r.id, map.has(r.id) ? pickRecord(map.get(r.id)!, r) : r);
  return Array.from(map.values()).sort((x, y) => (x.createdAt < y.createdAt ? -1 : x.createdAt > y.createdAt ? 1 : x.id < y.id ? -1 : 1));
}

export function mergeGems(a: GemTx[], b: GemTx[]): GemTx[] {
  const map = new Map<string, GemTx>();
  for (const g of [...a, ...b]) {
    const prev = map.get(g.id);
    if (!prev || g.createdAt < prev.createdAt) map.set(g.id, g);
  }
  return Array.from(map.values()).sort((x, y) => (x.createdAt < y.createdAt ? -1 : x.createdAt > y.createdAt ? 1 : x.id < y.id ? -1 : 1));
}

function earliest(a?: string, b?: string): string | undefined {
  if (!a) return b;
  if (!b) return a;
  return a < b ? a : b;
}

export function mergeGuide(a: GuideState, b: GuideState): GuideState {
  const completed: Partial<Record<LessonId, string>> = {};
  for (const l of LESSON_IDS) {
    const t = earliest(a.completed[l], b.completed[l]);
    if (t) completed[l] = t;
  }
  const newer = a.updatedAt >= b.updatedAt ? a : b;
  return {
    completed,
    position: newer.position,
    practice: newer.practice,
    cardDismissedAt: earliest(a.cardDismissedAt, b.cardDismissedAt),
    rewardGrantedAt: earliest(a.rewardGrantedAt, b.rewardGrantedAt),
    updatedAt: newer.updatedAt,
  };
}

/** Union of two "first time" maps, keeping the earliest time for each key. */
function earliestMap(a: Partial<Record<string, string>> | undefined, b: Partial<Record<string, string>> | undefined): Partial<Record<string, string>> {
  const out: Partial<Record<string, string>> = { ...(a ?? {}) };
  for (const [k, v] of Object.entries(b ?? {})) if (v && (!out[k] || v < out[k]!)) out[k] = v;
  return out;
}

/**
 * Opened paths union (earliest opening kept: once open, a path stays open); "not yet" keeps the latest;
 * lessons mastered and badges earned union, earliest time kept.
 */
export function mergePaths(a: PathsState | undefined, b: PathsState | undefined): PathsState {
  const empty: PathsState = { opened: {}, deferred: {}, mastered: {}, badges: {}, updatedAt: '' };
  const x = a ?? empty;
  const y = b ?? empty;
  const opened: PathsState['opened'] = {};
  const deferred: PathsState['deferred'] = {};
  for (const t of TIER_IDS as TierId[]) {
    const oa = x.opened?.[t];
    const ob = y.opened?.[t];
    if (oa || ob) opened[t] = !oa ? ob : !ob ? oa : oa.at <= ob.at ? oa : ob;
    const da = x.deferred?.[t];
    const db = y.deferred?.[t];
    if (da || db) deferred[t] = !da ? db : !db ? da : da > db ? da : db;
  }
  return { opened, deferred, mastered: earliestMap(x.mastered, y.mastered), badges: earliestMap(x.badges, y.badges), updatedAt: x.updatedAt >= y.updatedAt ? x.updatedAt : y.updatedAt };
}

function later<T extends { updatedAt: string }>(a: T, b: T): T {
  return a.updatedAt >= b.updatedAt ? a : b;
}

export function mergeJourneys(local: Journey, remote: Journey): Journey {
  const profile =
    local.profile && remote.profile ? later(local.profile, remote.profile) : (local.profile ?? remote.profile);
  const older = local.createdAt <= remote.createdAt ? local : remote;
  return {
    ...local,
    // Deterministic identity: the older journey's id wins, so two devices converge on one id.
    journeyId: older.journeyId,
    createdAt: older.createdAt,
    updatedAt: local.updatedAt > remote.updatedAt ? local.updatedAt : remote.updatedAt,
    revision: Math.max(local.revision, remote.revision) + 1,
    profile,
    activeSpaceId: local.activeSpaceId,
    checkins: mergeById(local.checkins, remote.checkins),
    areas: mergeById(local.areas, remote.areas),
    evidence: mergeById(local.evidence, remote.evidence),
    harmony: mergeById(local.harmony, remote.harmony),
    journal: mergeById(local.journal, remote.journal),
    protocols: mergeById(local.protocols ?? [], remote.protocols ?? []),
    dayNotes: mergeById(local.dayNotes ?? [], remote.dayNotes ?? []),
    goals: mergeById(local.goals ?? [], remote.goals ?? []),
    practiceLogs: mergeById(local.practiceLogs ?? [], remote.practiceLogs ?? []),
    paths: mergePaths(local.paths, remote.paths),
    gems: mergeGems(local.gems, remote.gems),
    guide: mergeGuide(local.guide, remote.guide),
    intake: later(local.intake, remote.intake),
    prefs: later(local.prefs, remote.prefs),
  };
}
