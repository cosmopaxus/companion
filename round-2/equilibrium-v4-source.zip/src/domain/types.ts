// Core data model for Equilibrium. Pure types — no React, no platform imports.
// Every record has a stable id and ISO timestamps so journeys can be exported,
// restored and merged by id without duplicating events.

export type SpaceId = 'personal' | 'bewell';
export type DirectionId = 'center' | 'focus' | 'activate' | 'connect';
export type ElementId = 'fire' | 'air' | 'water' | 'earth';
export type Rating = 1 | 2 | 3 | 4 | 5;
/** Self-reported. 'adult' = confirmed 18+ before brackets existed (no bracket chosen yet). */
export type AgeBracket = 'under18' | '18-24' | '25-34' | '35-44' | '45-54' | '55-64' | '65plus' | 'adult';
export type Experience = 'none' | 'some' | 'regular' | 'skip';
/** A check-in reading: a whole number from 0 (the heavy / depleted / isolated end) to 100 (bright / charged / connected). */
export type Level = number;
export type EvidenceKind = 'win' | 'observation' | 'setback';
export type LessonId = 'today' | 'journey' | 'connect' | 'journal' | 'you';
export type GemReason = 'checkin' | 'journal' | 'evidence' | 'harmony' | 'guide-complete' | 'practice' | 'goal';

export const SPACE_IDS: SpaceId[] = ['personal', 'bewell'];
export const DIRECTION_IDS: DirectionId[] = ['center', 'focus', 'activate', 'connect'];
export const ELEMENT_IDS: ElementId[] = ['fire', 'air', 'water', 'earth'];
export const EVIDENCE_KINDS: EvidenceKind[] = ['win', 'observation', 'setback'];
export const LESSON_IDS: LessonId[] = ['today', 'journey', 'connect', 'journal', 'you'];
export const GEM_REASONS: GemReason[] = ['checkin', 'journal', 'evidence', 'harmony', 'guide-complete', 'practice', 'goal'];

/** Fields shared by every user-created record. `deletedAt` is a tombstone so deletes survive a merge. */
export interface RecordBase {
  id: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
}

export interface Profile {
  name: string;
  handle?: string;
  /** Self-reported age bracket. Under 18 turns on reflection mode (see age.ts). */
  ageBracket: AgeBracket;
  /** Up to two starting directions, in the order chosen. */
  chosenDirections: DirectionId[];
  createdAt: string;
  updatedAt: string;
}

export interface CheckIn extends RecordBase {
  spaceId: SpaceId;
  mood: Level;
  energy: Level;
  connection: Level;
  /** Scale marker. Check-ins saved before the sliders used 1–5; they are converted to 0–100 when read (see backup.ts). */
  scale: 100;
  note?: string;
}

export interface Area extends RecordBase {
  name: string;
  impact: Rating;
  difficulty: Rating;
  direction?: DirectionId;
}

export interface Evidence extends RecordBase {
  areaId: string;
  kind: EvidenceKind;
  text: string;
  /** The Space that was active when this was recorded (its gem goes there). Areas themselves are account-wide. */
  spaceId: SpaceId;
}

export interface ElementRating {
  pressure: Rating;
  resource: Rating;
}

export interface HarmonySnapshot extends RecordBase {
  spaceId: SpaceId;
  ratings: Record<ElementId, ElementRating>;
  note?: string;
}

/** A repeating rhythm: `on` activation days, then `off` integration days. Or: activation on chosen weekdays (0 = Sunday). */
export type ProtocolPattern = { type: 'cycle'; on: number; off: number } | { type: 'weekdays'; days: number[] };
export type DoseLevel = 'micro' | 'minor' | 'unsure';
export type ProtocolStatus = 'active' | 'paused' | 'finished';

/**
 * A microdosing rhythm the person chose or wrote. Adults only. Account-wide (the same in every Space).
 * Equilibrium never chooses an amount: `substance` and `amount` are the person's own words.
 */
export interface ProtocolPlan extends RecordBase {
  /** Preset id it was started from, or 'custom'. */
  presetId: string;
  name: string;
  pattern: ProtocolPattern;
  /** Local calendar day the rhythm counts from (YYYY-MM-DD). Resuming after a pause restarts it. */
  startDate: string;
  /** Optional: practice for this many weeks, then rest for `restWeeks`, then repeat. */
  cycleWeeks?: number;
  restWeeks?: number;
  status: ProtocolStatus;
  pausedAt?: string;
  endedAt?: string;
  level?: DoseLevel;
  substance?: string;
  amount?: string;
  intention?: string;
}

export type DayNoteStatus = 'taken' | 'skipped' | 'off';

/**
 * What happened on one day of a protocol, in the person's words. Adults only; one per calendar day
 * (id `day:YYYY-MM-DD`), account-wide like protocols. Never rewarded with gems.
 */
export interface DayNote extends RecordBase {
  day: string;
  status: DayNoteStatus;
  protocolId?: string;
  substance?: string;
  amount?: string;
  note?: string;
}

// ——— Paths of mastery (v2) ———

/** The four tiers, lowest first. Foundation is open to everyone from the start. */
export type TierId = 'foundation' | 'acolyte' | 'initiate' | 'adept';
export const TIER_IDS: TierId[] = ['foundation', 'acolyte', 'initiate', 'adept'];

export type GoalStatus = 'open' | 'reached' | 'released';

/**
 * A goal (shown on the path as an open quest). Account-wide, like Journey areas.
 * Reaching one earns its gem once; releasing one is a choice, never a failure, and costs nothing.
 */
export interface Goal extends RecordBase {
  title: string;
  why?: string;
  element?: ElementId;
  areaId?: string;
  status: GoalStatus;
  reachedAt?: string;
  releasedAt?: string;
  /** A line in the person's own words when it was reached. */
  reflection?: string;
}

/**
 * One day's practice of a path lesson. One per lesson per local day (id `prc:<lessonId>:<YYYY-MM-DD>`),
 * so mastery always means practice on different days. Account-wide.
 */
export interface PracticeLog extends RecordBase {
  lessonId: string;
  day: string;
  /** The Space that was active (its gem goes there). */
  spaceId: SpaceId;
  note?: string;
}

export interface TierOpening {
  at: string;
  /** 'invited': the app offered it when ready. 'seeker': opened early, by sincere choice. */
  how: 'invited' | 'seeker';
  /** What draws the person to this path (asked when opening early). */
  note?: string;
}

export interface PathsState {
  opened: Partial<Record<TierId, TierOpening>>;
  /** "Not yet" on an invitation, so the teacher doesn't repeat it. */
  deferred: Partial<Record<TierId, string>>;
  /** Lesson id → when it was first mastered. Mastery, once reached, is kept. */
  mastered: Partial<Record<string, string>>;
  /** Badge id → when it was first earned. Badges, once earned, are kept. */
  badges: Partial<Record<string, string>>;
  updatedAt: string;
}

export interface JournalEntry extends RecordBase {
  spaceId: SpaceId;
  text: string;
  prompt?: string;
}

/** Gem transactions are immutable. Ids are derived from their source (e.g. `gem:checkin:<id>`) so a merge or replay can never duplicate one. */
export interface GemTx {
  id: string;
  spaceId: SpaceId;
  amount: number;
  reason: GemReason;
  sourceId?: string;
  createdAt: string;
}

export interface PracticeState {
  checkin?: { mood?: Level; energy?: Level; connection?: Level; note?: string; saved?: boolean };
  area?: { name?: string; impact?: Rating; difficulty?: Rating };
  evidence?: { kind?: EvidenceKind; text?: string; saved?: boolean };
  privacyAnswer?: 'only-me' | 'space' | 'everyone';
  journalText?: string;
  journalSaved?: boolean;
  spaceToggle?: SpaceId;
  gemRevealed?: boolean;
}

export interface GuideState {
  /** Lesson id → ISO time first completed. Completion is never undone by replay. */
  completed: Partial<Record<LessonId, string>>;
  /** Where to resume. */
  position?: { lesson: LessonId; step: number };
  /** The Today card was dismissed ("Not now"). The guide stays available in You. */
  cardDismissedAt?: string;
  /** Set once, the first time all five lessons are complete. */
  rewardGrantedAt?: string;
  practice: PracticeState;
  updatedAt: string;
}

export type IntakeAnswer = 'yes' | 'no' | 'skip';

export interface IntakeState {
  answers: Partial<Record<string, IntakeAnswer>>;
  /** Microdosing experience, self-reported. Optional. */
  experience?: Experience;
  /** Which question set the saved answers were given against (INTAKE_VERSION). */
  version?: string;
  completedAt?: string;
  updatedAt: string;
}

export interface Prefs {
  haptics: boolean;
  /** Tones while a check-in slider moves (web). On by default; the check-in card has a quick toggle. */
  sound: boolean;
  reduceMotion: 'system' | 'reduce';
  /** v3: which academy hall frames the app — the current lesson's element (default) or a fixed one. */
  hall?: 'lesson' | ElementId;
  updatedAt: string;
}

export interface Journey {
  format: 'companion.journey';
  /**
   * 2 = v2 (goals, path practice, paths). v2 reads version 1 journeys and upgrades them; the first
   * build refuses version 2, so it can never silently drop v2 records from a backup or a synced copy.
   */
  schemaVersion: 2;
  journeyId: string;
  createdAt: string;
  updatedAt: string;
  /** Monotonic local change counter. Used by sync to detect unsynced work. */
  revision: number;
  profile: Profile | null;
  activeSpaceId: SpaceId;
  checkins: CheckIn[];
  areas: Area[];
  evidence: Evidence[];
  harmony: HarmonySnapshot[];
  journal: JournalEntry[];
  protocols: ProtocolPlan[];
  dayNotes: DayNote[];
  /** v2: goals (open quests), practice of path lessons, and which paths are open. Older journeys have none. */
  goals: Goal[];
  practiceLogs: PracticeLog[];
  paths: PathsState;
  gems: GemTx[];
  guide: GuideState;
  intake: IntakeState;
  prefs: Prefs;
}
