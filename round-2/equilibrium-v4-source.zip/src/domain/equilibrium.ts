// Compass (formerly "Harmony"): what the four balances mean together, where to begin, and how
// they've moved over time. Built only from what the person reported — the overall number is the
// plain average of the four, and the spread is the gap between the highest and lowest. Nothing is
// weighted, hidden or scored against anyone.

import type { ElementId, HarmonySnapshot, Journey, SpaceId } from './types';
import { ELEMENT_IDS } from './types';
import { balances, bandFor, BalanceBand, ELEMENTS } from './harmony';

export interface EquilibriumState {
  values: Record<ElementId, number>;
  /** Average of the four balances, rounded. */
  overall: number;
  /** Highest balance minus lowest. Small = the elements move together; large = discord. */
  spread: number;
  lowest: ElementId;
  highest: ElementId;
  word: string;
  sentence: string;
}

export function spreadWord(spread: number): string {
  if (spread < 15) return 'In step';
  if (spread < 30) return 'A little uneven';
  if (spread < 50) return 'Uneven';
  return 'Pulling apart';
}

export function equilibriumOf(snap: Pick<HarmonySnapshot, 'ratings'>): EquilibriumState {
  const values = balances(snap.ratings);
  const list = ELEMENT_IDS.map((id) => ({ id, v: values[id] }));
  const overall = Math.round(list.reduce((n, x) => n + x.v, 0) / list.length);
  // Ties resolve in compass order (Fire, Air, Water, Earth).
  const lowest = list.reduce((a, b) => (b.v < a.v ? b : a)).id;
  const highest = list.reduce((a, b) => (b.v > a.v ? b : a)).id;
  const spread = values[highest] - values[lowest];
  const lo = ELEMENTS[lowest];
  const hi = ELEMENTS[highest];
  let word: string;
  let sentence: string;
  if (spread < 15) {
    if (overall >= 45) {
      word = 'In equilibrium';
      sentence = 'Your four elements are moving together, and what you have meets what is asked.';
    } else {
      word = 'Evenly stretched';
      sentence = 'All four elements are under similar pressure. Small supports anywhere will help everywhere.';
    }
  } else if (spread < 30) {
    word = 'Nearly balanced';
    sentence = `Mostly in step, with ${lo.name} (${lo.lens.toLowerCase()}) a little behind the rest.`;
  } else if (spread < 50) {
    word = 'Some discord';
    sentence = `${hi.name} (${hi.lens.toLowerCase()}) is carrying more than ${lo.name} (${lo.lens.toLowerCase()}). That gap is where to place your care.`;
  } else {
    word = 'In discord';
    sentence = `${lo.name} (${lo.lens.toLowerCase()}) is far behind ${hi.name} (${hi.lens.toLowerCase()}). Begin with ${lo.name}, gently.`;
  }
  return { values, overall, spread, lowest, highest, word, sentence };
}

// ——— Practices ———

export type PracticeNeed = 'restore' | 'sustain' | 'share';

export function needFor(band: BalanceBand): PracticeNeed {
  return band === 'strained' || band === 'stretched' ? 'restore' : band === 'even' ? 'sustain' : 'share';
}

export const NEED_TITLE: Record<PracticeNeed, string> = {
  restore: 'To come back toward even',
  sustain: 'To keep it steady',
  share: 'To put it to good use',
};

/** Small, ordinary practices. Reflection and self-care, not treatment. */
export const PRACTICES: Record<ElementId, Record<PracticeNeed, string[]>> = {
  fire: {
    restore: [
      'Shrink the next step until it takes five minutes, then take it.',
      'Choose one thing to drop, delay or hand off today.',
      'Move for ten minutes. A brisk walk lets pressure burn off instead of build.',
    ],
    sustain: ['Protect the one commitment that matters most today, and let the rest be enough.'],
    share: ['Spend your momentum on the thing you have been putting off.', 'Lend your energy: help someone else begin something.'],
  },
  air: {
    restore: [
      'Empty the open loops: write every task on one page, without sorting.',
      'Three slow breaths, each exhale longer than the inhale.',
      'One tab, one task, twenty-five minutes. Then a real break.',
    ],
    sustain: ['Leave a little white space in the day: ten minutes with no input.'],
    share: ['Plan, learn or make something while your mind is clear.', 'Write down the idea you keep circling back to.'],
  },
  water: {
    restore: [
      'Name what you feel in a single word. Naming softens it.',
      'Reach out to one person. A short message is enough.',
      'Let it move: music, a walk, or a few honest minutes in the journal.',
    ],
    sustain: ['Notice one moment of tenderness today and stay with it a breath longer.'],
    share: ['Offer care to someone who could use it.', 'Savor something good, on purpose, for thirty seconds.'],
  },
  earth: {
    restore: [
      'The basics first: water, a real meal, an earlier night.',
      'Feet on the floor, five slow breaths. Feel the weight of your body.',
      'Tidy one small surface. Order outside invites order inside.',
    ],
    sustain: ['Keep one steady routine: the same wake time, or the same walk.'],
    share: ['Build on your ground: start a routine you would like to keep.', 'Share what is steady. Cook for someone, or make room for them.'],
  },
};

export interface Suggestion {
  element: ElementId;
  need: PracticeNeed;
  practices: string[];
}

/** Where to begin: the lowest element first; and, when one is well resourced, how to use it. */
export function suggestions(state: EquilibriumState): { begin: Suggestion; draw?: Suggestion } {
  const lowBand = bandFor(state.values[state.lowest]);
  const begin: Suggestion = { element: state.lowest, need: needFor(lowBand), practices: PRACTICES[state.lowest][needFor(lowBand)] };
  const highBand = bandFor(state.values[state.highest]);
  const draw = state.highest !== state.lowest && (highBand === 'supported' || highBand === 'resourced') ? { element: state.highest, need: 'share' as const, practices: PRACTICES[state.highest].share } : undefined;
  return { begin, draw };
}

// ——— Trend ———

export interface TrendPoint {
  id: string;
  at: string;
  overall: number;
  spread: number;
  values: Record<ElementId, number>;
}

/** Readings in a Space, oldest first, most recent `n`. */
export function trend(j: Journey, space: SpaceId, n = 12): TrendPoint[] {
  return j.harmony
    .filter((h) => !h.deletedAt && h.spaceId === space)
    .sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1))
    .slice(-n)
    .map((h) => {
      const s = equilibriumOf(h);
      return { id: h.id, at: h.createdAt, overall: s.overall, spread: s.spread, values: s.values };
    });
}

/** Change from the first to the last point in a trend, per series. */
export function trendChange(points: TrendPoint[]): { overall: number; spread: number; values: Record<ElementId, number> } | null {
  if (points.length < 2) return null;
  const a = points[0];
  const b = points[points.length - 1];
  return {
    overall: b.overall - a.overall,
    spread: b.spread - a.spread,
    values: Object.fromEntries(ELEMENT_IDS.map((el) => [el, b.values[el] - a.values[el]])) as Record<ElementId, number>,
  };
}
