// Pure journey operations. Each takes the current journey and returns a new one.
// Gem rewards are written in the same step as the event that earns them, with
// deterministic ids, so a replay, restore or merge can never double-award.

import type {
  AgeBracket,
  DayNoteStatus,
  Area,
  DoseLevel,
  ProtocolPattern,
  ProtocolPlan,
  Experience,
  DirectionId,
  ElementId,
  ElementRating,
  EvidenceKind,
  GemReason,
  GemTx,
  GuideState,
  IntakeAnswer,
  Journey,
  LessonId,
  PracticeState,
  Level,
  Prefs,
  Rating,
  SpaceId,
  TierId,
  Goal,
  PathsState,
} from './types';
import { LESSON_IDS, ELEMENT_IDS, TIER_IDS } from './types';
import { gemId, newId } from './ids';
import { GEM_AMOUNTS, GUIDE_REWARD_SPACE } from './gems';
import { isLevel, isRating } from './scales';
import { isAdult, isAgeBracket } from './age';
import { isDayKey, patternProblem } from './protocols';
import { evaluateIntake, INTAKE_QUESTIONS, INTAKE_VERSION } from './intake';
import { isTierOpen, LESSON_BY_ID, previousTier, readiness, TIERS } from './paths';
import { newMilestones } from './character';
import { localDayKey } from './time';

export class OpError extends Error {}

const iso = (now: Date) => now.toISOString();

export function emptyJourney(now: Date = new Date(), journeyId: string = newId('jrn')): Journey {
  const t = iso(now);
  return {
    format: 'companion.journey',
    schemaVersion: 2,
    journeyId,
    createdAt: t,
    updatedAt: t,
    revision: 0,
    profile: null,
    activeSpaceId: 'personal',
    checkins: [],
    areas: [],
    evidence: [],
    harmony: [],
    journal: [],
    protocols: [],
    dayNotes: [],
    goals: [],
    practiceLogs: [],
    paths: emptyPaths(t),
    gems: [],
    guide: { completed: {}, practice: {}, updatedAt: t },
    intake: { answers: {}, updatedAt: t },
    prefs: { haptics: true, sound: true, reduceMotion: 'system', updatedAt: t },
  };
}

export function emptyPaths(t: string): PathsState {
  return { opened: {}, deferred: {}, mastered: {}, badges: {}, updatedAt: t };
}

function touch(j: Journey, now: Date): Journey {
  return { ...j, updatedAt: iso(now), revision: j.revision + 1 };
}

function award(j: Journey, reason: GemReason, spaceId: SpaceId, sourceId: string | undefined, now: Date): GemTx[] {
  const id = gemId(reason, sourceId);
  if (j.gems.some((g) => g.id === id)) return j.gems;
  return [...j.gems, { id, spaceId, amount: GEM_AMOUNTS[reason], reason, sourceId, createdAt: iso(now) }];
}

function cleanText(s: string | undefined, max = 8000): string | undefined {
  if (s == null) return undefined;
  const t = s.replace(/\r\n/g, '\n').trim();
  return t.length ? t.slice(0, max) : undefined;
}

function assertRating(v: unknown, what: string): asserts v is Rating {
  if (!isRating(v)) throw new OpError(`${what} must be a whole number from 1 to 5.`);
}

function assertLevel(v: unknown, what: string): asserts v is Level {
  if (!isLevel(v)) throw new OpError(`${what} must be a whole number from 0 to 100.`);
}

// ——— Profile & onboarding ———

export interface OnboardingInput {
  name: string;
  handle?: string;
  ageBracket: AgeBracket;
  spaceId: SpaceId;
  directions: DirectionId[];
}

export function completeOnboarding(j: Journey, input: OnboardingInput, now: Date = new Date()): Journey {
  const name = cleanText(input.name, 60);
  if (!name) throw new OpError('Please add a name.');
  if (!isAgeBracket(input.ageBracket) || input.ageBracket === 'adult') throw new OpError('Please choose an age range.');
  const t = iso(now);
  const minor = input.ageBracket === 'under18';
  return touch(
    {
      ...j,
      profile: {
        name,
        handle: normalizeHandle(input.handle),
        ageBracket: input.ageBracket,
        chosenDirections: input.directions.slice(0, 2),
        createdAt: j.profile?.createdAt ?? t,
        updatedAt: t,
      },
      activeSpaceId: minor ? 'personal' : input.spaceId,
    },
    now,
  );
}

export function normalizeHandle(h: string | undefined): string | undefined {
  if (!h) return undefined;
  const t = h.trim().replace(/^@+/, '').toLowerCase().replace(/[^a-z0-9_.]/g, '').slice(0, 30);
  return t.length ? t : undefined;
}

export function updateProfile(j: Journey, patch: { name?: string; handle?: string; ageBracket?: AgeBracket }, now: Date = new Date()): Journey {
  if (!j.profile) throw new OpError('No profile yet.');
  const name = patch.name !== undefined ? cleanText(patch.name, 60) : j.profile.name;
  if (!name) throw new OpError('Please add a name.');
  const handle = patch.handle !== undefined ? normalizeHandle(patch.handle) : j.profile.handle;
  const ageBracket = patch.ageBracket ?? j.profile.ageBracket;
  if (!isAgeBracket(ageBracket)) throw new OpError('Please choose an age range.');
  // Reflection mode keeps everything in Personal; Be Well entries stay saved, just out of view.
  const activeSpaceId = ageBracket === 'under18' ? 'personal' : j.activeSpaceId;
  return touch({ ...j, activeSpaceId, profile: { ...j.profile, name, handle, ageBracket, updatedAt: iso(now) } }, now);
}

export function setChosenDirections(j: Journey, dirs: DirectionId[], now: Date = new Date()): Journey {
  if (!j.profile) throw new OpError('No profile yet.');
  const unique = Array.from(new Set(dirs)).slice(0, 2);
  return touch({ ...j, profile: { ...j.profile, chosenDirections: unique, updatedAt: iso(now) } }, now);
}

export function setActiveSpace(j: Journey, spaceId: SpaceId, now: Date = new Date()): Journey {
  if (j.activeSpaceId === spaceId) return j;
  if (spaceId === 'bewell' && j.profile?.ageBracket === 'under18') throw new OpError('The Be Well Space is for adults 18 and over.');
  return touch({ ...j, activeSpaceId: spaceId }, now);
}

// ——— Today: check-ins ———

export interface CheckInInput {
  mood: Level;
  energy: Level;
  connection: Level;
  note?: string;
}

export function addCheckIn(j: Journey, input: CheckInInput, now: Date = new Date(), id: string = newId('chk')): Journey {
  assertLevel(input.mood, 'Mood');
  assertLevel(input.energy, 'Energy');
  assertLevel(input.connection, 'Connection');
  const t = iso(now);
  const spaceId = j.activeSpaceId;
  const next: Journey = {
    ...j,
    checkins: [
      ...j.checkins,
      { id, spaceId, createdAt: t, updatedAt: t, mood: input.mood, energy: input.energy, connection: input.connection, scale: 100, note: cleanText(input.note, 2000) },
    ],
  };
  next.gems = award(next, 'checkin', spaceId, id, now);
  return touch(next, now);
}

export function deleteCheckIn(j: Journey, id: string, now: Date = new Date()): Journey {
  const t = iso(now);
  return touch({ ...j, checkins: j.checkins.map((c) => (c.id === id ? { ...c, deletedAt: t, updatedAt: t, note: undefined } : c)) }, now);
}

// ——— Journey: areas and evidence ———

export interface AreaInput {
  name: string;
  impact: Rating;
  difficulty: Rating;
  direction?: DirectionId;
}

export function addArea(j: Journey, input: AreaInput, now: Date = new Date(), id: string = newId('area')): Journey {
  const name = cleanText(input.name, 120);
  if (!name) throw new OpError('Give this area a name.');
  assertRating(input.impact, 'Impact');
  assertRating(input.difficulty, 'Difficulty');
  const t = iso(now);
  const area: Area = { id, name, impact: input.impact, difficulty: input.difficulty, direction: input.direction, createdAt: t, updatedAt: t };
  return touch({ ...j, areas: [...j.areas, area] }, now);
}

export function updateArea(j: Journey, id: string, input: AreaInput, now: Date = new Date()): Journey {
  const name = cleanText(input.name, 120);
  if (!name) throw new OpError('Give this area a name.');
  assertRating(input.impact, 'Impact');
  assertRating(input.difficulty, 'Difficulty');
  const t = iso(now);
  if (!j.areas.some((a) => a.id === id && !a.deletedAt)) throw new OpError('That area no longer exists.');
  return touch(
    {
      ...j,
      areas: j.areas.map((a) =>
        a.id === id ? { ...a, name, impact: input.impact, difficulty: input.difficulty, direction: input.direction, updatedAt: t } : a,
      ),
    },
    now,
  );
}

export function deleteArea(j: Journey, id: string, now: Date = new Date()): Journey {
  const t = iso(now);
  return touch(
    {
      ...j,
      areas: j.areas.map((a) => (a.id === id ? { ...a, deletedAt: t, updatedAt: t } : a)),
      evidence: j.evidence.map((e) => (e.areaId === id && !e.deletedAt ? { ...e, deletedAt: t, updatedAt: t } : e)),
    },
    now,
  );
}

export interface EvidenceInput {
  areaId: string;
  kind: EvidenceKind;
  text: string;
}

export function addEvidence(j: Journey, input: EvidenceInput, now: Date = new Date(), id: string = newId('ev')): Journey {
  const text = cleanText(input.text, 2000);
  if (!text) throw new OpError('Describe what happened, even in a few words.');
  if (!['win', 'observation', 'setback'].includes(input.kind)) throw new OpError('Choose win, observation or setback.');
  if (!j.areas.some((a) => a.id === input.areaId && !a.deletedAt)) throw new OpError('That area no longer exists.');
  const t = iso(now);
  const spaceId = j.activeSpaceId;
  const next: Journey = {
    ...j,
    evidence: [...j.evidence, { id, areaId: input.areaId, kind: input.kind, text, spaceId, createdAt: t, updatedAt: t }],
  };
  next.gems = award(next, 'evidence', spaceId, id, now);
  return touch(next, now);
}

export function deleteEvidence(j: Journey, id: string, now: Date = new Date()): Journey {
  const t = iso(now);
  return touch({ ...j, evidence: j.evidence.map((e) => (e.id === id ? { ...e, deletedAt: t, updatedAt: t } : e)) }, now);
}

// ——— Harmony ———

export function addHarmony(
  j: Journey,
  ratings: Record<ElementId, ElementRating>,
  note: string | undefined,
  now: Date = new Date(),
  id: string = newId('hrm'),
): Journey {
  for (const el of ELEMENT_IDS) {
    assertRating(ratings[el]?.pressure, `${el} pressure`);
    assertRating(ratings[el]?.resource, `${el} resource`);
  }
  const t = iso(now);
  const spaceId = j.activeSpaceId;
  const copy = Object.fromEntries(ELEMENT_IDS.map((el) => [el, { pressure: ratings[el].pressure, resource: ratings[el].resource }])) as Record<
    ElementId,
    ElementRating
  >;
  const next: Journey = { ...j, harmony: [...j.harmony, { id, spaceId, createdAt: t, updatedAt: t, ratings: copy, note: cleanText(note, 2000) }] };
  next.gems = award(next, 'harmony', spaceId, id, now);
  return touch(next, now);
}

export function deleteHarmony(j: Journey, id: string, now: Date = new Date()): Journey {
  const t = iso(now);
  return touch({ ...j, harmony: j.harmony.map((h) => (h.id === id ? { ...h, deletedAt: t, updatedAt: t, note: undefined } : h)) }, now);
}

// ——— Journal ———

export function addJournal(j: Journey, text: string, prompt: string | undefined, now: Date = new Date(), id: string = newId('jnl')): Journey {
  const body = cleanText(text, 20000);
  if (!body) throw new OpError('Write something first. Even a line counts.');
  const t = iso(now);
  const spaceId = j.activeSpaceId;
  const next: Journey = { ...j, journal: [...j.journal, { id, spaceId, createdAt: t, updatedAt: t, text: body, prompt: cleanText(prompt, 200) }] };
  next.gems = award(next, 'journal', spaceId, id, now);
  return touch(next, now);
}

export function editJournal(j: Journey, id: string, text: string, now: Date = new Date()): Journey {
  const body = cleanText(text, 20000);
  if (!body) throw new OpError("An entry can't be empty. Delete it instead if you'd like it gone.");
  const cur = j.journal.find((e) => e.id === id);
  if (cur && cur.text === body) return j; // nothing changed: don't mark it edited
  const t = iso(now);
  return touch({ ...j, journal: j.journal.map((e) => (e.id === id ? { ...e, text: body, updatedAt: t } : e)) }, now);
}

export function deleteJournal(j: Journey, id: string, now: Date = new Date()): Journey {
  const t = iso(now);
  // Tombstone keeps the id (so a merge can't resurrect it) but drops the private text.
  return touch({ ...j, journal: j.journal.map((e) => (e.id === id ? { ...e, text: '', prompt: undefined, deletedAt: t, updatedAt: t } : e)) }, now);
}

// ——— Guided first steps ———

function withGuide(j: Journey, guide: Partial<GuideState>, now: Date): Journey {
  return touch({ ...j, guide: { ...j.guide, ...guide, updatedAt: iso(now) } }, now);
}

export function setGuidePosition(j: Journey, lesson: LessonId, step: number, now: Date = new Date()): Journey {
  return withGuide(j, { position: { lesson, step } }, now);
}

export function setPractice(j: Journey, patch: Partial<PracticeState>, now: Date = new Date()): Journey {
  return withGuide(j, { practice: { ...j.guide.practice, ...patch } }, now);
}

export function dismissGuideCard(j: Journey, now: Date = new Date()): Journey {
  return withGuide(j, { cardDismissedAt: iso(now) }, now);
}

export function restoreGuideCard(j: Journey, now: Date = new Date()): Journey {
  return withGuide(j, { cardDismissedAt: undefined }, now);
}

/**
 * Marks a lesson complete (first completion time is kept on replay).
 * When all five are complete for the first time, grants the one-time reward to Personal.
 */
export function completeLesson(j: Journey, lesson: LessonId, now: Date = new Date()): { journey: Journey; rewarded: boolean } {
  const t = iso(now);
  const completed = { ...j.guide.completed, [lesson]: j.guide.completed[lesson] ?? t };
  const all = LESSON_IDS.every((l) => !!completed[l]);
  let next: Journey = { ...j, guide: { ...j.guide, completed, updatedAt: t } };
  let rewarded = false;
  const alreadyRewarded = !!j.guide.rewardGrantedAt || j.gems.some((g) => g.id === gemId('guide-complete'));
  if (all && !alreadyRewarded) {
    next = { ...next, gems: award(next, 'guide-complete', GUIDE_REWARD_SPACE, undefined, now), guide: { ...next.guide, rewardGrantedAt: t } };
    rewarded = true;
  }
  return { journey: touch(next, now), rewarded };
}

const PRACTICE_KEYS: Record<LessonId, (keyof PracticeState)[]> = {
  today: ['checkin'],
  journey: ['area', 'evidence'],
  connect: ['privacyAnswer'],
  journal: ['journalText', 'journalSaved'],
  you: ['spaceToggle', 'gemRevealed'],
};

/** Clear one lesson's practice answers so a replay starts fresh. Never touches completion or rewards. */
export function resetLessonPractice(j: Journey, lesson: LessonId, now: Date = new Date()): Journey {
  const practice = { ...j.guide.practice };
  let changed = false;
  for (const k of PRACTICE_KEYS[lesson]) {
    if (practice[k] !== undefined) {
      delete practice[k];
      changed = true;
    }
  }
  return changed ? withGuide(j, { practice }, now) : j;
}

export function resetPractice(j: Journey, now: Date = new Date()): Journey {
  return withGuide(j, { practice: {}, position: undefined }, now);
}

// ——— Safety & Path (placeholder intake) ———

export function saveIntake(
  j: Journey,
  answers: Partial<Record<string, IntakeAnswer>>,
  complete: boolean,
  now: Date = new Date(),
  experience: Experience | undefined = j.intake.experience,
): Journey {
  const t = iso(now);
  const known = Object.fromEntries(Object.entries(answers).filter(([k]) => INTAKE_QUESTIONS.some((q) => q.id === k)));
  return touch(
    { ...j, intake: { answers: known, experience, version: INTAKE_VERSION, completedAt: complete ? t : j.intake.completedAt, updatedAt: t } },
    now,
  );
}

export function clearIntake(j: Journey, now: Date = new Date()): Journey {
  return touch({ ...j, intake: { answers: {}, updatedAt: iso(now) } }, now);
}

// ——— Protocols (adults only) ———

export interface ProtocolInput {
  presetId: string;
  name: string;
  pattern: ProtocolPattern;
  startDate: string;
  cycleWeeks?: number;
  restWeeks?: number;
  level?: DoseLevel;
  substance?: string;
  amount?: string;
  intention?: string;
}

function assertProtocolAllowed(j: Journey) {
  if (!isAdult(j)) throw new OpError('Protocols are for adults 18 and over.');
  if (evaluateIntake(j.intake).supportNow) throw new OpError('Support comes first. When you feel safe, update Safety & Path and come back.');
}

function cleanProtocol(input: ProtocolInput): Omit<ProtocolPlan, 'id' | 'createdAt' | 'updatedAt' | 'status'> {
  const name = cleanText(input.name, 60);
  if (!name) throw new OpError('Give your protocol a name.');
  const pattern: ProtocolPattern = input.pattern.type === 'cycle' ? { type: 'cycle', on: input.pattern.on, off: input.pattern.off } : { type: 'weekdays', days: Array.from(new Set(input.pattern.days)).sort((a, b) => a - b) };
  const problem = patternProblem(pattern);
  if (problem) throw new OpError(problem);
  if (!isDayKey(input.startDate)) throw new OpError('Choose a start date.');
  const hasCycle = input.cycleWeeks !== undefined || input.restWeeks !== undefined;
  if (hasCycle) {
    if (!Number.isInteger(input.cycleWeeks) || input.cycleWeeks! < 1 || input.cycleWeeks! > 26) throw new OpError('Practice weeks must be from 1 to 26.');
    if (!Number.isInteger(input.restWeeks) || input.restWeeks! < 1 || input.restWeeks! > 12) throw new OpError('Rest weeks must be from 1 to 12.');
  }
  if (input.level !== undefined && !['micro', 'minor', 'unsure'].includes(input.level)) throw new OpError('Unknown level.');
  return {
    presetId: cleanText(input.presetId, 40) || 'custom',
    name,
    pattern,
    startDate: input.startDate,
    cycleWeeks: hasCycle ? input.cycleWeeks : undefined,
    restWeeks: hasCycle ? input.restWeeks : undefined,
    level: input.level,
    substance: cleanText(input.substance, 80),
    amount: cleanText(input.amount, 40),
    intention: cleanText(input.intention, 200),
  };
}

/** Start a protocol. Any current one is finished first, so there is only ever one. */
export function startProtocol(j: Journey, input: ProtocolInput, now: Date = new Date(), id: string = newId('pro')): Journey {
  assertProtocolAllowed(j);
  const fields = cleanProtocol(input);
  const t = iso(now);
  const ended = j.protocols.map((p) => (!p.deletedAt && p.status !== 'finished' ? { ...p, status: 'finished' as const, endedAt: t, updatedAt: t } : p));
  return touch({ ...j, protocols: [...ended, { id, createdAt: t, updatedAt: t, status: 'active', ...fields }] }, now);
}

function patchProtocol(j: Journey, id: string, fn: (p: ProtocolPlan, t: string) => ProtocolPlan, now: Date): Journey {
  const t = iso(now);
  if (!j.protocols.some((p) => p.id === id && !p.deletedAt)) throw new OpError('That protocol no longer exists.');
  return touch({ ...j, protocols: j.protocols.map((p) => (p.id === id ? { ...fn(p, t), updatedAt: t } : p)) }, now);
}

export function updateProtocol(j: Journey, id: string, input: ProtocolInput, now: Date = new Date()): Journey {
  assertProtocolAllowed(j);
  const fields = cleanProtocol(input);
  return patchProtocol(j, id, (p) => ({ ...p, ...fields }), now);
}

export function pauseProtocol(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchProtocol(j, id, (p, t) => (p.status === 'active' ? { ...p, status: 'paused', pausedAt: t } : p), now);
}

/** Resuming restarts the rhythm from `fromDay` (usually today). */
export function resumeProtocol(j: Journey, id: string, fromDay: string, now: Date = new Date()): Journey {
  assertProtocolAllowed(j);
  if (!isDayKey(fromDay)) throw new OpError('Choose a day to restart from.');
  return patchProtocol(j, id, (p) => (p.status === 'paused' ? { ...p, status: 'active', pausedAt: undefined, startDate: fromDay } : p), now);
}

export function endProtocol(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchProtocol(j, id, (p, t) => (p.status !== 'finished' ? { ...p, status: 'finished', endedAt: t, pausedAt: undefined } : p), now);
}

/** Remove a protocol from history (tombstone; its notes are dropped). */
export function deleteProtocol(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchProtocol(j, id, (p, t) => ({ ...p, status: 'finished', deletedAt: t, substance: undefined, amount: undefined, intention: undefined }), now);
}

// ——— Day notes (adults only) ———

export interface DayNoteInput {
  day: string;
  status: DayNoteStatus;
  protocolId?: string;
  substance?: string;
  amount?: string;
  note?: string;
}

export const dayNoteId = (day: string) => `day:${day}`;

/** Save (or replace) the note for one calendar day. */
export function saveDayNote(j: Journey, input: DayNoteInput, now: Date = new Date()): Journey {
  if (!isAdult(j)) throw new OpError('Day notes are for adults 18 and over.');
  if (!isDayKey(input.day)) throw new OpError('Choose a day.');
  if (!['taken', 'skipped', 'off'].includes(input.status)) throw new OpError('Choose taken, skipped or integration day.');
  const t = iso(now);
  const id = dayNoteId(input.day);
  const prev = j.dayNotes.find((n) => n.id === id);
  const taken = input.status === 'taken';
  const note = {
    id,
    day: input.day,
    status: input.status,
    protocolId: input.protocolId,
    substance: taken ? cleanText(input.substance, 80) : undefined,
    amount: taken ? cleanText(input.amount, 40) : undefined,
    note: cleanText(input.note, 2000),
    createdAt: prev && !prev.deletedAt ? prev.createdAt : t,
    updatedAt: t,
  };
  return touch({ ...j, dayNotes: [...j.dayNotes.filter((n) => n.id !== id), note] }, now);
}

export function deleteDayNote(j: Journey, day: string, now: Date = new Date()): Journey {
  const id = dayNoteId(day);
  if (!j.dayNotes.some((n) => n.id === id && !n.deletedAt)) return j;
  const t = iso(now);
  return touch({ ...j, dayNotes: j.dayNotes.map((n) => (n.id === id ? { id, day, status: n.status, createdAt: n.createdAt, updatedAt: t, deletedAt: t } : n)) }, now);
}

// ——— Preferences ———

export function setPrefs(j: Journey, patch: Partial<Omit<Prefs, 'updatedAt'>>, now: Date = new Date()): Journey {
  return touch({ ...j, prefs: { ...j.prefs, ...patch, updatedAt: iso(now) } }, now);
}

// ——— Goals (v2: open quests on the path) ———

export interface GoalInput {
  title: string;
  why?: string;
  element?: ElementId;
  areaId?: string;
}

function cleanGoal(j: Journey, input: GoalInput): Pick<Goal, 'title' | 'why' | 'element' | 'areaId'> {
  const title = cleanText(input.title, 120);
  if (!title) throw new OpError('Name your goal, even in a few words.');
  if (input.element !== undefined && !ELEMENT_IDS.includes(input.element)) throw new OpError('Unknown element.');
  const areaId = input.areaId && j.areas.some((a) => a.id === input.areaId && !a.deletedAt) ? input.areaId : undefined;
  return { title, why: cleanText(input.why, 400), element: input.element, areaId };
}

export function addGoal(j: Journey, input: GoalInput, now: Date = new Date(), id: string = newId('goal')): Journey {
  const fields = cleanGoal(j, input);
  const t = iso(now);
  return touch({ ...j, goals: [...(j.goals ?? []), { id, createdAt: t, updatedAt: t, status: 'open', ...fields }] }, now);
}

function patchGoal(j: Journey, id: string, fn: (g: Goal, t: string) => Goal, now: Date): Journey {
  const goals = j.goals ?? [];
  if (!goals.some((g) => g.id === id && !g.deletedAt)) throw new OpError('That goal no longer exists.');
  const t = iso(now);
  return touch({ ...j, goals: goals.map((g) => (g.id === id ? { ...fn(g, t), updatedAt: t } : g)) }, now);
}

export function updateGoal(j: Journey, id: string, input: GoalInput, now: Date = new Date()): Journey {
  const fields = cleanGoal(j, input);
  return patchGoal(j, id, (g) => ({ ...g, ...fields }), now);
}

/** Mark a goal reached. Its gem (to the active Space) is earned once, ever, even if it is reopened later. */
export function reachGoal(j: Journey, id: string, reflection?: string, now: Date = new Date()): Journey {
  const next = patchGoal(j, id, (g, t) => ({ ...g, status: 'reached', reachedAt: g.status === 'reached' && g.reachedAt ? g.reachedAt : t, releasedAt: undefined, reflection: cleanText(reflection, 400) }), now);
  return { ...next, gems: award(next, 'goal', j.activeSpaceId, id, now) };
}

/** Let a goal go. A choice, never a failure: nothing is taken away. */
export function releaseGoal(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchGoal(j, id, (g, t) => ({ ...g, status: 'released', releasedAt: t, reachedAt: undefined, reflection: undefined }), now);
}

export function reopenGoal(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchGoal(j, id, (g) => ({ ...g, status: 'open', reachedAt: undefined, releasedAt: undefined, reflection: undefined }), now);
}

export function deleteGoal(j: Journey, id: string, now: Date = new Date()): Journey {
  return patchGoal(j, id, (g, t) => ({ ...g, deletedAt: t, why: undefined, reflection: undefined }), now);
}

// ——— Path practice (v2) ———

export const practiceLogId = (lessonId: string, day: string) => `prc:${lessonId}:${day}`;

/** Log one day's practice of a lesson. One per lesson per day; logging again that day updates the note. */
export function logPractice(j: Journey, lessonId: string, day: string, note?: string, now: Date = new Date()): Journey {
  const lesson = LESSON_BY_ID[lessonId];
  if (!lesson || lesson.measure.type !== 'logged') throw new OpError('That lesson is practiced another way.');
  if (!isTierOpen(j, lesson.tier)) throw new OpError(`Open the ${lesson.tier} path to practice this lesson.`);
  if (!isDayKey(day)) throw new OpError('Choose a day.');
  if (day > localDayKey(now)) throw new OpError('Practice can only be noted for today or earlier.');
  const id = practiceLogId(lessonId, day);
  const logs = j.practiceLogs ?? [];
  const prev = logs.find((p) => p.id === id);
  const t = iso(now);
  const spaceId = prev && !prev.deletedAt ? prev.spaceId : j.activeSpaceId;
  const entry = { id, lessonId, day, spaceId, note: cleanText(note, 1000), createdAt: prev && !prev.deletedAt ? prev.createdAt : t, updatedAt: t };
  const next: Journey = { ...j, practiceLogs: [...logs.filter((p) => p.id !== id), entry] };
  next.gems = award(next, 'practice', spaceId, id, now);
  return touch(next, now);
}

/** Remove a day's practice (tombstone; its note is dropped). Its gem stays: it recognized showing up. */
export function unlogPractice(j: Journey, lessonId: string, day: string, now: Date = new Date()): Journey {
  const id = practiceLogId(lessonId, day);
  const logs = j.practiceLogs ?? [];
  const prev = logs.find((p) => p.id === id && !p.deletedAt);
  if (!prev) return j;
  const t = iso(now);
  return touch({ ...j, practiceLogs: logs.map((p) => (p.id === id ? { id, lessonId, day, spaceId: p.spaceId, createdAt: p.createdAt, updatedAt: t, deletedAt: t } : p)) }, now);
}

// ——— Opening paths (v2) ———

/**
 * Open the next path. 'invited' requires readiness on the path before it; 'seeker' opens it early
 * and asks what draws the person to it. Paths open one at a time, in order.
 */
export function openTier(j: Journey, tier: TierId, how: 'invited' | 'seeker', note: string | undefined, today: string, now: Date = new Date()): Journey {
  if (!TIER_IDS.includes(tier) || tier === 'foundation') throw new OpError('That path is already open.');
  if (isTierOpen(j, tier)) return j;
  if (TIERS[tier].outline) throw new OpError(`The ${TIERS[tier].name} lessons are still being prepared. This path opens when they’re ready.`);
  const prev = previousTier(tier)!;
  if (!isTierOpen(j, prev)) throw new OpError('Paths open one at a time. Open the path before this one first.');
  const why = cleanText(note, 600);
  if (how === 'invited' && !readiness(j, prev, today).ready) throw new OpError('This path hasn’t been offered yet. You can still open it as a sincere seeker.');
  if (how === 'seeker' && (!why || why.length < 8)) throw new OpError('Say, in a sentence, what draws you to this path.');
  const t = iso(now);
  const paths = j.paths ?? emptyPaths(t);
  return touch({ ...j, paths: { ...paths, opened: { ...paths.opened, [tier]: { at: t, how, note: why } }, updatedAt: t } }, now);
}

/** "Not yet" on an invitation: the teacher lets it rest for a while. The path stays openable. */
export function deferInvitation(j: Journey, tier: TierId, now: Date = new Date()): Journey {
  const t = iso(now);
  const paths = j.paths ?? emptyPaths(t);
  return touch({ ...j, paths: { ...paths, deferred: { ...paths.deferred, [tier]: t }, updatedAt: t } }, now);
}

/**
 * Keep milestones: the first time a lesson is mastered or a badge earned, record when. After that it
 * stays, even if a practice is removed or a goal reopened. Returns the same journey when nothing is new.
 */
export function recordMilestones(j: Journey, now: Date = new Date()): Journey {
  const fresh = newMilestones(j);
  if (!fresh.lessons.length && !fresh.badges.length) return j;
  const t = iso(now);
  const paths = j.paths ?? emptyPaths(t);
  const mastered = { ...(paths.mastered ?? {}) };
  for (const id of fresh.lessons) mastered[id] = t;
  const badges = { ...(paths.badges ?? {}) };
  for (const b of fresh.badges) badges[b.id] = b.at && b.at <= t ? b.at : t;
  return touch({ ...j, paths: { ...paths, mastered, badges, updatedAt: t } }, now);
}
