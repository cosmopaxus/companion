// Backup export and validated restore.
// Restore never applies anything until the whole file has been checked. Validation rebuilds
// every record from known fields only, so unexpected keys in a file are dropped rather than trusted.

import type {
  Area,
  CheckIn,
  DayNote,
  ProtocolPattern,
  ProtocolPlan,
  ProtocolStatus,
  DirectionId,
  ElementId,
  ElementRating,
  Evidence,
  GemTx,
  GuideState,
  HarmonySnapshot,
  IntakeState,
  Journey,
  JournalEntry,
  LessonId,
  Prefs,
  Profile,
  SpaceId,
  Goal,
  PracticeLog,
  PathsState,
  TierId,
  TierOpening,
} from './types';
import { DIRECTION_IDS, ELEMENT_IDS, EVIDENCE_KINDS, GEM_REASONS, LESSON_IDS, SPACE_IDS, TIER_IDS } from './types';
import { LESSON_BY_ID, TIERS } from './paths';
import { BADGE_IDS } from './character';
import { isLevel, isRating, levelFromRating } from './scales';
import { isAgeBracket } from './age';
import { isDayKey, patternProblem } from './protocols';
import { counts, JourneyCounts } from './selectors';

export const BACKUP_FORMAT = 'companion.backup';
export const BACKUP_VERSION = 1;

export interface BackupFile {
  format: typeof BACKUP_FORMAT;
  version: typeof BACKUP_VERSION;
  exportedAt: string;
  app: string;
  journey: Journey;
}

export function makeBackup(j: Journey, now: Date = new Date()): BackupFile {
  return { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: now.toISOString(), app: 'equilibrium v3 graphics & interface (claude build)', journey: j };
}

export function backupFileName(now: Date = new Date()): string {
  const d = now.toISOString().slice(0, 10);
  return `companion-backup-${d}.json`;
}

export type RestoreCheck =
  | { ok: true; journey: Journey; counts: JourneyCounts; exportedAt?: string; name?: string; dropped: number; problems: string[] }
  | { ok: false; errors: string[] };

export interface CheckOptions {
  /**
   * Lenient mode is for reading this device's own saved journey: records that fail validation are
   * set aside (counted in `dropped`) instead of failing the whole load. Restore stays strict.
   */
  lenient?: boolean;
}

const MAX_BYTES = 15 * 1024 * 1024;

class Collector {
  errors: string[] = [];
  count = 0;
  add(msg: string) {
    this.count += 1;
    if (this.errors.length < 8) this.errors.push(msg);
  }
}

const isObj = (v: unknown): v is Record<string, any> => typeof v === 'object' && v !== null && !Array.isArray(v);
const isIso = (v: unknown): v is string => typeof v === 'string' && v.length >= 10 && !Number.isNaN(Date.parse(v));
const isStr = (v: unknown, max = 20000): v is string => typeof v === 'string' && v.length <= max;
const optStr = (v: unknown, max = 20000): string | undefined => (typeof v === 'string' && v.length <= max && v.length > 0 ? v : undefined);
const isSpace = (v: unknown): v is SpaceId => SPACE_IDS.includes(v as SpaceId);
const isDirection = (v: unknown): v is DirectionId => DIRECTION_IDS.includes(v as DirectionId);

function base(r: Record<string, any>, where: string, c: Collector): { id: string; createdAt: string; updatedAt: string; deletedAt?: string } | null {
  if (!isStr(r.id, 200) || !r.id) {
    c.add(`${where}: missing an id.`);
    return null;
  }
  if (!isIso(r.createdAt)) {
    c.add(`${where}: invalid createdAt time.`);
    return null;
  }
  const updatedAt = isIso(r.updatedAt) ? r.updatedAt : r.createdAt;
  return { id: r.id, createdAt: r.createdAt, updatedAt, deletedAt: isIso(r.deletedAt) ? r.deletedAt : undefined };
}

function arr(v: unknown, name: string, c: Collector): any[] {
  if (v === undefined) return [];
  if (!Array.isArray(v)) {
    c.add(`"${name}" should be a list.`);
    return [];
  }
  return v;
}

function uniqueIds<T extends { id: string }>(list: T[], name: string, c: Collector): T[] {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const r of list) {
    if (seen.has(r.id)) {
      c.add(`${name}: the id ${r.id} appears twice.`);
      continue;
    }
    seen.add(r.id);
    out.push(r);
  }
  return out;
}

export function checkBackupText(text: string, opts: CheckOptions = {}): RestoreCheck {
  if (typeof text !== 'string' || !text.trim()) return { ok: false, errors: ['The file is empty.'] };
  if (text.length > MAX_BYTES) return { ok: false, errors: ['The file is too large to be an Equilibrium backup.'] };
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, errors: ["This isn't valid JSON, so it can't be an Equilibrium backup."] };
  }
  return checkBackup(parsed, opts);
}

export function checkBackup(input: unknown, opts: CheckOptions = {}): RestoreCheck {
  const c = new Collector();
  if (!isObj(input)) return { ok: false, errors: ["This doesn't look like an Equilibrium backup."] };
  let raw: any = input;
  let exportedAt: string | undefined;
  if (input.format === BACKUP_FORMAT) {
    if (input.version !== BACKUP_VERSION) return { ok: false, errors: [`This backup uses version ${String(input.version)}, which this build can't read.`] };
    raw = input.journey;
    exportedAt = isIso(input.exportedAt) ? input.exportedAt : undefined;
  }
  if (!isObj(raw) || raw.format !== 'companion.journey') {
    return { ok: false, errors: ["This doesn't look like an Equilibrium backup (missing the journey section)."] };
  }
  if (raw.schemaVersion !== 1 && raw.schemaVersion !== 2) return { ok: false, errors: [`Unsupported journey schema version: ${String(raw.schemaVersion)}.`] };
  if (!isStr(raw.journeyId, 200) || !raw.journeyId) c.add('The journey is missing its id.');
  if (!isIso(raw.createdAt)) c.add('The journey has an invalid creation time.');

  // Profile
  let profile: Profile | null = null;
  if (raw.profile != null) {
    const p = raw.profile;
    if (!isObj(p) || !isStr(p.name, 60) || !p.name.trim()) c.add('Profile: a name is required.');
    else {
      const dirs = Array.isArray(p.chosenDirections) ? p.chosenDirections.filter(isDirection).slice(0, 2) : [];
      profile = {
        name: p.name.trim(),
        handle: optStr(p.handle, 30),
        // Journeys from before age brackets carry only the 18+ confirmation.
        ageBracket: isAgeBracket(p.ageBracket) ? p.ageBracket : 'adult',
        chosenDirections: dirs,
        createdAt: isIso(p.createdAt) ? p.createdAt : raw.createdAt,
        updatedAt: isIso(p.updatedAt) ? p.updatedAt : raw.createdAt,
      };
      if (!isAgeBracket(p.ageBracket) && p.ageConfirmed !== true) c.add('Profile: missing an age range.');
    }
  }

  const checkins: CheckIn[] = [];
  arr(raw.checkins, 'checkins', c).forEach((r, i) => {
    const where = `Check-in ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isSpace(r.spaceId)) return c.add(`${where}: unknown Space.`);
    if (b.deletedAt) return void checkins.push({ ...b, spaceId: r.spaceId, mood: 50, energy: 50, connection: 50, scale: 100 });
    const lv = readLevels(r);
    if (!lv) return c.add(`${where}: readings must be whole numbers from 0 to 100.`);
    checkins.push({ ...b, spaceId: r.spaceId, ...lv, scale: 100, note: optStr(r.note, 2000) });
  });

  const areas: Area[] = [];
  arr(raw.areas, 'areas', c).forEach((r, i) => {
    const where = `Journey area ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isStr(r.name, 120) || (!r.name.trim() && !b.deletedAt)) return c.add(`${where}: needs a name.`);
    if (!isRating(r.impact) || !isRating(r.difficulty)) return c.add(`${where}: impact and difficulty must be 1–5.`);
    areas.push({ ...b, name: r.name, impact: r.impact, difficulty: r.difficulty, direction: isDirection(r.direction) ? r.direction : undefined });
  });

  const areaIds = new Set(areas.map((a) => a.id));
  const evidence: Evidence[] = [];
  arr(raw.evidence, 'evidence', c).forEach((r, i) => {
    const where = `Evidence ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isStr(r.areaId, 200) || !areaIds.has(r.areaId)) return c.add(`${where}: belongs to an area that isn't in the file.`);
    if (!EVIDENCE_KINDS.includes(r.kind)) return c.add(`${where}: kind must be win, observation or setback.`);
    if (!isStr(r.text, 2000) || (!r.text.trim() && !b.deletedAt)) return c.add(`${where}: needs a description.`);
    evidence.push({ ...b, areaId: r.areaId, kind: r.kind, text: r.text, spaceId: isSpace(r.spaceId) ? r.spaceId : 'personal' });
  });

  const harmony: HarmonySnapshot[] = [];
  arr(raw.harmony, 'harmony', c).forEach((r, i) => {
    const where = `Compass reading ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isSpace(r.spaceId)) return c.add(`${where}: unknown Space.`);
    if (!isObj(r.ratings)) return c.add(`${where}: missing ratings.`);
    const ratings = {} as Record<ElementId, ElementRating>;
    for (const el of ELEMENT_IDS) {
      const er = r.ratings[el];
      if (!isObj(er) || !isRating(er.pressure) || !isRating(er.resource)) return c.add(`${where}: ${el} ratings must be 1–5.`);
      ratings[el] = { pressure: er.pressure, resource: er.resource };
    }
    harmony.push({ ...b, spaceId: r.spaceId, ratings, note: optStr(r.note, 2000) });
  });

  const journal: JournalEntry[] = [];
  arr(raw.journal, 'journal', c).forEach((r, i) => {
    const where = `Journal entry ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isSpace(r.spaceId)) return c.add(`${where}: unknown Space.`);
    if (!isStr(r.text, 20000) || (!r.text.trim() && !b.deletedAt)) return c.add(`${where}: is empty.`);
    journal.push({ ...b, spaceId: r.spaceId, text: r.text, prompt: optStr(r.prompt, 200) });
  });

  // Protocols arrived after the first backups, so a missing list is simply empty.
  const protocols: ProtocolPlan[] = [];
  arr(raw.protocols, 'protocols', c).forEach((r, i) => {
    const where = `Protocol ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    const pat = r.pattern;
    const pattern: ProtocolPattern | null = isObj(pat) && pat.type === 'cycle' ? { type: 'cycle', on: pat.on, off: pat.off } : isObj(pat) && pat.type === 'weekdays' && Array.isArray(pat.days) ? { type: 'weekdays', days: pat.days } : null;
    if (!pattern || patternProblem(pattern)) return c.add(`${where}: its rhythm can't be read.`);
    if (!isDayKey(r.startDate)) return c.add(`${where}: missing a start date.`);
    const status: ProtocolStatus = r.status === 'active' || r.status === 'paused' || r.status === 'finished' ? r.status : 'finished';
    const weeks = (v: unknown, max: number) => (Number.isInteger(v) && (v as number) >= 1 && (v as number) <= max ? (v as number) : undefined);
    const cycleWeeks = weeks(r.cycleWeeks, 26);
    const restWeeks = weeks(r.restWeeks, 12);
    protocols.push({
      ...b,
      presetId: optStr(r.presetId, 40) ?? 'custom',
      name: optStr(r.name, 60) ?? 'My protocol',
      pattern,
      startDate: r.startDate,
      cycleWeeks: cycleWeeks && restWeeks ? cycleWeeks : undefined,
      restWeeks: cycleWeeks && restWeeks ? restWeeks : undefined,
      status: b.deletedAt ? 'finished' : status,
      pausedAt: isIso(r.pausedAt) ? r.pausedAt : undefined,
      endedAt: isIso(r.endedAt) ? r.endedAt : undefined,
      level: r.level === 'micro' || r.level === 'minor' || r.level === 'unsure' ? r.level : undefined,
      substance: b.deletedAt ? undefined : optStr(r.substance, 80),
      amount: b.deletedAt ? undefined : optStr(r.amount, 40),
      intention: b.deletedAt ? undefined : optStr(r.intention, 200),
    });
  });

  const dayNotes: DayNote[] = [];
  arr(raw.dayNotes, 'dayNotes', c).forEach((r, i) => {
    const where = `Day note ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isDayKey(r.day) || b.id !== `day:${r.day}`) return c.add(`${where}: its day can't be read.`);
    if (r.status !== 'taken' && r.status !== 'skipped' && r.status !== 'off') return c.add(`${where}: unknown status.`);
    const keep = !b.deletedAt;
    dayNotes.push({
      ...b,
      day: r.day,
      status: r.status,
      protocolId: optStr(r.protocolId, 200),
      substance: keep && r.status === 'taken' ? optStr(r.substance, 80) : undefined,
      amount: keep && r.status === 'taken' ? optStr(r.amount, 40) : undefined,
      note: keep ? optStr(r.note, 2000) : undefined,
    });
  });

  // v2 records. Journeys from the first build have none of these, so missing lists are simply empty.
  const goals: Goal[] = [];
  arr(raw.goals, 'goals', c).forEach((r, i) => {
    const where = `Goal ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    if (!isStr(r.title, 120) || (!r.title.trim() && !b.deletedAt)) return c.add(`${where}: needs a title.`);
    const status = r.status === 'open' || r.status === 'reached' || r.status === 'released' ? r.status : null;
    if (!status) return c.add(`${where}: unknown status.`);
    const keep = !b.deletedAt;
    goals.push({
      ...b,
      title: r.title,
      why: keep ? optStr(r.why, 400) : undefined,
      element: ELEMENT_IDS.includes(r.element) ? r.element : undefined,
      areaId: isStr(r.areaId, 200) && areaIds.has(r.areaId) ? r.areaId : undefined,
      status,
      reachedAt: status === 'reached' && isIso(r.reachedAt) ? r.reachedAt : status === 'reached' ? b.updatedAt : undefined,
      releasedAt: status === 'released' && isIso(r.releasedAt) ? r.releasedAt : undefined,
      reflection: keep && status === 'reached' ? optStr(r.reflection, 400) : undefined,
    });
  });

  const gems: GemTx[] = [];
  arr(raw.gems, 'gems', c).forEach((r, i) => {
    const where = `Gem ${i + 1}`;
    if (!isObj(r) || !isStr(r.id, 300) || !r.id) return c.add(`${where}: missing an id.`);
    if (!isSpace(r.spaceId)) return c.add(`${where}: unknown Space.`);
    if (!GEM_REASONS.includes(r.reason)) return c.add(`${where}: unknown reason.`);
    if (typeof r.amount !== 'number' || !Number.isInteger(r.amount) || r.amount < 0 || r.amount > 100) return c.add(`${where}: invalid amount.`);
    if (!isIso(r.createdAt)) return c.add(`${where}: invalid time.`);
    gems.push({ id: r.id, spaceId: r.spaceId, amount: r.amount, reason: r.reason, sourceId: optStr(r.sourceId, 200), createdAt: r.createdAt });
  });

  const uCheckins = uniqueIds(checkins, 'Check-ins', c);
  const uAreas = uniqueIds(areas, 'Journey areas', c);
  const uEvidence = uniqueIds(evidence, 'Evidence', c);
  const uHarmony = uniqueIds(harmony, 'Compass', c);
  const uJournal = uniqueIds(journal, 'Journal', c);
  const uProtocols = uniqueIds(protocols, 'Protocols', c);
  const uDayNotes = uniqueIds(dayNotes, 'Day notes', c);
  const uGems = uniqueIds(gems, 'Gems', c);
  const uGoals = uniqueIds(goals, 'Goals', c);

  // Guide, intake and prefs are forgiving: bad values fall back to defaults rather than failing the restore.
  const now = new Date().toISOString();
  const g = isObj(raw.guide) ? raw.guide : {};
  const completed: Partial<Record<LessonId, string>> = {};
  if (isObj(g.completed)) for (const l of LESSON_IDS) if (isIso(g.completed[l])) completed[l] = g.completed[l];
  const guide: GuideState = {
    completed,
    position: isObj(g.position) && LESSON_IDS.includes(g.position.lesson) && Number.isInteger(g.position.step) ? { lesson: g.position.lesson, step: Math.max(0, Math.min(3, g.position.step)) } : undefined,
    cardDismissedAt: isIso(g.cardDismissedAt) ? g.cardDismissedAt : undefined,
    rewardGrantedAt: isIso(g.rewardGrantedAt) ? g.rewardGrantedAt : undefined,
    practice: isObj(g.practice) ? sanitizePractice(g.practice) : {},
    updatedAt: isIso(g.updatedAt) ? g.updatedAt : now,
  };
  const ik = isObj(raw.intake) ? raw.intake : {};
  const answers: IntakeState['answers'] = {};
  if (isObj(ik.answers)) for (const [k, v] of Object.entries(ik.answers)) if (typeof k === 'string' && k.length < 40 && (v === 'yes' || v === 'no' || v === 'skip')) answers[k] = v;
  const intake: IntakeState = {
    answers,
    experience: ['none', 'some', 'regular', 'skip'].includes(ik.experience) ? ik.experience : undefined,
    version: isStr(ik.version, 40) ? ik.version : undefined,
    completedAt: isIso(ik.completedAt) ? ik.completedAt : undefined,
    updatedAt: isIso(ik.updatedAt) ? ik.updatedAt : now,
  };
  const pa = isObj(raw.paths) ? raw.paths : {};
  const opened: Partial<Record<TierId, TierOpening>> = {};
  const deferred: Partial<Record<TierId, string>> = {};
  for (const t of TIER_IDS) {
    if (t === 'foundation') continue;
    const o = isObj(pa.opened) ? pa.opened[t] : undefined;
    if (isObj(o) && isIso(o.at)) {
      const prev = TIER_IDS[TIER_IDS.indexOf(t) - 1];
      // Paths open in order, and outline paths can't be opened in this version.
      if (prev !== 'foundation' && !opened[prev]) c.add(`Paths: ${TIERS[t].name} is open but ${TIERS[prev].name} isn't.`);
      else if (!TIERS[t].outline) opened[t] = { at: o.at, how: o.how === 'invited' ? 'invited' : 'seeker', note: optStr(o.note, 600) };
    }
    if (isObj(pa.deferred) && isIso(pa.deferred[t])) deferred[t] = pa.deferred[t];
  }
  const keptMap = (v: unknown, ok: (k: string) => boolean) => {
    const out: Partial<Record<string, string>> = {};
    if (isObj(v)) for (const [k, at] of Object.entries(v)) if (ok(k) && isIso(at)) out[k] = at;
    return out;
  };
  const paths: PathsState = {
    opened,
    deferred,
    mastered: keptMap(pa.mastered, (k) => !!LESSON_BY_ID[k] && LESSON_BY_ID[k].measure.type !== 'outline'),
    badges: keptMap(pa.badges, (k) => BADGE_IDS.includes(k)),
    updatedAt: isIso(pa.updatedAt) ? pa.updatedAt : now,
  };
  const tomorrow = new Date(Date.now() + 86400000);
  const latestDay = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;
  const practiceLogs: PracticeLog[] = [];
  arr(raw.practiceLogs, 'practiceLogs', c).forEach((r, i) => {
    const where = `Path practice ${i + 1}`;
    if (!isObj(r)) return c.add(`${where}: not a record.`);
    const b = base(r, where, c);
    if (!b) return;
    const lesson = isStr(r.lessonId, 60) ? LESSON_BY_ID[r.lessonId] : undefined;
    if (!lesson || lesson.measure.type !== 'logged') return c.add(`${where}: unknown lesson.`);
    if (lesson.tier !== 'foundation' && !opened[lesson.tier]) return c.add(`${where}: belongs to a path that isn't open.`);
    if (!isDayKey(r.day) || b.id !== `prc:${r.lessonId}:${r.day}`) return c.add(`${where}: its day can't be read.`);
    if (r.day > latestDay) return c.add(`${where}: is dated in the future.`);
    practiceLogs.push({ ...b, lessonId: r.lessonId, day: r.day, spaceId: isSpace(r.spaceId) ? r.spaceId : 'personal', note: b.deletedAt ? undefined : optStr(r.note, 1000) });
  });

  const uPractice = uniqueIds(practiceLogs, 'Path practice', c);
  const pr = isObj(raw.prefs) ? raw.prefs : {};
  const prefs: Prefs = { haptics: pr.haptics !== false, sound: pr.sound !== false, reduceMotion: pr.reduceMotion === 'reduce' ? 'reduce' : 'system', updatedAt: isIso(pr.updatedAt) ? pr.updatedAt : now };
  if (pr.hall === 'lesson' || pr.hall === 'fire' || pr.hall === 'air' || pr.hall === 'water' || pr.hall === 'earth') prefs.hall = pr.hall;

  if (c.errors.length && !opts.lenient) return { ok: false, errors: c.errors };
  if (opts.lenient && (!isStr(raw.journeyId, 200) || !raw.journeyId || !isIso(raw.createdAt))) return { ok: false, errors: c.errors };

  const journey: Journey = {
    format: 'companion.journey',
    schemaVersion: 2,
    journeyId: raw.journeyId,
    createdAt: raw.createdAt,
    updatedAt: isIso(raw.updatedAt) ? raw.updatedAt : raw.createdAt,
    revision: Number.isInteger(raw.revision) && raw.revision >= 0 ? raw.revision : 0,
    profile,
    activeSpaceId: isSpace(raw.activeSpaceId) ? raw.activeSpaceId : 'personal',
    checkins: uCheckins,
    areas: uAreas,
    evidence: uEvidence,
    harmony: uHarmony,
    journal: uJournal,
    protocols: uProtocols,
    dayNotes: uDayNotes,
    goals: uGoals,
    practiceLogs: uPractice,
    paths,
    gems: uGems,
    guide,
    intake,
    prefs,
  };
  return { ok: true, journey, counts: counts(journey), exportedAt, name: profile?.name, dropped: c.count, problems: c.errors };
}

/**
 * Check-in readings. Current records carry `scale: 100` and 0–100 levels. Records from before the
 * sliders have no marker and 1–5 ratings; they convert exactly (1 → 0, 3 → 50, 5 → 100).
 */
function readLevels(r: Record<string, any>): { mood: number; energy: number; connection: number } | null {
  if (r.scale === 100) return isLevel(r.mood) && isLevel(r.energy) && isLevel(r.connection) ? { mood: r.mood, energy: r.energy, connection: r.connection } : null;
  if (r.scale === undefined && isRating(r.mood) && isRating(r.energy) && isRating(r.connection)) {
    return { mood: levelFromRating(r.mood), energy: levelFromRating(r.energy), connection: levelFromRating(r.connection) };
  }
  return null;
}

function sanitizePractice(p: Record<string, any>): GuideState['practice'] {
  const out: GuideState['practice'] = {};
  if (isObj(p.checkin)) {
    out.checkin = {
      mood: isLevel(p.checkin.mood) ? p.checkin.mood : undefined,
      energy: isLevel(p.checkin.energy) ? p.checkin.energy : undefined,
      connection: isLevel(p.checkin.connection) ? p.checkin.connection : undefined,
      note: optStr(p.checkin.note, 500),
      saved: p.checkin.saved === true,
    };
  }
  if (isObj(p.area)) out.area = { name: optStr(p.area.name, 120), impact: isRating(p.area.impact) ? p.area.impact : undefined, difficulty: isRating(p.area.difficulty) ? p.area.difficulty : undefined };
  if (isObj(p.evidence)) out.evidence = { kind: EVIDENCE_KINDS.includes(p.evidence.kind) ? p.evidence.kind : undefined, text: optStr(p.evidence.text, 500), saved: p.evidence.saved === true };
  if (['only-me', 'space', 'everyone'].includes(p.privacyAnswer)) out.privacyAnswer = p.privacyAnswer;
  if (optStr(p.journalText, 2000)) out.journalText = p.journalText;
  if (p.journalSaved === true) out.journalSaved = true;
  if (isSpace(p.spaceToggle)) out.spaceToggle = p.spaceToggle;
  if (p.gemRevealed === true) out.gemRevealed = true;
  return out;
}
