// Paths of mastery. Tiered paths in the spirit of Franz Bardon's Initiation into Hermetics, written
// in Equilibrium's own words. Foundation is open from the start. Each higher path is offered when the
// person is ready (consistent practice, goals reached, the current path's lessons mastered), and
// stays open to anyone who sincerely seeks it earlier. Pure functions only: no React, no storage.
//
// Rules this module keeps:
// • Progress only ever counts what was done. Nothing here reads how someone felt.
// • Dosing (protocols, day notes) never counts as practice and never earns anything.
// • Mastery always means practice on different days, never repeats in one day.

import type { ElementId, Journey, PracticeLog, TierId } from './types';
import { ELEMENT_IDS, TIER_IDS } from './types';
import { localDayKey } from './time';
import { addDays, daysBetween } from './protocols';

// ——— Settings (tune here) ———

/** When the next path is offered: practiced on `days` of the last `window` days, `goals` reached on this path, and its lessons mastered. */
export const READINESS = { days: 14, window: 21, goals: 2 } as const;
/** After "Not yet", the invitation rests this many days before the teacher mentions it again. */
export const INVITE_REST_DAYS = 7;
/** Element practice levels: one level per this many practices. */
export const PRACTICES_PER_LEVEL = 5;

// ——— Tiers ———

export interface Tier {
  id: TierId;
  name: string;
  /** What someone on this path is called on their character sheet. */
  rank: string;
  theme: string;
  intro: string;
  /** Outline tiers show their shape; their lessons are still being prepared. */
  outline?: boolean;
}

export const TIERS: Record<TierId, Tier> = {
  foundation: {
    id: 'foundation',
    name: 'Foundation',
    rank: 'Seeker',
    theme: 'The ground you stand on',
    intro: 'Wellness and character. Show up, name what matters, set goals and reach them. Everything higher is built on this ground.',
  },
  acolyte: {
    id: 'acolyte',
    name: 'Acolyte',
    rank: 'Acolyte',
    theme: 'Mirror and breath',
    intro:
      'Self-knowledge and attention. Watch the mind, take an honest inventory of your character by element, and bring awareness to breath, food and your word. Inspired by the first step of Franz Bardon’s Initiation into Hermetics, in Equilibrium’s own words.',
  },
  initiate: {
    id: 'initiate',
    name: 'Initiate',
    rank: 'Initiate',
    theme: 'Balancing the elements',
    intro: 'Working with your mirrors: strengthening what serves you and transforming what doesn’t, one element at a time, toward a balanced character.',
    outline: true,
  },
  adept: {
    id: 'adept',
    name: 'Adept',
    rank: 'Adept',
    theme: 'Mastery of mind',
    intro: 'Deeper concentration, stillness and will. The quiet mastery that the earlier paths prepare.',
    outline: true,
  },
};

export function nextTier(t: TierId): TierId | null {
  const i = TIER_IDS.indexOf(t);
  return i >= 0 && i < TIER_IDS.length - 1 ? TIER_IDS[i + 1] : null;
}

export function previousTier(t: TierId): TierId | null {
  const i = TIER_IDS.indexOf(t);
  return i > 0 ? TIER_IDS[i - 1] : null;
}

// ——— Lessons ———

export type Measure =
  | { type: 'checkinDays'; n: number }
  | { type: 'areaEvidence'; areas: number; evidence: number }
  | { type: 'goalsOpened'; n: number }
  | { type: 'goalsReached'; n: number }
  /** Practiced on `days` of any `window` consecutive days (best stretch so far). */
  | { type: 'rhythm'; days: number; window: number }
  /** A journal entry written with this prompt. */
  | { type: 'journal'; prompt: string }
  /** Logged practice on this many different days. */
  | { type: 'logged'; days: number }
  | { type: 'outline' };

/** Where a lesson's "do it" button goes. */
export type LessonAction = 'checkin' | 'areas' | 'goal' | 'journal' | 'log' | 'lookback' | 'none';

/** Icons a lesson can show on the map (a subset of the app's icon set). Element lessons show their glyph. */
export type LessonIcon = 'today' | 'journey' | 'flag' | 'journal' | 'calendar' | 'badge' | 'sun' | 'moon' | 'star' | 'observation' | 'compass' | 'leaf' | 'key' | 'heart' | 'path';

export interface PathLesson {
  id: string;
  icon?: LessonIcon;
  tier: TierId;
  title: string;
  /** One line: what to do. */
  summary: string;
  why: string;
  how: string[];
  measure: Measure;
  element?: ElementId;
  action: LessonAction;
}

export const LESSONS: PathLesson[] = [
  // ——— Foundation · The ground you stand on ———
  {
    id: 'f-show-up',
    icon: 'today',
    tier: 'foundation',
    title: 'Show up',
    summary: 'Check in on five different days.',
    why: 'Everything on this path starts with arriving. A check-in takes a minute and tells the truth about where you are. A low reading counts exactly as much as a high one.',
    how: ['Open Home and check in.', 'Do it on five different days. They don’t need to be in a row.'],
    measure: { type: 'checkinDays', n: 5 },
    action: 'checkin',
  },
  {
    id: 'f-name-what-matters',
    icon: 'journey',
    tier: 'foundation',
    title: 'Name what matters',
    summary: 'Add one area to practice, and record three pieces of evidence.',
    why: 'Growth gets real when you name it and watch what actually happens. Wins, observations and setbacks all count as evidence.',
    how: ['In Journey → Areas, add one thing you’d like to practice.', 'Record three things that actually happened: wins, observations or setbacks.'],
    measure: { type: 'areaEvidence', areas: 1, evidence: 3 },
    action: 'areas',
  },
  {
    id: 'f-first-goal',
    icon: 'flag',
    tier: 'foundation',
    title: 'Set your first goal',
    summary: 'Open one goal. It becomes a quest on your path.',
    why: 'A goal turns a wish into a direction. Keep it small enough to reach in a few weeks.',
    how: ['Add a goal: one clear thing you want to be true.', 'Say why it matters, if you like, and which element it calls on.'],
    measure: { type: 'goalsOpened', n: 1 },
    action: 'goal',
  },
  {
    id: 'f-honest-inventory',
    icon: 'journal',
    tier: 'foundation',
    title: 'An honest inventory',
    summary: 'Write three strengths and three habits you’d like to change.',
    why: 'Character grows from honest self-knowledge, without praise or blame. This is the seed of the mirror work on the Acolyte path.',
    how: ['Write three strengths you can rely on.', 'Write three habits you’d like to change.', 'Be plain and kind with yourself. No one else will read it.'],
    measure: { type: 'journal', prompt: 'Three strengths I have, and three habits I’d like to change' },
    action: 'journal',
  },
  {
    id: 'f-keep-rhythm',
    icon: 'calendar',
    tier: 'foundation',
    title: 'Keep a rhythm',
    summary: 'Practice on 7 of any 10 days.',
    why: 'Consistency matters more than intensity. Any practice counts: a check-in, a journal entry, evidence, a Compass reading, a path lesson or a goal.',
    how: ['Do one small practice on most days.', 'Seven days within any ten-day stretch completes the lesson.'],
    measure: { type: 'rhythm', days: 7, window: 10 },
    action: 'none',
  },
  {
    id: 'f-reach-goal',
    icon: 'badge',
    tier: 'foundation',
    title: 'Reach a goal',
    summary: 'Mark one goal as reached.',
    why: 'Finishing teaches you that your word to yourself can be trusted. Letting a goal go is allowed too, but this lesson asks for one you reach.',
    how: ['Pick an open goal and do what it asks.', 'When it’s true, mark it reached and say, in a line, what it took.'],
    measure: { type: 'goalsReached', n: 1 },
    action: 'goal',
  },
  {
    id: 'f-look-back',
    icon: 'observation',
    tier: 'foundation',
    title: 'Look back',
    summary: 'Read your weekly look-back, then write what changed.',
    why: 'Looking back in your own words shows growth that’s easy to miss day to day.',
    how: ['Open your weekly look-back.', 'Then write a few lines in your journal: what changed this week?'],
    measure: { type: 'journal', prompt: 'Looking back on this week, what changed?' },
    action: 'lookback',
  },

  // ——— Acolyte · Mirror and breath ———
  {
    id: 'a-watch-mind',
    tier: 'acolyte',
    title: 'Watching the mind',
    summary: 'Sit for five minutes and watch your thoughts without following them.',
    why: 'Before you can direct the mind, you have to see it. Watching thoughts come and go, without chasing or fighting them, builds the observer in you.',
    how: [
      'Sit comfortably, eyes closed or resting softly.',
      'For five minutes, notice each thought as it arises, like watching clouds pass.',
      'When one pulls you in, notice that too, and return to watching.',
      'Afterward, note how it went: busy, quiet, or somewhere between.',
    ],
    measure: { type: 'logged', days: 5 },
    element: 'air',
    action: 'log',
  },
  {
    id: 'a-bright-mirror',
    icon: 'sun',
    tier: 'acolyte',
    title: 'The bright mirror',
    summary: 'List your strengths, sorted by element.',
    why: 'Sort your good qualities by element: Fire for will and courage, Air for clarity and curiosity, Water for feeling and compassion, Earth for steadiness and care. Seeing them this way shows where you are already strong.',
    how: ['Write four headings: Fire, Air, Water, Earth.', 'Under each, list the strengths that belong there.', 'Add to it over the coming weeks as you notice more.'],
    measure: { type: 'journal', prompt: 'My strengths, sorted by element: Fire, Air, Water, Earth' },
    action: 'journal',
  },
  {
    id: 'a-shadow-mirror',
    icon: 'moon',
    tier: 'acolyte',
    title: 'The shadow mirror',
    summary: 'List what holds you back, sorted the same way.',
    why: 'The same honest sort, for what holds you back: Fire’s anger or impatience, Air’s scattering or overthinking, Water’s moodiness or clinging, Earth’s stubbornness or inertia. Write without judgment. It’s a map, not a verdict.',
    how: ['Write the same four headings.', 'List the traits that get in your way under each.', 'Notice which element carries the most. That’s useful, not shameful.'],
    measure: { type: 'journal', prompt: 'Traits that hold me back, sorted by element: Fire, Air, Water, Earth' },
    action: 'journal',
  },
  {
    id: 'a-conscious-breath',
    tier: 'acolyte',
    title: 'Conscious breath',
    summary: 'Breathe slowly for five minutes, letting each breath carry a quality you want.',
    why: 'Breath links body and feeling. Breathing with an intention teaches feeling to follow attention.',
    how: [
      'Choose one quality: calm, courage, clarity or warmth.',
      'Breathe in slowly through the nose, imagining the quality filling you.',
      'Breathe out slowly, letting its opposite leave.',
      'Keep it gentle. Never strain or hold the breath.',
    ],
    measure: { type: 'logged', days: 7 },
    element: 'water',
    action: 'log',
  },
  {
    id: 'a-mindful-meal',
    tier: 'acolyte',
    title: 'The mindful meal',
    summary: 'Eat one meal with full attention and an intention.',
    why: 'Earth is the body and what nourishes it. Eating with attention turns an ordinary act into practice.',
    how: ['Before eating, pause and set an intention, such as health or gratitude.', 'Eat slowly, noticing taste, texture and being nourished.', 'No screens for this meal.'],
    measure: { type: 'logged', days: 5 },
    element: 'earth',
    action: 'log',
  },
  {
    id: 'a-kept-word',
    tier: 'acolyte',
    title: 'The kept word',
    summary: 'Make one small promise to yourself each morning, and keep it.',
    why: 'Will grows like a muscle. Small promises kept build trust in yourself.',
    how: ['Each morning, choose one small, doable promise.', 'Keep it that day.', 'Log it once it’s kept. If it isn’t, notice why, without blame, and begin again tomorrow.'],
    measure: { type: 'logged', days: 7 },
    element: 'fire',
    action: 'log',
  },
  {
    id: 'a-evening-review',
    icon: 'star',
    tier: 'acolyte',
    title: 'The evening review',
    summary: 'Before sleep, replay your day and notice one moment of each element.',
    why: 'Reviewing the day closes it with awareness instead of worry, and keeps your mirrors honest and current.',
    how: ['Lying down, replay the day from morning to night, like a film.', 'Notice one moment of Fire, Air, Water and Earth in yourself.', 'Let it go, and rest.'],
    measure: { type: 'logged', days: 7 },
    action: 'log',
  },

  // ——— Initiate · Balancing the elements (outline) ———
  { id: 'i-transform', icon: 'key', tier: 'initiate', title: 'Transforming a shadow', summary: 'Choose one trait from your shadow mirror and practice its opposite for a month.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'i-strengthen', icon: 'sun', tier: 'initiate', title: 'Strengthening a light', summary: 'Choose one strength and use it on purpose every day.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'i-elemental-attention', icon: 'compass', tier: 'initiate', title: 'Elemental attention', summary: 'Sense each element in the body: warmth, lightness, flow and weight.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'i-single-point', icon: 'observation', tier: 'initiate', title: 'Single-pointed focus', summary: 'Hold your attention on one simple thing for several minutes.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'i-equilibrium', icon: 'compass', tier: 'initiate', title: 'Equilibrium of the soul', summary: 'Bring the four elements of your character toward balance, using your mirrors.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },

  // ——— Adept · Mastery of mind (outline) ———
  { id: 'd-stillness', icon: 'leaf', tier: 'adept', title: 'Stillness of mind', summary: 'Rest in a quiet mind for longer and longer stretches.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'd-mental-body', icon: 'star', tier: 'adept', title: 'Knowing yourself as mind', summary: 'Awareness of yourself as the one who thinks, apart from body and feeling.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'd-will', icon: 'key', tier: 'adept', title: 'Mastery of will', summary: 'Act from steady will, whatever the mood.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
  { id: 'd-service', icon: 'heart', tier: 'adept', title: 'Mastery in service', summary: 'Bring what you’ve built into the lives of others.', why: '', how: [], measure: { type: 'outline' }, action: 'none' },
];

export const LESSON_BY_ID: Record<string, PathLesson> = Object.fromEntries(LESSONS.map((l) => [l.id, l]));

export function lessonsFor(tier: TierId): PathLesson[] {
  return LESSONS.filter((l) => l.tier === tier);
}

export function isPracticable(l: PathLesson): boolean {
  return l.measure.type !== 'outline';
}

// ——— Practice days ———

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;

/**
 * Every local day with any practice: check-ins, journal, evidence, Compass readings, path
 * lessons, and goals opened or reached. Never protocols or day notes.
 */
/**
 * Days in a row with any practice (a check-in, a journal entry, a practice logged…), counting back
 * from today, or from yesterday when today has nothing yet (the streak isn't lost until a day passes).
 */
export function practiceStreak(j: Journey, today: string): number {
  const days = practiceDays(j);
  let d = days.has(today) ? today : addDayKey(today, -1);
  let n = 0;
  while (days.has(d)) {
    n++;
    d = addDayKey(d, -1);
  }
  return n;
}

function addDayKey(day: string, delta: number): string {
  const [y, m, d] = day.split('-').map(Number);
  const t = new Date(y, m - 1, d + delta);
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}

export function practiceDays(j: Journey): Set<string> {
  const days = new Set<string>();
  const add = (iso?: string) => {
    if (iso) days.add(localDayKey(iso));
  };
  j.checkins.filter(alive).forEach((c) => add(c.createdAt));
  j.journal.filter(alive).forEach((e) => add(e.createdAt));
  j.evidence.filter(alive).forEach((e) => add(e.createdAt));
  j.harmony.filter(alive).forEach((h) => add(h.createdAt));
  (j.practiceLogs ?? []).filter(alive).forEach((p) => days.add(p.day));
  (j.goals ?? []).filter(alive).forEach((g) => {
    add(g.createdAt);
    if (g.status === 'reached') add(g.reachedAt);
  });
  return days;
}

/** Days practiced within the `window` days ending on `today` (inclusive). */
export function daysInWindow(days: Set<string>, today: string, window: number): number {
  let n = 0;
  for (let i = 0; i < window; i++) if (days.has(addDays(today, -i))) n++;
  return n;
}

/** The most practice days found in any run of `window` consecutive days. */
export function bestWindow(days: Set<string>, window: number): number {
  const sorted = Array.from(days).sort();
  let best = 0;
  let start = 0;
  for (let end = 0; end < sorted.length; end++) {
    while (daysBetween(sorted[start], sorted[end]) >= window) start++;
    best = Math.max(best, end - start + 1);
  }
  return best;
}

/** The longest run of consecutive practice days. */
export function longestRun(days: Set<string>): number {
  const sorted = Array.from(days).sort();
  let best = 0;
  let run = 0;
  for (let i = 0; i < sorted.length; i++) {
    run = i > 0 && daysBetween(sorted[i - 1], sorted[i]) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
  }
  return best;
}

// ——— Lesson progress ———

export interface LessonProgress {
  count: number;
  target: number;
  mastered: boolean;
  /** Plain words, e.g. "3 of 5 days". */
  label: string;
}

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

export function logsFor(j: Journey, lessonId: string): PracticeLog[] {
  return (j.practiceLogs ?? []).filter((p) => alive(p) && p.lessonId === lessonId).sort((a, b) => (a.day < b.day ? -1 : 1));
}

/** Progress from what is on record now. Mastery, once reached, is also kept (see `lessonProgress`). */
export function liveLessonProgress(j: Journey, l: PathLesson): LessonProgress {
  const m = l.measure;
  const done = (count: number, target: number, label: string): LessonProgress => ({ count: Math.min(count, target), target, mastered: count >= target, label });
  switch (m.type) {
    case 'checkinDays': {
      const n = new Set(j.checkins.filter(alive).map((c) => localDayKey(c.createdAt))).size;
      return done(n, m.n, `${Math.min(n, m.n)} of ${m.n} days`);
    }
    case 'areaEvidence': {
      const areas = j.areas.filter(alive);
      const ids = new Set(areas.map((a) => a.id));
      const ev = j.evidence.filter((e) => alive(e) && ids.has(e.areaId)).length;
      const steps = Math.min(areas.length, m.areas) + Math.min(ev, m.evidence);
      const areaWord = areas.length >= m.areas ? (m.areas === 1 ? 'Area named' : `${m.areas} areas named`) : 'No area yet';
      return done(steps, m.areas + m.evidence, `${areaWord} · ${Math.min(ev, m.evidence)} of ${m.evidence} evidence`);
    }
    case 'goalsOpened': {
      const n = (j.goals ?? []).filter(alive).length;
      return done(n, m.n, n >= m.n ? 'Goal set' : 'No goal yet');
    }
    case 'goalsReached': {
      const n = (j.goals ?? []).filter((g) => alive(g) && g.status === 'reached').length;
      return done(n, m.n, `${Math.min(n, m.n)} of ${plural(m.n, 'goal')} reached`);
    }
    case 'rhythm': {
      const best = bestWindow(practiceDays(j), m.window);
      return done(best, m.days, `${Math.min(best, m.days)} of ${m.days} days, within ${m.window}`);
    }
    case 'journal': {
      const n = j.journal.filter((e) => alive(e) && e.prompt === m.prompt).length;
      return done(n, 1, n ? 'Written' : 'Not written yet');
    }
    case 'logged': {
      const n = logsFor(j, l.id).length;
      return done(n, m.days, `${Math.min(n, m.days)} of ${m.days} days`);
    }
    case 'outline':
      return { count: 0, target: 0, mastered: false, label: 'In preparation' };
  }
}

/** Progress as shown: once a lesson has been mastered it stays mastered, even if a practice is later removed. */
export function lessonProgress(j: Journey, l: PathLesson): LessonProgress {
  const live = liveLessonProgress(j, l);
  if (!live.mastered && isPracticable(l) && j.paths?.mastered?.[l.id]) return { count: live.target, target: live.target, mastered: true, label: 'Mastered' };
  return live;
}

export function isMastered(j: Journey, l: PathLesson): boolean {
  return isPracticable(l) && lessonProgress(j, l).mastered;
}

/** When a goal was first reached: its gem is written once and never removed, so reopening can't reset it. */
export function firstReachedAt(j: Journey, goalId: string): string | undefined {
  const gem = j.gems.find((g) => g.reason === 'goal' && g.sourceId === goalId);
  if (gem) return gem.createdAt;
  const g = (j.goals ?? []).find((x) => x.id === goalId);
  return g?.status === 'reached' ? g.reachedAt : undefined;
}

export function lessonsMastered(j: Journey): PathLesson[] {
  return LESSONS.filter((l) => isMastered(j, l));
}

// ——— Tiers: open, ready, current ———

export function tierOpenedAt(j: Journey, t: TierId): string | undefined {
  if (t === 'foundation') return j.profile?.createdAt ?? j.createdAt;
  return j.paths?.opened?.[t]?.at;
}

export function isTierOpen(j: Journey, t: TierId): boolean {
  return !!tierOpenedAt(j, t);
}

/** The highest open path. */
export function currentTier(j: Journey): TierId {
  let cur: TierId = 'foundation';
  for (const t of TIER_IDS) if (isTierOpen(j, t)) cur = t;
  return cur;
}

export interface Readiness {
  /** The path being completed. */
  tier: TierId;
  next: TierId | null;
  lessons: { done: number; total: number; ok: boolean };
  days: { count: number; need: number; window: number; ok: boolean };
  goals: { count: number; need: number; ok: boolean };
  ready: boolean;
}

/** Whether someone on `tier` is ready to be offered the next path. */
export function readiness(j: Journey, tier: TierId, today: string): Readiness {
  const ls = lessonsFor(tier).filter(isPracticable);
  const done = ls.filter((l) => isMastered(j, l)).length;
  const count = daysInWindow(practiceDays(j), today, READINESS.window);
  const since = tierOpenedAt(j, tier) ?? j.createdAt;
  // A goal counts for this path if it is reached now and was first reached after the path opened.
  const goals = (j.goals ?? []).filter((g) => {
    if (!alive(g) || g.status !== 'reached') return false;
    const first = firstReachedAt(j, g.id);
    return !!first && first >= since;
  }).length;
  const lessons = { done, total: ls.length, ok: ls.length > 0 && done === ls.length };
  const daysR = { count, need: READINESS.days, window: READINESS.window, ok: count >= READINESS.days };
  const goalsR = { count: goals, need: READINESS.goals, ok: goals >= READINESS.goals };
  return { tier, next: nextTier(tier), lessons, days: daysR, goals: goalsR, ready: lessons.ok && daysR.ok && goalsR.ok };
}

export type TierState = 'open' | 'invited' | 'seekable' | 'locked' | 'preparing';

/**
 * open: available now. invited: the previous path is complete and the person is ready.
 * seekable: the next path, which a sincere seeker may open early. locked: further ahead.
 * preparing: an outline path whose lessons aren't written yet; it can't be opened.
 */
export function tierState(j: Journey, t: TierId, today: string): TierState {
  if (isTierOpen(j, t)) return 'open';
  if (TIERS[t].outline) return 'preparing';
  const prev = previousTier(t);
  if (!prev || !isTierOpen(j, prev)) return 'locked';
  return readiness(j, prev, today).ready ? 'invited' : 'seekable';
}

// ——— The teacher ———

export type TeacherNote =
  | { kind: 'invite'; tier: TierId; readiness: Readiness }
  /** Ready, but the person said "Not yet" recently: the path waits, without being pressed. */
  | { kind: 'resting'; tier: TierId; readiness: Readiness }
  | { kind: 'lesson'; lesson: PathLesson; progress: LessonProgress }
  | { kind: 'consistency'; readiness: Readiness }
  /** Every open lesson is walked and the next path's lessons are still being written. */
  | { kind: 'preparing'; tier: TierId; after: TierId };

/**
 * What Equilibrium, as teacher, suggests next. It offers a higher path only when the pupil is ready
 * (and lets the offer rest after "Not yet"); otherwise it points to the next lesson to practice.
 */
export function teacherNote(j: Journey, today: string): TeacherNote {
  const cur = currentTier(j);
  const r = readiness(j, cur, today);
  const nxt = r.next;
  if (nxt && !isTierOpen(j, nxt) && !TIERS[nxt].outline && r.ready) {
    const deferred = j.paths?.deferred?.[nxt];
    const resting = !!deferred && daysBetween(localDayKey(deferred), today) < INVITE_REST_DAYS;
    return { kind: resting ? 'resting' : 'invite', tier: nxt, readiness: r };
  }
  for (const t of TIER_IDS) {
    if (!isTierOpen(j, t)) break;
    const lesson = lessonsFor(t).find((l) => isPracticable(l) && !isMastered(j, l));
    if (lesson) return { kind: 'lesson', lesson, progress: lessonProgress(j, lesson) };
  }
  if (nxt && TIERS[nxt].outline) return { kind: 'preparing', tier: nxt, after: cur };
  return { kind: 'consistency', readiness: r };
}

/** The lesson the teacher points to now, if any (used to mark "you are here" on the map). */
export function currentLessonId(j: Journey): string | null {
  for (const t of TIER_IDS) {
    if (!isTierOpen(j, t)) break;
    const lesson = lessonsFor(t).find((l) => isPracticable(l) && !isMastered(j, l));
    if (lesson) return lesson.id;
  }
  return null;
}

// ——— Elements practiced (grow only) ———

export interface ElementPractice {
  count: number;
  level: number;
  /** Practices toward the next level, and how many a level takes. */
  intoLevel: number;
  perLevel: number;
}

/**
 * Practice by element, from gem records (written once, never removed): logged lessons that train an
 * element, and goals reached that call on it. So a level, once earned, is never taken back.
 */
export function elementPractice(j: Journey): Record<ElementId, ElementPractice> {
  const counts: Record<ElementId, number> = { fire: 0, air: 0, water: 0, earth: 0 };
  const goalElement = new Map((j.goals ?? []).map((g) => [g.id, g.element]));
  for (const gem of j.gems) {
    if (gem.reason === 'practice' && gem.sourceId?.startsWith('prc:')) {
      const lessonId = gem.sourceId.split(':')[1];
      const el = LESSON_BY_ID[lessonId]?.element;
      if (el) counts[el]++;
    } else if (gem.reason === 'goal' && gem.sourceId) {
      const el = goalElement.get(gem.sourceId);
      if (el) counts[el]++;
    }
  }
  return Object.fromEntries(
    ELEMENT_IDS.map((el) => [el, { count: counts[el], level: Math.floor(counts[el] / PRACTICES_PER_LEVEL) + 1, intoLevel: counts[el] % PRACTICES_PER_LEVEL, perLevel: PRACTICES_PER_LEVEL }]),
  ) as Record<ElementId, ElementPractice>;
}

export function todayKey(now: Date = new Date()): string {
  return localDayKey(now);
}
