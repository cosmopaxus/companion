// Stable, collision-resistant ids without native crypto dependencies.
// Prefer crypto.randomUUID when the runtime has it (web, modern Hermes); fall back to
// time + random base36, which is ample for single-user local event ids.

let counter = 0;

export function newId(prefix: string): string {
  const c: any = (globalThis as any).crypto;
  if (c && typeof c.randomUUID === 'function') {
    return `${prefix}_${c.randomUUID().replace(/-/g, '').slice(0, 20)}`;
  }
  counter = (counter + 1) % 1296;
  const time = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 10);
  const rand2 = Math.random().toString(36).slice(2, 6);
  return `${prefix}_${time}${counter.toString(36).padStart(2, '0')}${rand}${rand2}`;
}

/** Deterministic gem id: the same source can only ever earn one transaction. */
export function gemId(reason: string, sourceId?: string): string {
  return sourceId ? `gem:${reason}:${sourceId}` : `gem:${reason}`;
}
