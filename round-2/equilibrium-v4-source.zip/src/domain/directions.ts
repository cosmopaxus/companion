import type { DirectionId, Journey } from './types';
import { DIRECTION_IDS } from './types';
import { activeAreas } from './selectors';

export interface DirectionInfo {
  id: DirectionId;
  name: string;
  verb: string;
  purpose: string;
  practices: string[];
  /** Optional əvōke support template associated with this direction. Never required. */
  template: string;
  templateNote?: string;
}

export const DIRECTIONS: Record<DirectionId, DirectionInfo> = {
  center: {
    id: 'center',
    name: 'Center',
    verb: 'Stabilize',
    purpose: 'Build a steadier baseline: simple rhythms, sleep and recovery.',
    practices: [
      'Keep the same wake time for a week',
      'Take two slow minutes before your first screen',
      'Wind down for twenty minutes without a screen',
    ],
    template: 'Harmony',
  },
  focus: {
    id: 'focus',
    name: 'Focus',
    verb: 'Organize',
    purpose: 'Reduce cognitive noise, choose a priority, and practice attention.',
    practices: [
      'Name one priority before noon',
      'Close three open loops, on screen or in your head',
      'Work in one uninterrupted 25-minute block',
    ],
    template: 'Clarity',
  },
  activate: {
    id: 'activate',
    name: 'Activate',
    verb: 'Move',
    purpose: 'Translate insight into action and follow-through.',
    practices: [
      'Take the smallest next step on something stalled',
      'Move your body for ten minutes',
      'Tell someone what you will finish this week',
    ],
    template: 'Energy',
  },
  connect: {
    id: 'connect',
    name: 'Connect',
    verb: 'Embody',
    purpose: 'Connection with yourself, your body, and other people.',
    practices: [
      'Notice three sensations in your body, without changing them',
      'Reach out to one person with no agenda',
      'Share a meal with your phone in another room',
    ],
    template: 'Sensuality',
    templateNote: 'Sensuality here means embodied connection in the broad sense, not only intimacy.',
  },
};

export const CHOSEN_WEIGHT = 3;

export interface DirectionScore {
  id: DirectionId;
  total: number;
  chosen: boolean;
  areaCount: number;
  highImpactCount: number;
}

export interface DirectionResult {
  current: DirectionId | null;
  scores: DirectionScore[];
}

/**
 * Rule-based and fully explainable — never an inference from journal text.
 * Each chosen starting direction: +3. Each active Journey area in a direction: +1, and +1 more if impact is 4–5.
 * Ties go to the direction you chose first, then catalog order (Center, Focus, Activate, Connect).
 */
export function computeDirection(j: Journey): DirectionResult {
  const chosen = j.profile?.chosenDirections ?? [];
  const scores: DirectionScore[] = DIRECTION_IDS.map((id) => ({
    id,
    total: chosen.includes(id) ? CHOSEN_WEIGHT : 0,
    chosen: chosen.includes(id),
    areaCount: 0,
    highImpactCount: 0,
  }));
  for (const a of activeAreas(j)) {
    if (!a.direction) continue;
    const s = scores.find((x) => x.id === a.direction)!;
    s.areaCount += 1;
    s.total += 1;
    if (a.impact >= 4) {
      s.highImpactCount += 1;
      s.total += 1;
    }
  }
  const rank = (id: DirectionId) => {
    const i = chosen.indexOf(id);
    return i === -1 ? 10 + DIRECTION_IDS.indexOf(id) : i;
  };
  const ordered = [...scores].sort((a, b) => b.total - a.total || rank(a.id) - rank(b.id));
  const current = ordered[0].total > 0 ? ordered[0].id : null;
  return { current, scores };
}

export function explainScore(s: DirectionScore): string[] {
  const lines: string[] = [];
  if (s.chosen) lines.push(`You chose it as a starting direction (+${CHOSEN_WEIGHT})`);
  if (s.areaCount > 0) {
    lines.push(`${s.areaCount} Journey area${s.areaCount === 1 ? '' : 's'} in this direction (+${s.areaCount})`);
  }
  if (s.highImpactCount > 0) {
    lines.push(`${s.highImpactCount} of them high impact (+${s.highImpactCount})`);
  }
  return lines;
}
