// Journal search and Markdown export. Pure: the screen decides which entries to pass in.

import type { JournalEntry } from './types';
import { SPACE_NAME } from './spaces';
import { formatLongDate, formatTime, localDayKey } from './time';

/** Case- and accent-insensitive match on the entry text and its prompt. Every word must appear. */
export function searchJournal(entries: JournalEntry[], query: string): JournalEntry[] {
  const fold = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const words = fold(query).split(/\s+/).filter(Boolean);
  if (!words.length) return entries;
  return entries.filter((e) => {
    const hay = fold(`${e.prompt ?? ''}\n${e.text}`);
    return words.every((w) => hay.includes(w));
  });
}

/** Markdown, oldest first, grouped by day. Text is kept exactly as written. */
export function journalMarkdown(entries: JournalEntry[], opts: { name?: string; now?: Date; note?: string } = {}): string {
  const now = opts.now ?? new Date();
  const list = entries.filter((e) => !e.deletedAt).sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
  const lines: string[] = [];
  lines.push(`# Journal${opts.name ? ` · ${opts.name}` : ''}`);
  lines.push('');
  lines.push(`Exported from Equilibrium on ${formatLongDate(now)}, ${now.getFullYear()}. ${list.length} entr${list.length === 1 ? 'y' : 'ies'}.${opts.note ? ` ${opts.note}` : ''}`);
  let day = '';
  for (const e of list) {
    const d = localDayKey(e.createdAt);
    if (d !== day) {
      day = d;
      const dt = new Date(e.createdAt);
      lines.push('', `## ${formatLongDate(dt)}, ${dt.getFullYear()}`);
    }
    lines.push('', `### ${formatTime(e.createdAt)} · ${SPACE_NAME[e.spaceId]}`);
    if (e.prompt) lines.push('', `*${e.prompt}*`);
    lines.push('', e.text.trim());
  }
  lines.push('');
  return lines.join('\n');
}

export function journalFileName(now: Date = new Date()): string {
  return `companion-journal-${localDayKey(now)}.md`;
}
