import type { EvidenceKind, Level, Rating } from './types';

export type CheckInDimension = 'mood' | 'energy' | 'connection';

export const CHECKIN_SCALES: Record<CheckInDimension, { label: string; question: string; anchors: Record<Rating, string> }> = {
  mood: {
    label: 'Mood',
    question: 'How does your mood feel?',
    anchors: { 1: 'Heavy', 2: 'Low', 3: 'Okay', 4: 'Good', 5: 'Bright' },
  },
  energy: {
    label: 'Energy',
    question: 'How much energy is available?',
    anchors: { 1: 'Depleted', 2: 'Low', 3: 'Steady', 4: 'Good', 5: 'Charged' },
  },
  connection: {
    label: 'Connection',
    question: 'How connected do you feel, to yourself or others?',
    anchors: { 1: 'Isolated', 2: 'Distant', 3: 'Okay', 4: 'Close', 5: 'Connected' },
  },
};

export const IMPACT_ANCHORS: Record<Rating, string> = {
  1: 'A little',
  2: 'Some',
  3: 'Noticeable',
  4: 'A lot',
  5: 'Life-changing',
};

export const DIFFICULTY_ANCHORS: Record<Rating, string> = {
  1: 'Easy',
  2: 'Manageable',
  3: 'Moderate',
  4: 'Hard',
  5: 'Very hard',
};

export const EVIDENCE_INFO: Record<EvidenceKind, { label: string; plural: string; helper: string; placeholder: string }> = {
  win: {
    label: 'Win',
    plural: 'wins',
    helper: 'Something that moved forward, however small.',
    placeholder: 'e.g. I took a ten-minute walk after lunch',
  },
  observation: {
    label: 'Observation',
    plural: 'observations',
    helper: 'Something you noticed or learned.',
    placeholder: 'e.g. I sleep better when I stop working by 9',
  },
  setback: {
    label: 'Setback',
    plural: 'setbacks',
    helper: "A step that didn't go as hoped. Useful information, not failure.",
    placeholder: "e.g. Stayed up late scrolling again — I was lonely, I think",
  },
};

export const AREA_EXAMPLES = [
  'A steadier sleep rhythm',
  'More patience',
  'Finishing a creative project',
  'Making room for connection',
];

export const JOURNAL_PROMPTS = [
  'What did today ask of me?',
  'Something I noticed in my body',
  'A small thing that went well',
  'What I want to remember',
  'Where did I feel most like myself?',
];

export function isRating(v: unknown): v is Rating {
  return v === 1 || v === 2 || v === 3 || v === 4 || v === 5;
}

// ——— Check-in levels (0–100) ———

export const LEVEL_MIN = 0;
export const LEVEL_MAX = 100;

export function isLevel(v: unknown): v is Level {
  return typeof v === 'number' && Number.isInteger(v) && v >= LEVEL_MIN && v <= LEVEL_MAX;
}

/** Check-ins saved before the sliders used 1–5. 1 → 0, 3 → 50, 5 → 100 (the same mapping Harmony uses). */
export function levelFromRating(r: Rating): Level {
  return (r - 1) * 25;
}

/** Which of the five familiar words a level sits in: 0–19, 20–39, 40–59, 60–79, 80–100. */
export function levelBand(v: Level): Rating {
  if (v < 20) return 1;
  if (v < 40) return 2;
  if (v < 60) return 3;
  if (v < 80) return 4;
  return 5;
}

export function levelWord(dim: CheckInDimension, v: Level): string {
  return CHECKIN_SCALES[dim].anchors[levelBand(v)];
}

/** Below this, Today offers support options alongside the check-in (the old "1 of 5"). */
export const HEAVY_MOOD_BELOW = 20;
