// Microdosing rhythms: which days are activation days and which are integration days.
// Pure date math on local calendar days (YYYY-MM-DD), so time zones and daylight saving never
// shift a day. Equilibrium lists commonly published schedules and never chooses an amount.

import type { Journey, ProtocolPattern, ProtocolPlan } from './types';

export interface ProtocolPreset {
  id: string;
  name: string;
  /** Where the schedule is commonly credited, if anywhere. */
  aka?: string;
  pattern: ProtocolPattern;
  blurb: string;
}

export const PROTOCOL_PRESETS: ProtocolPreset[] = [
  {
    id: 'one-two',
    name: 'One day on, two days off',
    aka: 'Often called the Fadiman protocol',
    pattern: { type: 'cycle', on: 1, off: 2 },
    blurb: 'A three-day rhythm: one activation day, then two integration days to notice what changes.',
  },
  {
    id: 'four-three',
    name: 'Four days on, three days off',
    aka: 'Often associated with Paul Stamets',
    pattern: { type: 'cycle', on: 4, off: 3 },
    blurb: 'A weekly rhythm: four activation days in a row, then three integration days.',
  },
  {
    id: 'three-two',
    name: 'Three days on, two days off',
    pattern: { type: 'cycle', on: 3, off: 2 },
    blurb: 'A five-day rhythm: three activation days in a row, then two integration days.',
  },
  {
    id: 'every-other',
    name: 'Every other day',
    pattern: { type: 'cycle', on: 1, off: 1 },
    blurb: 'Activation and integration days take turns.',
  },
  {
    id: 'two-a-week',
    name: 'Two days a week',
    pattern: { type: 'weekdays', days: [1, 4] },
    blurb: 'Activation on Monday and Thursday; every other day is for integration. You can pick different days.',
  },
];

export const CUSTOM_ID = 'custom';

export const WEEKDAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const WEEKDAY_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// ——— Local calendar days ———

const DAY_RE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function isDayKey(v: unknown): v is string {
  if (typeof v !== 'string') return false;
  const m = DAY_RE.exec(v);
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}

/** Whole days from a to b (b − a), counting calendar days. */
export function daysBetween(a: string, b: string): number {
  const pa = DAY_RE.exec(a)!;
  const pb = DAY_RE.exec(b)!;
  return Math.round((Date.UTC(+pb[1], +pb[2] - 1, +pb[3]) - Date.UTC(+pa[1], +pa[2] - 1, +pa[3])) / 86400000);
}

export function addDays(day: string, n: number): string {
  const m = DAY_RE.exec(day)!;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3] + n));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

export function weekdayOf(day: string): number {
  const m = DAY_RE.exec(day)!;
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])).getUTCDay();
}

export function formatDay(day: string, style: 'short' | 'long' = 'short'): string {
  const m = DAY_RE.exec(day)!;
  const w = weekdayOf(day);
  return style === 'long' ? `${WEEKDAY_LONG[w]}, ${MONTH_SHORT[+m[2] - 1]} ${+m[3]}` : `${WEEKDAY_SHORT[w]} ${MONTH_SHORT[+m[2] - 1]} ${+m[3]}`;
}

// ——— Patterns ———

const NUMBER_WORDS = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen'];

export function describePattern(p: ProtocolPattern): string {
  if (p.type === 'weekdays') {
    const days = [...p.days].sort((a, b) => a - b).map((d) => WEEKDAY_SHORT[d]);
    return `Activation on ${days.join(', ')}`;
  }
  const n = (x: number) => NUMBER_WORDS[x] ?? String(x);
  const on = `${n(p.on)} day${p.on === 1 ? '' : 's'} on`;
  const off = `${n(p.off)} day${p.off === 1 ? '' : 's'} off`;
  return `${on[0].toUpperCase()}${on.slice(1)}, ${off}`;
}

/** The rhythm in words, unless the protocol's name already says exactly that. */
export function patternUnlessNamed(name: string, presetId: string, p: ProtocolPattern): string | null {
  const preset = PROTOCOL_PRESETS.find((x) => x.id === presetId);
  const described = describePattern(p);
  return (preset && preset.name === name) || described === name ? null : described;
}

export function patternProblem(p: ProtocolPattern): string | null {
  if (p.type === 'cycle') {
    if (!Number.isInteger(p.on) || p.on < 1 || p.on > 7) return 'Activation days in a row must be from 1 to 7.';
    if (!Number.isInteger(p.off) || p.off < 1 || p.off > 14) return 'Integration days must be from 1 to 14.';
    return null;
  }
  const days = Array.from(new Set(p.days));
  if (!days.every((d) => Number.isInteger(d) && d >= 0 && d <= 6)) return 'Unknown weekday.';
  if (days.length < 1) return 'Choose at least one activation day.';
  if (days.length > 5) return 'Keep at least two integration days each week.';
  return null;
}

// ——— What kind of day is it? ———

export type DayKind = 'activation' | 'integration' | 'rest' | 'upcoming' | 'paused' | 'none';

export interface DayInfo {
  day: string;
  kind: DayKind;
  /** For cycle patterns: position within the current run, e.g. activation day 2 of 4. */
  index?: number;
  of?: number;
}

export function dayFor(plan: ProtocolPlan, day: string): DayInfo {
  if (plan.deletedAt || plan.status === 'finished') return { day, kind: 'none' };
  if (plan.status === 'paused') return { day, kind: 'paused' };
  const since = daysBetween(plan.startDate, day);
  if (since < 0) return { day, kind: 'upcoming' };
  let pos = since;
  if (plan.cycleWeeks && plan.restWeeks) {
    const period = (plan.cycleWeeks + plan.restWeeks) * 7;
    pos = since % period;
    if (pos >= plan.cycleWeeks * 7) return { day, kind: 'rest', index: pos - plan.cycleWeeks * 7 + 1, of: plan.restWeeks * 7 };
  }
  const p = plan.pattern;
  if (p.type === 'weekdays') return { day, kind: p.days.includes(weekdayOf(day)) ? 'activation' : 'integration' };
  const i = pos % (p.on + p.off);
  return i < p.on ? { day, kind: 'activation', index: i + 1, of: p.on } : { day, kind: 'integration', index: i - p.on + 1, of: p.off };
}

export function upcoming(plan: ProtocolPlan, from: string, n: number): DayInfo[] {
  return Array.from({ length: n }, (_, i) => dayFor(plan, addDays(from, i)));
}

/** The next activation day on or after `from`, within a year. */
export function nextActivation(plan: ProtocolPlan, from: string): string | null {
  for (let i = 0; i < 366; i++) {
    const d = addDays(from, i);
    if (dayFor(plan, d).kind === 'activation') return d;
  }
  return null;
}

export const DAY_LABEL: Record<DayKind, string> = {
  activation: 'Activation day',
  integration: 'Integration day',
  rest: 'Rest period',
  upcoming: 'Not started yet',
  paused: 'Paused',
  none: 'No protocol',
};

// ——— Selectors ———

/** The one current protocol (active or paused), if any. */
export function currentProtocol(j: Journey): ProtocolPlan | null {
  // After two devices merge there could briefly be two; the most recently changed one is current.
  const live = j.protocols.filter((p) => !p.deletedAt && p.status !== 'finished');
  return live.sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1))[0] ?? null;
}

export function pastProtocols(j: Journey): ProtocolPlan[] {
  return j.protocols.filter((p) => !p.deletedAt && p.status === 'finished').sort((a, b) => ((a.endedAt ?? a.updatedAt) < (b.endedAt ?? b.updatedAt) ? 1 : -1));
}

/** Shown wherever an amount can be written down. Equilibrium never suggests one. */
export const START_LOW =
  'Start low, go slow. Begin with the smallest amount, change one thing at a time, and give yourself a few activation days before adjusting. Equilibrium never chooses an amount for you.';
