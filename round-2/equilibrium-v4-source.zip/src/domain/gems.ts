import type { GemReason, GemTx, SpaceId } from './types';

export const GEM_AMOUNTS: Record<GemReason, number> = {
  checkin: 2,
  journal: 1,
  evidence: 1,
  harmony: 2,
  'guide-complete': 5,
  practice: 1,
  goal: 3,
};

export const GEM_REASON_LABEL: Record<GemReason, string> = {
  checkin: 'Check-in',
  journal: 'Journal entry',
  evidence: 'Evidence recorded',
  harmony: 'Compass reading',
  'guide-complete': 'Completed first steps',
  practice: 'Path practice',
  goal: 'Goal reached',
};

export const GEM_RULES: { reason: GemReason; label: string; amount: number; note?: string }[] = [
  { reason: 'checkin', label: 'A real check-in', amount: 2, note: 'The same for a 1 or a 5.' },
  { reason: 'harmony', label: 'A Compass reading', amount: 2 },
  { reason: 'journal', label: 'A journal entry', amount: 1 },
  { reason: 'evidence', label: 'Evidence of any kind', amount: 1, note: 'Wins, observations and setbacks alike.' },
  { reason: 'practice', label: 'Practicing a path lesson', amount: 1, note: 'Once per lesson per day.' },
  { reason: 'goal', label: 'Reaching a goal', amount: 3, note: 'Once per goal. Letting a goal go costs nothing.' },
  { reason: 'guide-complete', label: 'Finishing first steps', amount: 5, note: 'Once. Always goes to Personal.' },
];

/** The first-steps reward belongs to Personal: it is about learning the app, not any Space's practice. */
export const GUIDE_REWARD_SPACE: SpaceId = 'personal';

export function balanceFor(gems: GemTx[], spaceId: SpaceId): number {
  return gems.reduce((sum, g) => (g.spaceId === spaceId ? sum + g.amount : sum), 0);
}

export function totalBalance(gems: GemTx[]): number {
  return gems.reduce((sum, g) => sum + g.amount, 0);
}
