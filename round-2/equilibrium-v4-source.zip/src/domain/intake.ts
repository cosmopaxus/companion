// Safety & Path — PLACEHOLDER intake. Transparent rules, not validated screening.
// Flagged for specialist (clinical + legal) review before any production health use.
// It never grants permission, never chooses a dose, and never removes access to reflection features.
// For adults only: under 18, Equilibrium hides it (see age.ts).

import type { Experience, IntakeAnswer, IntakeState } from './types';

export interface IntakeQuestion {
  id: string;
  text: string;
  detail: string;
  /**
   * 'major'   → a major caution in this screening model; talk with a clinician first.
   * 'caution' → worth discussing with a clinician.
   * 'support' → surface support resources now, ahead of anything else.
   */
  kind: 'major' | 'caution' | 'support';
}

export const INTAKE_QUESTIONS: IntakeQuestion[] = [
  { id: 'pregnancy', text: 'Pregnant, possibly pregnant, or breastfeeding', detail: 'A major caution in this screening model.', kind: 'major' },
  { id: 'history_psychosis', text: 'Personal or family history of psychosis, schizophrenia or bipolar I', detail: 'A major psychological caution.', kind: 'major' },
  { id: 'lithium', text: 'Currently taking lithium', detail: 'A major medication caution.', kind: 'major' },
  { id: 'heart', text: 'A significant heart condition or high blood pressure', detail: 'Worth extra care, especially with higher-intensity experiences.', kind: 'caution' },
  { id: 'maoi', text: 'Currently taking an MAOI', detail: 'A medication-interaction caution.', kind: 'caution' },
  { id: 'psych_meds', text: 'Taking an antidepressant or another psychiatric medication', detail: "This doesn't decide anything for you. It's worth reviewing with your prescriber.", kind: 'caution' },
  { id: 'crisis_now', text: "I'm in a mental-health crisis, or I might be in danger right now", detail: 'Equilibrium will point you to support first, not to a protocol.', kind: 'support' },
];

export const EXPERIENCE_OPTIONS: { id: Experience; label: string }[] = [
  { id: 'none', label: 'Not yet' },
  { id: 'some', label: 'A few times' },
  { id: 'regular', label: 'I have a regular practice' },
  { id: 'skip', label: 'Prefer not to say' },
];

/** Bump when the questions change, so people who answered an older set are asked to review. */
export const INTAKE_VERSION = 'placeholder-2026-09b';

export interface IntakeResult {
  answered: number;
  majorCount: number;
  cautionCount: number;
  supportNow: boolean;
  complete: boolean;
  /** Saved against an older question set: some questions are new. */
  needsReview: boolean;
}

export function evaluateIntake(state: IntakeState): IntakeResult {
  let answered = 0;
  let majorCount = 0;
  let cautionCount = 0;
  let supportNow = false;
  for (const q of INTAKE_QUESTIONS) {
    const a: IntakeAnswer | undefined = state.answers[q.id];
    if (a) answered += 1;
    if (a !== 'yes') continue;
    if (q.kind === 'major') majorCount += 1;
    else if (q.kind === 'caution') cautionCount += 1;
    else supportNow = true;
  }
  const complete = !!state.completedAt;
  return { answered, majorCount, cautionCount, supportNow, complete, needsReview: complete && state.version !== INTAKE_VERSION };
}

/** One line for the You screen. */
export function intakeSummary(r: IntakeResult): string {
  if (!r.complete) return 'Optional, before any microdosing. A short, transparent screen · draft pending specialist review.';
  if (r.needsReview) return 'Some questions are new since you answered · review when you have a minute';
  if (r.supportNow) return 'Completed · you noted feeling unsafe — support options are one tap away';
  const n = r.majorCount + r.cautionCount;
  if (!n) return 'Completed · nothing flagged, with limits';
  return `Completed · ${n} factor${n === 1 ? '' : 's'} worth discussing with a clinician${r.majorCount ? `, ${r.majorCount} of them a major caution` : ''}`;
}
