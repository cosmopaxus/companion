import type { ElementId, ElementRating, HarmonySnapshot, Rating } from './types';
import { ELEMENT_IDS } from './types';

export interface ElementInfo {
  id: ElementId;
  name: string;
  lens: string;
  /** How the lens reads inside a sentence: "In your drive, …" */
  inPhrase: string;
  prompt: string;
  pressureExamples: string;
  resourceExamples: string;
}

export const ELEMENTS: Record<ElementId, ElementInfo> = {
  fire: {
    id: 'fire',
    name: 'Fire',
    lens: 'Will',
    inPhrase: 'your drive',
    prompt: 'Drive, conviction, the push to act.',
    pressureExamples: 'Deadlines, conflict, having to push through or prove something.',
    resourceExamples: 'Motivation, conviction, a clear reason to act, energy to begin.',
  },
  air: {
    id: 'air',
    name: 'Air',
    lens: 'Mind',
    inPhrase: 'your thinking',
    prompt: 'Attention, ideas, mental space.',
    pressureExamples: 'Mental noise, too many open loops, worry, decisions piling up.',
    resourceExamples: 'Clarity, curiosity, being able to focus, room to think.',
  },
  water: {
    id: 'water',
    name: 'Water',
    lens: 'Feeling',
    inPhrase: 'your emotional life',
    prompt: 'Emotion, tenderness, what moves through you.',
    pressureExamples: 'Grief, tension, feeling overwhelmed or holding something heavy.',
    resourceExamples: 'Feeling supported, able to feel and let feelings move, tenderness.',
  },
  earth: {
    id: 'earth',
    name: 'Earth',
    lens: 'Form',
    inPhrase: 'your body and daily structure',
    prompt: 'Body, home, rhythm, the practical ground.',
    pressureExamples: 'Poor sleep, physical discomfort, money or housing strain, chaos at home.',
    resourceExamples: 'Rest, nourishment, routines, a stable place to land.',
  },
};

export const PRESSURE_ANCHORS: Record<Rating, string> = {
  1: 'Very little',
  2: 'Some',
  3: 'Moderate',
  4: 'A lot',
  5: 'Overwhelming',
};

export const RESOURCE_ANCHORS: Record<Rating, string> = {
  1: 'Very little',
  2: 'Some',
  3: 'Moderate',
  4: 'Plenty',
  5: 'Abundant',
};

/** Map a 1–5 rating to 0–100. Preserves the existing implementation: (rating − 1) × 25. */
export function toScore(r: Rating): number {
  return (r - 1) * 25;
}

/** Element balance: (resource + 100 − pressure) / 2, rounded. 50 means pressure and resource are matched. */
export function balance(rating: ElementRating): number {
  return Math.round((toScore(rating.resource) + 100 - toScore(rating.pressure)) / 2);
}

export type BalanceBand = 'strained' | 'stretched' | 'even' | 'supported' | 'resourced';

export function bandFor(b: number): BalanceBand {
  if (b <= 24) return 'strained';
  if (b <= 44) return 'stretched';
  if (b <= 55) return 'even';
  if (b <= 75) return 'supported';
  return 'resourced';
}

export const BAND_LABEL: Record<BalanceBand, string> = {
  strained: 'Strained',
  stretched: 'Stretched',
  even: 'Even',
  supported: 'Supported',
  resourced: 'Resourced',
};

export function bandSentence(el: ElementId, b: number): string {
  const where = ELEMENTS[el].inPhrase;
  switch (bandFor(b)) {
    case 'strained':
      return `In ${where}, pressure is well ahead of resource. Worth gentleness, and perhaps one small support.`;
    case 'stretched':
      return `In ${where}, a little more is being asked than you have to give right now.`;
    case 'even':
      return `In ${where}, pressure and resource are roughly matched.`;
    case 'supported':
      return `In ${where}, you have more to draw on than is being asked of you.`;
    case 'resourced':
      return `In ${where}, there is plenty to draw on — a strength you might lean on.`;
  }
}

export function defaultRatings(): Record<ElementId, ElementRating> {
  return {
    fire: { pressure: 3, resource: 3 },
    air: { pressure: 3, resource: 3 },
    water: { pressure: 3, resource: 3 },
    earth: { pressure: 3, resource: 3 },
  };
}

export function balances(ratings: Record<ElementId, ElementRating>): Record<ElementId, number> {
  return {
    fire: balance(ratings.fire),
    air: balance(ratings.air),
    water: balance(ratings.water),
    earth: balance(ratings.earth),
  };
}

export interface ReadingSummary {
  mostResourced: { id: ElementId; value: number } | null;
  mostStretched: { id: ElementId; value: number } | null;
  allEven: boolean;
}

/** Plain-language highlights for a reading: where there is the most room, and the most strain. */
export function summarize(ratings: Record<ElementId, ElementRating>): ReadingSummary {
  const b = balances(ratings);
  const sorted = ELEMENT_IDS.map((id) => ({ id, value: b[id] })).sort((x, y) => y.value - x.value);
  const allEven = sorted[0].value === sorted[sorted.length - 1].value;
  if (allEven) return { mostResourced: null, mostStretched: null, allEven: true };
  // Stable sort: ties resolve in compass order (Fire, Air, Water, Earth).
  return { mostResourced: sorted[0], mostStretched: sorted[sorted.length - 1], allEven: false };
}

/** Change in balance per element between two snapshots (b − a). */
export function deltas(a: HarmonySnapshot, b: HarmonySnapshot): Record<ElementId, number> {
  const ba = balances(a.ratings);
  const bb = balances(b.ratings);
  return {
    fire: bb.fire - ba.fire,
    air: bb.air - ba.air,
    water: bb.water - ba.water,
    earth: bb.earth - ba.earth,
  };
}
