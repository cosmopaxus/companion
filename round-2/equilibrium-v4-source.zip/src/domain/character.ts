// The character sheet and inventory. Everything here only builds: it counts what was done
// (days practiced, goals reached, lessons mastered, wins) and never reads how someone felt.
// Compass stays separate, on its own page.
//
// "Only builds" is kept literally: lessons mastered and badges earned are recorded the first time
// they happen (paths.mastered / paths.badges), element levels and goals reached come from gem
// records (written once, never removed), so removing a practice or reopening a goal never takes
// anything back.

import type { ElementId, Journey, TierId } from './types';
import { ELEMENT_IDS } from './types';
import { bestWindow, currentTier, elementPractice, ElementPractice, firstReachedAt, isMastered, isPracticable, LESSONS, lessonsFor, liveLessonProgress, longestRun, practiceDays, TIERS } from './paths';

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;

/** Goals ever reached (their gem exists), unless the person deleted them. */
export function goalsEverReached(j: Journey): { id: string; title: string; element?: ElementId; at: string; reflection?: string; reopened: boolean }[] {
  const out = [];
  for (const g of (j.goals ?? []).filter(alive)) {
    const at = firstReachedAt(j, g.id);
    if (!at) continue;
    out.push({ id: g.id, title: g.title, element: g.element, at, reflection: g.status === 'reached' ? g.reflection : undefined, reopened: g.status !== 'reached' });
  }
  return out;
}

export interface CharacterStats {
  tier: TierId;
  rank: string;
  daysPracticed: number;
  longestRun: number;
  goalsReached: number;
  goalsOpen: number;
  lessonsMastered: number;
  wins: number;
  evidence: number;
  reflections: number;
  gems: number;
  elements: Record<ElementId, ElementPractice>;
}

export function characterStats(j: Journey): CharacterStats {
  const days = practiceDays(j);
  const tier = currentTier(j);
  const evidence = j.evidence.filter(alive);
  return {
    tier,
    rank: TIERS[tier].rank,
    daysPracticed: days.size,
    longestRun: longestRun(days),
    goalsReached: goalsEverReached(j).length,
    goalsOpen: (j.goals ?? []).filter((g) => alive(g) && g.status === 'open').length,
    lessonsMastered: LESSONS.filter((l) => isMastered(j, l)).length,
    wins: evidence.filter((e) => e.kind === 'win').length,
    evidence: evidence.length,
    reflections: j.journal.filter(alive).length,
    gems: j.gems.reduce((s, g) => s + g.amount, 0),
    elements: elementPractice(j),
  };
}

// ——— Badges ———

export interface Badge {
  id: string;
  name: string;
  /** How it is earned, in plain words. */
  how: string;
  rare?: boolean;
  element?: ElementId;
  earned: boolean;
  /** When it was earned. */
  earnedAt?: string;
}

export type BadgeDraft = Omit<Badge, 'earned' | 'earnedAt'> & { live: boolean; liveAt?: string };

function firstAt<T extends { createdAt: string; deletedAt?: string }>(list: T[], pred: (x: T) => boolean = () => true): string | undefined {
  return list.filter((x) => alive(x) && pred(x)).map((x) => x.createdAt).sort()[0];
}

function nthAt(list: string[], n: number): string | undefined {
  const s = [...list].sort();
  return s.length >= n ? s[n - 1] : undefined;
}

/** Every badge, with whether what's on record right now earns it. */
export function badgeDrafts(j: Journey): BadgeDraft[] {
  const days = practiceDays(j);
  const reached = goalsEverReached(j).map((g) => g.at);
  const ep = elementPractice(j);
  const tierWalked = (t: TierId) => {
    const ls = lessonsFor(t).filter(isPracticable);
    return ls.length > 0 && ls.every((l) => isMastered(j, l));
  };
  const anyMastered = LESSONS.some((l) => isMastered(j, l));
  const journalDates = j.journal.filter(alive).map((e) => e.createdAt);
  const list: BadgeDraft[] = [];
  const add = (b: Omit<BadgeDraft, 'live' | 'liveAt'>, live: boolean, liveAt?: string) => list.push({ ...b, live, liveAt: live ? liveAt : undefined });

  const firstCheckin = firstAt(j.checkins);
  add({ id: 'first-light', name: 'First light', how: 'Your first check-in.' }, !!firstCheckin, firstCheckin);
  const firstEvidence = firstAt(j.evidence);
  add({ id: 'witness', name: 'Witness', how: 'Your first piece of evidence.' }, !!firstEvidence, firstEvidence);
  const firstWin = firstAt(j.evidence, (e) => e.kind === 'win');
  add({ id: 'first-win', name: 'First win', how: 'Your first win recorded.' }, !!firstWin, firstWin);
  add({ id: 'pen-in-hand', name: 'Pen in hand', how: 'Ten journal entries.' }, journalDates.length >= 10, nthAt(journalDates, 10));
  const firstGoal = firstAt(j.goals ?? []);
  add({ id: 'quest-begun', name: 'Quest begun', how: 'Your first goal set.' }, !!firstGoal, firstGoal);
  add({ id: 'quest-complete', name: 'Quest complete', how: 'Your first goal reached.' }, reached.length >= 1, nthAt(reached, 1));
  add({ id: 'three-quests', name: 'Three quests', how: 'Three goals reached.' }, reached.length >= 3, nthAt(reached, 3));
  add({ id: 'steady', name: 'Steady', how: 'Practiced on 7 of any 10 days.' }, bestWindow(days, 10) >= 7);
  add({ id: 'unbroken', name: 'Unbroken', how: 'Fourteen days of practice in a row.', rare: true }, longestRun(days) >= 14);
  add({ id: 'lesson-mastered', name: 'First mastery', how: 'Your first path lesson mastered.' }, anyMastered);
  add({ id: 'foundation-laid', name: 'Foundation laid', how: 'Every Foundation lesson mastered.', rare: true }, tierWalked('foundation'));
  add({ id: 'mirror-and-breath', name: 'Mirror and breath', how: 'Every Acolyte lesson mastered.', rare: true }, tierWalked('acolyte'));
  add({ id: 'kindled', name: 'Kindled', how: 'Five Fire practices.', element: 'fire' }, ep.fire.count >= 5);
  add({ id: 'clear-sky', name: 'Clear sky', how: 'Five Air practices.', element: 'air' }, ep.air.count >= 5);
  add({ id: 'deep-water', name: 'Deep water', how: 'Five Water practices.', element: 'water' }, ep.water.count >= 5);
  add({ id: 'rooted', name: 'Rooted', how: 'Five Earth practices.', element: 'earth' }, ep.earth.count >= 5);
  add({ id: 'balance', name: 'Balance', how: 'Five practices in every element.', rare: true }, ELEMENT_IDS.every((el) => ep[el].count >= 5));
  add({ id: 'hundred-days', name: 'A hundred days', how: 'A hundred days of practice.', rare: true }, days.size >= 100);
  return list;
}

/** Every badge id, for validating restored records. Keep in step with badgeDrafts. */
export const BADGE_IDS: string[] = ['first-light', 'witness', 'first-win', 'pen-in-hand', 'quest-begun', 'quest-complete', 'three-quests', 'steady', 'unbroken', 'lesson-mastered', 'foundation-laid', 'mirror-and-breath', 'kindled', 'clear-sky', 'deep-water', 'rooted', 'balance', 'hundred-days'];

/** Badges as shown: earned if what's on record earns it now, or if it was ever earned before. */
export function badges(j: Journey): Badge[] {
  const kept = j.paths?.badges ?? {};
  return badgeDrafts(j).map(({ live, liveAt, ...b }) => {
    const at = kept[b.id] ?? liveAt;
    const earned = live || !!kept[b.id];
    return { ...b, earned, earnedAt: earned ? at : undefined };
  });
}

/** What's newly earned (lessons mastered, badges) and not yet kept. Used to record milestones once. */
export function newMilestones(j: Journey): { lessons: string[]; badges: { id: string; at?: string }[] } {
  const keptLessons = j.paths?.mastered ?? {};
  const keptBadges = j.paths?.badges ?? {};
  const lessons = LESSONS.filter((l) => isPracticable(l) && !keptLessons[l.id] && liveLessonProgress(j, l).mastered).map((l) => l.id);
  const bs = badgeDrafts(j)
    .filter((b) => b.live && !keptBadges[b.id])
    .map((b) => ({ id: b.id, at: b.liveAt }));
  return { lessons, badges: bs };
}

/** Inventory: goals reached and badges earned, newest first. */
export interface InventoryItem {
  kind: 'goal' | 'badge';
  id: string;
  name: string;
  detail?: string;
  at?: string;
  rare?: boolean;
  element?: ElementId;
  /** A reached goal that has since been reopened or let go. It stays in the inventory. */
  reopened?: boolean;
}

export function inventory(j: Journey): InventoryItem[] {
  const items: InventoryItem[] = [];
  for (const g of goalsEverReached(j)) items.push({ kind: 'goal', id: g.id, name: g.title, detail: g.reflection, at: g.at, element: g.element, reopened: g.reopened });
  for (const b of badges(j).filter((x) => x.earned)) items.push({ kind: 'badge', id: b.id, name: b.name, detail: b.how, at: b.earnedAt, rare: b.rare, element: b.element });
  return items.sort((a, b) => ((a.at ?? '') < (b.at ?? '') ? 1 : (a.at ?? '') > (b.at ?? '') ? -1 : 0));
}

