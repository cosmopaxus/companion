// The Dashboard's data: everything recorded, in one time-ordered feed, plus a seven-day look
// back at the person's own check-in readings. Pure selectors; no scores are invented — only
// what was recorded, counted or averaged.

import type { CheckInDimension } from './scales';
import type { Journey, SpaceId } from './types';
import { EVIDENCE_INFO, levelWord } from './scales';
import { balances, ELEMENTS } from './harmony';
import { localDayKey } from './time';
import { addDays, patternUnlessNamed } from './protocols';
import { isAdult } from './age';
import { ELEMENT_IDS, TIER_IDS } from './types';
import { LESSON_BY_ID, TIERS } from './paths';

export type TimelineKind = 'checkin' | 'journal' | 'harmony' | 'journey' | 'path' | 'protocol';

export type TimelineTarget =
  | { type: 'checkins' }
  | { type: 'journal' }
  | { type: 'harmony'; id: string }
  | { type: 'area'; id: string }
  | { type: 'protocol' }
  | { type: 'lesson'; id: string }
  | { type: 'goal'; id: string }
  | { type: 'tier'; id: string };

export interface TimelineItem {
  id: string;
  at: string;
  kind: TimelineKind;
  title: string;
  detail?: string;
  quote?: string;
  target: TimelineTarget;
}

export const DAY_NOTE_LABEL: Record<'taken' | 'skipped' | 'off', string> = { taken: 'Taken', skipped: 'Skipped', off: 'Integration day' };

export const TIMELINE_KIND_LABEL: Record<TimelineKind, string> = {
  checkin: 'Check-ins',
  journal: 'Journal',
  harmony: 'Compass',
  journey: 'Journey',
  path: 'Path',
  protocol: 'Protocol & day notes',
};

const alive = <T extends { deletedAt?: string }>(x: T) => !x.deletedAt;
const excerpt = (s: string | undefined, n = 140) => (s ? (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s) : undefined);

/** Everything in one feed, newest first: the Space's check-ins, journal and Harmony, plus account-wide Journey and (adults) protocol events. */
export function timeline(j: Journey, space: SpaceId): TimelineItem[] {
  const items: TimelineItem[] = [];
  for (const c of j.checkins) {
    if (!alive(c) || c.spaceId !== space) continue;
    const word = (d: CheckInDimension) => `${c[d]} ${levelWord(d, c[d])}`;
    items.push({ id: `c:${c.id}`, at: c.createdAt, kind: 'checkin', title: 'Check-in', detail: `Mood ${word('mood')} · Energy ${word('energy')} · Connection ${word('connection')}`, quote: excerpt(c.note), target: { type: 'checkins' } });
  }
  for (const e of j.journal) {
    if (!alive(e) || e.spaceId !== space) continue;
    items.push({ id: `j:${e.id}`, at: e.createdAt, kind: 'journal', title: e.prompt ? `Journal · ${e.prompt}` : 'Journal', quote: excerpt(e.text), target: { type: 'journal' } });
  }
  for (const h of j.harmony) {
    if (!alive(h) || h.spaceId !== space) continue;
    const b = balances(h.ratings);
    items.push({ id: `h:${h.id}`, at: h.createdAt, kind: 'harmony', title: 'Compass reading', detail: ELEMENT_IDS.map((el) => `${ELEMENTS[el].name} ${b[el]}`).join(' · '), quote: excerpt(h.note), target: { type: 'harmony', id: h.id } });
  }
  const areaName = new Map(j.areas.filter(alive).map((a) => [a.id, a.name]));
  for (const a of j.areas) {
    if (!alive(a)) continue;
    items.push({ id: `a:${a.id}`, at: a.createdAt, kind: 'journey', title: 'Journey area added', detail: `${a.name} · impact ${a.impact} of 5 · difficulty ${a.difficulty} of 5`, target: { type: 'area', id: a.id } });
  }
  for (const ev of j.evidence) {
    if (!alive(ev) || !areaName.has(ev.areaId)) continue;
    items.push({ id: `e:${ev.id}`, at: ev.createdAt, kind: 'journey', title: `${EVIDENCE_INFO[ev.kind].label} · ${areaName.get(ev.areaId)}`, quote: excerpt(ev.text), target: { type: 'area', id: ev.areaId } });
  }
  for (const g of j.goals ?? []) {
    if (!alive(g)) continue;
    items.push({ id: `g:${g.id}:set`, at: g.createdAt, kind: 'path', title: 'Goal set', detail: g.title, quote: excerpt(g.why), target: { type: 'goal', id: g.id } });
    if (g.status === 'reached' && g.reachedAt) items.push({ id: `g:${g.id}:reached`, at: g.reachedAt, kind: 'path', title: 'Goal reached', detail: g.title, quote: excerpt(g.reflection), target: { type: 'goal', id: g.id } });
    if (g.status === 'released' && g.releasedAt) items.push({ id: `g:${g.id}:released`, at: g.releasedAt, kind: 'path', title: 'Goal let go', detail: g.title, target: { type: 'goal', id: g.id } });
  }
  for (const p of j.practiceLogs ?? []) {
    const l = LESSON_BY_ID[p.lessonId];
    if (!alive(p) || !l) continue;
    items.push({ id: `l:${p.id}`, at: p.createdAt, kind: 'path', title: `Practiced · ${l.title}`, detail: TIERS[l.tier].name, quote: excerpt(p.note), target: { type: 'lesson', id: l.id } });
  }
  for (const t of TIER_IDS) {
    const o = j.paths?.opened?.[t];
    if (o) items.push({ id: `t:${t}`, at: o.at, kind: 'path', title: `${TIERS[t].name} path opened`, detail: o.how === 'invited' ? 'Offered when you were ready' : 'Opened as a sincere seeker', quote: excerpt(o.note), target: { type: 'tier', id: t } });
  }
  if (isAdult(j)) {
    for (const p of j.protocols) {
      if (!alive(p)) continue;
      const pattern = patternUnlessNamed(p.name, p.presetId, p.pattern);
      const detail = pattern ? `${p.name} · ${pattern}` : p.name;
      items.push({ id: `p:${p.id}:start`, at: p.createdAt, kind: 'protocol', title: 'Protocol started', detail, target: { type: 'protocol' } });
      if (p.status === 'paused' && p.pausedAt) items.push({ id: `p:${p.id}:pause`, at: p.pausedAt, kind: 'protocol', title: 'Protocol paused', detail, target: { type: 'protocol' } });
      if (p.endedAt) items.push({ id: `p:${p.id}:end`, at: p.endedAt, kind: 'protocol', title: 'Protocol ended', detail, target: { type: 'protocol' } });
    }
    for (const n of j.dayNotes ?? []) {
      if (!alive(n)) continue;
      const what = [n.substance, n.amount].filter(Boolean).join(' · ');
      items.push({ id: `n:${n.id}`, at: n.createdAt, kind: 'protocol', title: `Day note · ${DAY_NOTE_LABEL[n.status]}`, detail: what || undefined, quote: excerpt(n.note), target: { type: 'protocol' } });
    }
  }
  return items.sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : a.id < b.id ? 1 : -1));
}

/** Group a feed by local calendar day, keeping order. */
export function byDay(items: TimelineItem[]): { day: string; items: TimelineItem[] }[] {
  const out: { day: string; items: TimelineItem[] }[] = [];
  for (const it of items) {
    const day = localDayKey(it.at);
    const last = out[out.length - 1];
    if (last && last.day === day) last.items.push(it);
    else out.push({ day, items: [it] });
  }
  return out;
}

export interface FeelingDay {
  day: string;
  count: number;
  mood?: number;
  energy?: number;
  connection?: number;
}

/** The seven local days ending `today`, oldest first, with the average of each reading that day (rounded). */
export function weekFeelings(j: Journey, space: SpaceId, today: string): FeelingDay[] {
  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
  const acc = new Map(days.map((d) => [d, { n: 0, mood: 0, energy: 0, connection: 0 }]));
  for (const c of j.checkins) {
    if (!alive(c) || c.spaceId !== space) continue;
    const a = acc.get(localDayKey(c.createdAt));
    if (!a) continue;
    a.n += 1;
    a.mood += c.mood;
    a.energy += c.energy;
    a.connection += c.connection;
  }
  return days.map((day) => {
    const a = acc.get(day)!;
    return a.n
      ? { day, count: a.n, mood: Math.round(a.mood / a.n), energy: Math.round(a.energy / a.n), connection: Math.round(a.connection / a.n) }
      : { day, count: 0 };
  });
}

export interface WeekCounts {
  checkins: number;
  journal: number;
  harmony: number;
  wins: number;
  observations: number;
  setbacks: number;
}

/** What was recorded in the last seven local days (today included). Counts only; nothing is scored. */
export function weekCounts(j: Journey, space: SpaceId, today: string): WeekCounts {
  const from = addDays(today, -6);
  const inWeek = (iso: string) => {
    const d = localDayKey(iso);
    return d >= from && d <= today;
  };
  const areaIds = new Set(j.areas.filter(alive).map((a) => a.id));
  const ev = j.evidence.filter((e) => alive(e) && areaIds.has(e.areaId) && inWeek(e.createdAt));
  return {
    checkins: j.checkins.filter((c) => alive(c) && c.spaceId === space && inWeek(c.createdAt)).length,
    journal: j.journal.filter((e) => alive(e) && e.spaceId === space && inWeek(e.createdAt)).length,
    harmony: j.harmony.filter((h) => alive(h) && h.spaceId === space && inWeek(h.createdAt)).length,
    wins: ev.filter((e) => e.kind === 'win').length,
    observations: ev.filter((e) => e.kind === 'observation').length,
    setbacks: ev.filter((e) => e.kind === 'setback').length,
  };
}
