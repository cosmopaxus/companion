import React, { useEffect, useRef, useState } from 'react';
import { useInsets } from '../../ui/insets';
import { Animated, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { EvidenceKind, LessonId, Rating, SpaceId } from '../../domain/types';
import { LESSON_IDS } from '../../domain/types';
import { completeLesson, resetLessonPractice, setGuidePosition, setPractice } from '../../domain/ops';
import { guideProgress } from '../../domain/selectors';
import { AREA_EXAMPLES, DIFFICULTY_ANCHORS, EVIDENCE_INFO, IMPACT_ANCHORS } from '../../domain/scales';
import { GEM_AMOUNTS } from '../../domain/gems';
import { SPACE_NAME } from '../../domain/spaces';
import { useStore } from '../../state/store';
import { TABS, useNav } from '../../state/nav';
import { useReducedMotion } from '../../state/motion';
import { successFeedback } from '../../platform/haptics';
import { color, radius, serif, space, type } from '../../theme/tokens';
import { Button, Card, Chip, Eyebrow, IconButton, Notice, Tag } from '../../ui/primitives';
import { Field, RatingScale, Segmented } from '../../ui/controls';
import { CheckInForm, CheckInSummary, checkInComplete } from '../../ui/CheckInForm';
import { EVIDENCE_COLOR, EVIDENCE_ICON, Gem, Icon } from '../../ui/Icon';
import { EvidenceMarks } from '../../ui/EvidenceMarks';
import { LESSON_BY_ID, LESSONS, STEPS, lessonFor } from './lessons';
import { isAdult } from '../../domain/age';
import { useAccount } from '../../sync/account';

type View_ = { kind: 'map' } | { kind: 'lesson'; lesson: LessonId; step: number } | { kind: 'celebrate' };

export function Guide() {
  const nav = useNav();
  const store = useStore();
  const insets = useInsets('overlay');
  const reduce = useReducedMotion();
  const { journey } = store;
  const [view, setView] = useState<View_>({ kind: 'map' });
  const scrollRef = useRef<ScrollView>(null);
  const open = nav.guide.open;

  // Decide where to open: an explicit lesson (replay) → that lesson; a saved place in an unfinished lesson → resume; else the map.
  const [wasOpen, setWasOpen] = useState(false);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) {
      const pos = journey.guide.position;
      if (nav.guide.lesson) setView({ kind: 'lesson', lesson: nav.guide.lesson, step: 0 });
      else if (pos && !journey.guide.completed[pos.lesson]) setView({ kind: 'lesson', lesson: pos.lesson, step: pos.step });
      else setView({ kind: 'map' });
    }
  }

  useEffect(() => {
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  }, [view]);

  // Lessons completed on reaching "Learned" in this session (so closing there still counts), and whether that earned the gift.
  const [justCompleted, setJustCompleted] = useState<Partial<Record<LessonId, { rewarded: boolean }>>>({});

  const go = (lesson: LessonId, step: number) => {
    setView({ kind: 'lesson', lesson, step });
    const alreadyDone = !!store.current().guide.completed[lesson];
    if (step === 3 && !alreadyDone) {
      let rewarded = false;
      store.apply((j) => {
        const r = completeLesson(j, lesson);
        rewarded = r.rewarded;
        return setGuidePosition(r.journey, lesson, step);
      });
      successFeedback();
      setJustCompleted((m) => ({ ...m, [lesson]: { rewarded } }));
    } else if (step === 0 && alreadyDone && !justCompleted[lesson]) {
      // Replay: start the practice fresh (completion and the one-time gift are untouched).
      store.apply((j) => setGuidePosition(resetLessonPractice(j, lesson), lesson, step));
    } else {
      store.apply((j) => setGuidePosition(j, lesson, step));
    }
  };

  const finishLesson = (lesson: LessonId) => {
    const jc = justCompleted[lesson];
    if (jc?.rewarded) return setView({ kind: 'celebrate' });
    if (!jc) return setView({ kind: 'map' }); // a replay
    const next = LESSON_IDS.find((l) => l !== lesson && !store.current().guide.completed[l]);
    if (next) go(next, 0);
    else setView({ kind: 'map' });
  };

  return (
    <Modal visible={open} animationType={reduce ? 'none' : 'slide'} onRequestClose={nav.closeGuide} presentationStyle="fullScreen">
      <View style={[st.root, { paddingTop: insets.top }]} role="dialog" aria-modal aria-label="First steps guide" testID="guide">
        <View style={st.topBar}>
          {view.kind === 'lesson' ? (
            <Pressable role="button" aria-label="Back to the map" onPress={() => setView({ kind: 'map' })} hitSlop={8} style={st.mapBtn} testID="guide-map">
              <Icon name="map" size={18} color={color.gold} />
              <Text style={st.mapText}>Map</Text>
            </Pressable>
          ) : (
            <View style={[st.mapBtn, { paddingHorizontal: 8 }]}>
              <Icon name="map" size={18} color={color.gold} />
              <Text style={st.mapText}>First steps</Text>
            </View>
          )}
          <IconButton icon="close" label="Close the guide. Your place is saved." onPress={nav.closeGuide} testID="guide-close" />
        </View>
        <View style={st.practiceStrip} role="note">
          <Icon name="sparkle" size={14} color={color.gold} />
          <Text style={st.practiceStripText}>Practice mode — nothing here is added to your history</Text>
        </View>
        <ScrollView ref={scrollRef} style={{ flex: 1 }} contentContainerStyle={[st.scroll, { paddingBottom: insets.bottom + space.xxl }]} keyboardShouldPersistTaps="handled">
          <View style={st.inner}>
            {view.kind === 'map' ? <MapView onOpen={(l) => go(l, journey.guide.position?.lesson === l && !journey.guide.completed[l] ? journey.guide.position.step : 0)} onClose={nav.closeGuide} /> : null}
            {view.kind === 'lesson' ? <LessonView key={view.lesson} lesson={view.lesson} step={view.step} replay={!justCompleted[view.lesson] && !!journey.guide.completed[view.lesson]} onStep={(s) => go(view.lesson, s)} onFinish={() => finishLesson(view.lesson)} /> : null}
            {view.kind === 'celebrate' ? (
              <Celebrate
                onRealCheckIn={() => {
                  nav.closeGuide();
                  nav.reset('today');
                  nav.requestFocus('checkin');
                }}
                onMap={() => setView({ kind: 'map' })}
              />
            ) : null}
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

// ——— The five-stop map ———

function MapView({ onOpen, onClose }: { onOpen: (l: LessonId) => void; onClose: () => void }) {
  const { journey } = useStore();
  const prog = guideProgress(journey);
  const pos = journey.guide.position;
  const resumeLesson = pos && !journey.guide.completed[pos.lesson] ? pos.lesson : prog.next;
  return (
    <View style={{ gap: space.xl }} testID="guide-hub">
      <View style={{ gap: space.sm }}>
        <Text role="heading" aria-level={1} style={type.display}>
          {prog.complete ? "You've walked the whole map" : prog.done ? 'Welcome back' : 'Learn the ground'}
        </Text>
        <Text style={type.bodySoft}>
          {prog.complete
            ? 'Replay any lesson whenever you like. Practice never touches your real journey, and the completion gift is only given once.'
            : 'Five short lessons — one for each part of Equilibrium. About four minutes. You can close this any time; your place is kept.'}
        </Text>
      </View>
      {!prog.complete && resumeLesson ? (
        <Button label={prog.done ? `Continue: ${LESSON_BY_ID[resumeLesson].title}` : 'Begin with Home'} iconRight="chevron" onPress={() => onOpen(resumeLesson)} full testID="guide-continue" />
      ) : null}
      <View style={{ gap: 0 }}>
        {LESSONS.map((l, i) => {
          const done = !!journey.guide.completed[l.id];
          const inProgress = pos?.lesson === l.id && !done;
          return (
            <View key={l.id} style={{ flexDirection: 'row', gap: space.lg }}>
              <View style={{ alignItems: 'center', width: 44 }}>
                <View style={[st.stop, done && st.stopDone, inProgress && st.stopActive]}>
                  {done ? <Icon name="check" size={20} color={color.onSage} strokeWidth={2.6} /> : <Text style={[st.stopNum, inProgress && { color: color.gold }]}>{i + 1}</Text>}
                </View>
                {i < LESSONS.length - 1 ? <View style={[st.trail, done && { borderColor: color.sage }]} /> : null}
              </View>
              <Pressable
                role="button"
                aria-label={`Lesson ${i + 1}, ${l.title}: ${l.short} ${done ? 'Completed. Replay' : inProgress ? 'In progress. Resume' : 'Start'}`}
                onPress={() => onOpen(l.id)}
                style={(s: any) => [st.stopCard, (s.hovered || s.pressed) && { backgroundColor: color.paperStrong, borderColor: color.controlBorder }]}
                testID={`guide-lesson-${l.id}`}
              >
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={type.heading}>{l.title}</Text>
                  <Text style={type.small}>{l.short}</Text>
                </View>
                <Text style={[type.label, { color: done ? color.sage : color.gold }]}>{done ? 'Replay' : inProgress ? 'Resume' : 'Start'}</Text>
              </Pressable>
            </View>
          );
        })}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, justifyContent: 'center' }}>
        <Gem size={16} tone={journey.guide.rewardGrantedAt ? 'gold' : 'muted'} />
        <Text style={type.small}>{journey.guide.rewardGrantedAt ? `Completion gift received: +${GEM_AMOUNTS['guide-complete']} gems in Personal` : `Finish all five for a one-time gift of ${GEM_AMOUNTS['guide-complete']} gems`}</Text>
      </View>
      <Button label={prog.complete ? 'Close' : 'Close for now'} kind="quiet" onPress={onClose} style={{ alignSelf: 'center' }} />
    </View>
  );
}

// ——— A lesson: why → example → try → learned ———

function LessonView({ lesson, step, replay, onStep, onFinish }: { lesson: LessonId; step: number; replay: boolean; onStep: (s: number) => void; onFinish: () => void }) {
  const { journey } = useStore();
  const adult = isAdult(journey);
  const info = lessonFor(lesson, adult);
  const [tried, setTried] = useState(false);
  const idx = LESSON_IDS.indexOf(lesson);
  const nextLesson = LESSONS.find((l) => l.id !== lesson && !journey.guide.completed[l.id]);
  const practiceDone = isPracticeDone(lesson, journey.guide.practice, adult) || tried;

  return (
    <View style={{ gap: space.xl }} testID={`lesson-${lesson}`}>
      <View style={{ gap: space.sm }}>
        <Eyebrow>
          Lesson {idx + 1} of 5 · {info.title}
          {replay ? ' · replay' : ''}
        </Eyebrow>
        <View style={st.steps} aria-label={`Step ${step + 1} of 4: ${STEPS[step]}`}>
          {STEPS.map((s, i) => (
            <View key={s} style={{ flex: 1, gap: 4 }}>
              <View style={[st.stepBar, i <= step && { backgroundColor: i === step ? color.gold : color.sage }]} />
              <Text style={[st.stepLabel, i === step && { color: color.ink, fontWeight: '700' }]}>{s}</Text>
            </View>
          ))}
        </View>
      </View>

      {step === 0 ? (
        <View style={{ gap: space.lg }} testID="lesson-why">
          <View style={st.bigIcon}>
            <Icon name={info.icon} size={34} color={color.sage} />
          </View>
          <Text role="heading" aria-level={1} style={type.display}>
            {info.why}
          </Text>
          <Text style={[type.body, { fontSize: 17, lineHeight: 26 }]}>{info.whyDetail}</Text>
          <TabHint tab={info.tab} />
        </View>
      ) : null}

      {step === 1 ? (
        <View style={{ gap: space.lg }} testID="lesson-example">
          <Text role="heading" aria-level={1} style={type.title}>
            Example: {info.exampleTitle}
          </Text>
          <LessonExample lesson={lesson} />
          <Text style={type.bodySoft}>{info.exampleCaption}</Text>
        </View>
      ) : null}

      {step === 2 ? (
        <View style={{ gap: space.lg }} testID="lesson-try">
          <View style={{ gap: 4 }}>
            <Text role="heading" aria-level={1} style={type.title}>
              {info.tryTitle}
            </Text>
            <Text style={type.bodySoft}>{info.tryPrompt}</Text>
          </View>
          <Card tone="practice" style={{ gap: space.lg }}>
            <Tag label="Practice" tone="practice" icon="sparkle" />
            <LessonTry lesson={lesson} onDone={() => setTried(true)} />
          </Card>
        </View>
      ) : null}

      {step === 3 ? (
        <View style={{ gap: space.lg }} testID="lesson-learned">
          <Stamp label={info.title} />
          <Text role="heading" aria-level={1} style={[type.display, { textAlign: 'center' }]}>
            {replay ? 'A good refresher.' : 'Nicely done.'}
          </Text>
          <Card style={{ gap: space.md }}>
            {info.learned.map((t) => (
              <View key={t} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
                <Icon name="check" size={18} color={color.sage} strokeWidth={2.4} />
                <Text style={[type.body, { flex: 1 }]}>{t}</Text>
              </View>
            ))}
          </Card>
          <TabHint tab={info.tab} />
        </View>
      ) : null}

      <View style={st.lessonNav}>
        {step > 0 ? <Button label="Back" kind="quiet" onPress={() => onStep(step - 1)} testID="lesson-back" /> : <View />}
        {step < 2 ? <Button label={step === 0 ? 'Show me an example' : 'Let me try'} iconRight="chevron" onPress={() => onStep(step + 1)} testID="lesson-next" /> : null}
        {step === 2 ? <Button label="Continue" iconRight="chevron" onPress={() => onStep(3)} disabled={!practiceDone} testID="lesson-next" /> : null}
        {step === 3 ? <Button label={replay ? 'Back to the map' : nextLesson ? `Next: ${nextLesson.title}` : 'Finish first steps'} iconRight="chevron" kind={!nextLesson && !replay ? 'gold' : 'primary'} onPress={onFinish} testID="lesson-finish" /> : null}
      </View>
      {step === 2 && !practiceDone ? <Text style={[type.small, { textAlign: 'right' }]}>Finish the practice above to continue.</Text> : null}
    </View>
  );
}

function isPracticeDone(lesson: LessonId, p: ReturnType<typeof useStore>['journey']['guide']['practice'], adult: boolean): boolean {
  switch (lesson) {
    case 'today':
      return !!p.checkin?.saved;
    case 'journey':
      return !!p.evidence?.saved;
    case 'connect':
      return p.privacyAnswer === 'only-me';
    case 'journal':
      return !!p.journalSaved;
    case 'you':
      return (!adult || !!p.spaceToggle) && !!p.gemRevealed;
  }
}

function TabHint({ tab }: { tab: string }) {
  const labels: Record<string, string> = { today: 'Home', journey: 'Journey', connect: 'Connect', journal: 'Journal', you: 'You' };
  return (
    <View style={{ gap: space.sm }}>
      <Text style={type.small}>Find it in the {labels[tab]} tab:</Text>
      <View style={st.miniBar} aria-hidden>
        {TABS.map((t) => (
          <View key={t} style={[st.miniTab, t === tab && st.miniTabOn]}>
            <Icon name={t as any} size={18} color={t === tab ? color.sage : color.controlBorder} filled={t === tab} />
            <Text style={[st.miniTabText, t === tab && { color: color.sage, fontWeight: '700' }]}>{labels[t]}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function Stamp({ label }: { label: string }) {
  const reduce = useReducedMotion();
  const [scale] = useState(() => new Animated.Value(reduce ? 1 : 0.6));
  useEffect(() => {
    if (reduce) return;
    Animated.spring(scale, { toValue: 1, useNativeDriver: false, friction: 5, tension: 120 }).start();
  }, [reduce, scale]);
  return (
    <Animated.View style={[st.stamp, { transform: [{ scale }, { rotate: '-6deg' }] }]} aria-hidden>
      <Icon name="check" size={26} color={color.sage} strokeWidth={2.6} />
      <Text style={st.stampText}>{label.toUpperCase()}</Text>
      <Text style={st.stampSub}>learned</Text>
    </Animated.View>
  );
}

// ——— Examples (static) ———

function LessonExample({ lesson }: { lesson: LessonId }) {
  const account = useAccount();
  const store = useStore();
  switch (lesson) {
    case 'today':
      return (
        <Card style={{ gap: space.md }}>
          <Tag label="Example" />
          <CheckInSummary mood={52} energy={71} connection={28} />
          <Text style={[type.body, { fontStyle: 'italic' }]}>“Slept well. Quiet morning. Missed Sam.”</Text>
        </Card>
      );
    case 'journey': {
      const ex = [
        { id: 'x1', kind: 'win' as EvidenceKind, text: 'Lights out by 11 on Tuesday' },
        { id: 'x2', kind: 'observation' as EvidenceKind, text: 'Coffee after 2pm makes falling asleep harder' },
        { id: 'x3', kind: 'setback' as EvidenceKind, text: 'Up past 1am on Friday — I was restless' },
      ];
      return (
        <Card style={{ gap: space.md }}>
          <Tag label="Example" />
          <Text style={type.heading}>A steadier sleep rhythm</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            <Tag label="Easy win" tone="sage" icon="leaf" />
            <Tag label="Impact 5 · Life-changing" />
            <Tag label="Difficulty 2 · Manageable" />
          </View>
          <EvidenceMarks evidence={ex.map((e, i) => ({ ...e, areaId: 'x', spaceId: 'personal', createdAt: String(i), updatedAt: String(i) }))} />
          {ex.map((e) => (
            <View key={e.id} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
              <Icon name={EVIDENCE_ICON[e.kind]} size={18} color={EVIDENCE_COLOR[e.kind]} />
              <Text style={[type.small, { color: color.ink, flex: 1 }]}>
                <Text style={{ fontWeight: '700', color: EVIDENCE_COLOR[e.kind] }}>{EVIDENCE_INFO[e.kind].label}: </Text>
                {e.text}
              </Text>
            </View>
          ))}
          <Text style={type.small}>1 win · 1 observation · 1 setback</Text>
        </Card>
      );
    }
    case 'connect':
      return (
        <View style={{ gap: space.md }}>
          <Card style={{ gap: space.sm }}>
            <Tag label="Planned" tone="gold" />
            <Text style={type.body}>Pulse, a quiet shared presence · gatherings in real life · sharing you explicitly choose</Text>
          </Card>
          <Card tone="sage" style={{ gap: space.sm }}>
            <Tag label="Available now" tone="sage" />
            <Text style={type.body}>Practice the Connect direction on your own: a Journey area, or a journal entry about someone you'd like to reach.</Text>
          </Card>
        </View>
      );
    case 'journal':
      return (
        <Card style={{ gap: space.sm }}>
          <Tag label="Example" />
          <Text style={st.prompt}>A small thing that went well</Text>
          <Text style={type.body}>Walked the long way home. Noticed the light on the river, and didn't reach for my phone once.</Text>
        </Card>
      );
    case 'you': {
      const rows = [
            ...(isAdult(store.journey) ? [['swap', 'Spaces', 'Personal and Be Well each keep their own check-ins, journal, Compass and gems.']] : []),
            ['sparkle', 'Gems', 'A ledger of participation you can inspect line by line.'],
            ['download', 'Your data', 'Export everything as one file; restore it later.'],
            ['device', 'Account', account.signedIn ? `Signed in as ${account.user?.email} — your journey syncs across devices.` : account.configured ? 'Guest for now — sign in any time to use one journey across devices.' : 'Guest — saved on this device only. Accounts aren’t connected in this build.'],
      ];
      return (
        <Card padded={false}>
          {rows.map(([icon, title, body], i) => (
            <View key={title} style={[{ flexDirection: 'row', gap: space.md, padding: space.lg, alignItems: 'flex-start' }, i < rows.length - 1 && { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border }]}>
              <Icon name={icon as any} size={20} color={color.sage} />
              <View style={{ flex: 1 }}>
                <Text style={type.label}>{title}</Text>
                <Text style={type.small}>{body}</Text>
              </View>
            </View>
          ))}
        </Card>
      );
    }
  }
}

// ——— Try (interactive, practice-only) ———

function LessonTry({ lesson, onDone }: { lesson: LessonId; onDone: () => void }) {
  const store = useStore();
  const p = store.journey.guide.practice;
  const set = (patch: Parameters<typeof setPractice>[1]) => store.apply((j) => setPractice(j, patch));

  if (lesson === 'today') {
    const v = p.checkin ?? {};
    return (
      <View style={{ gap: space.lg }}>
        <CheckInForm idPrefix="practice-checkin" value={v} onChange={(nv) => set({ checkin: { ...nv, saved: false } })} noteLabel="Practice note" />
        <Button
          label="Save practice check-in"
          full
          disabled={!checkInComplete(v)}
          onPress={() => {
            set({ checkin: { ...v, saved: true } });
            onDone();
          }}
          testID="practice-checkin-save"
        />
        {v.saved ? <Notice tone="success">Practice saved — and not added to your history. A real one earns {GEM_AMOUNTS.checkin} gems.</Notice> : null}
      </View>
    );
  }

  if (lesson === 'journey') {
    const a = p.area ?? {};
    const e = p.evidence ?? {};
    return (
      <View style={{ gap: space.lg }}>
        <View style={{ gap: space.sm }}>
          <Text style={type.label}>1. Pick an intention</Text>
          <View role="radiogroup" aria-label="Example intentions" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {AREA_EXAMPLES.map((ex) => (
              <Chip key={ex} radio label={ex} selected={a.name === ex} onPress={() => set({ area: { impact: 4, difficulty: 2, ...a, name: ex }, evidence: { ...e, saved: false } })} />
            ))}
          </View>
        </View>
        {a.name ? (
          <>
            <RatingScale compact label="Impact" anchors={IMPACT_ANCHORS} value={a.impact as Rating} onChange={(r) => set({ area: { ...a, impact: r } })} />
            <RatingScale compact label="Difficulty" anchors={DIFFICULTY_ANCHORS} value={a.difficulty as Rating} onChange={(r) => set({ area: { ...a, difficulty: r } })} />
            {a.difficulty && a.difficulty <= 2 ? <Tag label="Easy win" tone="sage" icon="leaf" /> : null}
            <View style={{ gap: space.sm }}>
              <Text style={type.label}>2. Describe a small piece of evidence</Text>
              <Segmented
                label="Kind of evidence"
                value={e.kind}
                onChange={(k) => set({ evidence: { ...e, kind: k, saved: false } })}
                options={(['win', 'observation', 'setback'] as EvidenceKind[]).map((k) => ({ value: k, label: EVIDENCE_INFO[k].label, icon: EVIDENCE_ICON[k], helper: EVIDENCE_INFO[k].helper, tone: EVIDENCE_COLOR[k] }))}
                testID="practice-evidence-kind"
              />
              <Field aria-label="Practice evidence" value={e.text ?? ''} onChangeText={(t) => set({ evidence: { ...e, text: t, saved: false } })} placeholder="e.g. I took a ten-minute walk" testID="practice-evidence-text" />
            </View>
            <Button
              label="Save practice evidence"
              full
              disabled={!e.kind || !(e.text ?? '').trim()}
              onPress={() => {
                set({ evidence: { ...e, saved: true } });
                onDone();
              }}
              testID="practice-evidence-save"
            />
            {e.saved && e.kind ? (
              <Notice tone="success">
                {e.kind === 'win' ? 'A win — that would add to the win count.' : e.kind === 'observation' ? 'An observation — noticing is practice too.' : 'A setback — useful information, not failure.'} Practice only; nothing was saved.
              </Notice>
            ) : null}
          </>
        ) : null}
      </View>
    );
  }

  if (lesson === 'connect') {
    const opts: { v: 'only-me' | 'space' | 'everyone'; label: string }[] = [
      { v: 'only-me', label: 'Only me' },
      { v: 'space', label: 'Everyone in my Space' },
      { v: 'everyone', label: 'Anyone in Connect' },
    ];
    return (
      <View style={{ gap: space.md }}>
        <View role="radiogroup" aria-label="Who can read your journal right now?" style={{ gap: space.sm }}>
          {opts.map((o) => (
            <Chip
              key={o.v}
              radio
              label={o.label}
              selected={p.privacyAnswer === o.v}
              onPress={() => {
                set({ privacyAnswer: o.v });
                if (o.v === 'only-me') onDone();
              }}
            />
          ))}
        </View>
        {p.privacyAnswer === 'only-me' ? <Notice tone="success">Right. Only you. Nothing in Equilibrium is shared, and Spaces don't publish anything.</Notice> : null}
        {p.privacyAnswer && p.privacyAnswer !== 'only-me' ? <Notice>Not quite — try again. Nothing you write is visible to anyone else.</Notice> : null}
      </View>
    );
  }

  if (lesson === 'journal') {
    const text = p.journalText ?? 'Today I noticed ';
    return (
      <View style={{ gap: space.md }}>
        <Field aria-label="Practice reflection" value={text} onChangeText={(t) => set({ journalText: t, journalSaved: false })} multiline minHeight={100} testID="practice-journal-text" />
        <Button
          label="Save practice reflection"
          full
          disabled={!text.trim() || text.trim() === 'Today I noticed'}
          onPress={() => {
            set({ journalText: text, journalSaved: true });
            onDone();
          }}
          testID="practice-journal-save"
        />
        {p.journalSaved ? (
          <View style={st.practiceEntry}>
            <Tag label="Practice entry · not in your journal" tone="practice" />
            <Text style={type.body}>{p.journalText}</Text>
          </View>
        ) : null}
      </View>
    );
  }

  // you
  const sp: SpaceId = p.spaceToggle ?? store.journey.activeSpaceId;
  const adult = isAdult(store.journey);
  return (
    <View style={{ gap: space.lg }}>
      {adult ? (
      <View role="radiogroup" aria-label="Practice Space" style={{ flexDirection: 'row', gap: space.sm }}>
        {(['personal', 'bewell'] as SpaceId[]).map((s) => (
          <Chip key={s} radio label={SPACE_NAME[s]} selected={p.spaceToggle === s} onPress={() => set({ spaceToggle: s })} />
        ))}
      </View>
      ) : null}
      {adult && p.spaceToggle ? (
        <Notice>{`In ${SPACE_NAME[sp]}, you'd see ${SPACE_NAME[sp]}'s own check-ins, journal, Compass readings and gems. Your Journey areas would stay exactly the same.`}</Notice>
      ) : null}
      <Pressable role="button" aria-label="Tap the gem to learn what gems mean" onPress={() => { set({ gemRevealed: true }); if (p.spaceToggle || !adult) onDone(); }} style={st.gemTap} testID="practice-gem">
        <Gem size={30} />
        <Text style={[type.label, { flex: 1 }]}>{p.gemRevealed ? 'Gems recognize showing up — check-ins, reflections, evidence. No cash value, nothing to buy.' : 'Tap the gem'}</Text>
      </Pressable>
    </View>
  );
}

function Celebrate({ onRealCheckIn, onMap }: { onRealCheckIn: () => void; onMap: () => void }) {
  const reduce = useReducedMotion();
  const [scale] = useState(() => new Animated.Value(reduce ? 1 : 0.4));
  useEffect(() => {
    if (!reduce) Animated.spring(scale, { toValue: 1, useNativeDriver: false, friction: 4, tension: 90 }).start();
  }, [reduce, scale]);
  return (
    <View style={{ gap: space.xl, alignItems: 'center', paddingTop: space.xl }} testID="guide-celebrate">
      <Animated.View style={{ transform: [{ scale }] }}>
        <View style={st.celebrateGem}>
          <Gem size={56} />
        </View>
      </Animated.View>
      <Text role="heading" aria-level={1} style={[type.display, { textAlign: 'center' }]}>
        You've walked the whole map.
      </Text>
      <Text style={[type.bodySoft, { textAlign: 'center', maxWidth: 440 }]}>
        {GEM_AMOUNTS['guide-complete']} gems are in your Personal Space — a one-time thank-you for learning the ground. Replaying lessons later won't add more.
      </Text>
      <Card style={{ gap: space.sm, alignSelf: 'stretch' }}>
        <Text style={type.heading}>Your first real step</Text>
        <Text style={type.bodySoft}>How are you arriving, right now? This one counts.</Text>
        <Button label="Check in for real" full onPress={onRealCheckIn} testID="celebrate-checkin" />
      </Card>
      <Button label="Back to the map" kind="quiet" onPress={onMap} />
    </View>
  );
}

const st = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.canvas },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: space.md, paddingVertical: 4, gap: space.sm },
  practiceStrip: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 8, paddingHorizontal: space.lg, backgroundColor: color.goldWash, borderTopWidth: 1, borderBottomWidth: 1, borderColor: color.goldBorder, borderStyle: 'dashed' },
  practiceStripText: { fontSize: 13.5, fontWeight: '600', color: color.gold, textAlign: 'center' },
  mapBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44, paddingHorizontal: 8 },
  mapText: { fontFamily: serif, fontSize: 17, color: color.ink },
  scroll: { paddingHorizontal: space.lg, paddingTop: space.xl },
  inner: { width: '100%', maxWidth: 600, alignSelf: 'center' },
  stop: { width: 40, height: 40, borderRadius: 20, borderWidth: 2, borderColor: color.controlBorder, backgroundColor: color.paperStrong, alignItems: 'center', justifyContent: 'center' },
  stopDone: { backgroundColor: color.sage, borderColor: color.sage },
  stopActive: { borderColor: color.gold, borderWidth: 2.5 },
  stopNum: { fontSize: 16, fontWeight: '700', color: color.inkSoft },
  trail: { flex: 1, width: 0, borderLeftWidth: 2, borderStyle: 'dashed', borderColor: color.controlBorder, minHeight: 18 },
  stopCard: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.lg, marginBottom: space.md, borderRadius: radius.lg, borderWidth: 1, borderColor: color.border, backgroundColor: color.paper },
  steps: { flexDirection: 'row', gap: 6 },
  stepBar: { height: 4, borderRadius: 2, backgroundColor: color.border },
  stepLabel: { fontSize: 12.5, color: color.inkSoft },
  bigIcon: { width: 64, height: 64, borderRadius: 32, backgroundColor: color.sageWash, alignItems: 'center', justifyContent: 'center' },
  lessonNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: space.md },
  miniBar: { flexDirection: 'row', backgroundColor: color.paper, borderRadius: radius.md, borderWidth: 1, borderColor: color.border, padding: 4 },
  miniTab: { flex: 1, alignItems: 'center', gap: 2, paddingVertical: 6, borderRadius: radius.sm },
  miniTabOn: { backgroundColor: color.sageWash },
  miniTabText: { fontSize: 11, color: color.inkSoft },
  stamp: { alignSelf: 'center', width: 132, height: 132, borderRadius: 66, borderWidth: 3, borderColor: color.sage, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong },
  stampText: { fontSize: 15, fontWeight: '800', letterSpacing: 2, color: color.sage, marginTop: 2 },
  stampSub: { fontFamily: serif, fontStyle: 'italic', fontSize: 14, color: color.gold },
  prompt: { fontFamily: serif, fontStyle: 'italic', fontSize: 17, color: color.sage2 },
  practiceEntry: { gap: space.sm, padding: space.lg, borderRadius: radius.md, backgroundColor: color.paper, borderWidth: 1, borderColor: color.border },
  gemTap: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.lg, borderRadius: radius.md, borderWidth: 1.5, borderStyle: 'dashed', borderColor: color.goldDeco, backgroundColor: color.paperStrong, minHeight: 64 },
  celebrateGem: { width: 110, height: 110, borderRadius: 55, backgroundColor: color.goldWash, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: color.goldBorder },
});
