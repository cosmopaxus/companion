import type { LessonId } from '../../domain/types';
import type { IconName } from '../../ui/Icon';
import type { TabId } from '../../state/nav';

export interface LessonInfo {
  id: LessonId;
  tab: TabId;
  icon: IconName;
  title: string;
  short: string;
  why: string;
  whyDetail: string;
  exampleTitle: string;
  exampleCaption: string;
  tryTitle: string;
  tryPrompt: string;
  learned: string[];
}

export const LESSONS: LessonInfo[] = [
  {
    id: 'today',
    tab: 'today',
    icon: 'home',
    title: 'Home',
    short: 'Notice how you are arriving.',
    why: 'Home is where you check in, and where everything comes together.',
    whyDetail: 'Home opens first. Your rhythm, your Compass, the last seven days and your timeline all live there. At its heart is the check-in: three quick sliders from 0 to 100 — mood, energy and connection — and an optional note. Each one has its own picture, color and sound that follow the slider. Check in as often as you like; there is no right number.',
    exampleTitle: 'An imaginary slow Sunday',
    exampleCaption: 'Rested, a little flat, missing a friend. Notice that nothing here is "good" or "bad" — just where things are.',
    tryTitle: 'Try it for the imaginary day',
    tryPrompt: 'Choose a mood, energy and connection for that Sunday, then save the practice check-in.',
    learned: ['Honest beats high: a low reading counts exactly as much as a high one.', 'A real check-in earns 2 gems, whatever the ratings.', 'This one was practice, so nothing was added to your history.'],
  },
  {
    id: 'journey',
    tab: 'journey',
    icon: 'journey',
    title: 'Journey',
    short: 'Practice what matters, and collect evidence.',
    why: 'Journey holds the few things you are practicing.',
    whyDetail: 'Rate each area for impact and difficulty; Equilibrium lists the most impactful, easiest ones first. Then record evidence of what actually happens.',
    exampleTitle: 'A steadier sleep rhythm',
    exampleCaption: 'High impact, low difficulty — an easy win. Its history holds wins, observations and setbacks side by side.',
    tryTitle: 'Try an intention and a first piece of evidence',
    tryPrompt: 'Pick an example intention, then describe one small thing that happened.',
    learned: ['Wins, observations and setbacks are all practice. Setbacks are information, not verdicts.', 'Only wins add to the win count; every piece of evidence earns a gem.', 'There is no percentage of progress — the evidence is the progress.'],
  },
  {
    id: 'connect',
    tab: 'connect',
    icon: 'connect',
    title: 'Connect',
    short: 'A future home for practicing together.',
    why: 'Connect is about people — later, and on your terms.',
    whyDetail: "It will hold shared presence and real-world gatherings. In this alpha it's a preview: it doesn't connect you to anyone yet.",
    exampleTitle: "What's planned, and what's here now",
    exampleCaption: "Not to be confused with the Connect direction, which is a personal practice you can start today.",
    tryTitle: 'A quick privacy check',
    tryPrompt: 'Who can read your journal right now?',
    learned: ['Nothing you write is shared.', 'When Connect arrives, sharing will always be its own explicit choice.', 'Switching Spaces never publishes anything.'],
  },
  {
    id: 'journal',
    tab: 'journal',
    icon: 'journal',
    title: 'Journal',
    short: 'A private place to notice and understand.',
    why: 'One private stream for reflection.',
    whyDetail: 'Write freely, or start from a gentle prompt. Entries are saved with the time and the Space you are in, and you can edit them later.',
    exampleTitle: 'A small thing that went well',
    exampleCaption: 'Short is fine. Specific is better than profound.',
    tryTitle: 'Write a practice reflection',
    tryPrompt: 'Edit the line below, or write your own. It stays in this guide.',
    learned: ['Your real journal starts empty and stays private.', 'Drafts are kept on the device until you save.', 'Each real entry earns 1 gem.'],
  },
  {
    id: 'you',
    tab: 'you',
    icon: 'you',
    title: 'You',
    short: 'Spaces, gems and your data.',
    why: 'You is where you make Equilibrium yours.',
    whyDetail: 'Switch Spaces, see your gem ledger, change your direction, and export or restore your whole journey.',
    exampleTitle: 'What lives in You',
    exampleCaption: 'Everything here is under your control.',
    tryTitle: 'Try switching Space',
    tryPrompt: 'Tap a Space to see what would change. This is practice — your real Space stays as it is.',
    learned: ['Check-ins, journal, Compass and gems follow the Space. Journey areas stay with you everywhere.', 'Gems recognize showing up. They have no cash value.', 'Export a backup any time. Accounts will carry your journey across devices once connected.'],
  },
];

export const LESSON_BY_ID: Record<LessonId, LessonInfo> = Object.fromEntries(LESSONS.map((l) => [l.id, l])) as Record<LessonId, LessonInfo>;

export const STEPS = ['Why', 'Example', 'Try', 'Learned'] as const;

/** Under 18 there's only the Personal Space, so the You lesson practices gems instead of switching Space. */
const YOU_REFLECTION: Partial<LessonInfo> = {
  whyDetail: 'See your gem ledger, change your direction, and export or restore your whole journey.',
  tryTitle: 'Try the gem',
  tryPrompt: 'Tap the gem to see what it means. This is practice — nothing is added to your history.',
  learned: ['Gems recognize showing up. They have no cash value.', 'Your journey is saved on this device, in your Personal Space.', 'Export a backup any time from Your data.'],
};

export function lessonFor(id: LessonId, adult: boolean): LessonInfo {
  const base = LESSON_BY_ID[id];
  return !adult && id === 'you' ? { ...base, ...YOU_REFLECTION } : base;
}
