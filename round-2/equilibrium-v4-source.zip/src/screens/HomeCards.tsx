import React, { useMemo, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import type { CheckInDimension } from '../domain/scales';
import { CHECKIN_SCALES, levelWord } from '../domain/scales';
import type { DayNoteStatus, TierId } from '../domain/types';
import { isAdult } from '../domain/age';
import { deleteDayNote, DayNoteInput, saveDayNote } from '../domain/ops';
import { addDays, currentProtocol, DAY_LABEL, dayFor, formatDay, nextActivation, START_LOW, upcoming, WEEKDAY_SHORT, weekdayOf } from '../domain/protocols';
import { byDay, DAY_NOTE_LABEL, FeelingDay, timeline, TIMELINE_KIND_LABEL, TimelineItem, TimelineKind, weekCounts, weekFeelings } from '../domain/timeline';
import { formatDayHeading, formatTime } from '../domain/time';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { color, radius, sans, space, type } from '../theme/tokens';
import { Sheet } from '../ui/layout';
import { Field } from '../ui/controls';
import { useToast } from '../state/toast';
import { Button, Card, Chip, Eyebrow, focusRing, Notice } from '../ui/primitives';
import { Icon, IconName } from '../ui/Icon';
import { RhythmStrip } from '../ui/RhythmStrip';
import { FeelGlyph } from '../ui/feel/FeelGlyph';

const DIMS: CheckInDimension[] = ['mood', 'energy', 'connection'];

const KIND_ICON: Record<TimelineKind, IconName> = {
  checkin: 'today',
  journal: 'journal',
  harmony: 'compass',
  journey: 'journey',
  path: 'path',
  protocol: 'calendar',
};

// ——— Rhythm (adults) ———

const STATUS_CHOICES: { id: DayNoteStatus; label: string }[] = [
  { id: 'taken', label: 'Taken' },
  { id: 'skipped', label: 'Skipped' },
  { id: 'off', label: 'Integration day' },
];

/** Today's place in your rhythm, with a quiet way to note what actually happened. */
export function RhythmCard({ today }: { today: string }) {
  const store = useStore();
  const { journey } = store;
  const nav = useNav();
  const toast = useToast();
  const [noting, setNoting] = useState(false);
  const p = currentProtocol(journey);
  const note = journey.dayNotes.find((n) => n.day === today && !n.deletedAt);
  if (!p) {
    return (
      <Card style={{ gap: space.sm }} testID="dash-rhythm">
        <Eyebrow heading>Your rhythm</Eyebrow>
        <Text style={type.heading}>No protocol yet</Text>
        <Text style={type.small}>Choose a common schedule or create your own, and your activation and integration days show here.</Text>
        <Button label="Choose a protocol" small kind="secondary" icon="calendar" onPress={() => nav.push({ name: 'protocol' })} style={{ alignSelf: 'flex-start' }} />
      </Card>
    );
  }
  const info = dayFor(p, today);
  const tomorrow = p.status === 'active' ? dayFor(p, addDays(today, 1)) : null;
  const next = p.status === 'active' ? nextActivation(p, addDays(today, 1)) : null;
  const label =
    info.kind === 'activation' || info.kind === 'integration'
      ? `${DAY_LABEL[info.kind]}${info.of && info.of > 1 ? ` ${info.index} of ${info.of}` : ''}`
      : info.kind === 'rest'
        ? `Rest period · day ${info.index} of ${info.of}`
        : info.kind === 'upcoming'
          ? `Starts ${formatDay(p.startDate, 'long')}`
          : DAY_LABEL[info.kind];
  const tomorrowWord = tomorrow && (tomorrow.kind === 'activation' || tomorrow.kind === 'integration' || tomorrow.kind === 'rest') ? DAY_LABEL[tomorrow.kind] : null;
  const noteWords = note ? [DAY_NOTE_LABEL[note.status], note.status === 'taken' ? note.amount : undefined].filter(Boolean).join(' · ') : '';
  return (
    <Card tone={info.kind === 'activation' ? 'gold' : 'paper'} style={{ gap: space.md }} testID="dash-rhythm">
      <View style={{ gap: 2 }}>
        <Eyebrow heading>Your rhythm · today</Eyebrow>
        <Text style={type.title} testID="dash-rhythm-today">
          {label}
        </Text>
        <Text style={type.small}>
          {p.name}
          {next && next !== addDays(today, 1) ? ` · next activation ${formatDay(next, 'long')}` : ''}
        </Text>
        {tomorrowWord ? (
          <Text style={type.small} testID="dash-rhythm-tomorrow">
            Tomorrow: {tomorrowWord.toLowerCase()}
          </Text>
        ) : null}
      </View>
      {p.status === 'active' ? <RhythmStrip days={upcoming(p, today, 7)} today={today} /> : null}
      {info.kind === 'integration' && !note ? (
        <View style={st.integration} testID="dash-rhythm-integration">
          <Text style={[type.small, { color: color.ink }]}>An integration day: notice what's settling. What's shifting for you?</Text>
          <Button
            label="Write about it"
            small
            kind="quiet"
            icon="journal"
            onPress={() => {
              nav.requestFocus("journal:What's shifting for me?");
              nav.setTab('journal');
            }}
            testID="dash-rhythm-write"
          />
        </View>
      ) : null}
      {note ? (
        <View style={st.noted} testID="dash-day-noted">
          <Icon name="check" size={16} color={color.sage} />
          <Text style={[type.small, { flex: 1, color: color.ink }]}>Noted · {noteWords}</Text>
          <Button label="Edit" small kind="quiet" onPress={() => setNoting(true)} testID="dash-day-edit" />
        </View>
      ) : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
        {!note ? <Button label="Note today" small icon="plus" onPress={() => setNoting(true)} testID="dash-note-today" /> : null}
        <Button label="Open your protocol" small kind="secondary" onPress={() => nav.push({ name: 'protocol' })} testID="dash-open-protocol" />
      </View>
      {noting ? (
        <NoteTodaySheet
          today={today}
          dayLabel={label}
          protocolId={p.id}
          defaults={{ status: note?.status ?? (info.kind === 'activation' ? 'taken' : info.kind === 'integration' || info.kind === 'rest' ? 'off' : undefined), substance: note?.substance ?? p.substance, amount: note?.amount ?? p.amount, note: note?.note }}
          existing={!!note}
          onClose={() => setNoting(false)}
          onSave={(input) => {
            const r = store.apply((jj) => saveDayNote(jj, input));
            if (!r.ok) return r.error;
            setNoting(false);
            toast.show('Noted · saved on this device');
            return null;
          }}
          onDelete={() => {
            store.apply((jj) => deleteDayNote(jj, today));
            setNoting(false);
            toast.show('Note removed');
          }}
        />
      ) : null}
    </Card>
  );
}

function NoteTodaySheet({
  today,
  dayLabel,
  protocolId,
  defaults,
  existing,
  onClose,
  onSave,
  onDelete,
}: {
  today: string;
  dayLabel: string;
  protocolId: string;
  defaults: { status?: DayNoteStatus; substance?: string; amount?: string; note?: string };
  existing: boolean;
  onClose: () => void;
  onSave: (input: DayNoteInput) => string | null;
  onDelete: () => void;
}) {
  const [status, setStatus] = useState<DayNoteStatus | undefined>(defaults.status);
  const [substance, setSubstance] = useState(defaults.substance ?? '');
  const [amount, setAmount] = useState(defaults.amount ?? '');
  const [text, setText] = useState(defaults.note ?? '');
  const [error, setError] = useState<string | null>(null);
  return (
    <Sheet
      visible
      onClose={onClose}
      title="Note today"
      testID="day-note-sheet"
      footer={
        <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
          <Button
            label="Save"
            disabled={!status}
            onPress={() => {
              if (!status) return;
              setError(onSave({ day: today, status, protocolId, substance, amount, note: text }));
            }}
            testID="day-note-save"
          />
          {existing ? <Button label="Remove note" kind="quiet" onPress={onDelete} testID="day-note-delete" /> : null}
        </View>
      }
    >
      <View style={{ gap: space.lg }}>
        <Text style={type.small} testID="day-note-day">
          {formatDay(today, 'long')} · {dayLabel}
        </Text>
        <View style={{ gap: space.sm }}>
          <Text style={type.label}>How did today go?</Text>
          <View role="radiogroup" aria-label="Today" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {STATUS_CHOICES.map((c) => (
              <Chip key={c.id} radio label={c.label} selected={status === c.id} onPress={() => setStatus(c.id)} testID={`day-note-${c.id}`} />
            ))}
          </View>
        </View>
        {status === 'taken' ? (
          <View style={{ gap: space.md }}>
            <Field label="What you took" optional value={substance} onChangeText={setSubstance} maxLength={80} placeholder="As it's labeled" testID="day-note-substance" />
            <Field label="Your amount" optional value={amount} onChangeText={setAmount} maxLength={40} placeholder="Your amount and unit" testID="day-note-amount" />
            <Text style={[type.small, { fontSize: 13 }]}>{START_LOW}</Text>
          </View>
        ) : null}
        <Field label="How it went" optional multiline minHeight={90} value={text} onChangeText={setText} maxLength={2000} placeholder="Anything you noticed: body, mood, sleep, focus." testID="day-note-text" />
        <Text style={[type.small, { fontSize: 13 }]}>Day notes stay on this device and in your backups. They don't earn gems.</Text>
        {error ? <Notice tone="caution">{error}</Notice> : null}
      </View>
    </Sheet>
  );
}

// ——— Last seven days (small multiples, one per feeling) ———

const BAR_AREA = 56;

export function WeekCard({ today }: { today: string }) {
  const { journey } = useStore();
  const days = useMemo(() => weekFeelings(journey, journey.activeSpaceId, today), [journey, today]);
  const lastWithData = [...days].reverse().find((d) => d.count > 0);
  const [selected, setSelected] = useState<string | null>(null);
  const [table, setTable] = useState(false);
  const sel = days.find((d) => d.day === (selected ?? lastWithData?.day ?? today))!;
  const { width } = useWindowDimensions();
  const narrow = width < 520; // phone: two-letter day names so seven fit under the bars
  const dayName = (d: string) => (d === today ? 'Today' : d === addDays(today, -1) ? 'Yesterday' : formatDay(d));
  const any = days.some((d) => d.count > 0);

  return (
    <Card style={{ gap: space.md }} testID="dash-week">
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
        <View style={{ flex: 1, gap: 2 }}>
          <Eyebrow heading>Last 7 days</Eyebrow>
          <Text style={type.small}>Your own check-in readings, averaged by day. Days without a check-in stay empty.</Text>
        </View>
        {any ? <Button label={table ? 'Show chart' : 'Show table'} small kind="quiet" onPress={() => setTable((v) => !v)} testID="dash-week-toggle" /> : null}
      </View>

      {!any ? (
        <Text style={type.bodySoft} testID="dash-week-empty">
          No check-ins in the last seven days. Check in on Today and this fills in.
        </Text>
      ) : table ? (
        <WeekTable days={days} dayName={dayName} />
      ) : (
        <>
          <View style={st.readout} aria-live="polite" testID="dash-week-readout">
            <Text style={type.label}>
              {dayName(sel.day)}
              <Text style={type.small}>{sel.count ? `  ·  ${sel.count} check-in${sel.count === 1 ? '' : 's'}` : '  ·  no check-in'}</Text>
            </Text>
          </View>
          {DIMS.map((d) => (
            <View key={d} style={st.multiple}>
              <View style={st.rowHead}>
                <FeelGlyph dim={d} level={sel[d]} size={30} />
                <View style={{ flex: 1 }}>
                  <Text style={type.label} numberOfLines={1}>
                    {CHECKIN_SCALES[d].label}
                  </Text>
                  <Text style={type.small} testID={`dash-week-${d}-value`}>
                    {sel[d] !== undefined ? `${sel[d]} · ${levelWord(d, sel[d]!)}` : '—'}
                  </Text>
                </View>
              </View>
              <View style={st.bars}>
                <View style={st.baseline} />
                {days.map((day) => (
                  <DayBar key={day.day} day={day} dim={d} selected={day.day === sel.day} onSelect={() => setSelected(day.day)} label={dayName(day.day)} />
                ))}
              </View>
            </View>
          ))}
          <View style={[st.multiple, { marginTop: -space.sm }]} aria-hidden>
            <View style={st.rowHead} />
            <View style={[st.bars, { height: 16, alignItems: 'flex-start' }]}>
              {days.map((day) => (
                <Text key={day.day} style={[st.dayLabel, (day.day === sel.day || day.day === today) && { color: color.ink, fontWeight: '700' }]}>
                  {narrow ? WEEKDAY_SHORT[weekdayOf(day.day)].slice(0, 2) : day.day === today ? 'Today' : WEEKDAY_SHORT[weekdayOf(day.day)]}
                </Text>
              ))}
            </View>
          </View>
        </>
      )}
    </Card>
  );
}

function DayBar({ day, dim, selected, onSelect, label }: { day: FeelingDay; dim: CheckInDimension; selected: boolean; onSelect: () => void; label: string }) {
  const v = day[dim];
  const h = v === undefined ? 0 : Math.max(4, Math.round((v / 100) * BAR_AREA));
  const hover = Platform.OS === 'web' ? { onHoverIn: onSelect } : {};
  return (
    <Pressable
      role="button"
      aria-label={v === undefined ? `${label}: no check-in` : `${label}: ${CHECKIN_SCALES[dim].label.toLowerCase()} ${v}, ${levelWord(dim, v)}`}
      onPress={onSelect}
      {...hover}
      style={(s: any) => [st.hit, selected && { backgroundColor: color.sageWash }, focusRing(s)]}
      testID={`dash-bar-${dim}-${day.day}`}
    >
      {v === undefined ? <View style={st.empty} /> : <View style={[st.bar, { height: h, backgroundColor: selected ? color.sage : color.sage2 }]} />}
    </Pressable>
  );
}

function WeekTable({ days, dayName }: { days: FeelingDay[]; dayName: (d: string) => string }) {
  return (
    <View role="table" aria-label="Last 7 days, averaged by day" testID="dash-week-table">
      <View role="row" style={[st.tRow, st.tHead]}>
        {['Day', 'Mood', 'Energy', 'Connection', 'Check-ins'].map((h) => (
          <Text key={h} role="columnheader" style={[st.tCell, h === 'Day' && st.tFirst, type.label, { fontSize: 13 }]}>
            {h}
          </Text>
        ))}
      </View>
      {[...days].reverse().map((d) => (
        <View key={d.day} role="row" style={st.tRow}>
          <Text role="rowheader" style={[st.tCell, st.tFirst, type.small, { color: color.ink }]}>
            {dayName(d.day)}
          </Text>
          {DIMS.map((dim) => (
            <Text key={dim} role="cell" style={[st.tCell, type.small, { color: color.ink }]}>
              {d[dim] ?? '—'}
            </Text>
          ))}
          <Text role="cell" style={[st.tCell, type.small]}>
            {d.count}
          </Text>
        </View>
      ))}
    </View>
  );
}

// ——— This week ———

export function CountsCard({ today }: { today: string }) {
  const { journey } = useStore();
  const nav = useNav();
  const c = weekCounts(journey, journey.activeSpaceId, today);
  const evidence = c.wins + c.observations + c.setbacks;
  const tiles: { label: string; value: number; sub?: string; testID: string }[] = [
    { label: 'Check-ins', value: c.checkins, testID: 'dash-count-checkins' },
    { label: 'Journal entries', value: c.journal, testID: 'dash-count-journal' },
    { label: 'Journey evidence', value: evidence, sub: evidence ? `${c.wins} win${c.wins === 1 ? '' : 's'} · ${c.observations} observation${c.observations === 1 ? '' : 's'} · ${c.setbacks} setback${c.setbacks === 1 ? '' : 's'}` : undefined, testID: 'dash-count-evidence' },
    { label: 'Compass readings', value: c.harmony, testID: 'dash-count-harmony' },
  ];
  return (
    <Card style={{ gap: space.md }} testID="dash-counts">
      <View style={{ gap: 2 }}>
        <Eyebrow heading>This week</Eyebrow>
        <Text style={type.small}>What you've recorded in the last seven days. Counts only — nothing is scored.</Text>
      </View>
      <View style={st.tiles}>
        {tiles.map((t) => (
          <View key={t.label} style={st.tile} testID={t.testID}>
            <Text style={type.small}>{t.label}</Text>
            <Text style={st.tileValue}>{t.value}</Text>
            {t.sub ? <Text style={[type.small, { fontSize: 12, lineHeight: 16 }]}>{t.sub}</Text> : null}
          </View>
        ))}
      </View>
      <Button label="Look back on your week" kind="secondary" small icon="calendar" onPress={() => nav.push({ name: 'lookback' })} testID="open-lookback" />
    </Card>
  );
}

// ——— Timeline ———

export function TimelineCard() {
  const store = useStore();
  const nav = useNav();
  const j = store.journey;
  const adult = isAdult(j);
  const items = useMemo(() => timeline(j, j.activeSpaceId), [j]);
  const [filter, setFilter] = useState<'all' | TimelineKind>('all');
  const [limit, setLimit] = useState(40);
  const kinds: ('all' | TimelineKind)[] = ['all', 'checkin', 'journal', 'harmony', 'journey', 'path', ...(adult ? (['protocol'] as TimelineKind[]) : [])];
  const shown = filter === 'all' ? items : items.filter((i) => i.kind === filter);
  const groups = byDay(shown.slice(0, limit));

  const open = (it: TimelineItem) => {
    const t = it.target;
    if (t.type === 'checkins') nav.push({ name: 'checkins' });
    else if (t.type === 'journal') nav.setTab('journal');
    else if (t.type === 'harmony') nav.push({ name: 'harmonyReading', id: t.id });
    else if (t.type === 'area') nav.push({ name: 'area', id: t.id });
    else if (t.type === 'lesson') nav.push({ name: 'lesson', id: t.id });
    else if (t.type === 'goal') nav.openSheet({ name: 'goal', goalId: t.id });
    else if (t.type === 'tier') nav.push({ name: 'tier', id: t.id as TierId });
    else nav.push({ name: 'protocol' });
  };

  return (
    <Card style={{ gap: space.md }} testID="dash-timeline">
      <View style={{ gap: 2 }}>
        <Eyebrow heading>Your timeline</Eyebrow>
        <Text style={type.small}>Everything you've recorded, newest first. Practice from the first-steps guide isn't included.</Text>
      </View>
      <View role="radiogroup" aria-label="Show" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {kinds.map((k) => (
          <Chip key={k} radio label={k === 'all' ? 'All' : TIMELINE_KIND_LABEL[k]} selected={filter === k} onPress={() => { setFilter(k); setLimit(40); }} testID={`dash-filter-${k}`} />
        ))}
      </View>
      {groups.length === 0 ? (
        <Text style={type.bodySoft} testID="dash-timeline-empty">
          {items.length ? 'Nothing of this kind yet.' : 'Nothing recorded yet. Check in on Today to start your timeline.'}
        </Text>
      ) : (
        groups.map((g) => (
          <View key={g.day} style={{ gap: 4 }}>
            <Text style={[type.label, { color: color.gold, fontSize: 13, letterSpacing: 0.4 }]}>{formatDayHeading(g.items[0].at)}</Text>
            {g.items.map((it) => (
              <Pressable key={it.id} role="button" aria-label={`${formatTime(it.at)}. ${it.title}. ${it.detail ?? ''} ${it.quote ?? ''}. Open`} onPress={() => open(it)} style={(s: any) => [st.item, (s.hovered || s.pressed) && { backgroundColor: color.canvas }, focusRing(s)]} testID={`dash-item-${it.kind}`}>
                <View style={st.itemIcon}>
                  <Icon name={KIND_ICON[it.kind]} size={18} color={color.sage} />
                </View>
                <View style={{ flex: 1, gap: 2 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: space.sm }}>
                    <Text style={[type.label, { flex: 1 }]} numberOfLines={1}>
                      {it.title}
                    </Text>
                    <Text style={[type.small, { fontSize: 13 }]}>{formatTime(it.at)}</Text>
                  </View>
                  {it.detail ? <Text style={type.small}>{it.detail}</Text> : null}
                  {it.quote ? (
                    <Text style={[type.small, { color: color.ink, fontStyle: 'italic' }]} numberOfLines={3}>
                      “{it.quote}”
                    </Text>
                  ) : null}
                </View>
              </Pressable>
            ))}
          </View>
        ))
      )}
      {shown.length > limit ? <Button label={`Show more · ${shown.length - limit} earlier`} kind="secondary" small onPress={() => setLimit((l) => l + 40)} testID="dash-more" /> : null}
    </Card>
  );
}

const st = StyleSheet.create({
  integration: { gap: space.xs, padding: space.md, borderRadius: radius.md, backgroundColor: color.sageWash },
  noted: { flexDirection: 'row', alignItems: 'center', gap: space.sm, paddingVertical: space.xs },
  readout: { paddingVertical: 4 },
  multiple: { flexDirection: 'row', alignItems: 'flex-end', gap: space.md },
  rowHead: { width: 138, flexDirection: 'row', alignItems: 'center', gap: space.sm, alignSelf: 'center' },
  bars: { flex: 1, height: BAR_AREA + 8, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  baseline: { position: 'absolute', left: 0, right: 0, bottom: 4, height: 1, backgroundColor: color.border },
  hit: { flex: 1, height: BAR_AREA + 8, alignItems: 'center', justifyContent: 'flex-end', paddingBottom: 4, borderRadius: 8, marginHorizontal: 1 },
  bar: { width: '70%', maxWidth: 24, borderTopLeftRadius: 4, borderTopRightRadius: 4 },
  empty: { width: 8, height: 2, borderRadius: 1, backgroundColor: color.controlBorder, marginBottom: 3 },
  dayLabel: { flex: 1, textAlign: 'center', fontFamily: sans, fontSize: 11, lineHeight: 14, color: color.inkSoft },
  tiles: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  tile: { flexGrow: 1, flexBasis: '45%', gap: 2, padding: space.md, borderRadius: radius.md, backgroundColor: color.paperStrong, borderWidth: 1, borderColor: color.border },
  tileValue: { fontFamily: sans, fontSize: 28, lineHeight: 34, fontWeight: '600', color: color.ink },
  item: { flexDirection: 'row', gap: space.md, alignItems: 'flex-start', paddingVertical: space.sm, paddingHorizontal: space.sm, marginHorizontal: -space.sm, borderRadius: radius.md },
  itemIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: color.sageWash, alignItems: 'center', justifyContent: 'center' },
  tRow: { flexDirection: 'row', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border, paddingVertical: 6 },
  tHead: { borderBottomWidth: 1 },
  tCell: { flex: 1, textAlign: 'right' },
  tFirst: { flex: 1.6, textAlign: 'left' },
});
