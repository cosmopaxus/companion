// The check-in (painted academy, mockup 05): its own screen in the Moon Pool (Water hall, always),
// opened from Home's card.
// Saving records the check-in exactly as before (same ops, same draft key for the note), returns to
// Home, and Home's card shows the confirmation.

import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { HEAVY_MOOD_BELOW } from '../domain/scales';
import { addCheckIn, setPrefs } from '../domain/ops';
import { todaysCheckins } from '../domain/selectors';
import { GEM_AMOUNTS } from '../domain/gems';
import { SPACE_NAME } from '../domain/spaces';
import { soundSupported } from '../platform/feelSound';
import { successFeedback } from '../platform/haptics';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { useSaveLabel } from '../state/saveLabel';
import { setCheckinFlash } from '../state/checkinFlash';
import { color, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, IconButton, Notice } from '../ui/primitives';
import { CheckInForm, CheckInValue, checkInComplete } from '../ui/CheckInForm';
import { Icon } from '../ui/Icon';

export function CheckInScreen() {
  const store = useStore();
  const { journey } = store;
  const nav = useNav();
  const toast = useToast();
  const label = useSaveLabel();
  const sp = journey.activeSpaceId;
  const noteKey = `checkin-note:${sp}`;
  const note = store.drafts[noteKey] ?? '';
  const [value, setValue] = useState<CheckInValue>({});
  const [error, setError] = useState<string | null>(null);

  const save = () => {
    if (!checkInComplete(value)) return;
    const count = todaysCheckins(journey, sp, new Date()).length + 1;
    const r = store.apply((j) => addCheckIn(j, { mood: value.mood!, energy: value.energy!, connection: value.connection!, note }));
    if (!r.ok) {
      setError(r.error);
      return;
    }
    setError(null);
    successFeedback();
    setCheckinFlash({ at: new Date().toISOString(), count, mood: value.mood!, energy: value.energy!, connection: value.connection!, note: note.trim() || undefined, spaceId: sp });
    store.setDraft(noteKey, undefined);
    toast.show(label.done('Check-in'), { gems: GEM_AMOUNTS.checkin, tone: label.notSaving ? 'caution' : 'default' });
    nav.pop();
  };

  const sound = soundSupported ? (
    <IconButton
      icon={journey.prefs.sound ? 'sound' : 'soundOff'}
      label={journey.prefs.sound ? 'Slider sound is on. Turn it off' : 'Slider sound is off. Turn it on'}
      onPress={() => store.apply((j) => setPrefs(j, { sound: !j.prefs.sound }))}
      tone={color.inkSoft}
      size={20}
      testID="checkin-sound"
    />
  ) : undefined;

  return (
    <Screen back glass backLabel="Home" eyebrow={`Check-in · 3 quick readings`} title="How are you right now?" hall="water" testID="screen-checkin">
      <CheckInForm
        compact
        noteLabel="Add a note"
        notePlaceholder="What’s shaping today?"
        value={{ ...value, note }}
        onChange={(v) => {
          setValue({ mood: v.mood, energy: v.energy, connection: v.connection });
          if (v.note !== note) store.setDraft(noteKey, v.note);
        }}
      />
      {value.mood !== undefined && value.mood < HEAVY_MOOD_BELOW ? (
        <Notice icon="heart" action={<Button label="Support options" small kind="secondary" onPress={() => nav.push({ name: 'support' })} />}>
          Thanks for being honest about a heavy moment. If you need someone to talk to right now, support is one tap away.
        </Notice>
      ) : null}
      {error ? <Notice tone="caution">{error}</Notice> : null}
      <View style={{ gap: space.sm }}>
        <Button label="Save check-in" onPress={save} disabled={!checkInComplete(value)} full gems={GEM_AMOUNTS.checkin} testID="checkin-save" />
        {!checkInComplete(value) ? <Text style={[type.small, { textAlign: 'center' }]}>Choose mood, energy and connection to save.</Text> : null}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <Icon name="lock" size={15} color={color.inkSoft} />
          <Text style={[type.small, label.notSaving && { color: color.caution }]}>Private · {label.where} · {SPACE_NAME[sp]}</Text>
          {sound}
        </View>
        <Text style={[type.small, { textAlign: 'center' }]}>Honest beats high: a low reading counts as much as a high one.</Text>
      </View>
    </Screen>
  );
}
