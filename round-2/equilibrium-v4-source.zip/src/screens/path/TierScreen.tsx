// One path: what it is, its lessons, and how it opens. The teacher offers a path when the pupil is
// ready; a sincere seeker may open the next path sooner, after saying what draws them to it.

import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { TierId } from '../../domain/types';
import { deferInvitation, openTier } from '../../domain/ops';
import { isMastered, isPracticable, lessonProgress, lessonsFor, previousTier, readiness, tierState, TIERS, todayKey, currentLessonId, isTierOpen } from '../../domain/paths';
import { formatShortDate } from '../../domain/time';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { useToast } from '../../state/toast';
import { successFeedback } from '../../platform/haptics';
import { color, radius, space, type } from '../../theme/tokens';
import { Screen } from '../../ui/layout';
import { Button, Card, Eyebrow, focusRing, Notice, Tag } from '../../ui/primitives';
import { Field } from '../../ui/controls';
import { Icon } from '../../ui/Icon';
import { Medallion, TierBadge } from '../../ui/game';
import { ReadinessList } from './PathView';

export function TierScreen({ id }: { id: TierId }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const j = store.journey;
  const tier = TIERS[id];
  const today = todayKey();
  const state = tierState(j, id, today);
  const prev = previousTier(id);
  const r = prev ? readiness(j, prev, today) : null;
  const opening = j.paths?.opened?.[id];
  const here = currentLessonId(j);
  const [seeking, setSeeking] = useState(false);
  const [why, setWhy] = useState('');
  const [error, setError] = useState<string | null>(null);

  const open = (how: 'invited' | 'seeker') => {
    const res = store.apply((x) => openTier(x, id, how, how === 'seeker' ? why : undefined, today));
    if (!res.ok) return setError(res.error);
    setError(null);
    successFeedback();
    toast.show(`The ${tier.name} path is open`);
  };

  return (
    <Screen back backLabel="Journey" testID="screen-tier">
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <TierBadge tier={id} size={64} open={state === 'open'} />
        <View style={{ flex: 1, gap: 4 }}>
          <Eyebrow>Path · {tier.theme}</Eyebrow>
          <Text role="heading" aria-level={1} style={type.display}>
            {tier.name}
          </Text>
        </View>
      </View>
      <Text style={[type.body, { fontSize: 17, lineHeight: 26 }]}>{tier.intro}</Text>

      {state === 'open' ? (
        <Notice tone="success" icon="check" testID="tier-open">
          {id === 'foundation' ? 'Open to everyone, from the start.' : `Opened ${opening ? formatShortDate(opening.at) : ''} · ${opening?.how === 'invited' ? 'offered when you were ready' : 'as a sincere seeker'}`}
        </Notice>
      ) : state === 'invited' && r ? (
        <Card tone="gold" style={{ gap: space.md }} testID="tier-invited">
          <Text style={type.title}>Your teacher is offering this path.</Text>
          <ReadinessList r={r} />
          {error ? <Notice tone="caution">{error}</Notice> : null}
          <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
            <Button label={`Begin the ${tier.name} path`} kind="gold" onPress={() => open('invited')} testID="tier-begin" />
            <Button label="Not yet" kind="quiet" onPress={() => { store.apply((x) => deferInvitation(x, id)); nav.pop(); }} />
          </View>
        </Card>
      ) : state === 'seekable' && r && prev ? (
        <Card style={{ gap: space.md }} testID="tier-seekable">
          <Eyebrow heading>When it opens</Eyebrow>
          <Text style={type.bodySoft}>Your teacher offers the {tier.name} path when you’re ready:</Text>
          <ReadinessList r={r} testID="tier-readiness" />
          <View style={st.door}>
            <Icon name="key" size={20} color={color.gold} strokeWidth={2} />
            <Text style={[type.small, { flex: 1, color: color.ink }]}>
              The door is open to a sincere seeker. Your teacher suggests walking the {TIERS[prev].name} path first, but you may begin now.
            </Text>
          </View>
          {seeking ? (
            <View style={{ gap: space.md }}>
              <Field label="What draws you to this path?" value={why} onChangeText={setWhy} placeholder="A sentence in your own words" multiline minHeight={80} maxLength={600} autoFocus testID="tier-seeker-why" />
              {error ? <Notice tone="caution">{error}</Notice> : null}
              <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
                <Button label={`Open the ${tier.name} path`} onPress={() => open('seeker')} disabled={why.trim().length < 8} testID="tier-seeker-open" />
                <Button label="Cancel" kind="quiet" onPress={() => setSeeking(false)} />
              </View>
            </View>
          ) : (
            <Button label="Open as a sincere seeker" kind="secondary" icon="key" onPress={() => setSeeking(true)} testID="tier-seeker" />
          )}
        </Card>
      ) : state === 'preparing' ? (
        <Notice icon="leaf" title="Being prepared" testID="tier-preparing">
          This path’s lessons are still being written, so it can’t be opened yet. Its outline is below; it opens when the lessons are ready.
        </Notice>
      ) : prev ? (
        <Notice icon="lock" testID="tier-locked">
          Opens after the {TIERS[prev].name} path.
        </Notice>
      ) : null}

      <View style={{ gap: space.sm }}>
        <Eyebrow heading>Lessons</Eyebrow>
        <Card padded={false}>
          {lessonsFor(id).map((l, i, all) => {
            const p = lessonProgress(j, l);
            const done = isMastered(j, l);
            const s = !isPracticable(l) ? 'outline' : !isTierOpen(j, id) ? 'locked' : done ? 'done' : l.id === here ? 'now' : 'open';
            return (
              <Pressable key={l.id} role="button" aria-label={`${l.title}. ${l.summary} ${done ? 'Mastered.' : p.label}. Open`} onPress={() => nav.push({ name: 'lesson', id: l.id })} style={(ps: any) => [st.row, i < all.length - 1 && st.rowBorder, (ps.hovered || ps.pressed) && { backgroundColor: color.canvas }, focusRing(ps)]} testID={`tier-lesson-${l.id}`}>
                <Medallion state={s === 'now' ? 'open' : s} element={l.element} icon={l.icon} size={40} />
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={type.label}>{l.title}</Text>
                  <Text style={type.small}>{l.summary}</Text>
                  {isPracticable(l) && isTierOpen(j, id) ? <Text style={[type.small, { fontSize: 12.5, color: done ? color.sage : color.gold, fontWeight: '600' }]}>{done ? 'Mastered' : p.label}</Text> : null}
                </View>
                {s === 'now' ? <Tag label="Next" tone="gold" /> : null}
                <Icon name="chevron" size={18} color={color.inkSoft} />
              </Pressable>
            );
          })}
        </Card>
      </View>
    </Screen>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 14 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  door: { flexDirection: 'row', gap: space.sm, alignItems: 'flex-start', padding: space.md, borderRadius: radius.md, backgroundColor: color.goldWash, borderWidth: 1, borderColor: color.goldBorder },
});
