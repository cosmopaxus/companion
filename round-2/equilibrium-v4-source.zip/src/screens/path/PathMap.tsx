// The path map: each path is a winding trail of lesson medallions. Mastered lessons are filled,
// "you are here" wears a gold ring, open lessons are outlined, and paths not yet open are dashed.
// A completed path folds up so the trail stays short; tap its header to unfold it.

import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import type { Journey, TierId } from '../../domain/types';
import { TIER_IDS } from '../../domain/types';
import { currentLessonId, isMastered, isPracticable, isTierOpen, lessonProgress, lessonsFor, PathLesson, tierState, TierState, TIERS } from '../../domain/paths';
import { color, radius, space, type } from '../../theme/tokens';
import { focusRing, Tag } from '../../ui/primitives';
import { Medallion, NodeState, ProgressBar, TierBadge } from '../../ui/game';
import { Icon } from '../../ui/Icon';
import { useHall, wingFont } from '../../ui/academy/hall';
import { RegionSky, RegionStone } from '../../ui/academy/Grounds';
import { GroundsDecor } from '../../ui/academy/HallArt';
import { HerePulse } from '../../ui/academy/Motion';
import { canDrawGrounds, GroundsMap } from './GroundsMap';
import { BUILDINGS, BuildingId, groundsRoad, groundsWash, HALLS, ON_HALL } from '../../theme/academy';

const ROW_H = 118;
const NODE = 60;
const OFFSETS = [0, 1, 0, -1];

const STATE_TAG: Record<TierState, { label: string; tone: 'sage' | 'gold' | 'neutral' | 'practice' }> = {
  open: { label: 'Open', tone: 'sage' },
  invited: { label: 'Ready for you', tone: 'gold' },
  seekable: { label: 'Open to seekers', tone: 'practice' },
  locked: { label: 'Further on', tone: 'neutral' },
  preparing: { label: 'In preparation', tone: 'neutral' },
};

/** Visible only to screen readers (keeps a real heading outside the tappable band). */
const srOnly = { position: 'absolute' as const, width: 1, height: 1, overflow: 'hidden' as const, opacity: 0 };

export function PathMap({ journey, today, openGoals, onLesson, onTier, onInvite, onRest, heroTier }: { journey: Journey; today: string; openGoals: number; onLesson: (id: string) => void; onTier: (t: TierId) => void; onInvite: (t: TierId) => void; onRest: () => void; heroTier?: TierId | null }) {
  const [width, setWidth] = useState(0);
  const [unfolded, setUnfolded] = useState<Partial<Record<TierId, boolean>>>({});
  const here = currentLessonId(journey);
  const { hall, mode } = useHall();
  const wash = groundsWash(hall, mode, color.paper);

  return (
    <View testID="path-map" style={{ gap: space.lg }} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
      {TIER_IDS.map((t, ti) => {
        const state = tierState(journey, t, today);
        const lessons = lessonsFor(t);
        const practicable = lessons.filter(isPracticable);
        const mastered = practicable.filter((l) => isMastered(journey, l)).length;
        const complete = practicable.length > 0 && mastered === practicable.length;
        const open = isTierOpen(journey, t);
        const showNodes = open && (!complete || unfolded[t]);
        const prevOpen = ti === 0 || isTierOpen(journey, TIER_IDS[ti - 1]);
        const tag = complete ? { label: 'Mastered', tone: 'sage' as const } : STATE_TAG[state];
        return (
          <View key={t} style={[st.region, open ? { backgroundColor: wash } : st.regionClosed]} testID={`region-${t}`}>
            <Text role="heading" aria-level={2} style={srOnly}>
              {TIERS[t].name} path · {BUILDINGS[t as BuildingId].name}
            </Text>
            <Pressable
              role="button"
              aria-expanded={open && complete ? !!unfolded[t] : undefined}
              aria-label={`${TIERS[t].name} path. ${TIERS[t].theme}. ${tag.label}.${practicable.length && open ? ` ${mastered} of ${practicable.length} lessons mastered.` : ''} ${open && complete ? (unfolded[t] ? 'Fold its lessons' : 'Show its lessons') : 'Open path'}`}
              onPress={() => (open && complete ? setUnfolded((u) => ({ ...u, [t]: !u[t] })) : onTier(t))}
              style={(s: any) => [st.band, (s.hovered || s.pressed) && { opacity: 0.94 }, focusRing(s)]}
              testID={`map-tier-${t}`}
            >
              {open ? <RegionSky hall={hall} building={t as BuildingId} mode={mode} /> : <RegionStone building={t as BuildingId} />}
              <TierBadge tier={t} open={open} />
              <View style={{ flex: 1, gap: 2 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, flexWrap: 'wrap' }}>
                  <Text style={[type.heading, open && { color: ON_HALL.title, fontFamily: wingFont('academy'), fontWeight: '800' }]}>{TIERS[t].name}</Text>
                  <Tag label={tag.label} tone={tag.tone} />
                </View>
                <Text style={[type.small, open && { color: ON_HALL.soft }]}>
                  {BUILDINGS[t as BuildingId].name} · {TIERS[t].theme}
                </Text>
                {open && practicable.length ? (
                  <View style={{ marginTop: 6, gap: 4 }}>
                    <ProgressBar value={mastered} max={practicable.length} height={6} tone={color.goldDeco} label={`${mastered} of ${practicable.length} lessons mastered`} />
                    <Text style={[type.small, { fontSize: 12.5, color: ON_HALL.soft }]}>
                      {mastered} of {practicable.length} lessons mastered{complete ? (unfolded[t] ? ' · tap to fold' : ' · tap to unfold') : ''}
                    </Text>
                  </View>
                ) : null}
              </View>
              {!(open && complete) ? <Icon name="chevron" size={18} color={open ? ON_HALL.title : color.inkSoft} /> : <Icon name={unfolded[t] ? 'chevronDown' : 'chevron'} size={18} color={ON_HALL.title} />}
            </Pressable>
            {showNodes && t === heroTier ? (
              <Text style={[type.small, { textAlign: 'center', paddingHorizontal: space.lg, paddingBottom: space.lg }]} testID={`region-${t}-on-grounds`}>
                Its lessons are on the academy grounds above.
              </Text>
            ) : showNodes && width > 0 && !complete && canDrawGrounds(lessons) ? (
              <View style={{ paddingHorizontal: space.sm, paddingBottom: space.sm }}>
                <GroundsMap journey={journey} lessons={lessons} tier={t} here={here} openGoals={openGoals} today={today} width={width - 2 - 2 * space.sm} onLesson={onLesson} onTier={onTier} onInvite={onInvite} onRest={onRest} />
              </View>
            ) : showNodes && width > 0 ? (
              <Trail lessons={lessons} journey={journey} width={width - 2} here={here} openGoals={openGoals} onLesson={onLesson} building={t as BuildingId} road={groundsRoad(hall, mode, color.paper)} tint={mode === 'day' ? HALLS[hall].day[0] : HALLS[hall].day[2]} />
            ) : !open && prevOpen ? (
              <Text style={[type.small, { textAlign: 'center', paddingHorizontal: space.lg, paddingBottom: space.lg }]}>
                {lessons.length} lessons ·{' '}
                {state === 'preparing' ? 'being prepared; this path opens when they’re ready' : state === 'invited' ? 'your teacher is offering this path' : 'opens when you’re ready, or to a sincere seeker'}
              </Text>
            ) : null}
          </View>
        );
      })}
    </View>
  );
}

function nodeState(j: Journey, l: PathLesson, here: string | null): NodeState {
  if (!isPracticable(l)) return 'outline';
  if (!isTierOpen(j, l.tier)) return 'locked';
  if (isMastered(j, l)) return 'done';
  if (l.id === here) return 'now';
  return 'open';
}

function Trail({ lessons, journey, width, here, openGoals, onLesson, building, road, tint }: { lessons: PathLesson[]; journey: Journey; width: number; here: string | null; openGoals: number; onLesson: (id: string) => void; building: BuildingId; road: string; tint: string }) {
  // Keep every 160px label column inside the map.
  const amp = Math.max(40, Math.min(110, width / 2 - 82));
  const cx = (i: number) => width / 2 + OFFSETS[i % OFFSETS.length] * amp;
  const cy = (i: number) => i * ROW_H + 10 + NODE / 2 + 6;
  const height = lessons.length * ROW_H;
  const states = lessons.map((l) => nodeState(journey, l, here));
  const seg = (i: number) => `M ${cx(i)} ${cy(i)} C ${cx(i + 1)} ${cy(i)}, ${cx(i + 1)} ${cy(i)}, ${cx(i + 1)} ${cy(i + 1)}`;
  // Scenery goes in the empty side of each row, only when there's room clear of the label column.
  const spots = amp >= 90 ? lessons.map((_, i) => ({ off: OFFSETS[i % OFFSETS.length], i })).filter((r) => r.off !== 0).map((r) => ({ x: width / 2 - r.off * amp, y: cy(r.i) })) : [];
  const hereIndex = states.indexOf('now');

  return (
    <View style={{ width, height }}>
      <Svg width={width} height={height} style={StyleSheet.absoluteFill} pointerEvents="none" accessible={false} importantForAccessibility="no-hide-descendants" aria-hidden>
        {lessons.slice(0, -1).map((_, i) => (
          <Path key={`road-${i}`} d={seg(i)} stroke={road} strokeWidth={18} strokeLinecap="round" fill="none" />
        ))}
        <GroundsDecor building={building} spots={spots} tint={tint} />
        {hereIndex >= 0 ? <Circle cx={cx(hereIndex)} cy={cy(hereIndex)} r={NODE / 2 + 22} fill={color.goldDeco} opacity={0.22} /> : null}
        {lessons.slice(0, -1).map((_, i) => {
          const x1 = cx(i);
          const y1 = cy(i);
          const x2 = cx(i + 1);
          const y2 = cy(i + 1);
          const walked = states[i] === 'done' && (states[i + 1] === 'done' || states[i + 1] === 'now');
          return (
            <Path
              key={i}
              d={`M ${x1} ${y1} C ${x2} ${y1}, ${x2} ${y1}, ${x2} ${y2}`}
              stroke={walked ? color.sage2 : color.controlBorder}
              strokeWidth={walked ? 4 : 3}
              strokeDasharray={walked ? undefined : '2 9'}
              strokeLinecap="round"
              fill="none"
            />
          );
        })}
      </Svg>
      {hereIndex >= 0 ? (
        <View pointerEvents="none" style={[st.pulse, { left: cx(hereIndex) - (NODE + 44) / 2, top: cy(hereIndex) - (NODE + 44) / 2, width: NODE + 44, height: NODE + 44 }]}>
          <HerePulse size={NODE + 44} color={color.goldDeco} />
        </View>
      ) : null}
      {lessons.map((l, i) => {
        const s = states[i];
        const p = lessonProgress(journey, l);
        const size = s === 'now' ? NODE + 12 : NODE;
        const label = `${l.title}. ${s === 'done' ? 'Mastered' : s === 'now' ? `You are here. ${p.label}` : s === 'outline' ? 'In preparation' : s === 'locked' ? 'Not open yet' : p.label}. Open lesson`;
        return (
          <View key={l.id} style={[st.nodeWrap, { left: cx(i) - 80, top: cy(i) - size / 2 }]}>
            <Pressable role="button" aria-label={label} onPress={() => onLesson(l.id)} style={(st2: any) => [{ borderRadius: size / 2 + 6, padding: 3 }, (st2.hovered || st2.pressed) && { backgroundColor: color.sageWash }, focusRing(st2)]} testID={`map-lesson-${l.id}`}>
              <Medallion state={s} element={l.element} icon={l.icon} size={NODE} />
            </Pressable>
            <View style={{ alignItems: 'center', gap: 1, marginTop: 4 }}>
              {s === 'now' ? <Text style={st.here}>You are here</Text> : null}
              <Text style={[type.label, { fontSize: 14, textAlign: 'center' }, (s === 'locked' || s === 'outline') && { color: color.inkSoft }]} numberOfLines={2}>
                {l.title}
              </Text>
              {s !== 'outline' && s !== 'locked' ? (
                <Text style={[type.small, { fontSize: 12, lineHeight: 15, textAlign: 'center' }]} numberOfLines={2}>
                  {s === 'done' ? 'Mastered' : p.label}
                </Text>
              ) : null}
              {s === 'now' && openGoals > 0 ? (
                <View style={st.quest}>
                  <Icon name="flag" size={12} color={color.gold} strokeWidth={2.2} />
                  <Text style={[type.small, { fontSize: 12, color: color.gold, fontWeight: '700' }]}>
                    {openGoals} open quest{openGoals === 1 ? '' : 's'}
                  </Text>
                </View>
              ) : null}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const st = StyleSheet.create({
  region: { borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: color.border, borderBottomWidth: 4, borderBottomColor: color.lip, gap: space.md },
  regionClosed: { backgroundColor: color.canvas, borderStyle: 'dashed', borderColor: color.controlBorder, borderBottomWidth: 1 },
  band: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.lg, paddingBottom: space.xl, overflow: 'hidden' },
  nodeWrap: { position: 'absolute', width: 160, alignItems: 'center' },
  pulse: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  here: { fontSize: 11, fontWeight: '800', letterSpacing: 1, textTransform: 'uppercase', color: color.gold },
  quest: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill, backgroundColor: color.goldWash, borderWidth: 1, borderColor: color.goldBorder },
});
