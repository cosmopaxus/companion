// The character sheet and the inventory. Both only build: counts of what was done, goals reached,
// lessons mastered, badges earned. Nothing here reads how someone felt; Compass has its own page.

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ELEMENT_IDS } from '../../domain/types';
import { ELEMENTS } from '../../domain/harmony';
import { badges, characterStats, inventory } from '../../domain/character';
import { TIERS } from '../../domain/paths';
import { formatShortDate } from '../../domain/time';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { color, elementText, elementWash, radius, space, type } from '../../theme/tokens';
import { Screen } from '../../ui/layout';
import { Button, Card, Eyebrow, Notice, Tag } from '../../ui/primitives';
import { ElementGlyph, Gem, Icon } from '../../ui/Icon';
import { ElementLevel, RankMark, StatTile } from '../../ui/game';

export function CharacterScreen() {
  const { journey } = useStore();
  const nav = useNav();
  const s = characterStats(journey);
  const name = journey.profile?.name ?? '';
  return (
    <Screen back backLabel="Journey" testID="screen-character">
      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <RankMark initial={name.slice(0, 1).toUpperCase() || '·'} size={72} />
        <View style={{ flex: 1, gap: 2 }}>
          <Eyebrow>Character sheet</Eyebrow>
          <Text role="heading" aria-level={1} style={type.title}>
            {name}
          </Text>
          <Text style={[type.heading, { color: color.gold }]} testID="character-rank">
            {s.rank}
          </Text>
          <Text style={type.small}>
            {TIERS[s.tier].name} path · {TIERS[s.tier].theme}
          </Text>
        </View>
      </Card>

      <View style={{ gap: space.sm }}>
        <Eyebrow heading>What you’ve built</Eyebrow>
        <View style={st.grid} testID="character-stats">
          <StatTile label="Days practiced" value={s.daysPracticed} icon="calendar" testID="stat-days" />
          <StatTile label="Longest rhythm" value={s.longestRun} sub={s.longestRun === 1 ? 'day in a row' : 'days in a row'} icon="path" testID="stat-run" />
          <StatTile label="Goals reached" value={s.goalsReached} sub={s.goalsOpen ? `${s.goalsOpen} open` : undefined} icon="flag" testID="stat-goals" />
          <StatTile label="Lessons mastered" value={s.lessonsMastered} icon="star" testID="stat-lessons" />
          <StatTile label="Wins recorded" value={s.wins} sub={`${s.evidence} evidence in all`} icon="win" testID="stat-wins" />
          <StatTile label="Reflections" value={s.reflections} sub="journal entries" icon="journal" testID="stat-reflections" />
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start' }}>
          <Gem size={16} />
          <Text style={type.small}>
            {s.gems} gems across your Spaces · a record of showing up
          </Text>
        </View>
      </View>

      <View style={{ gap: space.sm }} testID="character-elements">
        <Eyebrow heading>Practice by element</Eyebrow>
        <Text style={type.small}>Each element levels up every five practices: path lessons that train it, and goals you reach that call on it. Levels are earned and never taken back.</Text>
        {ELEMENT_IDS.map((el) => (
          <ElementLevel key={el} element={el} practice={s.elements[el]} testID={`element-${el}`} />
        ))}
      </View>

      <Notice icon="compass" action={<Button label="Open Compass" small kind="secondary" onPress={() => nav.push({ name: 'equilibrium' })} />}>
        Everything here only grows, and nothing reads how you felt. Your balance between the elements lives on its own page, Compass.
      </Notice>
    </Screen>
  );
}

export function InventoryScreen() {
  const { journey } = useStore();
  const nav = useNav();
  const items = inventory(journey);
  const goals = items.filter((i) => i.kind === 'goal');
  const all = badges(journey);
  const earned = all.filter((b) => b.earned);
  const locked = all.filter((b) => !b.earned);
  const openQuests = (journey.goals ?? []).filter((g) => !g.deletedAt && g.status === 'open').length;

  return (
    <Screen back backLabel="Journey" title="Inventory" subtitle="What you’ve reached and earned. Kept for good." testID="screen-inventory">
      <View style={{ gap: space.sm }} testID="inventory-goals">
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Eyebrow heading>Goals reached · {goals.length}</Eyebrow>
          {openQuests ? <Tag label={`${openQuests} open quest${openQuests === 1 ? '' : 's'}`} tone="gold" icon="flag" /> : null}
        </View>
        {goals.length === 0 ? (
          <Notice icon="flag" action={<Button label="Set a goal" small kind="secondary" icon="plus" onPress={() => nav.openSheet({ name: 'goal' })} />}>
            Goals you reach are kept here, with a line about what they took.
          </Notice>
        ) : (
          goals.map((g) => (
            <Card key={g.id} style={[{ gap: 6 }, g.element ? { borderLeftWidth: 5, borderLeftColor: elementText[g.element] } : null]} testID="inventory-goal">
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
                {g.element ? <ElementGlyph element={g.element} size={18} color={elementText[g.element]} /> : <Icon name="flag" size={18} color={color.gold} />}
                <Text style={[type.heading, { flex: 1 }]}>{g.name}</Text>
              </View>
              {g.detail ? <Text style={[type.body, { fontStyle: 'italic' }]}>“{g.detail}”</Text> : null}
              <Text style={type.small}>
                Reached {g.at ? formatShortDate(g.at) : ''}
                {g.element ? ` · ${ELEMENTS[g.element].name}` : ''}
                {g.reopened ? ' · reopened since, still yours' : ''}
              </Text>
            </Card>
          ))
        )}
      </View>

      <View style={{ gap: space.sm }} testID="inventory-badges">
        <Eyebrow heading>
          Badges · {earned.length} of {all.length}
        </Eyebrow>
        <View style={st.badgeGrid}>
          {earned.map((b) => (
            <View key={b.id} role="img" style={[st.badge, b.rare ? st.badgeRare : null, b.element ? { backgroundColor: elementWash[b.element] } : null]} testID={`badge-${b.id}`} aria-label={`Earned badge: ${b.name}. ${b.how}${b.rare ? ' Rare.' : ''}${b.earnedAt ? ` Earned ${formatShortDate(b.earnedAt)}.` : ''}`}>
              <View style={[st.badgeIcon, b.rare ? { borderColor: color.gold } : null]}>{b.element ? <ElementGlyph element={b.element} size={22} color={elementText[b.element]} /> : <Icon name={b.rare ? 'star' : 'badge'} size={22} color={color.gold} filled={b.rare} />}</View>
              <Text style={[type.label, { textAlign: 'center' }]}>{b.name}</Text>
              <Text style={[type.small, { fontSize: 12.5, lineHeight: 16, textAlign: 'center' }]}>{b.how}</Text>
              {b.rare ? <Tag label="Rare" tone="gold" /> : null}
            </View>
          ))}
        </View>
        {locked.length ? (
          <>
            <Text style={[type.small, { marginTop: space.sm }]}>Still to earn</Text>
            <View style={st.badgeGrid}>
              {locked.map((b) => (
                <View key={b.id} role="img" style={[st.badge, st.badgeLocked]} testID={`badge-locked-${b.id}`} aria-label={`Not yet earned: ${b.name}. ${b.how}`}>
                  <View style={[st.badgeIcon, { borderStyle: 'dashed', borderColor: color.controlBorder, backgroundColor: color.canvas }]}>
                    <Icon name="lock" size={18} color={color.inkSoft} />
                  </View>
                  <Text style={[type.label, { textAlign: 'center', color: color.inkSoft }]}>{b.name}</Text>
                  <Text style={[type.small, { fontSize: 12.5, lineHeight: 16, textAlign: 'center' }]}>{b.how}</Text>
                </View>
              ))}
            </View>
          </>
        ) : null}
      </View>
    </Screen>
  );
}

const st = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  badgeGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: space.sm },
  badge: { width: '48.5%', alignItems: 'center', gap: 4, padding: space.md, borderRadius: radius.md, backgroundColor: color.goldWash, borderWidth: 1, borderColor: color.goldBorder },
  badgeRare: { borderWidth: 2, borderColor: color.goldDeco },
  badgeLocked: { backgroundColor: color.canvas, borderStyle: 'dashed', borderColor: color.controlBorder },
  badgeIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong, borderWidth: 1.5, borderColor: color.goldDeco },
});
