// Goals, shown on the path as open quests. Add one, edit it, mark it reached (with a line about what
// it took), let it go, or reopen it. Letting a goal go is a choice, never a failure.

import React, { useState } from 'react';
import { Text, View } from 'react-native';
import type { ElementId } from '../../domain/types';
import { ELEMENT_IDS } from '../../domain/types';
import { ELEMENTS } from '../../domain/harmony';
import { addGoal, deleteGoal, releaseGoal, reachGoal, reopenGoal, updateGoal } from '../../domain/ops';
import { GEM_AMOUNTS, totalBalance } from '../../domain/gems';
import { formatShortDate } from '../../domain/time';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { useToast } from '../../state/toast';
import { successFeedback } from '../../platform/haptics';
import { color, elementText, space, type } from '../../theme/tokens';
import { Sheet } from '../../ui/layout';
import { Button, Chip, Notice, Tag } from '../../ui/primitives';
import { Field } from '../../ui/controls';

type Mode = 'edit' | 'view' | 'reach' | 'delete';

export const GOAL_EXAMPLES = ['Walk every morning this week', 'Finish the first chapter', 'Call my brother', 'Lights out by 11 for ten nights'];

export function GoalSheet() {
  const nav = useNav();
  const store = useStore();
  const toast = useToast();
  const sheet = nav.sheet?.name === 'goal' ? nav.sheet : null;
  const goal = sheet?.goalId ? (store.journey.goals ?? []).find((g) => g.id === sheet.goalId && !g.deletedAt) : undefined;
  const areas = store.journey.areas.filter((a) => !a.deletedAt);

  const [mode, setMode] = useState<Mode>('edit');
  const [title, setTitle] = useState('');
  const [why, setWhy] = useState('');
  const [element, setElement] = useState<ElementId | undefined>();
  const [areaId, setAreaId] = useState<string | undefined>();
  const [reflection, setReflection] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Reset each time the sheet opens for a different goal (adjusting state during render).
  const openKey = sheet ? `goal:${sheet.goalId ?? 'new'}` : null;
  const [lastKey, setLastKey] = useState<string | null>(null);
  if (openKey !== lastKey) {
    setLastKey(openKey);
    if (sheet) {
      setMode(goal ? 'view' : 'edit');
      setTitle(goal?.title ?? '');
      setWhy(goal?.why ?? '');
      setElement(goal?.element);
      setAreaId(goal?.areaId);
      setReflection('');
      setError(null);
    }
  }

  const run = (fn: Parameters<typeof store.apply>[0], done: string, close = true) => {
    const r = store.apply(fn);
    if (!r.ok) {
      setError(r.error);
      return false;
    }
    setError(null);
    if (close) nav.closeSheet();
    toast.show(done);
    return true;
  };

  const save = () => {
    const input = { title, why, element, areaId };
    if (goal) {
      if (run((j) => updateGoal(j, goal.id, input), 'Goal updated', false)) setMode('view');
    } else if (run((j) => addGoal(j, input), 'Goal set · a new quest on your path')) successFeedback();
  };

  const reach = () => {
    if (!goal) return;
    const before = totalBalance(store.current().gems);
    const r = store.apply((j) => reachGoal(j, goal.id, reflection));
    if (!r.ok) return setError(r.error);
    successFeedback();
    nav.closeSheet();
    const earned = totalBalance(store.current().gems) - before;
    toast.show(earned > 0 ? 'Goal reached · added to your inventory' : 'Goal reached again', { gems: earned > 0 ? earned : undefined });
  };
  const gemDone = !!goal && store.journey.gems.some((g) => g.reason === 'goal' && g.sourceId === goal.id);

  const titleFor = !goal ? 'Set a goal' : mode === 'edit' ? 'Edit goal' : mode === 'reach' ? 'You reached it' : mode === 'delete' ? 'Delete this goal?' : 'Goal';

  const footer =
    mode === 'edit' ? (
      <>
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label={goal ? 'Save changes' : 'Set this goal'} full onPress={save} disabled={!title.trim()} testID="goal-save" />
        {goal ? <Button label="Cancel" kind="quiet" full onPress={() => setMode('view')} /> : null}
      </>
    ) : mode === 'reach' ? (
      <>
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label={gemDone ? 'Mark reached' : `Mark reached · +${GEM_AMOUNTS.goal} gems`} kind="gold" full onPress={reach} testID="goal-reach-confirm" />
        <Button label="Not yet" kind="quiet" full onPress={() => setMode('view')} />
      </>
    ) : mode === 'delete' && goal ? (
      <>
        <Button label="Delete goal" kind="danger" full onPress={() => run((j) => deleteGoal(j, goal.id), 'Goal deleted')} testID="goal-delete-confirm" />
        <Button label="Cancel" kind="quiet" full onPress={() => setMode('view')} />
      </>
    ) : null;

  return (
    <Sheet visible={!!sheet} onClose={nav.closeSheet} title={titleFor} testID="goal-sheet" footer={footer}>
      {mode === 'edit' ? (
        <>
          <Field label="What do you want to be true?" value={title} onChangeText={setTitle} placeholder="e.g. Walk every morning this week" maxLength={120} testID="goal-title" />
          {!goal && !title ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
              {GOAL_EXAMPLES.map((ex) => (
                <Chip key={ex} label={ex} onPress={() => setTitle(ex)} />
              ))}
            </View>
          ) : null}
          <Field label="Why it matters" optional value={why} onChangeText={setWhy} placeholder="A line for your future self" multiline minHeight={70} maxLength={400} testID="goal-why" />
          <View style={{ gap: space.sm }}>
            <Text style={type.label}>
              Element <Text style={[type.small, { fontWeight: '400' }]}> optional</Text>
            </Text>
            <Text style={type.small}>Which part of you does this call on? Reaching it adds a practice to that element on your character sheet.</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }} role="radiogroup" aria-label="Element">
              <Chip radio label="None" selected={!element} onPress={() => setElement(undefined)} />
              {ELEMENT_IDS.map((el) => (
                <Chip radio key={el} label={`${ELEMENTS[el].name} · ${ELEMENTS[el].lens}`} selected={element === el} onPress={() => setElement(el)} testID={`goal-element-${el}`} />
              ))}
            </View>
          </View>
          {areas.length ? (
            <View style={{ gap: space.sm }}>
              <Text style={type.label}>
                Journey area <Text style={[type.small, { fontWeight: '400' }]}> optional</Text>
              </Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }} role="radiogroup" aria-label="Journey area">
                <Chip radio label="None" selected={!areaId} onPress={() => setAreaId(undefined)} />
                {areas.map((a) => (
                  <Chip radio key={a.id} label={a.name} selected={areaId === a.id} onPress={() => setAreaId(a.id)} />
                ))}
              </View>
            </View>
          ) : null}
        </>
      ) : goal && mode === 'view' ? (
        <View style={{ gap: space.lg }} testID="goal-view">
          <View style={{ gap: space.sm }}>
            <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
              <Tag label={goal.status === 'open' ? 'Open quest' : goal.status === 'reached' ? `Reached ${goal.reachedAt ? formatShortDate(goal.reachedAt) : ''}` : 'Let go'} tone={goal.status === 'reached' ? 'sage' : goal.status === 'open' ? 'gold' : 'neutral'} icon={goal.status === 'reached' ? 'check' : 'flag'} />
              {goal.element ? <Tag label={ELEMENTS[goal.element].name} /> : null}
              {goal.areaId ? <Tag label={areas.find((a) => a.id === goal.areaId)?.name ?? 'Journey area'} /> : null}
            </View>
            <Text style={type.title}>{goal.title}</Text>
            {goal.why ? <Text style={type.bodySoft}>{goal.why}</Text> : null}
            {goal.status === 'reached' && goal.reflection ? (
              <Text style={[type.body, { fontStyle: 'italic', color: goal.element ? elementText[goal.element] : color.sage }]}>“{goal.reflection}”</Text>
            ) : null}
            <Text style={type.small}>Set {formatShortDate(goal.createdAt)}</Text>
          </View>
          {error ? <Notice tone="caution">{error}</Notice> : null}
          {goal.status === 'open' ? (
            <View style={{ gap: space.sm }}>
              <Button label="I reached it" kind="gold" full icon="check" onPress={() => setMode('reach')} testID="goal-reach" />
              <Button label="Edit" kind="secondary" full icon="edit" onPress={() => setMode('edit')} testID="goal-edit" />
              <Button label="Let it go" kind="quiet" full onPress={() => run((j) => releaseGoal(j, goal.id), 'Goal let go. Nothing is lost.')} testID="goal-release" />
              <Text style={[type.small, { textAlign: 'center' }]}>Letting a goal go is a choice, not a failure. Nothing is taken away.</Text>
            </View>
          ) : (
            <Button label="Reopen as a quest" kind="secondary" full onPress={() => run((j) => reopenGoal(j, goal.id), 'Reopened')} testID="goal-reopen" />
          )}
          <Button label="Delete goal" kind="quiet" small icon="trash" onPress={() => setMode('delete')} style={{ alignSelf: 'center' }} testID="goal-delete" />
        </View>
      ) : goal && mode === 'reach' ? (
        <View style={{ gap: space.md }}>
          <Text style={type.title}>{goal.title}</Text>
          <Field label="What did it take?" optional value={reflection} onChangeText={setReflection} placeholder="A line in your own words" multiline minHeight={80} maxLength={400} autoFocus testID="goal-reflection" />
          <Text style={type.small}>
            {gemDone
              ? 'You reached this once before, so it’s already in your inventory and its gems are already yours.'
              : `It goes into your inventory${goal.element ? `, and counts as a ${ELEMENTS[goal.element].name} practice` : ''}. Its gems are earned once, even if you reopen it later.`}
          </Text>
        </View>
      ) : goal && mode === 'delete' ? (
        <Text style={type.bodySoft}>It will be removed from your path and inventory. Any gems it earned stay: they recognized what you did.</Text>
      ) : null}
    </Sheet>
  );
}
