// One lesson on a path: why it matters, how to practice it, progress, and the way to do it.
// Logged lessons take "I practiced today" (once per day); others point to where the practice happens.

import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ELEMENTS } from '../../domain/harmony';
import { logPractice, practiceLogId, unlogPractice } from '../../domain/ops';
import type { Journey } from '../../domain/types';
import { isMastered, isPracticable, isTierOpen, lessonProgress, lessonsFor, LESSON_BY_ID, logsFor, practiceDays, TIERS, todayKey } from '../../domain/paths';
import { addDays, formatDay } from '../../domain/protocols';
import { GEM_AMOUNTS, totalBalance as totalGemsOf } from '../../domain/gems';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { useToast } from '../../state/toast';
import { successFeedback } from '../../platform/haptics';
import { color, elementText, elementWash, serif, space, type } from '../../theme/tokens';
import { Screen } from '../../ui/layout';
import { Button, Card, Eyebrow, IconButton, Notice, Tag } from '../../ui/primitives';
import { Field } from '../../ui/controls';
import { Medallion, ProgressBar } from '../../ui/game';
import { HallPips, hallInk } from '../../ui/academy/GlassParts';
import { useHall } from '../../ui/academy/hall';

const totalGems = (j: Journey) => totalGemsOf(j.gems);

export function LessonScreen({ id }: { id: string }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const j = store.journey;
  const lesson = LESSON_BY_ID[id];
  const today = todayKey();
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const hallNow = useHall().hall;

  if (!lesson) {
    return (
      <Screen back title="Lesson not found" testID="screen-lesson">
        <Notice>This lesson isn’t part of this version of Equilibrium.</Notice>
      </Screen>
    );
  }

  const tier = TIERS[lesson.tier];
  const all = lessonsFor(lesson.tier);
  const index = all.findIndex((l) => l.id === lesson.id);
  const open = isTierOpen(j, lesson.tier);
  const practicable = isPracticable(lesson);
  const progress = lessonProgress(j, lesson);
  const mastered = isMastered(j, lesson);
  const logs = logsFor(j, lesson.id);
  const loggedToday = logs.some((l) => l.day === today);
  const m = lesson.measure;
  const pipHall = lesson.element ?? hallNow;
  const openGoals = (j.goals ?? []).filter((g) => !g.deletedAt && g.status === 'open').length;

  const toJournal = (prompt: string) => {
    nav.reset('journal');
    nav.requestFocus(`journal:${prompt}`);
  };

  const log = () => {
    // Today is read when the button is pressed, so a screen left open past midnight logs the right day.
    const before = store.current();
    const r = store.apply((x) => logPractice(x, lesson.id, todayKey(), note));
    if (!r.ok) return setError(r.error);
    setError(null);
    setNote('');
    successFeedback();
    const after = store.current();
    const earned = totalGems(after) - totalGems(before);
    const nowMastered = !isMastered(before, lesson) && isMastered(after, lesson);
    toast.show(nowMastered ? `Lesson mastered · ${lesson.title}` : 'Practice noted for today', { gems: earned > 0 ? earned : undefined });
  };

  // Mockup 06: a quiet way to write about the lesson, with its prompt filled in.
  const reflect = <Button label="Reflect in your Grimoire" kind="quiet" icon="journal" onPress={() => toJournal(`What is “${lesson.title}” teaching me?`)} style={{ alignSelf: 'center' }} testID="lesson-reflect" />;

  return (
    <Screen back glass hall={lesson.element} backLabel={tier.name} eyebrow={`${tier.name} · Lesson ${index + 1} of ${all.length}`} title={lesson.title} testID="screen-lesson">
      <Card style={{ gap: space.md }} testID="lesson-teaching">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
          <Medallion state={!practicable ? 'outline' : !open ? 'locked' : mastered ? 'done' : 'open'} element={lesson.element} icon={lesson.icon} size={60} />
          <Text style={[type.body, { flex: 1, fontSize: 17, lineHeight: 26 }]}>{lesson.summary}</Text>
        </View>
        {lesson.element || !practicable ? (
          <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
            {lesson.element ? <Tag label={`${ELEMENTS[lesson.element].name} · ${ELEMENTS[lesson.element].lens}`} /> : null}
            {!practicable ? <Tag label="In preparation" tone="practice" /> : null}
          </View>
        ) : null}
      </Card>

      {!practicable ? (
        <Notice icon="leaf" title="This lesson is being prepared">
          The {tier.name} path is shown as an outline for now. Its full lessons will be added here.
        </Notice>
      ) : !open ? (
        <Notice icon="lock" title={`On the ${tier.name} path`} action={<Button label={`About the ${tier.name} path`} small kind="secondary" onPress={() => nav.push({ name: 'tier', id: lesson.tier })} />}>
          This path isn’t open yet. Your teacher offers it when you’re ready, and a sincere seeker may open it sooner.
        </Notice>
      ) : (
        <Card style={{ gap: space.md }} testID="lesson-progress">
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: space.sm }}>
            <Text role="heading" aria-level={2} style={type.heading}>
              Progress
            </Text>
            {mastered ? <Tag label="Mastered" tone="sage" icon="check" /> : null}
          </View>
          {progress.target <= 21 ? (
            <HallPips count={progress.count} target={progress.target} hall={pipHall} label={progress.label} />
          ) : (
            <ProgressBar value={progress.count} max={progress.target} tone={mastered ? color.sage : hallInk(pipHall)} label={progress.label} />
          )}
          <Text style={type.label} testID="lesson-progress-label">
            {mastered ? `Mastered · ${progress.label}` : progress.label}
          </Text>
          {m.type === 'rhythm' ? <RecentDays days={practiceDays(j)} today={today} n={m.window} /> : null}
        </Card>
      )}

      {practicable && open && m.type !== 'logged' ? (
        <View style={{ gap: space.md }} testID="lesson-actions">
          {m.type === 'journal' ? (
            <>
              {lesson.action === 'lookback' ? <Button label="Open your weekly look-back" kind="secondary" icon="calendar" onPress={() => nav.push({ name: 'lookback' })} testID="lesson-lookback" /> : null}
              <Button label={progress.mastered ? 'Write again in your journal' : 'Write it in your journal'} icon="journal" onPress={() => toJournal(m.prompt)} full testID="lesson-journal" />
              <Text style={type.small}>The prompt is filled in for you: “{m.prompt}”.</Text>
            </>
          ) : lesson.action === 'checkin' ? (
            <Button label="Check in now" icon="sparkle" onPress={() => { nav.reset('today'); nav.requestFocus('checkin'); }} full testID="lesson-checkin" />
          ) : lesson.action === 'areas' ? (
            <Button label="Open Journey areas" icon="journey" onPress={() => { nav.reset('journey'); nav.requestFocus('journey:areas'); }} full testID="lesson-areas" />
          ) : lesson.action === 'goal' && m.type === 'goalsReached' && openGoals > 0 ? (
            <Button label={`See your open quests · ${openGoals}`} icon="flag" onPress={() => { nav.reset('journey'); nav.requestFocus('journey:path'); }} full testID="lesson-quests" />
          ) : lesson.action === 'goal' ? (
            <Button label="Set a goal" icon="flag" onPress={() => nav.openSheet({ name: 'goal' })} full testID="lesson-goal" />
          ) : null}
          {m.type !== 'journal' ? reflect : null}
        </View>
      ) : null}

      {lesson.why ? (
        <View style={{ gap: space.sm }}>
          <Eyebrow heading tone={hallInk(pipHall)}>Why</Eyebrow>
          <Text style={type.body}>{lesson.why}</Text>
        </View>
      ) : null}

      {lesson.how.length ? (
        <View style={{ gap: space.sm }}>
          <Eyebrow heading tone={hallInk(pipHall)}>How</Eyebrow>
          <Card padded={false}>
            {lesson.how.map((h, i) => (
              <View key={i} style={[st.step, i < lesson.how.length - 1 && st.rowBorder]}>
                <View style={[st.stepNum, lesson.element ? { backgroundColor: elementWash[lesson.element] } : null]}>
                  <Text style={[st.stepNumText, lesson.element ? { color: elementText[lesson.element] } : null]}>{i + 1}</Text>
                </View>
                <Text style={[type.body, { flex: 1 }]}>{h}</Text>
              </View>
            ))}
          </Card>
        </View>
      ) : null}

      {practicable && open && m.type === 'logged' ? (
        <View style={{ gap: space.md }} testID="lesson-actions">
          <Card style={{ gap: space.md }}>
            {loggedToday ? (
              <Notice tone="success" title="Practiced today" testID="lesson-logged-today">
                {`Noted for ${formatDay(today)}. Come back tomorrow for the next day.`}
              </Notice>
            ) : (
              <>
                <Field label="How did it go?" optional value={note} onChangeText={setNote} placeholder="A word or a line" maxLength={1000} multiline minHeight={60} testID="lesson-note" />
                {error ? <Notice tone="caution">{error}</Notice> : null}
                <Button label="I practiced today" icon="check" full gems={j.gems.some((g) => g.sourceId === practiceLogId(lesson.id, today)) ? undefined : GEM_AMOUNTS.practice} onPress={log} testID="lesson-log" />
              </>
            )}
          </Card>
          {reflect}
        </View>
      ) : null}

      {logs.length ? (
        <View style={{ gap: space.sm }} testID="lesson-log-list">
          <Eyebrow heading>Days practiced · {logs.length}</Eyebrow>
          <Card padded={false}>
            {[...logs].reverse().map((l, i) => (
              <View key={l.id} style={[st.logRow, i < logs.length - 1 && st.rowBorder]}>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={type.label}>{formatDay(l.day)}</Text>
                  {l.note ? <Text style={type.small}>{l.note}</Text> : null}
                </View>
                <IconButton icon="trash" label={`Remove practice on ${formatDay(l.day)}`} onPress={() => store.apply((x) => unlogPractice(x, lesson.id, l.day))} tone={color.inkSoft} size={18} />
              </View>
            ))}
          </Card>
        </View>
      ) : null}
    </Screen>
  );
}

/** The last n days as marks: filled for a day with any practice. A record, not a score. */
function RecentDays({ days, today, n }: { days: Set<string>; today: string; n: number }) {
  const list = Array.from({ length: n }, (_, i) => addDays(today, i - n + 1));
  const count = list.filter((d) => days.has(d)).length;
  return (
    <View style={{ gap: 6 }} role="img" aria-label={`Practiced on ${count} of the last ${n} days`}>
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
        {list.map((d) => (
          <View key={d} style={[st.dayMark, days.has(d) ? { backgroundColor: color.sage, borderColor: color.sage } : null, d === today && { borderWidth: 2, borderColor: color.gold }]} />
        ))}
      </View>
      <Text style={[type.small, { fontSize: 12.5 }]}>The last {n} days, oldest first. Filled: a day you practiced.</Text>
    </View>
  );
}

const st = StyleSheet.create({
  step: { flexDirection: 'row', gap: space.md, alignItems: 'flex-start', padding: space.lg },
  stepNum: { width: 28, height: 28, borderRadius: 14, backgroundColor: color.sageWash, alignItems: 'center', justifyContent: 'center' },
  stepNumText: { fontFamily: serif, fontSize: 15, color: color.sage, fontWeight: '700' },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  logRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingLeft: space.lg, paddingRight: space.sm, paddingVertical: 10 },
  dayMark: { width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, borderColor: color.controlBorder, backgroundColor: color.paperStrong },
});

