// The path map, full screen at the top of Journey (painted academy, mockup 09, decided Oct 14).
// On phones the painting runs edge to edge under a dark header with the title, the path's progress
// and a legend; the Space and gem chips float over its top right.

import React from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import type { Journey, TierId } from '../../domain/types';
import { TIER_IDS } from '../../domain/types';
import { currentLessonId, isMastered, isPracticable, isTierOpen, lessonsFor, TIERS, todayKey } from '../../domain/paths';
import { useNav } from '../../state/nav';
import { useArtOverlay } from '../../state/artChrome';
import { useLayout } from '../../ui/layout';
import { useInsets } from '../../ui/insets';
import { serif, space } from '../../theme/tokens';
import { HEADER_SHADE } from '../../theme/paintings';
import { canDrawGrounds, GroundsMap } from './GroundsMap';

/** The path drawn on the grounds: the open, unfinished path where "you are here" (if it fits the painting). */
export function groundsTierFor(j: Journey): TierId | null {
  const here = currentLessonId(j);
  for (const t of TIER_IDS) {
    if (!isTierOpen(j, t)) break;
    const lessons = lessonsFor(t);
    const practicable = lessons.filter(isPracticable);
    const complete = practicable.length > 0 && practicable.every((l) => isMastered(j, l));
    if (!complete && canDrawGrounds(lessons) && (!here || lessons.some((l) => l.id === here))) return t;
  }
  return null;
}

let gid = 0;

export function GroundsHero({ journey, tier, openGoals }: { journey: Journey; tier: TierId; openGoals: number }) {
  const nav = useNav();
  const { width } = useWindowDimensions();
  const { wide } = useLayout();
  const overlay = useArtOverlay();
  const insets = useInsets('page');
  const [id] = React.useState(() => `gh-${++gid}`);
  const lessons = lessonsFor(tier);
  const practicable = lessons.filter(isPracticable);
  const mastered = practicable.filter((l) => isMastered(journey, l)).length;
  const W = wide ? Math.min(560, width) : width;
  const headTop = (overlay ? insets.top : 0) + 12;
  return (
    <View style={[{ width: W, alignSelf: 'center' }, !wide && { marginHorizontal: -space.lg }]} testID="grounds-hero">
      <GroundsMap
        journey={journey}
        lessons={lessons}
        tier={tier}
        here={currentLessonId(journey)}
        openGoals={openGoals}
        today={todayKey()}
        width={W}
        bleed={!wide}
        onLesson={(lid) => nav.push({ name: 'lesson', id: lid })}
        onTier={(t) => nav.push({ name: 'tier', id: t })}
        onInvite={(t) => nav.push({ name: 'invitation', tier: t })}
        onRest={() => nav.push({ name: 'rest' })}
        header={
          <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
            <Svg width={W} height={HEADER_SHADE.height + headTop} style={StyleSheet.absoluteFill} pointerEvents="none" aria-hidden>
              <Defs>
                <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
                  <Stop offset={0} stopColor={HEADER_SHADE.rgb} stopOpacity={HEADER_SHADE.top} />
                  <Stop offset={0.62} stopColor={HEADER_SHADE.rgb} stopOpacity={HEADER_SHADE.mid} />
                  <Stop offset={1} stopColor={HEADER_SHADE.rgb} stopOpacity={0} />
                </LinearGradient>
              </Defs>
              <Rect x={0} y={0} width={W} height={HEADER_SHADE.height + headTop} fill={`url(#${id})`} />
            </Svg>
            <View style={{ paddingTop: headTop, paddingHorizontal: space.lg, gap: 6, paddingRight: overlay ? 130 : space.lg }} pointerEvents="none">
              <Text role="heading" aria-level={2} style={st.title}>
                Academy grounds
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Text style={st.sub}>Path map</Text>
                <View style={st.progress}>
                  <Text style={st.progressText} testID="grounds-progress">
                    {TIERS[tier].name} · {mastered} of {practicable.length}
                  </Text>
                </View>
              </View>
            </View>
            <View style={[st.legend, { left: space.md, right: space.md }]} pointerEvents="none" aria-hidden testID="grounds-legend">
              <Legend swatch={<View style={[st.dot, { backgroundColor: '#E3B755' }]} />} label="Mastered" />
              <Legend swatch={<View style={[st.dot, { borderWidth: 2, borderColor: '#FBE7BE' }]} />} label="Open" />
              <Legend swatch={<View style={[st.dot, { backgroundColor: '#1D8F75' }]} />} label="Rest" />
              <Legend swatch={<View style={[st.dot, { borderWidth: 2, borderColor: '#E8C46B', borderStyle: 'dashed' }]} />} label="When ready" />
            </View>
          </View>
        }
      />
    </View>
  );
}

function Legend({ swatch, label }: { swatch: React.ReactNode; label: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
      {swatch}
      <Text style={st.legendText}>{label}</Text>
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontFamily: serif, fontSize: 21, lineHeight: 26, fontWeight: '700', color: '#FFFFFF' },
  sub: { fontSize: 14, lineHeight: 18, fontWeight: '700', color: '#F3E9FF' },
  progress: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999, borderWidth: 1, borderColor: 'rgba(243,216,142,0.6)', backgroundColor: 'rgba(24,17,46,0.5)' },
  progressText: { fontSize: 13, lineHeight: 17, fontWeight: '800', color: '#F3D88E' },
  legend: { position: 'absolute', bottom: space.md, alignSelf: 'center', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 12, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, backgroundColor: 'rgba(24,17,46,0.78)' },
  legendText: { fontSize: 12.5, lineHeight: 16, fontWeight: '700', color: '#FFFFFF' },
  dot: { width: 12, height: 12, borderRadius: 6 },
});
