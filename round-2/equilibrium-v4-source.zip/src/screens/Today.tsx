import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { SHARP } from '../ui/academy/paintingSources';
import { deleteCheckIn, dismissGuideCard } from '../domain/ops';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { computeDirection, DIRECTIONS } from '../domain/directions';
import { areaStats, evidenceFor, guideProgress, isEasyWin, rankedAreas, todaysCheckins } from '../domain/selectors';
import { formatLongDate, formatRelative, formatTime, greetingFor, localDayKey, ordinal } from '../domain/time';
import { isAdult } from '../domain/age';
import { currentProtocol } from '../domain/protocols';
import { CountsCard, RhythmCard, TimelineCard, WeekCard } from './HomeCards';
import { EquilibriumCard } from './Equilibrium';
import { GuideCard } from './path/PathView';
import { GEM_AMOUNTS } from '../domain/gems';
import { SPACE_NAME } from '../domain/spaces';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { color, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, focusRing, IconButton, Tag } from '../ui/primitives';
import { CheckInSummary, CheckInTiles } from '../ui/CheckInForm';
import { setCheckinFlash, useCheckinFlash } from '../state/checkinFlash';
import { Gem, Icon } from '../ui/Icon';
import { EvidenceMarks } from '../ui/EvidenceMarks';
import { WingProvider } from '../ui/academy/hall';

export function Today() {
  const store = useStore();
  const { journey } = store;
  const nav = useNav();
  const toast = useToast();
  const scrollRef = useRef<ScrollView>(null);
  const now = new Date();
  const space_ = journey.activeSpaceId;
  const saved = useCheckinFlash();
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const today = todaysCheckins(journey, space_, now);
  const direction = useMemo(() => computeDirection(journey), [journey]);
  const areas = rankedAreas(journey).slice(0, 3);
  const guide = guideProgress(journey);
  const showGuideCard = !guide.complete && !journey.guide.cardDismissedAt;

  // The confirmation belongs to the Space it was made in; switching Space shows that Space's form.
  const shownSaved = saved && saved.spaceId === space_ ? saved : null;

  useEffect(() => {
    // Lessons and the guide ask for the check-in: it has its own screen now.
    if (nav.focusTarget === 'checkin') {
      nav.requestFocus(null);
      nav.push({ name: 'checkin' });
    }
  }, [nav.focusTarget]); // eslint-disable-line react-hooks/exhaustive-deps

  const name = journey.profile?.name ?? '';
  const { width } = useWindowDimensions();
  const twoCol = width >= 1240;
  const adult = isAdult(journey);
  const protocol = currentProtocol(journey);
  const guideBlock = (
    <>
      {showGuideCard ? (
        <Card tone="gold" style={{ gap: space.md }} testID="guide-card">
          <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
            <View style={st.guideIcon}>
              <Icon name="map" size={22} color={color.gold} />
            </View>
            <View style={{ flex: 1, gap: 4 }}>
              <Text style={type.heading}>{guide.done ? `Resume first steps · ${guide.done} of 5 done` : 'New here? Walk the five-part map.'}</Text>
              <Text style={type.small}>Five short practice lessons, about four minutes. Nothing you try in practice is added to your history.</Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
            <Button label={guide.done ? 'Resume' : 'Start first steps'} kind="gold" small onPress={() => nav.openGuide()} testID="guide-start" />
            <Button label="Not now" kind="quiet" small onPress={() => store.apply((j) => dismissGuideCard(j))} testID="guide-dismiss" />
          </View>
        </Card>
      ) : null}
    </>
  );
  const latestToday = today[0];
  const checkinHeader = (
    <View testID="checkin-band" style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: space.sm }}>
      <View style={{ flexShrink: 1 }}>
        <Eyebrow>Check in · {SPACE_NAME[space_]}</Eyebrow>
        <Text role="heading" aria-level={2} style={[type.heading, { lineHeight: 22 }]}>
          Today’s check-in
        </Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        {!shownSaved ? (
          <View style={st.gemTag} aria-label={`A check-in earns ${GEM_AMOUNTS.checkin} gems`}>
            <Gem size={13} tone="gold" />
            <Text style={st.gemTagText}>+{GEM_AMOUNTS.checkin} gems</Text>
          </View>
        ) : null}
        {latestToday && !shownSaved ? <Icon name="chevron" size={18} color={color.actionText} /> : null}
      </View>
    </View>
  );
  // Mockup 04: after a check-in, the whole card is the button — the title, today's three tiles, nothing more.
  const checkinBlock = shownSaved ? (
    <Card style={[st.homeCard, { gap: space.md }]} testID="checkin-card">
      {checkinHeader}
      <View style={st.savedPanel} testID="checkin-saved" aria-live="polite">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
          <View style={st.savedCheck}>
            <Icon name="check" size={18} color={color.onSage} strokeWidth={2.6} />
          </View>
          <Text style={[type.heading, { flex: 1 }]}>Checked in at {formatTime(shownSaved.at)}</Text>
        </View>
        <CheckInTiles compact mood={shownSaved.mood} energy={shownSaved.energy} connection={shownSaved.connection} />
        {shownSaved.note ? <Text style={type.small}>“{shownSaved.note}”</Text> : null}
        <Text style={type.small}>
          Your {ordinal(shownSaved.count)} check-in today · +{GEM_AMOUNTS.checkin} gems in {SPACE_NAME[space_]}
        </Text>
        <Button label="Check in again" kind="secondary" small onPress={() => { setCheckinFlash(null); nav.push({ name: 'checkin' }); }} testID="checkin-again" />
      </View>
    </Card>
  ) : latestToday ? (
    <Card padded={false} testID="checkin-card">
      <Pressable
        role="button"
        aria-label={`Today’s check-in in ${SPACE_NAME[space_]}, last at ${formatTime(latestToday.createdAt)}. Check in again`}
        onPress={() => nav.push({ name: 'checkin' })}
        style={(p: any) => [st.homeCard, { gap: 8, borderRadius: 22 }, (p.hovered || p.pressed) && { backgroundColor: color.actionWash }, focusRing(p)]}
        testID="checkin-open"
      >
        {checkinHeader}
        <CheckInTiles compact mood={latestToday.mood} energy={latestToday.energy} connection={latestToday.connection} />
      </Pressable>
    </Card>
  ) : (
    <Card style={[st.homeCard, { gap: 10 }]} testID="checkin-card">
      {checkinHeader}
      <Text style={type.small}>Three quick readings: mood, energy and connection. Honest beats high.</Text>
      <Button label="Check in" icon="sparkle" small full onPress={() => nav.push({ name: 'checkin' })} testID="checkin-open" />
    </Card>
  );
  const restBlock = (
    <Pressable role="button" aria-label="Take a 2-minute rest in the Sanctuary" onPress={() => nav.push({ name: 'rest' })} style={(s: any) => [st.restRow, (s.hovered || s.pressed) && { opacity: 0.92 }, focusRing(s)]} testID="rest-open">
      <Image source={SHARP['healing-sanctuary']} style={st.restThumb} resizeMode="cover" aria-hidden />
      <Text style={st.restText}>
        Take a 2-minute rest <Text style={{ fontWeight: '600' }}>· Sanctuary</Text>
      </Text>
      <Icon name="chevron" size={18} color={color.sage} />
    </Pressable>
  );
  const soFarBlock = (
    <>
      {today.length ? (
        <View style={{ gap: space.sm }} testID="today-so-far">
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Eyebrow heading>Today so far · {today.length} check-in{today.length === 1 ? '' : 's'}</Eyebrow>
            <Button label="All check-ins" kind="quiet" small onPress={() => nav.push({ name: 'checkins' })} testID="checkins-all" />
          </View>
          <Card padded={false}>
            {today.map((c, i) => (
              <View key={c.id} style={[st.dayRow, i < today.length - 1 && st.rowBorder]} testID="today-checkin">
                <Text style={[type.label, { width: 72 }]}>{formatTime(c.createdAt)}</Text>
                <View style={{ flex: 1, gap: 4 }}>
                  <CheckInSummary mood={c.mood} energy={c.energy} connection={c.connection} />
                  {c.note ? (
                    <Text style={type.small} numberOfLines={2}>
                      {c.note}
                    </Text>
                  ) : null}
                </View>
                <IconButton icon="trash" label={`Delete the ${formatTime(c.createdAt)} check-in`} onPress={() => setConfirmDel(c.id)} tone={color.inkSoft} size={18} />
              </View>
            ))}
          </Card>
        </View>
      ) : null}
    </>
  );
  const directionBlock = (
    <>
      <Pressable role="button" aria-label="Your direction. Open directions" onPress={() => nav.push({ name: 'directions' })} style={(s: any) => [focusRing(s), { borderRadius: radius.lg }]}>
        <Card style={{ gap: space.sm }} testID="direction-card">
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Eyebrow heading>Your direction</Eyebrow>
            <Icon name="chevron" size={18} color={color.inkSoft} />
          </View>
          {direction.current ? (
            <>
              <Text style={type.title}>
                {DIRECTIONS[direction.current].name}
                <Text style={[type.heading, { color: color.gold }]}> — {DIRECTIONS[direction.current].verb}</Text>
              </Text>
              <Text style={type.bodySoft}>{DIRECTIONS[direction.current].purpose}</Text>
              <View style={st.tryRow}>
                <Icon name="leaf" size={18} color={color.sage} />
                <Text style={[type.small, { flex: 1, color: color.ink }]}>
                  <Text style={{ fontWeight: '700' }}>A small practice: </Text>
                  {DIRECTIONS[direction.current].practices[now.getDate() % 3]}
                </Text>
              </View>
              <Text style={type.small}>Why this direction? Tap to see exactly how it's worked out.</Text>
            </>
          ) : (
            <>
              <Text style={type.heading}>No direction yet</Text>
              <Text style={type.small}>Choose a starting direction, or tag a Journey area, and Equilibrium will show where your practice is pointing.</Text>
            </>
          )}
        </Card>
      </Pressable>
    </>
  );
  const practiceBlock = (
    <>
      <View style={{ gap: space.sm }} testID="today-practice">
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Eyebrow heading>Practice what matters</Eyebrow>
          {areas.length ? <Button label="All of Journey" kind="quiet" small onPress={() => nav.setTab('journey')} /> : null}
        </View>
        {areas.length ? (
          <Card padded={false}>
            {areas.map((a, i) => {
              const stats = areaStats(journey, a.id);
              return (
                <View key={a.id} style={[st.practiceRow, !twoCol && width < 560 && { flexDirection: 'column', alignItems: 'stretch' }, i < areas.length - 1 && st.rowBorder]}>
                  <Pressable role="button" aria-label={`${a.name}. Open`} onPress={() => nav.push({ name: 'area', id: a.id })} style={(s: any) => [{ flex: 1, gap: 4 }, focusRing(s)]}>
                    <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'center', flexWrap: 'wrap' }}>
                      <Text style={type.label}>{a.name}</Text>
                      {isEasyWin(a) ? <Tag label="Easy win" tone="sage" /> : null}
                    </View>
                    <EvidenceMarks evidence={evidenceFor(journey, a.id)} max={10} />
                    <Text style={type.small}>{stats.total ? `${stats.wins} win${stats.wins === 1 ? '' : 's'} · last evidence ${formatRelative(stats.last!.createdAt, now)}` : 'No evidence yet'}</Text>
                  </Pressable>
                  <Button label="Add evidence" small kind="secondary" icon="plus" onPress={() => nav.push({ name: 'area', id: a.id, focus: true })} accessibilityHint={`Record evidence for ${a.name}`} />
                </View>
              );
            })}
          </Card>
        ) : (
          <Card style={{ gap: space.md }}>
            <Text style={type.bodySoft}>Name one thing you'd like to practice — a steadier sleep rhythm, more patience, finishing something. Then record what actually happens.</Text>
            <Button label="Add to Journey" small icon="plus" kind="secondary" onPress={() => nav.openSheet({ name: 'areaEditor' })} testID="today-add-area" />
          </Card>
        )}
      </View>
    </>
  );
  const firstStepsBlock = (
    <>
      {!showGuideCard && !guide.complete ? (
        <Button label={`First steps · ${guide.done} of 5 done`} kind="quiet" small icon="map" onPress={() => nav.openGuide()} style={{ alignSelf: 'center' }} />
      ) : null}
    </>
  );
  const rhythmBlock = adult && protocol ? <RhythmCard today={localDayKey(now)} /> : null;
  const pathBlock = <GuideCard />;
  const equilibriumBlock = <EquilibriumCard />;
  const weekBlock = (
    <>
      <WeekCard today={localDayKey(now)} />
      <CountsCard today={localDayKey(now)} />
    </>
  );
  const timelineBlock = <TimelineCard />;

  return (
    <WingProvider wing="academy">
    <Screen
      scrollRef={scrollRef}
      eyebrow={formatLongDate(now)}
      title={`${greetingFor(now)}, ${name}.`}
      glass
      art="home"
      testID="screen-today"
      maxWidth={twoCol ? 1120 : undefined}
    >
      {twoCol ? (
        <View style={{ flexDirection: 'row', gap: space.xl, alignItems: 'flex-start' }}>
          <View style={{ flex: 1.15, gap: space.xl }}>
            {guideBlock}
            {pathBlock}
            {checkinBlock}
            {equilibriumBlock}
            {restBlock}
            {rhythmBlock}
            {soFarBlock}
            {directionBlock}
            {practiceBlock}
            {firstStepsBlock}
          </View>
          <View style={{ flex: 1, gap: space.xl }}>
            {weekBlock}
            {timelineBlock}
          </View>
        </View>
      ) : (
        <>
          {guideBlock}
          <View style={{ gap: space.sm }}>
            {pathBlock}
            {checkinBlock}
            {equilibriumBlock}
            {restBlock}
          </View>
          {rhythmBlock}
          {soFarBlock}
          {weekBlock}
          {directionBlock}
          {practiceBlock}
          {timelineBlock}
          {firstStepsBlock}
        </>
      )}
      <ConfirmSheet
        visible={!!confirmDel}
        title="Delete this check-in?"
        body="It will be removed from today's list and your history. Its gems stay — they recognize that you showed up."
        confirmLabel="Delete check-in"
        onCancel={() => setConfirmDel(null)}
        onConfirm={() => {
          if (confirmDel) store.apply((j) => deleteCheckIn(j, confirmDel));
          setConfirmDel(null);
          toast.show('Check-in deleted');
        }}
      />
    </Screen>
    </WingProvider>
  );
}


const st = StyleSheet.create({
  guideIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: color.paperStrong, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: color.goldBorder },
  dayRow: { flexDirection: 'row', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 14, alignItems: 'flex-start' },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  tryRow: { flexDirection: 'row', gap: space.sm, alignItems: 'flex-start', backgroundColor: color.canvas, padding: space.md, borderRadius: radius.md },
  practiceRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.lg },
  link: { color: color.sage, fontWeight: '700', textDecorationLine: 'underline' },
  savedPanel: { gap: space.md, padding: space.lg, borderRadius: radius.md, backgroundColor: color.sageWash, borderWidth: 1, borderColor: color.sageBorder },
  restRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, minHeight: 48, paddingLeft: 6, paddingRight: space.md, paddingVertical: 6, borderRadius: 18, backgroundColor: color.sageWash, borderWidth: 1, borderColor: color.sageBorder },
  restThumb: { width: 36, height: 36, borderRadius: 11 },
  homeCard: { paddingHorizontal: 16, paddingVertical: 12 },
  restText: { flex: 1, fontSize: 15, lineHeight: 20, fontWeight: '800', color: color.sage },
  gemTag: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: color.goldWash },
  gemTagText: { fontSize: 13, lineHeight: 17, fontWeight: '800', color: color.goldPressed },
  savedCheck: { width: 30, height: 30, borderRadius: 15, backgroundColor: color.sage, alignItems: 'center', justifyContent: 'center' },
});
