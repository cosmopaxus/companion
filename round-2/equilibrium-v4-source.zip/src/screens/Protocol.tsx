import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { DoseLevel, ProtocolPattern, ProtocolPlan } from '../domain/types';
import { isAdult, REFLECTION_MODE_NOTE } from '../domain/age';
import { evaluateIntake } from '../domain/intake';
import { deleteProtocol, endProtocol, pauseProtocol, ProtocolInput, resumeProtocol, startProtocol, updateProtocol } from '../domain/ops';
import {
  addDays,
  currentProtocol,
  CUSTOM_ID,
  DAY_LABEL,
  dayFor,
  daysBetween,
  describePattern,
  formatDay,
  nextActivation,
  pastProtocols,
  patternProblem,
  patternUnlessNamed,
  PROTOCOL_PRESETS,
  START_LOW,
  upcoming,
  WEEKDAY_SHORT,
} from '../domain/protocols';
import { localDayKey } from '../domain/time';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { color, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Chip, Eyebrow, focusRing, IconButton, Notice, Tag, Toggle } from '../ui/primitives';
import { Field, Segmented } from '../ui/controls';
import { Stepper } from '../ui/Stepper';
import { RhythmStrip } from '../ui/RhythmStrip';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { Icon } from '../ui/Icon';

const LEVELS: { id: DoseLevel; label: string; detail: string }[] = [
  { id: 'micro', label: 'Micro', detail: 'Below the threshold of noticeable effects' },
  { id: 'minor', label: 'Minor', detail: 'Gently noticeable' },
  { id: 'unsure', label: 'Not sure yet', detail: 'Start with the smallest amount' },
];


interface Draft extends ProtocolInput {
  editingId?: string;
  restOn: boolean;
}

function draftFromPreset(presetId: string, today: string): Draft {
  const preset = PROTOCOL_PRESETS.find((p) => p.id === presetId);
  return {
    presetId,
    name: preset?.name ?? 'My rhythm',
    pattern: preset ? (preset.pattern.type === 'cycle' ? { ...preset.pattern } : { type: 'weekdays', days: [...preset.pattern.days] }) : { type: 'cycle', on: 1, off: 2 },
    startDate: today,
    restOn: false,
    cycleWeeks: 4,
    restWeeks: 2,
  };
}

function draftFromPlan(p: ProtocolPlan): Draft {
  return {
    editingId: p.id,
    presetId: p.presetId,
    name: p.name,
    pattern: p.pattern.type === 'cycle' ? { ...p.pattern } : { type: 'weekdays', days: [...p.pattern.days] },
    startDate: p.startDate,
    restOn: !!(p.cycleWeeks && p.restWeeks),
    cycleWeeks: p.cycleWeeks ?? 4,
    restWeeks: p.restWeeks ?? 2,
    level: p.level,
    substance: p.substance,
    amount: p.amount,
    intention: p.intention,
  };
}

function toInput(d: Draft): ProtocolInput {
  return {
    presetId: d.presetId,
    name: d.name,
    pattern: d.pattern,
    startDate: d.startDate,
    cycleWeeks: d.restOn ? d.cycleWeeks : undefined,
    restWeeks: d.restOn ? d.restWeeks : undefined,
    level: d.level,
    substance: d.substance,
    amount: d.amount,
    intention: d.intention,
  };
}

/** A preview plan for showing what a draft or preset would look like. */
function previewPlan(input: ProtocolInput): ProtocolPlan {
  return { id: 'preview', createdAt: '', updatedAt: '', status: 'active', ...input };
}

export function ProtocolScreen() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const j = store.journey;
  const today = localDayKey(new Date());
  const current = currentProtocol(j);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [choosing, setChoosing] = useState(!current);
  const [confirm, setConfirm] = useState<null | { kind: 'end' | 'remove'; id: string }>(null);
  const [error, setError] = useState<string | null>(null);
  const intake = evaluateIntake(j.intake);

  if (!isAdult(j)) {
    return (
      <Screen back title="Your protocol" testID="screen-protocol">
        <Notice icon="heart">{REFLECTION_MODE_NOTE}</Notice>
      </Screen>
    );
  }

  if (intake.supportNow) {
    return (
      <Screen back title="Your protocol" testID="screen-protocol">
        <Card tone="caution" style={{ gap: space.sm }} testID="protocol-support-first">
          <Text style={[type.heading, { color: color.caution }]}>Support first</Text>
          <Text style={type.body}>In Safety & Path you said you might be in crisis or in danger. Please reach out to someone now — in the US, call or text 988, or call 911 in an emergency. Protocols will be here when you feel safe.</Text>
          <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
            <Button label="See support options" kind="urgent" small onPress={() => nav.push({ name: 'support' })} />
            <Button label="Update Safety & Path" kind="secondary" small onPress={() => nav.push({ name: 'intake' })} />
          </View>
        </Card>
      </Screen>
    );
  }

  const cautionNotice =
    intake.majorCount + intake.cautionCount > 0 ? (
      <Notice tone="caution" title={intake.majorCount ? 'Please talk with a clinician first' : 'Worth a conversation first'} testID="protocol-caution" action={<Button label="Review Safety & Path" small kind="secondary" onPress={() => nav.push({ name: 'intake' })} />}>
        {`You noted ${intake.majorCount ? `${intake.majorCount} major caution${intake.majorCount === 1 ? '' : 's'}` : `${intake.cautionCount} factor${intake.cautionCount === 1 ? '' : 's'}`} in Safety & Path. This is your choice to make; please make it with a clinician's input.`}
      </Notice>
    ) : !intake.complete ? (
      <Notice testID="protocol-intake-prompt" action={<Button label="Answer Safety & Path" small kind="secondary" onPress={() => nav.push({ name: 'intake' })} />}>
        Before you start, consider the short Safety & Path screen. It's optional and takes about two minutes.
      </Notice>
    ) : null;

  // ——— Set up or edit ———
  if (draft) {
    const set = (patch: Partial<Draft>) => setDraft({ ...draft, ...patch });
    const isCustom = draft.presetId === CUSTOM_ID;
    const weekdays = draft.pattern.type === 'weekdays';
    const problem = patternProblem(draft.pattern);
    const preview = previewPlan(toInput(draft));
    const offset = daysBetween(today, draft.startDate);
    const save = () => {
      const input = toInput(draft);
      const r = store.apply((jj) => (draft.editingId ? updateProtocol(jj, draft.editingId, input) : startProtocol(jj, input)));
      if (!r.ok) return setError(r.error);
      setError(null);
      setDraft(null);
      setChoosing(false);
      toast.show(draft.editingId ? 'Protocol updated' : 'Protocol started · saved on this device');
    };
    return (
      <Screen key="setup" back title={draft.editingId ? 'Edit your protocol' : isCustom ? 'Create your own' : 'Set up your protocol'} subtitle="Your rhythm, in your words. You can change any of it later." testID="screen-protocol-setup">
        <Card style={{ gap: space.lg }}>
          <Field label="Name" value={draft.name} onChangeText={(t) => set({ name: t })} maxLength={60} testID="protocol-name" />
          {isCustom ? (
            <Segmented
              label="Rhythm type"
              value={weekdays ? 'weekdays' : 'cycle'}
              onChange={(v) => set({ pattern: v === 'weekdays' ? { type: 'weekdays', days: [1, 4] } : { type: 'cycle', on: 1, off: 2 } })}
              options={[
                { value: 'cycle', label: 'Days on and off' },
                { value: 'weekdays', label: 'Chosen weekdays' },
              ]}
              testID="protocol-type"
            />
          ) : (
            <View style={{ gap: 2 }}>
              <Text style={type.label}>Rhythm</Text>
              <Text style={type.bodySoft}>{describePattern(draft.pattern)}</Text>
            </View>
          )}
          {isCustom && draft.pattern.type === 'cycle' ? (
            <>
              <Stepper label="Activation days in a row" value={draft.pattern.on} min={1} max={7} onChange={(v) => set({ pattern: { type: 'cycle', on: v, off: (draft.pattern as any).off } })} testID="protocol-on" />
              <Stepper label="Then integration days" value={draft.pattern.off} min={1} max={14} onChange={(v) => set({ pattern: { type: 'cycle', on: (draft.pattern as any).on, off: v } })} testID="protocol-off" />
            </>
          ) : null}
          {draft.pattern.type === 'weekdays' && (isCustom || draft.presetId === 'two-a-week') ? (
            <View style={{ gap: space.sm }}>
              <Text style={type.label}>Activation days</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {WEEKDAY_SHORT.map((w, i) => {
                  const days = (draft.pattern as { days: number[] }).days;
                  const sel = days.includes(i);
                  return <Chip key={w} label={w} selected={sel} onPress={() => set({ pattern: { type: 'weekdays', days: sel ? days.filter((d) => d !== i) : [...days, i] } as ProtocolPattern })} testID={`protocol-weekday-${i}`} />;
                })}
              </View>
            </View>
          ) : null}
          {problem ? <Text style={[type.small, { color: color.caution }]}>{problem}</Text> : null}
          <Stepper
            label={offset < 0 ? 'Started' : 'Starts'}
            helper={offset === 0 ? 'Today' : offset === 1 ? 'Tomorrow' : offset < 0 ? `${-offset} day${offset === -1 ? '' : 's'} ago — for a rhythm you already follow` : `In ${offset} days`}
            value={offset}
            min={-365}
            max={60}
            decIcon="back"
            incIcon="chevron"
            format={(v) => formatDay(addDays(today, v))}
            onChange={(v) => set({ startDate: addDays(today, v) })}
            testID="protocol-start"
          />
        </Card>

        <Card style={{ gap: space.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={type.label}>Regular rest weeks</Text>
              <Text style={type.small}>Many people practice for several weeks, then take a break of a few weeks. Optional.</Text>
            </View>
            <Toggle label="Regular rest weeks" value={draft.restOn} onChange={(v) => set({ restOn: v })} />
          </View>
          {draft.restOn ? (
            <>
              <Stepper label="Practice for" value={draft.cycleWeeks ?? 4} min={1} max={26} format={(v) => `${v} wk`} onChange={(v) => set({ cycleWeeks: v })} testID="protocol-cycle-weeks" />
              <Stepper label="Then rest for" value={draft.restWeeks ?? 2} min={1} max={12} format={(v) => `${v} wk`} onChange={(v) => set({ restWeeks: v })} testID="protocol-rest-weeks" />
            </>
          ) : null}
        </Card>

        <Card style={{ gap: space.lg }}>
          <View style={{ gap: 4 }}>
            <Eyebrow>Your notes · optional</Eyebrow>
            <Text style={type.small}>Only for you, in your own words. They stay on this device.</Text>
          </View>
          <Notice icon="leaf" testID="protocol-start-low">
            {START_LOW}
          </Notice>
          <View style={{ gap: space.sm }}>
            <Text style={type.label}>Level</Text>
            <View role="radiogroup" aria-label="Level" style={{ gap: space.sm }}>
              {LEVELS.map((l) => (
                <Chip key={l.id} radio label={`${l.label} · ${l.detail}`} selected={draft.level === l.id} onPress={() => set({ level: draft.level === l.id ? undefined : l.id })} testID={`protocol-level-${l.id}`} />
              ))}
            </View>
          </View>
          <Field label="What you take" optional value={draft.substance ?? ''} onChangeText={(t) => set({ substance: t })} maxLength={80} placeholder="As it's labeled" testID="protocol-substance" />
          <Field label="Your amount" optional value={draft.amount ?? ''} onChangeText={(t) => set({ amount: t })} maxLength={40} placeholder="Your amount and unit" helper="Exactly as you'd write it. Equilibrium doesn't calculate or convert anything." testID="protocol-amount" />
          <Field label="Intention" optional value={draft.intention ?? ''} onChangeText={(t) => set({ intention: t })} maxLength={200} placeholder="What are you practicing toward?" testID="protocol-intention" />
        </Card>

        <Card style={{ gap: space.md }} testID="protocol-preview">
          <Eyebrow heading>Your first two weeks</Eyebrow>
          {problem ? <Text style={type.small}>Fix the rhythm above to see a preview.</Text> : <RhythmStrip days={upcoming(preview, offset < 0 ? today : draft.startDate, 14)} today={today} testID="protocol-preview-strip" />}
        </Card>

        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label={draft.editingId ? 'Save changes' : 'Start this protocol'} full disabled={!!problem || !draft.name.trim()} onPress={save} testID="protocol-save" />
        <Button label="Cancel" kind="quiet" full onPress={() => { setDraft(null); setError(null); }} />
        {!draft.editingId && current ? <Text style={[type.small, { textAlign: 'center' }]}>Starting this ends “{current.name}”. It stays in your history.</Text> : null}
      </Screen>
    );
  }

  // ——— Choose a rhythm ———
  if (choosing || !current) {
    return (
      <Screen key="choose" back title="Choose a protocol" subtitle="A rhythm of activation days and integration days. You choose it; Equilibrium helps you keep it." testID="screen-protocol">
        {cautionNotice}
        <Notice icon="leaf">{START_LOW}</Notice>
        <View style={{ gap: space.md }}>
          {PROTOCOL_PRESETS.map((p) => (
            <Pressable key={p.id} role="button" aria-label={`${p.name}. ${p.aka ? `${p.aka}. ` : ''}${p.blurb} Choose`} onPress={() => setDraft(draftFromPreset(p.id, today))} style={(s: any) => [{ borderRadius: radius.lg }, focusRing(s)]} testID={`protocol-preset-${p.id}`}>
              <Card style={{ gap: space.md }}>
                <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={type.heading}>{p.name}</Text>
                    {p.aka ? <Text style={[type.small, { color: color.gold, fontWeight: '700' }]}>{p.aka}</Text> : null}
                    <Text style={type.small}>{p.blurb}</Text>
                  </View>
                  <Icon name="chevron" size={18} color={color.inkSoft} />
                </View>
                <RhythmStrip days={upcoming(previewPlan({ presetId: p.id, name: p.name, pattern: p.pattern, startDate: today }), today, 7)} today={today} />
              </Card>
            </Pressable>
          ))}
          <Pressable role="button" aria-label="Create your own rhythm" onPress={() => setDraft(draftFromPreset(CUSTOM_ID, today))} style={(s: any) => [{ borderRadius: radius.lg }, focusRing(s)]} testID="protocol-preset-custom">
            <Card tone="sage" style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
              <Icon name="plus" size={22} color={color.sage} />
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={type.heading}>Create your own</Text>
                <Text style={type.small}>Any number of days on and off, or the weekdays you choose.</Text>
              </View>
            </Card>
          </Pressable>
        </View>
        {current ? <Button label="Keep my current protocol" kind="quiet" full onPress={() => setChoosing(false)} /> : null}
        <Text style={type.small}>These are common schedules people follow, not recommendations for you. Your protocol is the same in every Space and stays on this device.</Text>
      </Screen>
    );
  }

  // ——— Your current protocol ———
  const info = dayFor(current, today);
  const next = current.status === 'active' ? nextActivation(current, addDays(today, 1)) : null;
  const past = pastProtocols(j);
  const todayText =
    info.kind === 'activation' || info.kind === 'integration'
      ? `${DAY_LABEL[info.kind]}${info.of && info.of > 1 ? ` ${info.index} of ${info.of}` : ''}`
      : info.kind === 'rest'
        ? `Rest period · day ${info.index} of ${info.of}`
        : info.kind === 'upcoming'
          ? `Starts ${formatDay(current.startDate, 'long')}`
          : DAY_LABEL[info.kind];
  return (
    <Screen key="current" back title="Your protocol" subtitle="The same in every Space. Saved on this device." testID="screen-protocol">
      {cautionNotice}
      <Card style={{ gap: space.md }} testID="protocol-current">
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
          <View style={{ flex: 1, gap: 2 }}>
            <Text style={type.title}>{current.name}</Text>
            {(() => {
              const rest = current.cycleWeeks && current.restWeeks ? `${current.cycleWeeks} weeks, then ${current.restWeeks} weeks rest` : '';
              const line = [patternUnlessNamed(current.name, current.presetId, current.pattern) ?? '', rest].filter(Boolean).join(' · ');
              return line ? <Text style={type.small}>{line}</Text> : null;
            })()}
            <Text style={type.small}>
              {daysBetween(current.startDate, today) >= 0 ? 'Since' : 'Starts'} {formatDay(current.startDate, 'long')}
            </Text>
          </View>
          <Tag label={current.status === 'paused' ? 'Paused' : 'Active'} tone={current.status === 'paused' ? 'neutral' : 'sage'} />
        </View>
        <View style={[st.today, info.kind === 'activation' && { backgroundColor: color.goldWash, borderColor: color.goldBorder }]} testID="protocol-today">
          <Eyebrow>Today</Eyebrow>
          <Text style={type.heading}>{todayText}</Text>
          {next ? <Text style={type.small}>Next activation day: {formatDay(next, 'long')}</Text> : null}
        </View>
        {current.status === 'active' ? <RhythmStrip days={upcoming(current, today, 14)} today={today} testID="protocol-strip" /> : null}
        {current.level || current.substance || current.amount || current.intention ? (
          <View style={{ gap: 4 }} testID="protocol-notes">
            {current.level ? <Text style={type.small}>Level · {LEVELS.find((l) => l.id === current.level)!.label}</Text> : null}
            {current.substance ? <Text style={type.small}>What you take · {current.substance}</Text> : null}
            {current.amount ? <Text style={type.small}>Your amount · {current.amount}</Text> : null}
            {current.intention ? <Text style={[type.body, { fontStyle: 'italic' }]}>“{current.intention}”</Text> : null}
          </View>
        ) : null}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          <Button label="Edit" small kind="secondary" icon="edit" onPress={() => setDraft(draftFromPlan(current))} testID="protocol-edit" />
          {current.status === 'active' ? (
            <Button label="Pause" small kind="secondary" onPress={() => { store.apply((jj) => pauseProtocol(jj, current.id)); toast.show('Paused'); }} testID="protocol-pause" />
          ) : (
            <Button label="Resume from today" small onPress={() => { const r = store.apply((jj) => resumeProtocol(jj, current.id, today)); if (!r.ok) setError(r.error); else toast.show('Resumed · counting from today'); }} testID="protocol-resume" />
          )}
          <Button label="End protocol" small kind="quiet" onPress={() => setConfirm({ kind: 'end', id: current.id })} testID="protocol-end" />
        </View>
      </Card>
      {error ? <Notice tone="caution">{error}</Notice> : null}
      <Notice icon="calendar">Today, reminders and a place to note each day arrive in the next update. For now, your rhythm is saved and ready.</Notice>
      <Button label="Choose a different protocol" kind="secondary" full onPress={() => setChoosing(true)} testID="protocol-change" />

      {past.length ? (
        <View style={{ gap: space.sm }}>
          <Eyebrow heading>Earlier protocols</Eyebrow>
          <Card padded={false}>
            {past.map((p, i) => (
              <View key={p.id} style={[st.pastRow, i < past.length - 1 && st.rowBorder]} testID="protocol-past">
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={type.label}>{p.name}</Text>
                  <Text style={type.small}>
                    {[patternUnlessNamed(p.name, p.presetId, p.pattern), formatDay(p.startDate)].filter(Boolean).join(' · ')}
                    {p.endedAt ? ` – ${formatDay(localDayKey(p.endedAt))}` : ''}
                  </Text>
                </View>
                <IconButton icon="trash" label={`Remove ${p.name} from your history`} onPress={() => setConfirm({ kind: 'remove', id: p.id })} tone={color.inkSoft} size={18} />
              </View>
            ))}
          </Card>
        </View>
      ) : null}

      <ConfirmSheet
        visible={confirm?.kind === 'end'}
        title="End this protocol?"
        body="It moves to your history with its notes. You can start another any time."
        confirmLabel="End protocol"
        danger={false}
        onConfirm={() => {
          if (confirm) store.apply((jj) => endProtocol(jj, confirm.id));
          setConfirm(null);
          setChoosing(true);
          toast.show('Protocol ended');
        }}
        onCancel={() => setConfirm(null)}
      />
      <ConfirmSheet
        visible={confirm?.kind === 'remove'}
        title="Remove from history?"
        body="This removes the protocol and its notes from this device. It can't be undone, except from a backup."
        confirmLabel="Remove"
        onConfirm={() => {
          if (confirm) store.apply((jj) => deleteProtocol(jj, confirm.id));
          setConfirm(null);
          toast.show('Removed');
        }}
        onCancel={() => setConfirm(null)}
      />
    </Screen>
  );
}

const st = StyleSheet.create({
  today: { gap: 2, padding: space.md, borderRadius: radius.md, backgroundColor: color.sageWash, borderWidth: 1, borderColor: color.sageBorder },
  pastRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 12 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
