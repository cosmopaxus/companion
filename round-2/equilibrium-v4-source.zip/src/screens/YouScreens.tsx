import React, { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import type { AgeBracket, DirectionId, Experience, GemTx, IntakeAnswer, Journey } from '../domain/types';
import { EVIDENCE_INFO } from '../domain/scales';
import { DIRECTION_IDS } from '../domain/types';
import { computeDirection, DIRECTIONS, explainScore, CHOSEN_WEIGHT } from '../domain/directions';
import { gemBalance, gemsFor } from '../domain/selectors';
import { GEM_REASON_LABEL, GEM_RULES } from '../domain/gems';
import { setActiveSpace, setChosenDirections, updateProfile, saveIntake, clearIntake } from '../domain/ops';
import { SPACE_NAME, SPACE_SCOPE_NOTE, SPACES } from '../domain/spaces';
import { formatDayHeading, formatShortDate, formatTime } from '../domain/time';
import { LESSON_BY_ID } from '../domain/paths';
import { evaluateIntake, EXPERIENCE_OPTIONS } from '../domain/intake';
import { AGE_BRACKETS, ageLabel, isAdult, REFLECTION_MODE_NOTE } from '../domain/age';
import { IntakeQuestions } from '../ui/IntakeQuestions';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { useAccount } from '../sync/account';
import { color, radius, space, type } from '../theme/tokens';
import { Screen, Sheet } from '../ui/layout';
import { Button, Card, Chip, Eyebrow, focusRing, Notice, spaceKey, Tag } from '../ui/primitives';
import { Field } from '../ui/controls';
import { Gem, Icon } from '../ui/Icon';

// ——— Profile ———

export function ProfileScreen() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const p = store.journey.profile!;
  const [name, setName] = useState(p.name);
  const [handle, setHandle] = useState(p.handle ?? '');
  const [age, setAge] = useState<AgeBracket>(p.ageBracket);
  const [confirm, setConfirm] = useState<null | 'toAdult' | 'toMinor'>(null);
  const [error, setError] = useState<string | null>(null);
  const save = () => {
    const r = store.apply((j) => updateProfile(j, { name, handle, ageBracket: age }));
    if (!r.ok) return setError(r.error);
    toast.show('Profile saved');
    nav.pop();
  };
  const onSave = () => {
    const wasMinor = p.ageBracket === 'under18';
    const isMinor = age === 'under18';
    if (wasMinor && !isMinor) return setConfirm('toAdult');
    if (!wasMinor && isMinor) return setConfirm('toMinor');
    save();
  };
  return (
    <Screen back title="Profile" subtitle="Only used on this device for now." testID="screen-profile">
      <Card style={{ gap: space.lg }}>
        <Field label="Name" value={name} onChangeText={setName} maxLength={60} />
        <Field label="Handle" optional value={handle} onChangeText={setHandle} autoCapitalize="none" autoCorrect={false} maxLength={31} placeholder="@yourname" helper="Reserved for possible community features. Nobody can see it now." />
        <View style={{ gap: space.sm }}>
          <Text style={type.label}>Age range</Text>
          {age === 'adult' ? <Text style={type.small}>You confirmed you're 18 or older. Choose a range if you'd like.</Text> : null}
          <View role="radiogroup" aria-label="Age range" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {AGE_BRACKETS.map((b) => (
              <Chip key={b.id} radio label={b.label} selected={age === b.id} onPress={() => setAge(b.id)} testID={`profile-age-${b.id}`} />
            ))}
          </View>
          {age === 'under18' ? <Text style={type.small}>{REFLECTION_MODE_NOTE}</Text> : null}
        </View>
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label="Save" disabled={!name.trim()} onPress={onSave} testID="profile-save" />
      </Card>
      <ConfirmSheet
        visible={confirm === 'toAdult'}
        title="Confirm you're 18 or older"
        body={`Changing your age range to ${ageLabel(age)} shows Equilibrium's microdosing tools, including Safety & Path and the Be Well Space. Only continue if you're 18 or older.`}
        confirmLabel="I'm 18 or older"
        danger={false}
        onConfirm={() => {
          setConfirm(null);
          save();
        }}
        onCancel={() => setConfirm(null)}
      />
      <ConfirmSheet
        visible={confirm === 'toMinor'}
        title="Switch to under 18?"
        body="Microdosing tools, Safety & Path and the Be Well Space will be hidden, and Equilibrium will stay in your Personal Space. Nothing is deleted."
        confirmLabel="Switch"
        danger={false}
        onConfirm={() => {
          setConfirm(null);
          save();
        }}
        onCancel={() => setConfirm(null)}
      />
    </Screen>
  );
}

// ——— Space switcher ———

export function SpaceSheet() {
  const nav = useNav();
  const store = useStore();
  const toast = useToast();
  const open = nav.sheet?.name === 'space';
  const cur = store.journey.activeSpaceId;
  return (
    <Sheet visible={open} onClose={nav.closeSheet} title="Choose a Space" testID="space-sheet">
      <View role="radiogroup" aria-label="Space" style={{ gap: space.md }}>
        {SPACES.filter((sp) => sp.id === 'personal' || isAdult(store.journey)).map((sp) => {
          const sel = cur === sp.id;
          return (
            <Pressable
              key={sp.id}
              role="radio"
              aria-checked={sel}
              aria-label={`${sp.name}. ${sp.blurb}. ${gemBalance(store.journey, sp.id)} gems.`}
              onPress={() => {
                store.apply((j) => setActiveSpace(j, sp.id));
                nav.closeSheet();
                if (!sel) toast.show(`Now in ${sp.name}`);
              }}
              {...spaceKey(() => {
                store.apply((j) => setActiveSpace(j, sp.id));
                nav.closeSheet();
              })}
              style={(s: any) => [st.spaceOpt, sel && st.spaceOptSel, focusRing(s)]}
              testID={`space-${sp.id}`}
            >
              <View style={[st.radio, sel && { borderColor: color.sage }]}>{sel ? <View style={st.radioDot} /> : null}</View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={type.heading}>{sp.name}</Text>
                <Text style={type.small}>{sp.blurb}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <Gem size={15} />
                <Text style={type.label}>{gemBalance(store.journey, sp.id)}</Text>
              </View>
            </Pressable>
          );
        })}
      </View>
      <Notice>{SPACE_SCOPE_NOTE}</Notice>
    </Sheet>
  );
}

// ——— Directions ———

export function DirectionsScreen() {
  const store = useStore();
  const nav = useNav();
  const { journey } = store;
  const result = computeDirection(journey);
  const chosen = journey.profile?.chosenDirections ?? [];
  const [open, setOpen] = useState<DirectionId | null>(result.current);
  const [limitNote, setLimitNote] = useState<string | null>(null);
  const toggle = (d: DirectionId) => {
    if (!chosen.includes(d) && chosen.length >= 2) {
      setLimitNote(`You can choose up to two. Remove ${DIRECTIONS[chosen[0]].name} or ${DIRECTIONS[chosen[1]].name} first.`);
      return;
    }
    setLimitNote(null);
    const next = chosen.includes(d) ? chosen.filter((x) => x !== d) : [...chosen, d];
    store.apply((j) => setChosenDirections(j, next));
  };
  const max = Math.max(1, ...result.scores.map((s) => s.total));
  return (
    <Screen back title="Directions" subtitle="A direction is a practice orientation — not a diagnosis, and not a fixed identity." testID="screen-directions">
      <Card style={{ gap: space.md }} testID="direction-explain">
        <Eyebrow>How your current direction is worked out</Eyebrow>
        <Text style={type.body}>
          {result.current ? (
            <>
              Right now your practice points to <Text style={{ fontWeight: '700' }}>{DIRECTIONS[result.current].name}</Text>.
            </>
          ) : (
            'Nothing points anywhere yet.'
          )}
        </Text>
        <Text style={type.small}>
          Simple, visible rules — never a guess from your journal. Each starting direction you choose adds {CHOSEN_WEIGHT}. Each Journey area tagged with a direction adds 1, plus 1 more if its impact is 4 or 5. Ties go to the direction you chose first.
        </Text>
        <View style={{ gap: space.sm }}>
          {result.scores.map((s) => (
            <View key={s.id} style={{ gap: 4 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.label}>
                  {DIRECTIONS[s.id].name} {result.current === s.id ? '· current' : ''}
                </Text>
                <Text style={type.label}>{s.total}</Text>
              </View>
              <View style={st.barTrack}>
                <View style={[st.bar, { width: `${(s.total / max) * 100}%`, backgroundColor: result.current === s.id ? color.sage : color.controlBorder }]} />
              </View>
              {explainScore(s).length ? <Text style={type.small}>{explainScore(s).join(' · ')}</Text> : null}
            </View>
          ))}
        </View>
      </Card>

      <View style={{ gap: space.sm }}>
        <Eyebrow heading>Starting directions · choose up to two</Eyebrow>
        {limitNote ? <Notice>{limitNote}</Notice> : null}
        {DIRECTION_IDS.map((d) => {
          const info = DIRECTIONS[d];
          const sel = chosen.includes(d);
          const expanded = open === d;
          return (
            <Card key={d} style={[{ gap: space.md }, sel && { borderColor: color.sage, borderWidth: 2 }]} testID={`direction-${d}`}>
              <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
                <View style={{ flex: 1, gap: 4 }}>
                  <Text style={type.title}>
                    {info.name} <Text style={[type.heading, { color: color.gold }]}>· {info.verb}</Text>
                  </Text>
                  <Text style={type.bodySoft}>{info.purpose}</Text>
                </View>
              </View>
              <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
                <Chip label={sel ? 'Chosen' : 'Choose'} selected={sel} onPress={() => toggle(d)} accessibilityLabel={`${sel ? 'Remove' : 'Choose'} ${info.name} as a starting direction`} />
                <Button label={expanded ? 'Hide practices' : 'Practice ideas'} kind="quiet" small onPress={() => setOpen(expanded ? null : d)} />
              </View>
              {expanded ? (
                <View style={{ gap: space.sm }}>
                  {info.practices.map((pr) => (
                    <View key={pr} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
                      <Icon name="leaf" size={16} color={color.sage} />
                      <Text style={[type.small, { color: color.ink, flex: 1 }]}>{pr}</Text>
                    </View>
                  ))}
                  <Button label={`Add a Journey area in ${info.name}`} kind="secondary" small icon="plus" onPress={() => nav.openSheet({ name: 'areaEditor', presetDirection: d })} />
                  {isAdult(journey) ? (
                  <View style={st.template}>
                    <Text style={[type.small, { color: color.ink }]}>
                      <Text style={{ fontWeight: '700' }}>Optional əvōke support: </Text>
                      the {info.template} template pairs with this direction. Equilibrium works fully without any offering.
                      {info.templateNote ? ` ${info.templateNote}` : ''}
                    </Text>
                    <Tag label="Template not available in this alpha" tone="gold" />
                  </View>
                  ) : null}
                </View>
              ) : null}
            </Card>
          );
        })}
      </View>
    </Screen>
  );
}

// ——— Gems ———

export function GemsScreen() {
  const { journey } = useStore();
  const sp = journey.activeSpaceId;
  const [scope, setScope] = useState<'space' | 'all'>('space');
  const list = gemsFor(journey, scope === 'all' ? 'all' : sp);
  return (
    <Screen back testID="screen-gems">
      <View style={{ alignItems: 'center', gap: space.sm, paddingVertical: space.md }}>
        <Gem size={44} />
        <Text role="heading" aria-level={1} style={[type.display, { fontSize: 44, lineHeight: 50 }]} testID="gem-balance">
          {gemBalance(journey, sp)}
        </Text>
        <Text style={type.bodySoft}>
          gem{gemBalance(journey, sp) === 1 ? '' : 's'} in {SPACE_NAME[sp]}
        </Text>
        <View style={{ flexDirection: 'row', gap: space.sm }}>
          {SPACES.map((s) => (
            <Tag key={s.id} label={`${s.name} ${gemBalance(journey, s.id)}`} tone={s.id === sp ? 'gold' : 'neutral'} />
          ))}
        </View>
      </View>
      <Card style={{ gap: space.md }}>
        <Text style={type.heading}>What gems are</Text>
        <Text style={type.bodySoft}>Gems recognize participation — showing up, reflecting and learning. They have no cash value, and can't be bought, spent or traded.</Text>
        <View style={{ gap: 0 }}>
          {GEM_RULES.map((r, i) => (
            <View key={r.reason} style={[st.ruleRow, i < GEM_RULES.length - 1 && st.rowBorder]}>
              <View style={{ flex: 1 }}>
                <Text style={type.label}>{r.label}</Text>
                {r.note ? <Text style={type.small}>{r.note}</Text> : null}
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <Gem size={14} />
                <Text style={type.label}>+{r.amount}</Text>
              </View>
            </View>
          ))}
        </View>
        <Text style={type.small}>Never rewarded: feeling better, spending money, using any substance, or sharing anything. Gems stay if you later delete an entry — they recognize that you showed up. The first-steps gift always lands in Personal, because it's about learning the app rather than any Space's practice.</Text>
      </Card>
      <View style={{ gap: space.sm }} testID="gem-ledger">
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Eyebrow heading>Ledger</Eyebrow>
          <View style={{ flexDirection: 'row', gap: space.sm }}>
            <Chip radio label={SPACE_NAME[sp]} selected={scope === 'space'} onPress={() => setScope('space')} />
            <Chip radio label="All Spaces" selected={scope === 'all'} onPress={() => setScope('all')} />
          </View>
        </View>
        {list.length === 0 ? (
          <Text style={type.bodySoft}>No gems here yet. A check-in is a good first one.</Text>
        ) : (
          <Card padded={false}>
            {list.map((g, i) => (
              <View key={g.id} style={[st.ruleRow, { paddingHorizontal: space.lg }, i < list.length - 1 && st.rowBorder]} testID="gem-tx">
                <View style={{ flex: 1 }}>
                  <Text style={type.label}>{GEM_REASON_LABEL[g.reason]}</Text>
                  <Text style={[type.small, { color: color.ink }]} numberOfLines={1}>
                    {gemSource(journey, g)}
                  </Text>
                  <Text style={type.small}>
                    {formatDayHeading(g.createdAt)} · {formatTime(g.createdAt)} · {SPACE_NAME[g.spaceId]}
                  </Text>
                </View>
                <Text style={[type.label, { color: color.gold }]}>+{g.amount}</Text>
              </View>
            ))}
          </Card>
        )}
      </View>
    </Screen>
  );
}

/** What a gem was for, looked up from its source record, so the ledger explains itself. */
function gemSource(j: Journey, g: GemTx): string {
  switch (g.reason) {
    case 'checkin': {
      const c = j.checkins.find((x) => x.id === g.sourceId);
      return !c || c.deletedAt ? 'Check-in (since removed)' : `Mood ${c.mood} · Energy ${c.energy} · Connection ${c.connection}`;
    }
    case 'journal': {
      const e = j.journal.find((x) => x.id === g.sourceId);
      return !e || e.deletedAt ? 'Entry (since deleted)' : `“${e.text.slice(0, 60)}${e.text.length > 60 ? '…' : ''}”`;
    }
    case 'evidence': {
      const e = j.evidence.find((x) => x.id === g.sourceId);
      const a = e ? j.areas.find((x) => x.id === e.areaId) : undefined;
      return !e || e.deletedAt ? 'Evidence (since removed)' : `${EVIDENCE_INFO[e.kind].label} · ${a?.name ?? 'an area'}`;
    }
    case 'harmony': {
      const h = j.harmony.find((x) => x.id === g.sourceId);
      return !h || h.deletedAt ? 'Reading (since removed)' : 'Four-element reflection';
    }
    case 'practice': {
      const p = (j.practiceLogs ?? []).find((x) => x.id === g.sourceId);
      const l = p ? LESSON_BY_ID[p.lessonId] : undefined;
      return !p || p.deletedAt || !l ? 'Practice (since removed)' : `${l.title} · ${formatShortDate(p.day + 'T12:00:00')}`;
    }
    case 'goal': {
      const goal = (j.goals ?? []).find((x) => x.id === g.sourceId);
      return !goal || goal.deletedAt ? 'Goal (since removed)' : goal.title;
    }
    case 'guide-complete':
      return 'All five first-steps lessons';
  }
}

// ——— Safety & Path (placeholder, adults only) ———

export function IntakeScreen() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const intake = store.journey.intake;
  const [answers, setAnswers] = useState<Partial<Record<string, IntakeAnswer>>>(intake.answers);
  const [experience, setExperience] = useState<Experience | undefined>(intake.experience);
  const saved = evaluateIntake(intake);
  const [editing, setEditing] = useState(!intake.completedAt || saved.needsReview);
  const result = evaluateIntake({ ...intake, answers });

  if (!isAdult(store.journey)) {
    return (
      <Screen back title="Safety & Path" testID="screen-intake">
        <Notice icon="heart">{REFLECTION_MODE_NOTE}</Notice>
      </Screen>
    );
  }

  return (
    <Screen back title="Safety & Path" subtitle="Optional. For adults considering microdosing or another psychedelic context." testID="screen-intake">
      <Notice tone="preview" title="Draft · pending specialist review">
        These questions are a transparent placeholder, not validated screening. They can't give medical clearance or permission, and Equilibrium never chooses a dose for you. Nothing here changes your access to check-ins, Journey, Journal or Compass.
      </Notice>

      {editing ? (
        <View style={{ gap: space.md }}>
          {saved.needsReview ? <Notice testID="intake-review">A few questions are new or reworded since you last answered. Your earlier answers are kept where they still apply.</Notice> : null}
          <IntakeQuestions answers={answers} experience={experience} onAnswers={setAnswers} onExperience={setExperience} />
          {answers.crisis_now === 'yes' ? <Button label="See support options" kind="urgent" small onPress={() => nav.push({ name: 'support' })} /> : null}
          <Button
            label="Save my answers"
            full
            disabled={result.answered === 0 && !experience}
            onPress={() => {
              store.apply((j) => saveIntake(j, answers, true, undefined, experience));
              setEditing(false);
              toast.show('Saved on this device');
            }}
            testID="intake-save"
          />
          <Text style={[type.small, { textAlign: 'center' }]}>Answers stay on this device and in your own backups. They are never used for analytics.</Text>
        </View>
      ) : (
        <Card style={{ gap: space.md }} testID="intake-result">
          {result.supportNow ? (
            <View style={{ gap: space.sm, padding: space.lg, borderRadius: 16, backgroundColor: color.cautionWash, borderWidth: 1, borderColor: color.cautionBorder }} testID="intake-support">
              <Text style={[type.heading, { color: color.caution }]}>Support first</Text>
              <Text style={type.body}>You said you might be in crisis or in danger right now. That matters more than anything else on this page. Please reach out to someone now — in the US you can call or text 988, or call 911 in an emergency.</Text>
              <Button label="See support options" kind="urgent" small onPress={() => nav.push({ name: 'support' })} />
            </View>
          ) : null}
          {result.majorCount > 0 ? (
            <>
              <Text style={type.title}>Please talk with a clinician first</Text>
              <Text style={type.bodySoft}>
                You noted {result.majorCount} major caution{result.majorCount === 1 ? '' : 's'} in this screening model
                {result.cautionCount ? `, and ${result.cautionCount} other factor${result.cautionCount === 1 ? '' : 's'} worth discussing` : ''}. Before any microdosing or other psychedelic use, talk it through with a qualified clinician. This isn't a diagnosis or a decision about you.
              </Text>
            </>
          ) : result.cautionCount > 0 ? (
            <>
              <Text style={type.title}>Worth a conversation first</Text>
              <Text style={type.bodySoft}>
                You noted {result.cautionCount} factor{result.cautionCount === 1 ? '' : 's'} worth discussing with a qualified clinician before exploring any psychedelic context. This isn't a diagnosis or a decision about you.
              </Text>
            </>
          ) : (
            <>
              <Text style={type.title}>{result.supportNow ? 'No health factors noted' : 'Nothing flagged — with limits'}</Text>
              <Text style={type.bodySoft}>You didn't note any of the factors this short list asks about. The list is incomplete, and this is not medical clearance or permission.</Text>
            </>
          )}
          <Text style={type.small}>
            {experience && experience !== 'skip' ? `Microdosing before: ${EXPERIENCE_OPTIONS.find((o) => o.id === experience)!.label.toLowerCase()}. ` : ''}
            If you do choose to microdose, start low and go slow. Everything else in Equilibrium stays fully available either way.
          </Text>
          <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
            {!result.supportNow ? <Button label="Your protocol" small icon="calendar" onPress={() => nav.push({ name: 'protocol' })} testID="intake-to-protocol" /> : null}
            <Button label="Review answers" small kind="secondary" onPress={() => setEditing(true)} testID="intake-edit" />
            <Button
              label="Clear answers"
              small
              kind="quiet"
              onPress={() => {
                store.apply((j) => clearIntake(j));
                setAnswers({});
                setExperience(undefined);
                setEditing(true);
                toast.show('Answers cleared');
              }}
            />
          </View>
        </Card>
      )}
    </Screen>
  );
}

// ——— Support ———

export function SupportScreen() {
  const store = useStore();
  const adult = isAdult(store.journey);
  const open = (url: string) => Linking.openURL(url).catch(() => {});
  return (
    <Screen back title="Support" subtitle="Equilibrium is a reflection tool, not a crisis or medical service." testID="screen-support">
      <Card tone="caution" style={{ gap: space.sm }}>
        <Text style={[type.heading, { color: color.caution }]}>In immediate danger?</Text>
        <Text style={type.body}>Call 911 in the US, or your local emergency number.</Text>
        <Button label="Call 911" kind="urgent" small onPress={() => open('tel:911')} />
      </Card>
      <Card style={{ gap: space.sm }}>
        <Text style={type.heading}>988 Suicide & Crisis Lifeline (US)</Text>
        <Text style={type.bodySoft}>Call or text 988, or chat online, any time, for emotional distress or suicidal thoughts.</Text>
        <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
          <Button label="Call 988" small onPress={() => open('tel:988')} />
          <Button label="Text 988" small kind="secondary" onPress={() => open('sms:988')} />
          <Button label="988lifeline.org" small kind="quiet" role="link" onPress={() => open('https://988lifeline.org')} />
        </View>
      </Card>
      {adult ? (
      <Card style={{ gap: space.sm }} testID="support-fireside">
        <Text style={type.heading}>Fireside Project</Text>
        <Text style={type.bodySoft}>Free, confidential peer support during or after a psychedelic experience. Call or text 62-FIRESIDE (623-473-7433); check their site for current hours.</Text>
        <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
          <Button label="Call" small kind="secondary" onPress={() => open('tel:6234737433')} />
          <Button label="Text" small kind="secondary" onPress={() => open('sms:6234737433')} />
          <Button label="firesideproject.org" small kind="quiet" role="link" onPress={() => open('https://firesideproject.org')} />
        </View>
      </Card>
      ) : null}
      <Card style={{ gap: space.sm }}>
        <Text style={type.heading}>Outside the US</Text>
        <Text style={type.bodySoft}>Find a free, confidential helpline in your country.</Text>
        <Button label="findahelpline.com" small kind="quiet" role="link" onPress={() => open('https://findahelpline.com')} />
      </Card>
      <Text style={type.small}>Links open outside Equilibrium. Some previews and browsers block phone links; the numbers are written out above.</Text>
    </Screen>
  );
}

// ——— About this alpha ———

const STATUS: { area: string; state: 'Working' | 'Preview' | 'Not built' | 'Blocked'; note: string }[] = [
  { area: 'New in v3 · Today’s look', state: 'Working', note: 'Cinzel headings, Nunito text, indigo buttons and glass cards. Home, Compass, Journal and lessons open on a window into your hall that melts into frosted glass. Painted art comes next; your hall’s colors stand in for now.' },
  { area: 'New in v3 · New names', state: 'Working', note: 'Companion is now Equilibrium. The elemental reading (once Harmony, then Equilibrium) is now Compass. Your entries and readings are unchanged.' },
  { area: 'New in v3 · The academy look (phase 1)', state: 'Working', note: 'Home and the check-in sit in your hall: Fire, Air, Water or Earth, chosen by your lesson or by you (You → Preferences). Solid buttons press like keys.' },
  { area: 'New in v3 · The academy grounds (phase 2)', state: 'Working', note: 'The path map is the academy: the Courtyard, the Library, the Tower and the Sanctum, lit when open.' },
  { area: 'New in v3 · Celebrations and motion (phase 3)', state: 'Working', note: 'Lessons mastered and seals earned are celebrated; halls breathe gently. All of it stops under reduced motion.' },
  { area: 'New in v2 · Paths of mastery', state: 'Working', note: 'Foundation and Acolyte lessons, offered when you’re ready. Initiate and Adept are outlines; lesson text is a draft under review.' },
  { area: 'New in v2 · Path map, character sheet, inventory', state: 'Working', note: 'Counts only grow. Nothing reads how you felt.' },
  { area: 'New in v2 · Goals as quests', state: 'Working', note: 'Reach them, or let them go at no cost.' },
  { area: 'New in v2 · Weekly look-back', state: 'Working', note: 'Your own words; no scores.' },
  { area: 'New in v2 · Journal search and Markdown export', state: 'Working', note: 'Search every word; export what you see.' },
  { area: 'New in v2 · Night theme', state: 'Working', note: 'Day, Night or Match device on the web; phones follow their own setting.' },
  { area: 'Home, Journey, Journal, Spaces', state: 'Working', note: 'Saved on this device.' },
  { area: 'Compass', state: 'Working', note: 'Readings, what they mean, practices and your trend.' },
  { area: 'First steps walkthrough', state: 'Working', note: 'Practice only; one-time gift.' },
  { area: 'Gems and ledger', state: 'Working', note: 'Recognition only; no value.' },
  { area: 'Export and restore', state: 'Working', note: 'Validated before anything changes.' },
  { area: 'Accounts & cross-device sync', state: 'Blocked', note: 'Code and tests exist; no backend connected in this build.' },
  { area: 'Connect (Pulse, gatherings)', state: 'Preview', note: 'Described, not live.' },
  { area: 'Age ranges and under-18 reflection mode', state: 'Working', note: 'Self-reported; microdosing tools hidden under 18.' },
  { area: 'Safety & Path intake', state: 'Preview', note: 'Adults only. Placeholder pending specialist review.' },
  { area: 'əvōke support templates', state: 'Not built', note: 'Mentioned in Directions only.' },
  { area: 'Protocols', state: 'Working', note: 'Adults only. Common schedules or your own; notes stay on this device.' },
  { area: 'Rhythm and day notes on Home', state: 'Working', note: 'Adults only. Taken, skipped or integration day; no gems.' },
  { area: 'Update notice', state: 'Working', note: 'The installed app offers a refresh when a new version is published.' },
  { area: 'Reminders and notifications', state: 'Not built', note: 'Next in this alpha.' },
  { area: 'Research participation', state: 'Not built', note: 'Would need its own consent.' },
];

export function AboutScreen() {
  const account = useAccount();
  const rows = STATUS.map((r) =>
    r.area.startsWith('Accounts') && account.configured
      ? { ...r, state: 'Preview' as const, note: account.backend === 'demo' ? 'In-memory demo backend for testing — nothing leaves this page.' : 'Backend configured; not yet verified end to end on two devices.' }
      : r,
  );
  return (
    <Screen back title="About this version" subtitle="Equilibrium v3 · Graphics & Interface (Claude build). What's new, what works, what's a preview, and what isn't built yet." testID="screen-about">
      <Card padded={false}>
        {rows.map((s, i) => (
          <View key={s.area} style={[st.ruleRow, { paddingHorizontal: space.lg }, i < rows.length - 1 && st.rowBorder]}>
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={type.label}>{s.area}</Text>
              {s.note ? <Text style={type.small}>{s.note}</Text> : null}
            </View>
            <Tag label={s.state} tone={s.state === 'Working' ? 'sage' : s.state === 'Preview' ? 'gold' : s.state === 'Blocked' ? 'caution' : 'neutral'} />
          </View>
        ))}
      </Card>
      <Text style={type.small}>Equilibrium offers reflection and practice support — not medical advice, diagnosis, treatment, or dosing guidance. Its microdosing tools are for adults 18 and over.</Text>
    </Screen>
  );
}

const st = StyleSheet.create({
  spaceOpt: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.lg, borderRadius: radius.lg, borderWidth: 1.5, borderColor: color.border, backgroundColor: color.paperStrong },
  spaceOptSel: { borderColor: color.sage, borderWidth: 2 },
  radio: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.75, borderColor: color.controlBorder, alignItems: 'center', justifyContent: 'center' },
  radioDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: color.sage },
  barTrack: { height: 8, borderRadius: 4, backgroundColor: color.canvas, overflow: 'hidden' },
  bar: { height: 8, borderRadius: 4 },
  template: { gap: space.sm, padding: space.md, borderRadius: radius.md, backgroundColor: color.canvas, borderWidth: 1, borderColor: color.border },
  ruleRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: 12 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
