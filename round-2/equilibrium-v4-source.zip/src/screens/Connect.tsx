import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useNav } from '../state/nav';
import { color, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, Notice, Tag } from '../ui/primitives';
import { Icon, IconName } from '../ui/Icon';

const PLANNED: { icon: IconName; title: string; body: string }[] = [
  { icon: 'connect', title: 'Pulse — shared presence', body: 'A quiet sense that others are practicing too. No feed, no follower counts, no public scores.' },
  { icon: 'map', title: 'Gatherings in real life', body: 'Circles, events and small groups that point you toward people, not back to the screen.' },
  { icon: 'shield', title: 'Sharing on your terms', body: 'Anything shared will be a separate, explicit choice — never a side effect of writing or switching Spaces.' },
];

export function Connect() {
  const nav = useNav();
  return (
    <Screen title="Connect" subtitle="How might you connect with others? A future home for practicing together." testID="screen-connect">
      <Notice tone="preview" title="Preview — nothing here is live yet">
        Connect doesn't link you to anyone in this alpha. Your check-ins, journal and Journey stay private to you and aren't shared with anyone.
      </Notice>

      <View style={{ gap: space.sm }}>
        <Eyebrow heading>What we're building toward</Eyebrow>
        <Card padded={false}>
          {PLANNED.map((p, i) => (
            <View key={p.title} style={[st.row, i < PLANNED.length - 1 && st.rowBorder]}>
              <View style={st.icon}>
                <Icon name={p.icon} size={20} color={color.gold} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'center', flexWrap: 'wrap' }}>
                  <Text style={type.label}>{p.title}</Text>
                  <Tag label="Planned" tone="gold" />
                </View>
                <Text style={type.small}>{p.body}</Text>
              </View>
            </View>
          ))}
        </Card>
      </View>

      <Card tone="sage" style={{ gap: space.md }} testID="connect-now">
        <Eyebrow heading tone={color.sage}>Available now · personal practice</Eyebrow>
        <Text style={type.title}>Practice connection on your own</Text>
        <Text style={type.bodySoft}>
          This tab is about people. The <Text style={{ fontWeight: '700', color: color.ink }}>Connect direction</Text> is different — a personal practice of embodied connection with yourself, your body and others. You can work on it today:
        </Text>
        <View style={{ gap: space.sm }}>
          <Button label="Add a Journey area in Connect" icon="plus" kind="secondary" small full onPress={() => nav.openSheet({ name: 'areaEditor', presetName: 'Making room for connection', presetDirection: 'connect' })} />
          <Button label="Write about someone you'd like to reach" icon="journal" kind="secondary" small full onPress={() => { nav.requestFocus('journal:Someone I would like to reach'); nav.setTab('journal'); }} />
          <Button label="Read about the four directions" kind="quiet" small iconRight="chevron" onPress={() => nav.push({ name: 'directions' })} />
        </View>
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', gap: space.md, padding: space.lg, alignItems: 'flex-start' },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  icon: { width: 40, height: 40, borderRadius: radius.pill, backgroundColor: color.goldWash, alignItems: 'center', justifyContent: 'center' },
});
