import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import type { EvidenceKind } from '../domain/types';
import { addEvidence, deleteArea, deleteEvidence } from '../domain/ops';
import { areaStats, evidenceFor, isEasyWin, rankedAreas } from '../domain/selectors';
import { DIRECTIONS } from '../domain/directions';
import { DIFFICULTY_ANCHORS, EVIDENCE_INFO, IMPACT_ANCHORS } from '../domain/scales';
import { formatDayHeading, formatTime, localDayKey } from '../domain/time';
import { SPACE_NAME } from '../domain/spaces';
import { GEM_AMOUNTS } from '../domain/gems';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { successFeedback } from '../platform/haptics';
import { color, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, IconButton, Notice, Tag } from '../ui/primitives';
import { Field, Segmented } from '../ui/controls';
import { EVIDENCE_COLOR, EVIDENCE_ICON, Icon } from '../ui/Icon';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { useSaveLabel } from '../state/saveLabel';

export function AreaDetail({ id, compose, focus }: { id: string; compose?: EvidenceKind; focus?: boolean }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const { journey } = store;
  const area = journey.areas.find((a) => a.id === id && !a.deletedAt);
  const draftKey = `evidence:${id}`;
  const [kind, setKind] = useState<EvidenceKind | undefined>(compose);
  const [error, setError] = useState<string | null>(null);
  const [confirmArea, setConfirmArea] = useState(false);
  const [confirmEv, setConfirmEv] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState<EvidenceKind | null>(null);
  const inputRef = useRef<TextInput>(null);
  const text = store.drafts[draftKey] ?? '';
  const label = useSaveLabel();

  useEffect(() => {
    if (compose || focus) setTimeout(() => inputRef.current?.focus(), 250);
  }, [compose, focus]);

  if (!area) {
    return (
      <Screen back title="Area not found">
        <Notice>This area was removed. Its evidence was removed with it.</Notice>
      </Screen>
    );
  }
  const stats = areaStats(journey, id);
  const evidence = evidenceFor(journey, id);
  const rank = rankedAreas(journey).findIndex((a) => a.id === id) + 1;
  const now = new Date();

  const save = () => {
    if (!kind) return setError('Choose win, observation or setback.');
    const r = store.apply((j) => addEvidence(j, { areaId: id, kind, text }));
    if (!r.ok) return setError(r.error);
    setError(null);
    successFeedback();
    store.setDraft(draftKey, undefined);
    setJustSaved(kind);
    toast.show(label.notSaving ? `${EVIDENCE_INFO[kind].label} added — not saved` : `${EVIDENCE_INFO[kind].label} recorded`, { gems: GEM_AMOUNTS.evidence, tone: label.notSaving ? 'caution' : 'default' });
  };

  // Group evidence by local day.
  const groups: { key: string; heading: string; items: typeof evidence }[] = [];
  for (const e of evidence) {
    const key = localDayKey(e.createdAt);
    let g = groups.find((x) => x.key === key);
    if (!g) groups.push((g = { key, heading: formatDayHeading(e.createdAt, now), items: [] }));
    g.items.push(e);
  }

  return (
    <Screen back backLabel="Journey" testID="screen-area">
      <View style={{ gap: space.sm }}>
        <Eyebrow>Journey · priority {rank}</Eyebrow>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.sm }}>
          <Text role="heading" aria-level={1} style={[type.display, { flex: 1 }]}>
            {area.name}
          </Text>
          <IconButton icon="edit" label="Edit area" onPress={() => nav.openSheet({ name: 'areaEditor', areaId: id })} tone={color.sage} />
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
          {isEasyWin(area) ? <Tag label="Easy win" tone="sage" icon="leaf" /> : null}
          {area.direction ? <Tag label={`${DIRECTIONS[area.direction].name} · ${DIRECTIONS[area.direction].verb}`} tone="gold" /> : null}
          <Tag label={`Impact ${area.impact} · ${IMPACT_ANCHORS[area.impact]}`} />
          <Tag label={`Difficulty ${area.difficulty} · ${DIFFICULTY_ANCHORS[area.difficulty]}`} />
        </View>
      </View>

      <View style={st.stats} testID="area-stats">
        {(['win', 'observation', 'setback'] as EvidenceKind[]).map((k) => {
          const n = k === 'win' ? stats.wins : k === 'observation' ? stats.observations : stats.setbacks;
          return (
            <View key={k} style={[st.stat, k === 'win' && { backgroundColor: color.sageWash, borderColor: color.sageBorder }]} aria-label={`${n} ${n === 1 ? EVIDENCE_INFO[k].label.toLowerCase() : EVIDENCE_INFO[k].plural}`}>
              <Icon name={EVIDENCE_ICON[k]} size={20} color={EVIDENCE_COLOR[k]} />
              <Text style={[st.statNum, { color: EVIDENCE_COLOR[k] }]} testID={`stat-${k}`}>
                {n}
              </Text>
              <Text style={type.small}>{n === 1 ? EVIDENCE_INFO[k].label.toLowerCase() : EVIDENCE_INFO[k].plural}</Text>
            </View>
          );
        })}
      </View>

      <Card style={{ gap: space.lg }} testID="evidence-composer">
        <View style={{ gap: 4 }}>
          <Eyebrow>Record evidence</Eyebrow>
          <Text style={type.title}>What happened?</Text>
          <Text style={type.small}>Small wins count, and setbacks are useful information too.</Text>
        </View>
        <Segmented
          label="Kind of evidence"
          value={kind}
          onChange={(v) => {
            setKind(v);
            setJustSaved(null);
          }}
          testID="evidence-kind"
          options={(['win', 'observation', 'setback'] as EvidenceKind[]).map((k) => ({ value: k, label: EVIDENCE_INFO[k].label, icon: EVIDENCE_ICON[k], helper: EVIDENCE_INFO[k].helper, tone: EVIDENCE_COLOR[k] }))}
        />
        <Field
          ref={inputRef}
          label="Describe it"
          value={text}
          onChangeText={(t) => {
            store.setDraft(draftKey, t);
            setJustSaved(null);
          }}
          multiline
          minHeight={80}
          placeholder={kind ? EVIDENCE_INFO[kind].placeholder : 'Be specific and small: what, when, how it went.'}
          maxLength={2000}
          testID="evidence-text"
        />
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label="Save evidence" full onPress={save} disabled={!kind || !text.trim()} testID="evidence-save" />
        {justSaved ? (
          <Notice tone="success" testID="evidence-saved">
            {justSaved === 'win'
              ? `Win recorded. That's ${stats.wins} for this area. +${GEM_AMOUNTS.evidence} gem`
              : justSaved === 'observation'
                ? `Observation recorded — noticing is practice. +${GEM_AMOUNTS.evidence} gem`
                : `Setback recorded. Useful information, not a verdict. +${GEM_AMOUNTS.evidence} gem`}
          </Notice>
        ) : !kind || !text.trim() ? (
          <Text style={[type.small, { textAlign: 'center' }]}>Choose a kind and describe it to save.</Text>
        ) : null}
      </Card>

      <View style={{ gap: space.md }} testID="evidence-history">
        <Eyebrow>Evidence history</Eyebrow>
        {groups.length === 0 ? <Text style={type.bodySoft}>Nothing yet. The first piece of evidence is often the smallest.</Text> : null}
        {groups.map((g) => (
          <View key={g.key} style={{ gap: space.sm }}>
            <Text style={[type.label, { color: color.inkSoft }]}>{g.heading}</Text>
            <Card padded={false}>
              {g.items.map((e, i) => (
                <View key={e.id} style={[st.evRow, i < g.items.length - 1 && st.rowBorder]} testID="evidence-item">
                  <View style={[st.evIcon, { borderColor: EVIDENCE_COLOR[e.kind] }]}>
                    <Icon name={EVIDENCE_ICON[e.kind]} size={18} color={EVIDENCE_COLOR[e.kind]} filled={e.kind === 'win'} />
                  </View>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={[type.small, { color: EVIDENCE_COLOR[e.kind], fontWeight: '700' }]}>
                      {EVIDENCE_INFO[e.kind].label}
                      <Text style={{ color: color.inkSoft, fontWeight: '400' }}>
                        {' '}
                        · {formatTime(e.createdAt)} · {SPACE_NAME[e.spaceId]}
                      </Text>
                    </Text>
                    <Text style={type.body}>{e.text}</Text>
                  </View>
                  <IconButton icon="trash" label={`Remove the ${EVIDENCE_INFO[e.kind].label.toLowerCase()} from ${formatTime(e.createdAt)}: ${e.text.slice(0, 40)}`} onPress={() => setConfirmEv(e.id)} tone={color.inkSoft} size={18} />
                </View>
              ))}
            </Card>
          </View>
        ))}
      </View>

      <Button label="Remove this area" kind="danger" small icon="trash" onPress={() => setConfirmArea(true)} style={{ alignSelf: 'center' }} />

      <ConfirmSheet
        visible={confirmArea}
        title="Remove this area?"
        body={`“${area.name}” and its ${stats.total} piece${stats.total === 1 ? '' : 's'} of evidence will be removed from your journey. Gems already earned stay — they recognize that you showed up.`}
        confirmLabel="Remove area"
        onCancel={() => setConfirmArea(false)}
        onConfirm={() => {
          store.apply((j) => deleteArea(j, id));
          setConfirmArea(false);
          nav.pop();
          toast.show('Area removed');
        }}
      />
      <ConfirmSheet
        visible={!!confirmEv}
        title="Remove this evidence?"
        body="It will be removed from this area's history. Its gem stays."
        confirmLabel="Remove"
        onCancel={() => setConfirmEv(null)}
        onConfirm={() => {
          if (confirmEv) store.apply((j) => deleteEvidence(j, confirmEv));
          setConfirmEv(null);
          toast.show('Evidence removed');
        }}
      />
    </Screen>
  );
}

const st = StyleSheet.create({
  stats: { flexDirection: 'row', gap: space.sm },
  stat: { flex: 1, alignItems: 'center', gap: 2, paddingVertical: space.md, borderRadius: radius.md, borderWidth: 1, borderColor: color.border, backgroundColor: color.paper },
  statNum: { fontSize: 26, fontWeight: '700', lineHeight: 30 },
  evRow: { flexDirection: 'row', gap: space.md, alignItems: 'flex-start', paddingLeft: space.lg, paddingRight: space.sm, paddingVertical: 12 },
  evIcon: { width: 34, height: 34, borderRadius: 17, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong, marginTop: 2 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
