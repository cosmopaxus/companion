import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { ElementId, ElementRating, HarmonySnapshot } from '../domain/types';
import { ELEMENT_IDS } from '../domain/types';
import { addHarmony, deleteHarmony } from '../domain/ops';
import { balance, balances, BAND_LABEL, bandFor, bandSentence, defaultRatings, deltas, ELEMENTS, PRESSURE_ANCHORS, RESOURCE_ANCHORS } from '../domain/harmony';
import { harmonyFor } from '../domain/selectors';
import { formatDayHeading, formatTime } from '../domain/time';
import { SPACE_NAME } from '../domain/spaces';
import { GEM_AMOUNTS } from '../domain/gems';
import { newId } from '../domain/ids';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { successFeedback } from '../platform/haptics';
import { color, elementColor, elementText, elementWash, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, focusRing, Notice } from '../ui/primitives';
import { Field, RatingScale } from '../ui/controls';
import { EquilibriumOrb } from '../ui/EquilibriumOrb';
import { equilibriumOf, spreadWord } from '../domain/equilibrium';
import { BeginCard } from './Equilibrium';
import { ElementGlyph, Icon } from '../ui/Icon';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { useSaveLabel } from '../state/saveLabel';

export function Harmony() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const sp = store.journey.activeSpaceId;
  const history = harmonyFor(store.journey, sp);
  const [ratings, setRatings] = useState<Record<ElementId, ElementRating>>(defaultRatings);
  const [note, setNote] = useState('');
  const [howOpen, setHowOpen] = useState(history.length === 0);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);
  const [confirmUntouched, setConfirmUntouched] = useState(false);
  const values = useMemo(() => balances(ratings), [ratings]);
  const live = useMemo(() => equilibriumOf({ ratings }), [ratings]);
  const label = useSaveLabel();

  const set = (el: ElementId, key: keyof ElementRating, v: ElementRating[keyof ElementRating]) => {
    setTouched(true);
    setRatings((r) => ({ ...r, [el]: { ...r[el], [key]: v } }));
  };

  const trySave = () => (touched ? save() : setConfirmUntouched(true));

  const save = () => {
    setConfirmUntouched(false);
    const id = newId('hrm');
    const r = store.apply((j) => addHarmony(j, ratings, note, new Date(), id));
    if (!r.ok) return setError(r.error);
    successFeedback();
    toast.show(label.done('Compass reading'), { gems: GEM_AMOUNTS.harmony, tone: label.notSaving ? 'caution' : 'default' });
    nav.pop();
    nav.push({ name: 'harmonyReading', id });
  };

  return (
    <Screen back backLabel="Back" testID="screen-harmony">
      <View style={{ gap: 6 }}>
        <Eyebrow>Compass · {SPACE_NAME[sp]}</Eyebrow>
        <Text role="heading" aria-level={1} style={type.display}>
          Take a reading
        </Text>
        <Text style={type.bodySoft}>Pressure and resource across four elements. A short reflection, two minutes, honestly.</Text>
      </View>

      <Pressable role="button" aria-expanded={howOpen} onPress={() => setHowOpen((v) => !v)} style={(s: any) => [st.how, focusRing(s)]}>
        <Icon name="info" size={18} color={color.sage2} />
        <Text style={[type.label, { flex: 1 }]}>How Compass works</Text>
        <Icon name={howOpen ? 'chevronDown' : 'chevron'} size={16} color={color.inkSoft} />
      </Pressable>
      {howOpen ? (
        <Card tone="strong" style={{ gap: space.md, marginTop: -space.md }}>
          <Text style={type.body}>
            <Text style={{ fontWeight: '700' }}>Pressure</Text> is what's asking something of you. <Text style={{ fontWeight: '700' }}>Resource</Text> is what you have to meet it. Rate each from 1 to 5 for four elements.
          </Text>
          <Text style={type.body}>Each element gets a balance from 0 to 100. At 50, pressure and resource are matched. Above 50, you have more to draw on than is being asked; below 50, more is asked than you have.</Text>
          <Text style={type.body}>
            Together they make your equilibrium: the <Text style={{ fontWeight: '700' }}>overall</Text> is the average of the four, and the <Text style={{ fontWeight: '700' }}>spread</Text> is the gap between your highest and lowest. A small spread means the elements move together; a large one means discord, and the lowest element is the place to begin.
          </Text>
          <Text style={type.small}>This is what you report about yourself, a reflective signal — not a measurement of your body or brain, and not a score to improve.</Text>
        </Card>
      ) : null}

      <Card style={{ gap: space.sm, alignItems: 'center' }} testID="harmony-live">
        <EquilibriumOrb values={values} size={260} />
        <Text style={[type.label, { textAlign: 'center' }]} testID="harmony-live-word">
          {live.word} · overall {live.overall} · spread {live.spread}
        </Text>
        <Text style={[type.small, { textAlign: 'center' }]}>The shape updates as you rate. Everything starts at the midpoint — adjust what's true today.</Text>
      </Card>

      {ELEMENT_IDS.map((el) => {
        const info = ELEMENTS[el];
        const b = balance(ratings[el]);
        return (
          <Card key={el} style={[{ gap: space.lg }, { borderLeftWidth: 5, borderLeftColor: elementColor[el] }]} testID={`harmony-${el}`}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
              <View style={[st.glyph, { backgroundColor: elementWash[el] }]}>
                <ElementGlyph element={el} size={22} color={elementText[el]} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={type.heading}>
                  {info.name} <Text style={{ color: elementText[el] }}>· {info.lens}</Text>
                </Text>
                <Text style={type.small}>{info.prompt}</Text>
              </View>
              <View style={[st.balance, { borderColor: elementColor[el] }]} aria-label={`${info.name} balance ${b}, ${BAND_LABEL[bandFor(b)]}`} testID={`harmony-${el}-balance`}>
                <Text style={[st.balanceNum, { color: elementText[el] }]}>{b}</Text>
                <Text style={st.balanceBand}>{BAND_LABEL[bandFor(b)]}</Text>
              </View>
            </View>
            <RatingScale compact label="Pressure" question={info.pressureExamples} anchors={PRESSURE_ANCHORS} value={ratings[el].pressure} onChange={(v) => set(el, 'pressure', v)} accent={elementColor[el]} testID={`harmony-${el}-pressure`} />
            <RatingScale compact label="Resource" question={info.resourceExamples} anchors={RESOURCE_ANCHORS} value={ratings[el].resource} onChange={(v) => set(el, 'resource', v)} accent={elementColor[el]} testID={`harmony-${el}-resource`} />
            <Text style={[type.small, { color: color.ink }]}>{bandSentence(el, b)}</Text>
          </Card>
        );
      })}

      <Card style={{ gap: space.lg }}>
        <Field label="Anything behind these numbers?" optional value={note} onChangeText={setNote} multiline minHeight={80} placeholder="A word or two about what's shaping today." maxLength={2000} />
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <Button label="Save this reading" full onPress={trySave} icon="compass" testID="harmony-save" />
        <Text style={[type.small, { textAlign: 'center' }]}>Saved to {SPACE_NAME[sp]} with the time. +{GEM_AMOUNTS.harmony} gems.</Text>
      </Card>
      <ConfirmSheet
        visible={confirmUntouched}
        danger={false}
        title="Everything is still at the midpoint"
        body="You haven't changed any ratings, so all four elements read 3 for pressure and 3 for resource (even). If that's honestly how today is, save it. Otherwise, go back and adjust what's true."
        confirmLabel="Yes, save it as even"
        onCancel={() => setConfirmUntouched(false)}
        onConfirm={save}
      />

    </Screen>
  );
}

export function HarmonyReading({ id }: { id: string }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const [confirm, setConfirm] = useState(false);
  const snap = store.journey.harmony.find((h) => h.id === id && !h.deletedAt);
  if (!snap) {
    return (
      <Screen back title="Reading not found">
        <Notice>This reading was removed.</Notice>
      </Screen>
    );
  }
  const list = harmonyFor(store.journey, snap.spaceId);
  const idx = list.findIndex((h) => h.id === id);
  const prev: HarmonySnapshot | undefined = list[idx + 1];
  const values = balances(snap.ratings);
  const d = prev ? deltas(prev, snap) : null;
  const ghosts = list.slice(idx + 1, idx + 5).reverse().map((h) => balances(h.ratings));
  const eq = equilibriumOf(snap);

  return (
    <Screen back testID="screen-harmony-reading">
      <View style={{ gap: 6 }}>
        <Eyebrow>
          Compass reading · {SPACE_NAME[snap.spaceId]}
        </Eyebrow>
        <Text role="heading" aria-level={1} style={type.display}>
          {formatDayHeading(snap.createdAt)}, {formatTime(snap.createdAt)}
        </Text>
      </View>
      <Card style={{ gap: space.md }}>
        <EquilibriumOrb values={values} history={ghosts} size={280} testID="reading-orb" />
        {ghosts.length ? <Text style={[type.small, { textAlign: 'center' }]}>Faint outlines: the {ghosts.length} reading{ghosts.length === 1 ? '' : 's'} before this one.</Text> : null}
        <View style={{ gap: 4 }}>
          <Text style={type.title} testID="reading-word">
            {eq.word}
          </Text>
          <Text style={type.bodySoft}>{eq.sentence}</Text>
          <Text style={type.small} testID="reading-figures">
            Overall {eq.overall} · {BAND_LABEL[bandFor(eq.overall)]} · spread {eq.spread}, {spreadWord(eq.spread).toLowerCase()}
          </Text>
        </View>
      </Card>
      <Card padded={false}>
        {ELEMENT_IDS.map((el, i) => {
          const b = values[el];
          const delta = d?.[el];
          return (
            <View key={el} style={[st.readRow, i < 3 && st.rowBorder]} testID={`reading-${el}`}>
              <View style={[st.glyph, { backgroundColor: elementWash[el] }]}>
                <ElementGlyph element={el} size={20} color={elementText[el]} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: space.sm, flexWrap: 'wrap' }}>
                  <Text style={type.label}>
                    {ELEMENTS[el].name} · {ELEMENTS[el].lens}
                  </Text>
                  <Text style={[type.label, { color: elementText[el] }]}>
                    {b} · {BAND_LABEL[bandFor(b)]}
                  </Text>
                  {delta !== undefined && delta !== null ? (
                    <Text style={type.small}>{delta === 0 ? 'no change' : `${delta > 0 ? '+' : ''}${delta} since last`}</Text>
                  ) : null}
                </View>
                <Text style={type.small}>
                  Pressure {snap.ratings[el].pressure} ({PRESSURE_ANCHORS[snap.ratings[el].pressure].toLowerCase()}) · Resource {snap.ratings[el].resource} ({RESOURCE_ANCHORS[snap.ratings[el].resource].toLowerCase()})
                </Text>
                <Text style={[type.small, { color: color.ink }]}>{bandSentence(el, b)}</Text>
              </View>
            </View>
          );
        })}
      </Card>
      {snap.note ? (
        <Card tone="strong" style={{ gap: 4 }}>
          <Eyebrow tone={color.inkSoft}>Your note</Eyebrow>
          <Text style={type.body}>{snap.note}</Text>
        </Card>
      ) : null}
      <BeginCard snap={snap} title={idx === 0 ? 'Where to begin' : 'What this reading suggested'} />
      <Notice>These are self-reported reflective signals — useful for noticing patterns, not a diagnosis or a measurement.</Notice>
      <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap', justifyContent: 'space-between' }}>
        <Button label="Write about this" kind="secondary" small icon="journal" onPress={() => { nav.reset(); nav.requestFocus('journal:After my Compass reading'); nav.setTab('journal'); }} />
        <Button label="Remove reading" kind="danger" small icon="trash" onPress={() => setConfirm(true)} />
      </View>
      <ConfirmSheet
        visible={confirm}
        title="Remove this reading?"
        body="It will be removed from your Compass history. Its gems stay."
        confirmLabel="Remove reading"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          store.apply((j) => deleteHarmony(j, id));
          setConfirm(false);
          nav.pop();
          toast.show('Reading removed');
        }}
      />
    </Screen>
  );
}

const st = StyleSheet.create({
  how: { flexDirection: 'row', alignItems: 'center', gap: space.sm, paddingVertical: 12, paddingHorizontal: space.lg, backgroundColor: color.paper, borderRadius: radius.md, borderWidth: 1, borderColor: color.border, minHeight: 48 },
  glyph: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  balance: { alignItems: 'center', minWidth: 76, paddingVertical: 6, paddingHorizontal: 8, borderRadius: radius.md, borderWidth: 1.5, backgroundColor: color.paperStrong },
  balanceNum: { fontSize: 24, fontWeight: '700', lineHeight: 28 },
  balanceBand: { fontSize: 12, color: color.inkSoft, fontWeight: '600' },
  histRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.md, paddingRight: space.lg },
  readRow: { flexDirection: 'row', gap: space.md, padding: space.lg, alignItems: 'flex-start' },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
