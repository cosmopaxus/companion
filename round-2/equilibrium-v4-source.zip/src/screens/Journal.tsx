import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { addJournal, deleteJournal, editJournal } from '../domain/ops';
import { journalFor } from '../domain/selectors';
import { JOURNAL_PROMPTS } from '../domain/scales';
import { formatDayHeading, formatTime, localDayKey } from '../domain/time';
import { SPACE_NAME } from '../domain/spaces';
import { GEM_AMOUNTS } from '../domain/gems';
import type { JournalEntry } from '../domain/types';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { successFeedback } from '../platform/haptics';
import { color, radius, serif, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { DateTile } from '../ui/academy/GlassParts';
import { Button, Card, Chip, IconButton, Notice } from '../ui/primitives';
import { Field } from '../ui/controls';
import { Icon } from '../ui/Icon';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { useSaveLabel } from '../state/saveLabel';
import { journalFileName, journalMarkdown, searchJournal } from '../domain/journalExport';
import { exportBackupFile } from '../platform/backupIO';

export function Journal() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const { journey } = store;
  const sp = journey.activeSpaceId;
  const textKey = `journal:${sp}`;
  const promptKey = `journal-prompt:${sp}`;
  const text = store.drafts[textKey] ?? '';
  const prompt = store.drafts[promptKey];
  const [error, setError] = useState<string | null>(null);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const inputRef = useRef<TextInput>(null);
  const scrollRef = useRef<ScrollView>(null);
  const allEntries = journalFor(journey, sp);
  const [query, setQuery] = useState('');
  const entries = searchJournal(allEntries, query);
  const searching = query.trim().length > 0;
  const now = new Date();
  const label = useSaveLabel();
  const [exporting, setExporting] = useState(false);

  const exportMd = async () => {
    setExporting(true);
    const md = journalMarkdown(entries, { name: journey.profile?.name, note: searching ? `Entries matching “${query.trim()}” in ${SPACE_NAME[sp]}.` : `All entries in ${SPACE_NAME[sp]}.` });
    const r = await exportBackupFile(md, journalFileName(), 'text/markdown');
    setExporting(false);
    if (r.ok) toast.show(r.method === 'download' ? 'Journal downloaded as Markdown' : 'Journal ready to save');
    else toast.show(r.error, { tone: 'caution' });
  };

  useEffect(() => {
    if (nav.focusTarget?.startsWith('journal')) {
      // "journal:<prompt>" — the prompt itself may contain colons.
      const at = nav.focusTarget.indexOf(':');
      const p = at >= 0 ? nav.focusTarget.slice(at + 1) : undefined;
      if (p) store.setDraft(promptKey, p);
      nav.requestFocus(null);
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [nav.focusTarget]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = () => {
    const r = store.apply((j) => addJournal(j, text, prompt));
    if (!r.ok) return setError(r.error);
    setError(null);
    successFeedback();
    store.setDraft(textKey, undefined);
    store.setDraft(promptKey, undefined);
    setSavedAt(new Date().toISOString());
    toast.show(label.done('Journal entry'), { gems: GEM_AMOUNTS.journal, tone: label.notSaving ? 'caution' : 'default' });
  };

  const groups: { key: string; heading: string; items: JournalEntry[] }[] = [];
  for (const e of entries) {
    const key = localDayKey(e.createdAt);
    let g = groups.find((x) => x.key === key);
    if (!g) groups.push((g = { key, heading: formatDayHeading(e.createdAt, now), items: [] }));
    g.items.push(e);
  }

  return (
    <Screen scrollRef={scrollRef} glass hall="earth" eyebrow={`Grimoire · ${SPACE_NAME[sp]}`} title="Today’s page" subtitle="What do you want to notice or understand?" testID="screen-journal">
      <Card style={{ gap: space.lg }} testID="journal-composer">
        <View style={{ gap: space.sm }}>
          <Text style={type.small}>A prompt, if it helps (swipe for more):</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -space.xl }} contentContainerStyle={{ gap: space.sm, paddingHorizontal: space.xl }} testID="journal-prompts">
            {JOURNAL_PROMPTS.map((p) => (
              <Chip key={p} label={p} selected={prompt === p} onPress={() => store.setDraft(promptKey, prompt === p ? undefined : p)} />
            ))}
          </ScrollView>
        </View>
        {prompt ? <Text style={st.prompt}>{prompt}</Text> : null}
        <Field
          ref={inputRef}
          aria-label={prompt ? `Journal entry. Prompt: ${prompt}` : 'Journal entry'}
          value={text}
          onChangeText={(t) => {
            store.setDraft(textKey, t);
            if (savedAt) setSavedAt(null);
            if (error) setError(null);
          }}
          multiline
          minHeight={140}
          placeholder="Write freely. A line is enough."
          maxLength={20000}
          testID="journal-input"
        />
        {error ? <Notice tone="caution">{error}</Notice> : null}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, flexWrap: 'wrap' }}>
          <Button label="Save entry" onPress={save} disabled={!text.trim()} gems={GEM_AMOUNTS.journal} testID="journal-save" />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, minWidth: 180 }}>
            <Icon name="lock" size={16} color={color.inkSoft} />
            <Text style={[type.small, label.notSaving && { color: color.caution }]}>Private · {label.where} · {SPACE_NAME[sp]}</Text>
          </View>
        </View>
        {text && !savedAt && !label.notSaving ? <Text style={type.small}>Your draft is kept on this device until you save it.</Text> : null}
        {savedAt ? <Notice tone={label.notSaving ? 'caution' : 'success'} testID="journal-saved">{`${label.notSaving ? 'Added' : 'Saved'} at ${formatTime(savedAt)} · +${GEM_AMOUNTS.journal} gem${label.notSaving ? ' · not saved on this browser' : ''}`}</Notice> : null}
      </Card>

      {allEntries.length ? (
        <View style={{ gap: space.sm }} testID="journal-tools">
          <View style={st.searchRow}>
            <Icon name="search" size={20} color={color.inkSoft} />
            <View style={{ flex: 1 }}>
              <Field aria-label="Search your journal" value={query} onChangeText={setQuery} placeholder="Search your journal" autoCorrect={false} autoCapitalize="none" testID="journal-search" />
            </View>
            {searching ? <IconButton icon="close" label="Clear search" onPress={() => setQuery('')} tone={color.inkSoft} size={18} testID="journal-search-clear" /> : null}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, flexWrap: 'wrap' }}>
            <Text style={[type.small, { flex: 1, minWidth: 160 }]} testID="journal-count">
              {searching ? `${entries.length} of ${allEntries.length} entr${allEntries.length === 1 ? 'y' : 'ies'} match` : `${allEntries.length} entr${allEntries.length === 1 ? 'y' : 'ies'} in ${SPACE_NAME[sp]}`}
            </Text>
            <Button label={searching ? (entries.length === 1 ? 'Export this entry' : `Export these ${entries.length}`) : 'Export as Markdown'} kind="quiet" small icon="download" busy={exporting} disabled={!entries.length} onPress={() => void exportMd()} testID="journal-export" />
          </View>
        </View>
      ) : null}

      <View style={{ gap: space.lg }} testID="journal-stream">
        {searching && entries.length === 0 ? (
          <Text style={[type.bodySoft, { textAlign: 'center' }]} testID="journal-no-match">
            No entries match “{query.trim()}”.
          </Text>
        ) : entries.length === 0 ? (
          <View style={st.empty}>
            <Icon name="journal" size={28} color={color.sage2} />
            <Text style={type.heading}>Your journal is empty — and private.</Text>
            <Text style={[type.small, { textAlign: 'center' }]}>Entries you save in {SPACE_NAME[sp]} appear here, newest first.</Text>
          </View>
        ) : (
          <>
            <Text role="heading" aria-level={2} style={type.heading}>
              {searching ? 'Matching pages' : 'Earlier pages'}
            </Text>
            {groups.map((g) => (
              <View key={g.key} style={{ gap: space.sm }} aria-label={g.heading}>
                {g.items.map((e) => (
                  <EntryCard key={e.id} entry={e} onDelete={() => setConfirmDel(e.id)} />
                ))}
              </View>
            ))}
          </>
        )}
      </View>

      <ConfirmSheet
        visible={!!confirmDel}
        title="Delete this entry?"
        body="The text will be removed from this device. This can't be undone unless you have a backup. Its gem stays."
        confirmLabel="Delete entry"
        onCancel={() => setConfirmDel(null)}
        onConfirm={() => {
          if (confirmDel) store.apply((j) => deleteJournal(j, confirmDel));
          setConfirmDel(null);
          toast.show('Entry deleted');
        }}
      />
    </Screen>
  );
}

function EntryCard({ entry, onDelete }: { entry: JournalEntry; onDelete: () => void }) {
  const store = useStore();
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(entry.text);
  const [error, setError] = useState<string | null>(null);
  const edited = entry.updatedAt !== entry.createdAt;
  const hall = 'earth' as const; // The Grimoire lives in the Herb Garden.

  return (
    <Card style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }} testID="journal-entry">
      <DateTile iso={entry.createdAt} hall={hall} />
      <View style={{ flex: 1, minWidth: 0, gap: space.sm }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <Text style={[type.small, { flex: 1 }]}>
          {formatTime(entry.createdAt)} · {SPACE_NAME[entry.spaceId]}
          {edited ? ' · edited' : ''}
        </Text>
        {!editing ? (
          <>
            <IconButton icon="edit" label={`Edit the ${formatTime(entry.createdAt)} entry`} onPress={() => { setDraft(entry.text); setEditing(true); }} tone={color.inkSoft} size={18} />
            <IconButton icon="trash" label={`Delete the ${formatTime(entry.createdAt)} entry`} onPress={onDelete} tone={color.inkSoft} size={18} />
          </>
        ) : null}
      </View>
      {entry.prompt ? <Text style={st.prompt}>{entry.prompt}</Text> : null}
      {editing ? (
        <View style={{ gap: space.sm }}>
          <Field aria-label="Edit entry" value={draft} onChangeText={setDraft} multiline minHeight={120} autoFocus error={error ?? undefined} />
          <View style={{ flexDirection: 'row', gap: space.sm }}>
            <Button
              label="Save changes"
              small
              disabled={!draft.trim()}
              onPress={() => {
                const r = store.apply((j) => editJournal(j, entry.id, draft));
                if (!r.ok) return setError(r.error);
                setEditing(false);
                setError(null);
                toast.show('Entry updated');
              }}
            />
            <Button label="Cancel" small kind="quiet" onPress={() => setEditing(false)} />
          </View>
        </View>
      ) : (
        <Text style={st.entryText} selectable>
          {entry.text}
        </Text>
      )}
      </View>
    </Card>
  );
}

const st = StyleSheet.create({
  prompt: { fontFamily: serif, fontStyle: 'italic', fontSize: 17, lineHeight: 24, color: color.sage2 },
  entryText: { ...type.body, fontSize: 16.5, lineHeight: 26 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: space.sm },
  empty: { alignItems: 'center', gap: space.sm, paddingVertical: space.xxl, paddingHorizontal: space.xl, borderRadius: radius.lg, borderWidth: 1, borderStyle: 'dashed', borderColor: color.controlBorder },
});
