import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { areaStats, evidenceFor, isEasyWin, rankedAreas } from '../domain/selectors';
import { DIRECTIONS } from '../domain/directions';
import { AREA_EXAMPLES, DIFFICULTY_ANCHORS, IMPACT_ANCHORS } from '../domain/scales';
import { formatRelative } from '../domain/time';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { color, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Chip, Eyebrow, focusRing, Tag } from '../ui/primitives';
import { Icon } from '../ui/Icon';
import { EvidenceMarks } from '../ui/EvidenceMarks';
import { PillSwitch } from '../ui/controls';
import { PathView } from './path/PathView';
import { GroundsHero, groundsTierFor } from './path/GroundsHero';
import { useArtScreen } from '../state/artChrome';

type JourneyView = 'path' | 'areas';

/** Journey opens on the path; areas and evidence are one tap away. */
export function Journey() {
  const { journey } = useStore();
  const nav = useNav();
  const [view, setView] = useState<JourneyView>('path');
  const areas = rankedAreas(journey);

  // Other screens can ask for a view: "journey:areas" or "journey:path" (adjusted during render,
  // then the request is cleared).
  const requested: JourneyView | null = nav.focusTarget === 'journey:areas' ? 'areas' : nav.focusTarget === 'journey:path' ? 'path' : null;
  if (requested && requested !== view) setView(requested);
  useEffect(() => {
    if (requested) nav.requestFocus(null);
  }, [requested]); // eslint-disable-line react-hooks/exhaustive-deps

  const headerRight =
    view === 'path' ? (
      <Button label="Add goal" small icon="flag" onPress={() => nav.openSheet({ name: 'goal' })} testID="journey-add-goal" />
    ) : areas.length ? (
      <Button label="Add area" small icon="plus" onPress={() => nav.openSheet({ name: 'areaEditor' })} testID="journey-add" />
    ) : undefined;

  const heroTier = view === 'path' ? groundsTierFor(journey) : null;
  useArtScreen(!!heroTier);
  const openGoals = (journey.goals ?? []).filter((g) => !g.deletedAt && g.status === 'open').length;

  return (
    <Screen bleed={heroTier ? <GroundsHero journey={journey} tier={heroTier} openGoals={openGoals} /> : undefined} title="Journey" subtitle={view === 'path' ? 'Your path of practice: lessons, goals, and what you’ve built.' : "What you're practicing, and what has changed."} headerRight={headerRight} testID="screen-journey">
      <PillSwitch
        label="Journey view"
        value={view}
        onChange={setView}
        options={[
          { value: 'path', label: 'Path', icon: 'path' },
          { value: 'areas', label: 'Areas', icon: 'journey' },
        ]}
        testID="journey-view"
      />
      {view === 'path' ? <PathView heroTier={heroTier} /> : <AreasView />}
    </Screen>
  );
}

function AreasView() {
  const { journey } = useStore();
  const nav = useNav();
  const [howOpen, setHowOpen] = useState(false);
  const areas = rankedAreas(journey);
  const now = new Date();

  return (
    <View style={{ gap: space.xl }} testID="journey-areas">
      {areas.length === 0 ? (
        <Card style={{ gap: space.lg }} testID="journey-empty">
          <View style={st.emptyIcon}>
            <Icon name="journey" size={28} color={color.sage} />
          </View>
          <View style={{ gap: space.sm }}>
            <Text style={type.title}>Name one thing you'd like to practice.</Text>
            <Text style={type.bodySoft}>Journey holds a few things that matter to you. Each one collects evidence of what actually happens: wins, observations and setbacks — all of them count.</Text>
          </View>
          <View style={{ gap: space.sm }}>
            <Text style={type.small}>Start from an example, or write your own:</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
              {AREA_EXAMPLES.map((ex) => (
                <Chip key={ex} label={ex} icon="plus" onPress={() => nav.openSheet({ name: 'areaEditor', presetName: ex })} />
              ))}
            </View>
          </View>
          <Button label="Write my own" icon="edit" onPress={() => nav.openSheet({ name: 'areaEditor' })} testID="journey-add-empty" />
        </Card>
      ) : (
        <>
          <Pressable role="button" aria-expanded={howOpen} onPress={() => setHowOpen((v) => !v)} style={(s: any) => [st.how, focusRing(s)]}>
            <Icon name="info" size={18} color={color.sage2} />
            <Text style={[type.small, { flex: 1, color: color.ink }]}>How this order works</Text>
            <Icon name={howOpen ? 'chevronDown' : 'chevron'} size={16} color={color.inkSoft} />
          </Pressable>
          {howOpen ? (
            <Text style={[type.small, { marginTop: -space.md }]}>
              Areas are ordered by impact (highest first), then by difficulty (easiest first). Difficulty 1–2 is marked as an easy win: a good place to build momentum. It's a transparent starting point, not a prescription — change an area's ratings to reorder it.
            </Text>
          ) : null}
          <View style={{ gap: space.md }}>
            {areas.map((a, i) => {
              const stats = areaStats(journey, a.id);
              return (
                <Pressable key={a.id} role="button" aria-label={`Priority ${i + 1}: ${a.name}. Impact ${a.impact} of 5, ${IMPACT_ANCHORS[a.impact]}. Difficulty ${a.difficulty} of 5, ${DIFFICULTY_ANCHORS[a.difficulty]}. ${stats.wins} wins, ${stats.observations} observations, ${stats.setbacks} setbacks. Open`} onPress={() => nav.push({ name: 'area', id: a.id })} style={(s: any) => [{ borderRadius: radius.lg }, focusRing(s)]} testID={`area-card-${i}`}>
                  {({ hovered }: any) => (
                    <Card style={[{ gap: space.md }, hovered && { borderColor: color.controlBorder }]}>
                      <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
                        <View style={st.rank}>
                          <Text style={st.rankText}>{i + 1}</Text>
                        </View>
                        <View style={{ flex: 1, gap: 6 }}>
                          <Text style={type.heading}>{a.name}</Text>
                          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                            <Tag label={`Impact ${a.impact}`} />
                            <Tag label={`Difficulty ${a.difficulty}`} />
                            {isEasyWin(a) ? <Tag label="Easy win" tone="sage" icon="leaf" /> : null}
                            {a.direction ? <Tag label={DIRECTIONS[a.direction].name} tone="gold" /> : null}
                          </View>
                        </View>
                        <Icon name="chevron" size={18} color={color.inkSoft} />
                      </View>
                      <View style={st.statsRow}>
                        <EvidenceMarks evidence={evidenceFor(journey, a.id)} />
                        <Text style={type.small}>
                          <Text style={{ color: color.sage, fontWeight: '700' }}>
                            {stats.wins} win{stats.wins === 1 ? '' : 's'}
                          </Text>
                          {` · ${stats.observations} observation${stats.observations === 1 ? '' : 's'} · ${stats.setbacks} setback${stats.setbacks === 1 ? '' : 's'}`}
                        </Text>
                        {stats.last ? (
                          <Text style={type.small} numberOfLines={1}>
                            Last: “{stats.last.text}” · {formatRelative(stats.last.createdAt, now)}
                          </Text>
                        ) : (
                          <Text style={type.small}>No evidence yet — what's one small thing that happened?</Text>
                        )}
                      </View>
                    </Card>
                  )}
                </Pressable>
              );
            })}
          </View>
          <View style={st.legend} aria-label="Legend: filled circle is a win, ring is an observation, diamond is a setback">
            <EvidenceMarks evidence={[{ id: 'l1', kind: 'win', createdAt: '1', updatedAt: '1', areaId: '', text: '', spaceId: 'personal' }]} />
            <Text style={type.small}>win</Text>
            <EvidenceMarks evidence={[{ id: 'l2', kind: 'observation', createdAt: '1', updatedAt: '1', areaId: '', text: '', spaceId: 'personal' }]} />
            <Text style={type.small}>observation</Text>
            <EvidenceMarks evidence={[{ id: 'l3', kind: 'setback', createdAt: '1', updatedAt: '1', areaId: '', text: '', spaceId: 'personal' }]} />
            <Text style={type.small}>setback</Text>
          </View>
          <Eyebrow style={{ textAlign: 'center' }} tone={color.inkSoft}>
            Journey areas are shared across all your Spaces
          </Eyebrow>
        </>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  emptyIcon: { width: 52, height: 52, borderRadius: 26, backgroundColor: color.sageWash, alignItems: 'center', justifyContent: 'center' },
  how: { flexDirection: 'row', alignItems: 'center', gap: space.sm, paddingVertical: 10, paddingHorizontal: space.md, backgroundColor: color.paper, borderRadius: radius.pill, borderWidth: 1, borderColor: color.border, alignSelf: 'flex-start', minHeight: 44 },
  rank: { width: 34, height: 34, borderRadius: 17, borderWidth: 1.5, borderColor: color.goldDeco, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong },
  rankText: { fontSize: 15, fontWeight: '700', color: color.gold },
  statsRow: { gap: 6, paddingTop: space.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: color.border },
  legend: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center', flexWrap: 'wrap' },
});
