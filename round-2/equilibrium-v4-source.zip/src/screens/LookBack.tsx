// Your week, in your own words: the evidence you recorded, goals reached and set, path practice,
// and how many days you showed up. No scores and no averaged feelings.

import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { Evidence } from '../domain/types';
import { lookBack, LOOKBACK_PROMPT } from '../domain/lookback';
import { addDays, formatDay } from '../domain/protocols';
import { practiceDays, todayKey } from '../domain/paths';
import { SPACE_NAME } from '../domain/spaces';
import { localDayKey } from '../domain/time';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { color, elementText, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, Notice } from '../ui/primitives';
import { EVIDENCE_COLOR, EVIDENCE_ICON, Icon } from '../ui/Icon';

export function LookBackScreen() {
  const store = useStore();
  const nav = useNav();
  const today = todayKey();
  const [end, setEnd] = useState(today);
  const j = store.journey;
  const lb = lookBack(j, j.activeSpaceId, end);
  const days = practiceDays(j);
  const week = Array.from({ length: 7 }, (_, i) => addDays(end, i - 6));
  const isThisWeek = end === today;
  const startDay = localDayKey(j.profile?.createdAt ?? j.createdAt);
  const lookbackDone = j.journal.some((e) => !e.deletedAt && e.prompt === LOOKBACK_PROMPT);

  const write = () => {
    nav.reset('journal');
    nav.requestFocus(`journal:${LOOKBACK_PROMPT}`);
  };

  return (
    <Screen back title="Your week" subtitle="What changed, in your own words. Nothing here is scored." testID="screen-lookback">
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <Button label="Earlier" kind="quiet" small icon="back" disabled={lb.from <= startDay} onPress={() => setEnd(addDays(end, -7))} testID="lookback-prev" />
        <Text style={[type.label, { flex: 1, textAlign: 'center' }]} testID="lookback-range" numberOfLines={1}>
          {rangeLabel(lb.from, lb.to)}
        </Text>
        <Button label="Later" kind="quiet" small iconRight="chevron" disabled={isThisWeek} onPress={() => setEnd(addDays(end, 7) > today ? today : addDays(end, 7))} testID="lookback-next" />
      </View>

      <Card style={{ gap: space.md }} testID="lookback-days">
        <Text style={type.title}>
          You showed up on {lb.daysShownUp} of 7 days.
        </Text>
        <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'space-between' }} role="img" aria-label={week.map((d) => `${formatDay(d)}: ${days.has(d) ? 'practiced' : 'no practice'}`).join('; ')}>
          {week.map((d) => (
            <View key={d} style={{ alignItems: 'center', gap: 4, flex: 1 }}>
              <View style={[st.mark, days.has(d) ? { backgroundColor: color.sage, borderColor: color.sage } : null]}>{days.has(d) ? <Icon name="check" size={14} color={color.onSage} strokeWidth={2.6} /> : null}</View>
              <Text style={[type.small, { fontSize: 12 }]}>{formatDay(d).slice(0, 3)}</Text>
            </View>
          ))}
        </View>
        <Text style={type.small}>Any practice counts: a check-in, journal entry, evidence, reading, lesson or goal.</Text>
      </Card>

      {lb.empty ? (
        <Notice icon="calendar">Nothing recorded this week. That’s all right. A single check-in starts the next one.</Notice>
      ) : null}

      <QuoteList title="Wins" items={lb.wins} empty="No wins recorded this week." testID="lookback-wins" />
      <QuoteList title="Observations" items={lb.observations} testID="lookback-observations" />
      <QuoteList title="Setbacks" items={lb.setbacks} note="Information, not failure." testID="lookback-setbacks" />

      {lb.goalsReached.length || lb.goalsSet.length ? (
        <View style={{ gap: space.sm }} testID="lookback-goals">
          <Eyebrow heading>Goals</Eyebrow>
          <Card padded={false}>
            {[...lb.goalsReached.map((g) => ({ g, reached: true })), ...lb.goalsSet.filter((g) => !lb.goalsReached.includes(g)).map((g) => ({ g, reached: false }))].map(({ g, reached }, i, arr) => (
              <View key={g.id + reached} style={[st.row, i < arr.length - 1 && st.rowBorder]}>
                <Icon name={reached ? 'check' : 'flag'} size={18} color={reached ? color.sage : color.gold} strokeWidth={2.2} />
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={type.label}>
                    {reached ? 'Reached: ' : 'Set: '}
                    {g.title}
                  </Text>
                  {reached && g.reflection ? <Text style={[type.small, { fontStyle: 'italic', color: g.element ? elementText[g.element] : color.ink }]}>“{g.reflection}”</Text> : null}
                </View>
              </View>
            ))}
          </Card>
        </View>
      ) : null}

      {lb.lessons.length ? (
        <View style={{ gap: space.sm }} testID="lookback-lessons">
          <Eyebrow heading>Path practice</Eyebrow>
          <Card padded={false}>
            {lb.lessons.map(({ lesson, days: n }, i) => (
              <View key={lesson.id} style={[st.row, i < lb.lessons.length - 1 && st.rowBorder]}>
                <Icon name="path" size={18} color={color.sage2} />
                <Text style={[type.label, { flex: 1 }]}>{lesson.title}</Text>
                <Text style={type.small}>
                  {n} day{n === 1 ? '' : 's'}
                </Text>
              </View>
            ))}
          </Card>
        </View>
      ) : null}

      <Text style={type.small} testID="lookback-also">
        Also this week in {SPACE_NAME[j.activeSpaceId]}: {lb.checkins} check-in{lb.checkins === 1 ? '' : 's'}, {lb.journal} journal entr{lb.journal === 1 ? 'y' : 'ies'}, {lb.readings} Compass reading{lb.readings === 1 ? '' : 's'}.
      </Text>

      <Card tone="sage" style={{ gap: space.md }}>
        <Text style={type.heading}>{LOOKBACK_PROMPT}</Text>
        <Text style={type.small}>{lookbackDone ? 'A few lines in your journal, whenever a week deserves them.' : 'A few lines in your journal. Your teacher counts it toward the Foundation lesson “Look back”.'}</Text>
        <Button label="Write what changed" icon="journal" onPress={write} testID="lookback-write" />
      </Card>
    </Screen>
  );
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "Oct 8 – 14", or "Sep 29 – Oct 5" across months. Short enough for a phone. */
function rangeLabel(from: string, to: string): string {
  const [, fm, fd] = from.split('-').map(Number);
  const [, tm, td] = to.split('-').map(Number);
  return fm === tm ? `${MONTHS[fm - 1]} ${fd} – ${td}` : `${MONTHS[fm - 1]} ${fd} – ${MONTHS[tm - 1]} ${td}`;
}

function QuoteList({ title, items, empty, note, testID }: { title: string; items: (Evidence & { areaName: string })[]; empty?: string; note?: string; testID?: string }) {
  if (!items.length && !empty) return null;
  return (
    <View style={{ gap: space.sm }} testID={testID}>
      <Eyebrow heading>
        {title} · {items.length}
      </Eyebrow>
      {note && items.length ? <Text style={type.small}>{note}</Text> : null}
      {items.length === 0 ? (
        <Text style={type.small}>{empty}</Text>
      ) : (
        <Card padded={false}>
          {items.map((e, i) => (
            <View key={e.id} style={[st.row, i < items.length - 1 && st.rowBorder]}>
              <Icon name={EVIDENCE_ICON[e.kind]} size={18} color={EVIDENCE_COLOR[e.kind]} strokeWidth={2} />
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={[type.body, { fontStyle: 'italic' }]}>“{e.text}”</Text>
                <Text style={type.small}>
                  {e.areaName} · {formatDay(localDayKey(e.createdAt))}
                </Text>
              </View>
            </View>
          ))}
        </Card>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  mark: { width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, borderColor: color.controlBorder, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong },
  row: { flexDirection: 'row', alignItems: 'flex-start', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 12 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
