import React from 'react';
import { HALL_CHOICES, HALLS } from '../theme/academy';
import { useHall } from '../ui/academy/hall';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { computeDirection, DIRECTIONS } from '../domain/directions';
import { gemBalance, guideProgress } from '../domain/selectors';
import { evaluateIntake, intakeSummary } from '../domain/intake';
import { ageLabel, isAdult, REFLECTION_MODE_NOTE } from '../domain/age';
import { setPrefs } from '../domain/ops';
import { SPACE_NAME } from '../domain/spaces';
import { formatTime, localDayKey } from '../domain/time';
import { currentProtocol, DAY_LABEL, dayFor } from '../domain/protocols';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useAccount } from '../sync/account';
import { hapticsSupported } from '../platform/haptics';
import { soundSupported } from '../platform/feelSound';
import { useInstall } from '../platform/install';
import { color, isNight, radius, serif, space, themeChoice, ThemeChoice, type } from '../theme/tokens';
import { setThemeChoice, themeChoiceSupported } from '../platform/theme';
import { Screen } from '../ui/layout';
import { Button, Card, Chip, Notice, Row, Section, Toggle } from '../ui/primitives';
import { Gem } from '../ui/Icon';

export function You() {
  const store = useStore();
  const nav = useNav();
  const account = useAccount();
  const { journey } = store;
  const hallNow = useHall();
  const p = journey.profile!;
  const sp = journey.activeSpaceId;
  const dir = computeDirection(journey);
  const guide = guideProgress(journey);
  const intake = evaluateIntake(journey.intake);
  const install = useInstall();
  const adult = isAdult(journey);
  const protocol = currentProtocol(journey);

  const persistText =
    store.persist.kind === 'saved'
      ? `Saved on this device${store.persist.at ? ` · ${formatTime(store.persist.at)}` : ''}`
      : store.persist.kind === 'saving'
        ? 'Saving…'
        : store.persist.kind === 'error'
          ? 'Not saved — tap for details'
          : store.persist.kind === 'memory'
            ? 'Not saving on this browser'
            : 'Loading…';

  return (
    <Screen title="You" subtitle="Make this yours, and stay in control of your data." testID="screen-you">
      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <View style={st.avatar}>
          <Text style={st.avatarText}>{p.name.slice(0, 1).toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1, gap: 2 }}>
          <Text style={type.title}>{p.name}</Text>
          <Text style={type.small}>{p.handle ? `@${p.handle} · reserved, not visible to anyone` : 'No handle'}</Text>
          <Text style={type.small} testID="you-age">Age · {ageLabel(p.ageBracket)}</Text>
        </View>
        <Button label="Edit" small kind="secondary" onPress={() => nav.push({ name: 'profile' })} />
      </Card>

      <Section title="Your practice">
        <Row icon="compass" title="Compass" detail="What your balance means, where to begin, and how it has shifted over time." onPress={() => nav.push({ name: 'equilibrium' })} />
        {adult ? <Row icon="swap" title="Space" detail="Check-ins, journal, Compass and gems follow the Space." value={SPACE_NAME[sp]} onPress={() => nav.openSheet({ name: 'space' })} /> : null}
        <Row icon="compass" title="Direction" detail={dir.current ? `${DIRECTIONS[dir.current].verb} · see how it's worked out` : 'Not set'} value={dir.current ? DIRECTIONS[dir.current].name : undefined} onPress={() => nav.push({ name: 'directions' })} />
        <Row
          icon="sparkle"
          title="Gems"
          detail="A record of showing up. No cash value."
          right={
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Gem size={16} />
              <Text style={type.label}>{gemBalance(journey, sp)}</Text>
            </View>
          }
          onPress={() => nav.push({ name: 'gems' })}
        />
        <Row icon="map" title="First steps" detail={guide.complete ? 'All five lessons complete · replay any time' : `${guide.done} of 5 lessons done · resume where you left off`} onPress={() => nav.openGuide()} last />
      </Section>

      {adult ? (
        <Section title="Microdosing · optional">
          <Row
            icon="shield"
            title="Safety & Path"
            detail={intakeSummary(intake)}
            tone={intake.supportNow || intake.needsReview ? color.caution : undefined}
            onPress={() => nav.push({ name: 'intake' })}
          />
          <Row
            icon="calendar"
            title="Your protocol"
            detail={protocol ? `${protocol.name}${protocol.status === 'paused' ? ' · paused' : ` · ${DAY_LABEL[dayFor(protocol, localDayKey(new Date())).kind].toLowerCase()} today`}` : 'Not set · choose a rhythm or create your own'}
            onPress={() => nav.push({ name: 'protocol' })}
            last
          />
        </Section>
      ) : (
        <Notice icon="heart" testID="you-reflection-mode">
          {REFLECTION_MODE_NOTE}
        </Notice>
      )}

      <Section title="Data & account">
        <Row icon={account.signedIn ? 'cloud' : 'device'} title="Account & sync" detail={account.summary} onPress={() => nav.push({ name: 'account' })} />
        <Row icon="download" title="Your data" detail={`Export, restore or erase · ${persistText}`} onPress={() => nav.push({ name: 'data' })} tone={store.persist.kind === 'error' || store.persist.kind === 'memory' ? color.caution : undefined} last />
      </Section>

      <Section title="Preferences">
        <View style={st.appearance} testID="appearance">
          <View style={{ gap: 2 }}>
            <Text style={type.label}>Appearance</Text>
            <Text style={type.small}>
              {themeChoiceSupported
                ? ['Day is warm paper; Night is a dark page for evening journaling.', themeChoice === 'system' ? `Following this device: ${isNight ? 'Night' : 'Day'} now (checked each time Equilibrium opens).` : null, 'Changing it refreshes Equilibrium; your entries stay.'].filter(Boolean).join(' ')
                : `Equilibrium follows your phone’s light or dark setting. ${isNight ? 'Night' : 'Day'} now.`}
            </Text>
          </View>
          {themeChoiceSupported ? (
            <View role="radiogroup" aria-label="Appearance" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
              {([
                ['day', 'Day', 'sun'],
                ['night', 'Night', 'moon'],
                ['system', 'Match device', 'device'],
              ] as [ThemeChoice, string, 'sun' | 'moon' | 'device'][]).map(([v, label, icon]) => (
                <Chip key={v} radio label={label} icon={icon} selected={themeChoice === v} onPress={() => v !== themeChoice && setThemeChoice(v)} testID={`appearance-${v}`} />
              ))}
            </View>
          ) : null}
        </View>
        <View style={st.appearance} testID="hall-choice">
          <View style={{ gap: 2 }}>
            <Text style={type.label}>Your hall</Text>
            <Text style={type.small}>
              {`Each element has a hall in the academy. Now: ${HALLS[hallNow.hall].element} · ${HALLS[hallNow.hall].name}. ${(journey.prefs.hall ?? 'lesson') === 'lesson' ? 'Following your lesson; Foundation lessons rest in the Herb Garden.' : 'Kept by you.'}`}
            </Text>
          </View>
          <View role="radiogroup" aria-label="Your hall" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {HALL_CHOICES.map((v) => (
              <Chip
                key={v}
                radio
                label={v === 'lesson' ? 'Follow my lesson' : `${HALLS[v].element} · ${HALLS[v].name}`}
                selected={(journey.prefs.hall ?? 'lesson') === v}
                onPress={() => store.apply((j) => setPrefs(j, { hall: v }))}
                testID={`hall-${v}`}
              />
            ))}
          </View>
        </View>
        <Row
          title="Haptics"
          detail={hapticsSupported ? 'A light tap when you choose or save.' : `Not available on ${Platform.OS === 'web' ? 'web' : 'this device'}.`}
          right={<Toggle label="Haptics" value={journey.prefs.haptics && hapticsSupported} disabled={!hapticsSupported} onChange={(v) => store.apply((j) => setPrefs(j, { haptics: v }))} />}
        />
        <Row
          title="Sound"
          detail={soundSupported ? 'Quiet tones that follow the check-in sliders. Each feeling has its own.' : 'Not available on this device yet. The sliders give a light tap instead.'}
          right={<Toggle label="Slider sound" value={journey.prefs.sound && soundSupported} disabled={!soundSupported} onChange={(v) => store.apply((j) => setPrefs(j, { sound: v }))} />}
        />
        <Row
          title="Reduce motion"
          detail={journey.prefs.reduceMotion === 'reduce' ? 'Always reduced in Equilibrium.' : 'Follows your system setting.'}
          right={<Toggle label="Always reduce motion" value={journey.prefs.reduceMotion === 'reduce'} onChange={(v) => store.apply((j) => setPrefs(j, { reduceMotion: v ? 'reduce' : 'system' }))} />}
          last
        />
      </Section>

      {install.supported && !install.standalone ? (
        <Section title="Install">
          <Row
            icon="device"
            title="Add Equilibrium to your home screen"
            detail={
              install.canPrompt
                ? 'Opens like an app, works offline, and helps your browser keep your journey.'
                : install.ios
                  ? 'In Safari, tap Share, then “Add to Home Screen”. It opens like an app, works offline, and helps Safari keep your journey.'
                  : 'In your browser menu, choose “Install app” or “Add to Home screen”. It opens like an app and works offline.'
            }
            right={install.canPrompt ? <Button label="Install" small onPress={() => void install.prompt()} testID="install-app" /> : undefined}
            last
          />
        </Section>
      ) : null}

      <Section title="Help">
        <Row icon="heart" title="Support" detail="If you need someone to talk to now." onPress={() => nav.push({ name: 'support' })} />
        <Row icon="info" title="About this version" detail="What's new in v3 · Graphics & Interface, what works, and what isn't built yet." onPress={() => nav.push({ name: 'about' })} last />
      </Section>

      <Text style={[type.small, { textAlign: 'center' }]}>equilibrium · v3 · Graphics & Interface (Claude build) · {Platform.OS}</Text>
    </Screen>
  );
}

const st = StyleSheet.create({
  appearance: { gap: space.md, paddingHorizontal: space.lg, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  avatar: { width: 56, height: 56, borderRadius: radius.pill, backgroundColor: color.sage, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontFamily: serif, fontSize: 26, color: color.onSage },
});
