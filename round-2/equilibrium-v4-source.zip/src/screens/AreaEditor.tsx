import React, { useState } from 'react';
import { Text, View } from 'react-native';
import type { DirectionId, Rating } from '../domain/types';
import { DIRECTION_IDS } from '../domain/types';
import { addArea, updateArea } from '../domain/ops';
import { DIRECTIONS } from '../domain/directions';
import { AREA_EXAMPLES, DIFFICULTY_ANCHORS, IMPACT_ANCHORS } from '../domain/scales';
import { newId } from '../domain/ids';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { space, type } from '../theme/tokens';
import { Sheet } from '../ui/layout';
import { Button, Chip, Notice } from '../ui/primitives';
import { Field, RatingScale } from '../ui/controls';

export function AreaEditorSheet() {
  const nav = useNav();
  const store = useStore();
  const toast = useToast();
  const sheet = nav.sheet?.name === 'areaEditor' ? nav.sheet : null;
  const existing = sheet?.areaId ? store.journey.areas.find((a) => a.id === sheet.areaId && !a.deletedAt) : undefined;

  const [name, setName] = useState('');
  const [impact, setImpact] = useState<Rating | undefined>();
  const [difficulty, setDifficulty] = useState<Rating | undefined>();
  const [direction, setDirection] = useState<DirectionId | undefined>();
  const [error, setError] = useState<string | null>(null);

  // Reset the form each time the sheet opens for a different area or preset (adjusting state during render).
  const openKey = sheet ? `${sheet.areaId ?? ''}|${sheet.presetName ?? ''}|${sheet.presetDirection ?? ''}` : null;
  const [lastKey, setLastKey] = useState<string | null>(null);
  if (openKey !== lastKey) {
    setLastKey(openKey);
    if (sheet) {
      setName(existing?.name ?? sheet.presetName ?? '');
      setImpact(existing?.impact);
      setDifficulty(existing?.difficulty);
      setDirection(existing?.direction ?? sheet.presetDirection);
      setError(null);
    }
  }

  const canSave = !!name.trim() && !!impact && !!difficulty;
  const save = () => {
    if (!canSave) return;
    const input = { name, impact: impact!, difficulty: difficulty!, direction };
    const id = existing?.id ?? newId('area');
    const r = store.apply((j) => (existing ? updateArea(j, existing.id, input) : addArea(j, input, new Date(), id)));
    if (!r.ok) return setError(r.error);
    nav.closeSheet();
    toast.show(existing ? 'Area updated' : 'Added to Journey');
    if (!existing) nav.push({ name: 'area', id });
  };

  return (
    <Sheet
      visible={!!sheet}
      onClose={nav.closeSheet}
      title={existing ? 'Edit area' : 'Something to practice'}
      testID="area-editor"
      footer={
        <>
          {error ? <Notice tone="caution">{error}</Notice> : null}
          <Button label={existing ? 'Save changes' : 'Add to Journey'} full onPress={save} disabled={!canSave} testID="area-save" />
          {!canSave ? <Text style={[type.small, { textAlign: 'center' }]}>Add a name, impact and difficulty to save.</Text> : null}
        </>
      }
    >
      <Field label="What would you like to practice?" value={name} onChangeText={setName} placeholder="e.g. A steadier sleep rhythm" maxLength={120} testID="area-name" />
      {!existing && !name ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          {AREA_EXAMPLES.map((ex) => (
            <Chip key={ex} label={ex} onPress={() => setName(ex)} />
          ))}
        </View>
      ) : null}
      <RatingScale label="Impact" question="How much would this change things for you?" anchors={IMPACT_ANCHORS} value={impact} onChange={setImpact} testID="area-impact" />
      <RatingScale label="Difficulty" question="How hard does it feel right now? 1–2 marks an easy win." anchors={DIFFICULTY_ANCHORS} value={difficulty} onChange={setDifficulty} testID="area-difficulty" />
      <View style={{ gap: space.sm }}>
        <Text style={type.label}>
          Direction <Text style={[type.small, { fontWeight: '400' }]}> optional</Text>
        </Text>
        <Text style={type.small}>Tagging an area helps Equilibrium show where your practice is pointing.</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }} role="radiogroup" aria-label="Direction">
          <Chip radio label="None" selected={!direction} onPress={() => setDirection(undefined)} />
          {DIRECTION_IDS.map((d) => (
            <Chip radio key={d} label={`${DIRECTIONS[d].name} · ${DIRECTIONS[d].verb}`} selected={direction === d} onPress={() => setDirection(d)} />
          ))}
        </View>
      </View>
    </Sheet>
  );
}
