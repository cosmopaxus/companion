import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { checkinsFor } from '../domain/selectors';
import { deleteCheckIn } from '../domain/ops';
import { formatDayHeading, formatTime, localDayKey } from '../domain/time';
import { SPACE_NAME } from '../domain/spaces';
import type { CheckIn } from '../domain/types';
import { useStore } from '../state/store';
import { useToast } from '../state/toast';
import { color, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Card, Eyebrow, IconButton } from '../ui/primitives';
import { CheckInSummary } from '../ui/CheckInForm';
import { ConfirmSheet } from '../ui/ConfirmSheet';

/** Every check-in in the current Space, by day. Lets a mis-tap or an old note be removed. */
export function CheckInHistory() {
  const store = useStore();
  const toast = useToast();
  const sp = store.journey.activeSpaceId;
  const list = checkinsFor(store.journey, sp);
  const [confirm, setConfirm] = useState<string | null>(null);
  const groups: { key: string; heading: string; items: CheckIn[] }[] = [];
  for (const c of list) {
    const key = localDayKey(c.createdAt);
    let g = groups.find((x) => x.key === key);
    if (!g) groups.push((g = { key, heading: formatDayHeading(c.createdAt), items: [] }));
    g.items.push(c);
  }
  return (
    <Screen back title="Check-ins" subtitle={`Everything you've checked in with in ${SPACE_NAME[sp]}. No scores, no streaks — just the record.`} testID="screen-checkins">
      {groups.length === 0 ? <Text style={type.bodySoft}>No check-ins in {SPACE_NAME[sp]} yet.</Text> : null}
      {groups.map((g) => (
        <View key={g.key} style={{ gap: space.sm }}>
          <Eyebrow heading tone={color.inkSoft}>
            {g.heading} · {g.items.length}
          </Eyebrow>
          <Card padded={false}>
            {g.items.map((c, i) => (
              <View key={c.id} style={[st.row, i < g.items.length - 1 && st.border]} testID="history-checkin">
                <Text style={[type.label, { width: 72 }]}>{formatTime(c.createdAt)}</Text>
                <View style={{ flex: 1, gap: 4 }}>
                  <CheckInSummary mood={c.mood} energy={c.energy} connection={c.connection} />
                  {c.note ? <Text style={type.small}>{c.note}</Text> : null}
                </View>
                <IconButton icon="trash" label={`Delete the ${formatTime(c.createdAt)} check-in from ${g.heading}`} onPress={() => setConfirm(c.id)} tone={color.inkSoft} size={18} />
              </View>
            ))}
          </Card>
        </View>
      ))}
      <ConfirmSheet
        visible={!!confirm}
        title="Delete this check-in?"
        body="It will be removed from your history. Its gems stay — they recognize that you showed up."
        confirmLabel="Delete check-in"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (confirm) store.apply((j) => deleteCheckIn(j, confirm));
          setConfirm(null);
          toast.show('Check-in deleted');
        }}
      />
    </Screen>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', gap: space.md, paddingLeft: space.lg, paddingRight: space.sm, paddingVertical: 12, alignItems: 'flex-start' },
  border: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
