import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Text, View } from 'react-native';
import { backupFileName, checkBackup, makeBackup } from '../domain/backup';
import type { Journey } from '../domain/types';
import { V1_JOURNEY_KEY } from '../state/storage';
import { counts } from '../domain/selectors';
import { formatTime } from '../domain/time';
import { useStore } from '../state/store';
import { isAdult } from '../domain/age';
import { useNav } from '../state/nav';
import { useToast } from '../state/toast';
import { useAccount } from '../sync/account';
import { copyText, exportBackupFile, exportLabel } from '../platform/backupIO';
import { color, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, Notice } from '../ui/primitives';
import { Field } from '../ui/controls';
import { RestorePanel } from '../ui/RestorePanel';
import { ConfirmSheet } from '../ui/ConfirmSheet';
import { Icon } from '../ui/Icon';

/**
 * If the first build kept a journey in this browser, offer to merge a copy of it into this one
 * (by id, so nothing is duplicated). The first build's copy is only read, never changed.
 */
function V1MergeCard() {
  const store = useStore();
  const toast = useToast();
  const [found, setFound] = useState<Journey | null>(null);
  const [done, setDone] = useState(false);
  useEffect(() => {
    let live = true;
    AsyncStorage.getItem(V1_JOURNEY_KEY)
      .then((raw) => {
        if (!live || !raw) return;
        const check = checkBackup(JSON.parse(raw), { lenient: true });
        if (check.ok) setFound(check.journey);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);
  if (!found) return null;
  const fc = counts(found);
  return (
    <Card tone="sage" style={{ gap: space.md }} testID="v1-merge">
      <Eyebrow>From the first version</Eyebrow>
      <Text style={type.heading}>Your first-version journey is on this device</Text>
      <Text style={type.bodySoft}>
        {fc.checkins} check-ins · {fc.journal} journal entries · {fc.areas} Journey areas · {fc.evidence} evidence. Merge a copy into this journey; anything already here stays, and nothing is counted twice. The first version keeps its own copy, untouched.
      </Text>
      {done ? (
        <Notice tone="success">Merged. Your entries from the first version are here now.</Notice>
      ) : (
        <Button
          label="Merge my first-version journey"
          icon="download"
          onPress={() => {
            store.mergeIntoCurrent(found);
            setDone(true);
            toast.show('First-version journey merged');
          }}
          testID="v1-merge-go"
        />
      )}
    </Card>
  );
}

export function DataScreen() {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const [exportMsg, setExportMsg] = useState<{ tone: 'success' | 'caution'; text: string } | null>(null);
  const [showText, setShowText] = useState(false);
  const [erase, setErase] = useState(false);
  const c = counts(store.journey);
  const p = store.persist;

  const doExport = async () => {
    const text = JSON.stringify(makeBackup(store.journey), null, 2);
    const r = await exportBackupFile(text, backupFileName());
    setExportMsg(r.ok ? { tone: 'success', text: r.method === 'download' ? `Backup downloaded as ${backupFileName()}. If nothing appeared, your browser may have blocked it — copy the text instead.` : 'Backup handed over to save.' } : { tone: 'caution', text: r.error });
  };
  const doCopy = async () => {
    const ok = await copyText(JSON.stringify(makeBackup(store.journey)));
    setExportMsg(ok ? { tone: 'success', text: 'Backup text copied. Paste it somewhere private, like a notes file you control.' } : { tone: 'caution', text: "Couldn't copy here. The backup text is shown below — select all of it and copy." });
    if (!ok) setShowText(true);
  };

  return (
    <Screen back title="Your data" subtitle="It's yours: export it, bring it back, or erase it." testID="screen-data">
      <Card tone={p.kind === 'error' || p.kind === 'memory' ? 'caution' : 'sage'} style={{ gap: space.sm }} testID="persist-status">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
          <Icon name={p.kind === 'saved' ? 'check' : p.kind === 'saving' ? 'device' : 'info'} size={20} color={p.kind === 'error' || p.kind === 'memory' ? color.caution : color.sage} strokeWidth={2.2} />
          <Text style={[type.label, { flex: 1 }]}>
            {p.kind === 'saved' ? `Saved on this device${p.at ? ` · ${formatTime(p.at)}` : ''}` : p.kind === 'saving' ? 'Saving…' : p.kind === 'error' ? 'Latest changes not saved' : p.kind === 'memory' ? 'Not saving on this browser' : 'Loading…'}
          </Text>
        </View>
        {p.kind === 'error' || p.kind === 'memory' ? <Text style={[type.small, { color: color.caution }]}>{p.message}</Text> : null}
        {p.kind === 'error' ? <Button label="Try saving again" small kind="danger" onPress={store.retrySave} /> : null}
        <Text style={type.small}>
          {c.checkins} check-ins · {c.journal} journal entries · {c.areas} Journey areas · {c.evidence} evidence · {c.harmony} Compass readings · {c.gems} gems
        </Text>
      </Card>

      {store.recoveryNotice ? <Notice tone="caution">{store.recoveryNotice}</Notice> : null}

      <Card style={{ gap: space.md }} testID="export-card">
        <Eyebrow>Export</Eyebrow>
        <Text style={type.heading}>Download a complete backup</Text>
        <Text style={type.bodySoft}>One JSON file with every check-in, journal entry, Journey area, piece of evidence, Compass reading, gem and setting — in every Space. Keep it somewhere private; it contains your journal.</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          <Button label={exportLabel} icon="download" onPress={doExport} testID="export-download" />
          <Button label="Copy backup text" kind="secondary" onPress={doCopy} testID="export-copy" />
        </View>
        {exportMsg ? <Notice tone={exportMsg.tone}>{exportMsg.text}</Notice> : null}
        {showText ? <Field aria-label="Backup text" value={JSON.stringify(makeBackup(store.journey))} editable={false} multiline minHeight={120} selectTextOnFocus /> : null}
        <Button label={showText ? 'Hide backup text' : 'Show backup text'} kind="quiet" small onPress={() => setShowText((v) => !v)} />
      </Card>

      <V1MergeCard />

      <Card style={{ gap: space.md }} testID="restore-card">
        <Eyebrow>Restore</Eyebrow>
        <Text style={type.heading}>Bring back a backup</Text>
        <Text style={type.bodySoft}>
          {store.accountKey === 'guest'
            ? 'The file is checked first. If it passes, it replaces the journey on this device. You can undo once.'
            : 'The file is checked first. If it passes, its entries are merged into your account by id.'}
        </Text>
        <RestorePanel onRestored={() => toast.show('Journey restored')} />
        {store.canUndoRestore ? (
          <Notice
            title="Changed your mind?"
            action={
              <Button
                label="Undo last restore"
                small
                kind="secondary"
                onPress={async () => {
                  const r = await store.undoRestore();
                  toast.show(r.ok ? 'Previous journey is back' : r.error, { tone: r.ok ? 'default' : 'caution' });
                }}
                testID="restore-undo"
              />
            }
          >
            Your journey from before the last restore was kept on this device.
          </Notice>
        ) : null}
      </Card>

      <Card style={{ gap: space.md }}>
        <Eyebrow tone={color.caution}>Erase</Eyebrow>
        <Text style={type.heading}>Erase this device's journey</Text>
        <Text style={type.bodySoft}>Removes everything Equilibrium has saved on this device for {store.accountKey === 'guest' ? 'the guest journey' : 'this account'}. Export first if you want to keep anything.</Text>
        <Button label="Erase this device's journey" kind="danger" icon="trash" onPress={() => setErase(true)} testID="erase-open" />
      </Card>

      <ConfirmSheet
        visible={erase}
        title="Erase everything on this device?"
        body={`This permanently removes ${c.checkins} check-ins, ${c.journal} journal entries, ${c.areas} Journey areas and everything else saved here. It can't be undone without a backup.`}
        confirmLabel="Erase permanently"
        onCancel={() => setErase(false)}
        onConfirm={async () => {
          setErase(false);
          await store.eraseDevice();
          nav.reset('today');
        }}
      />
    </Screen>
  );
}

export function AccountScreen() {
  const account = useAccount();
  const store = useStore();

  if (!account.configured) {
    return (
      <Screen back title="Account & sync" subtitle="How your journey moves between devices." testID="screen-account">
        <Card tone="sage" style={{ gap: space.sm }}>
          <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'center' }}>
            <Icon name="device" size={20} color={color.sage} />
            <Text style={[type.label, { flex: 1 }]}>You're using Equilibrium as a guest</Text>
          </View>
          <Text style={type.bodySoft}>Everything is saved on this device only. No account is needed to use any part of the app.</Text>
        </Card>
        <Notice tone="preview" title="Accounts aren't connected in this build">
          Signing in isn't available yet, so nothing is syncing between your phone and the web. Use Export in Your data to move a journey by hand.
        </Notice>
        <Card style={{ gap: space.md }}>
          <Eyebrow>When accounts are connected</Eyebrow>
          {[
            'Sign in with a one-time code sent to your email — no password.',
            'The same journey appears on your phone and on the web.',
            "Anything you've written as a guest joins your account only if you choose.",
            'Edits made offline are kept and sync when you reconnect; entries from two devices are merged, never duplicated.',
            'Each account has its own copy on a device, so signing out never shows one person’s journal to another.',
          ].map((t) => (
            <View key={t} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
              <Icon name="check" size={16} color={color.sage} strokeWidth={2.2} />
              <Text style={[type.small, { color: color.ink, flex: 1 }]}>{t}</Text>
            </View>
          ))}
        </Card>
      </Screen>
    );
  }

  if (!isAdult(store.journey) && !account.signedIn) {
    return (
      <Screen back title="Account & sync" subtitle="How your journey moves between devices." testID="screen-account">
        <Notice icon="device">Accounts and sync are for adults 18 and over in this alpha. Your journey is saved on this device, and you can export a backup from Your data any time.</Notice>
      </Screen>
    );
  }

  if (account.pendingImport) {
    return (
      <Screen back title="Bring your guest journey?" subtitle={`Signed in as ${account.pendingImport.email}.`} testID="screen-account">
        <Card style={{ gap: space.md }}>
          <Text style={type.bodySoft}>This device has a guest journey. You can add it to your account, or keep it separate on this device. Nothing is imported unless you choose to.</Text>
          <Button label="Add it to my account" full onPress={() => account.completeSignIn(true)} testID="import-yes" />
          <Button label="Keep it separate on this device" full kind="secondary" onPress={() => account.completeSignIn(false)} testID="import-no" />
          <Button label="Cancel sign-in" full kind="quiet" onPress={account.cancelPending} />
        </Card>
      </Screen>
    );
  }

  if (account.signedIn && account.user) {
    const s = account.sync;
    return (
      <Screen back title="Account & sync" subtitle={account.user.email} testID="screen-account">
        {account.backend === 'demo' ? <Notice tone="caution" title="Demo backend">This build uses an in-memory test backend. Nothing leaves this page.</Notice> : null}
        <Card tone={s.kind === 'error' ? 'caution' : 'sage'} style={{ gap: space.sm }} testID="sync-status">
          <Text style={type.label}>
            {s.kind === 'synced' ? `Synced at ${formatTime(s.at)}` : s.kind === 'syncing' ? 'Syncing…' : s.kind === 'offline' ? 'Offline' : s.kind === 'error' ? 'Sync needs attention' : 'Waiting to sync'}
          </Text>
          {s.kind === 'offline' || s.kind === 'error' ? <Text style={type.small}>{s.message}</Text> : <Text style={type.small}>Changes save on this device first, then sync to your account.</Text>}
          <Button label="Sync now" small kind="secondary" onPress={account.syncNow} disabled={s.kind === 'syncing'} />
        </Card>
        <Button label="Sign out" kind="danger" onPress={account.signOut} />
        <Text style={type.small}>Signing out switches this device back to its separate guest journey. Your account's entries stay in your account.</Text>
      </Screen>
    );
  }

  return (
    <Screen back title="Sign in" subtitle="Keep one journey across your phone and the web." testID="screen-account">
      {account.backend === 'demo' ? <Notice tone="caution" title="Demo backend">Test build. The code is 123456 and nothing leaves this page.</Notice> : null}
      <SignInForm />
      <Text style={type.small}>{store.accountKey === 'guest' ? "You're a guest right now. If this device has a guest journey, you'll be asked whether to bring it into your account." : ''}</Text>
    </Screen>
  );
}

/** Email one-time-code sign-in. Used by the Account screen and by the welcome screen (returning people). */
export function SignInForm() {
  const account = useAccount();
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [stage, setStage] = useState<'email' | 'code'>('email');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <Card style={{ gap: space.lg }}>
      {stage === 'email' ? (
        <>
          <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" placeholder="you@example.com" testID="account-email" />
          <Button
            label="Send me a code"
            full
            busy={busy}
            disabled={!/\S+@\S+\.\S+/.test(email)}
            onPress={async () => {
              setBusy(true);
              const r = await account.sendCode(email);
              setBusy(false);
              if (r.ok) {
                setStage('code');
                setError(null);
              } else setError(r.error ?? 'Could not send a code.');
            }}
            testID="account-send"
          />
        </>
      ) : (
        <>
          <Text style={type.bodySoft}>We sent a code to {email}. It can take a minute.</Text>
          <Field label="Code" value={code} onChangeText={setCode} keyboardType="number-pad" autoComplete="one-time-code" maxLength={8} testID="account-code" />
          <Button
            label="Sign in"
            full
            busy={busy}
            disabled={code.trim().length < 6}
            onPress={async () => {
              setBusy(true);
              const r = await account.verifyCode(email, code);
              setBusy(false);
              if (!r.ok) setError(r.error ?? 'That code did not work.');
            }}
            testID="account-verify"
          />
          <Button label="Use a different email" kind="quiet" onPress={() => setStage('email')} />
        </>
      )}
      {error ? <Notice tone="caution">{error}</Notice> : null}
    </Card>
  );
}
