import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { checkBackup } from '../domain/backup';
import { V1_JOURNEY_KEY } from '../state/storage';
import { useInsets } from '../ui/insets';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { AgeBracket, DirectionId, Experience, IntakeAnswer, Journey, SpaceId } from '../domain/types';
import { DIRECTION_IDS } from '../domain/types';
import { DIRECTIONS } from '../domain/directions';
import { completeOnboarding, saveIntake } from '../domain/ops';
import { AGE_BRACKETS, REFLECTION_MODE_NOTE } from '../domain/age';
import { useNav } from '../state/nav';
import { IntakeQuestions } from '../ui/IntakeQuestions';
import { useStore } from '../state/store';
import { color, radius, space, type } from '../theme/tokens';
import { Button, Card, Chip, focusRing, Notice, spaceKey } from '../ui/primitives';
import { Field } from '../ui/controls';
import { Icon, IconName } from '../ui/Icon';
import { Wordmark } from '../ui/Wordmark';
import { RestorePanel } from '../ui/RestorePanel';
import { SPACES } from '../domain/spaces';
import { useAccount } from '../sync/account';
import { SignInForm } from './DataAccount';

const LOOP: { icon: IconName; text: string }[] = [
  { icon: 'today', text: 'Notice where you are.' },
  { icon: 'compass', text: 'Choose what matters.' },
  { icon: 'journey', text: 'Practice a direction.' },
  { icon: 'sparkle', text: 'See what changes.' },
];

export function Onboarding() {
  const store = useStore();
  const insets = useInsets('page');
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [showHandle, setShowHandle] = useState(false);
  const [age, setAge] = useState<AgeBracket | undefined>();
  const [answers, setAnswers] = useState<Partial<Record<string, IntakeAnswer>>>({});
  const [experience, setExperience] = useState<Experience | undefined>();
  const [spaceId, setSpaceId] = useState<SpaceId>('personal');
  const [dirs, setDirs] = useState<DirectionId[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [signInOpen, setSignInOpen] = useState(false);
  const account = useAccount();
  const nav = useNav();
  const minor = age === 'under18';
  // Under 18 skips the Space step (Be Well is for adults) and the Safety & Path step.
  const flow = minor ? [1, 3] : [1, 2, 3, 4];
  const next = (from: number) => flow[flow.indexOf(from) + 1];
  const prev = (from: number) => flow[flow.indexOf(from) - 1] ?? 0;

  const intakeAnswered = Object.keys(answers).length > 0 || !!experience;
  const finish = () => {
    const r = store.apply((j) => {
      const withIntake = !minor && intakeAnswered ? saveIntake(j, answers, true, undefined, experience) : j;
      return completeOnboarding(withIntake, { name, handle, ageBracket: age!, spaceId: minor ? 'personal' : spaceId, directions: dirs });
    });
    if (!r.ok) return setError(r.error);
    if (!minor && answers.crisis_now === 'yes') nav.push({ name: 'support' });
  };

  const toggleDir = (d: DirectionId) => {
    setDirs((cur) => (cur.includes(d) ? cur.filter((x) => x !== d) : cur.length >= 2 ? [cur[1], d] : [...cur, d]));
  };

  const steps = flow.length;
  const position = flow.indexOf(step) + 1;
  return (
    <ScrollView style={{ flex: 1, backgroundColor: color.canvas }} contentContainerStyle={[st.scroll, { paddingTop: insets.top + space.xl, paddingBottom: insets.bottom + space.xxl }]} keyboardShouldPersistTaps="handled">
      <View style={st.inner}>
        <View style={st.top}>
          <Wordmark size={22} />
          {step > 0 ? (
            <View style={st.dots} aria-label={`Step ${position} of ${steps}`} role="progressbar">
              {flow.map((_, i) => (
                <View key={i} style={[st.dot, i + 1 <= position && { backgroundColor: color.sage, width: i + 1 === position ? 22 : 8 }]} />
              ))}
            </View>
          ) : null}
        </View>

        {step === 0 ? (
          <View style={{ gap: space.xxl }} testID="onboarding-welcome">
            {store.recoveryNotice ? <Notice tone="caution" title="Your saved journey couldn't be opened">{store.recoveryNotice}</Notice> : null}
            {store.persist.kind === 'memory' ? (
              <Notice tone="caution" title="This browser isn't letting Equilibrium save">
                You can still look around and try everything, but nothing will be kept after you close this page. Export a backup from You → Your data to keep anything.
              </Notice>
            ) : null}
            <View style={{ gap: space.md }}>
              <Text role="heading" aria-level={1} style={[type.display, { fontSize: 40, lineHeight: 46 }]}>
                A practice for becoming.
              </Text>
              <Text style={type.bodySoft}>Equilibrium helps you notice where you are, choose what matters, practice a direction, and recognize change through what actually happens in your life.</Text>
            </View>
            <Card style={{ gap: space.lg }}>
              {LOOP.map((l, i) => (
                <View key={l.text} style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
                  <View style={st.loopIcon}>
                    <Icon name={l.icon} size={20} color={color.sage} />
                  </View>
                  <Text style={[type.heading, { flex: 1 }]}>{l.text}</Text>
                </View>
              ))}
            </Card>
            <V1ImportCard />
            <View style={{ gap: space.md }}>
              <Button label="Begin" full onPress={() => setStep(1)} iconRight="chevron" testID="onboarding-begin" />
              <Text style={[type.small, { textAlign: 'center' }]}>
                {store.persist.kind === 'memory' ? 'No account or purchase needed.' : 'No account or purchase needed. Everything stays on this device unless you choose otherwise.'}
              </Text>
            </View>
            {account.configured ? (
              <View style={{ gap: space.md }}>
                <Button label={signInOpen ? 'Hide sign in' : 'I already have an account'} kind="quiet" onPress={() => setSignInOpen((v) => !v)} style={{ alignSelf: 'center' }} testID="onboarding-signin" />
                {signInOpen ? <SignInForm /> : null}
              </View>
            ) : null}
            <View style={{ gap: space.md }}>
              <Button label={restoreOpen ? 'Hide restore' : 'I have a backup to restore'} kind="quiet" onPress={() => setRestoreOpen((v) => !v)} style={{ alignSelf: 'center' }} testID="onboarding-restore" />
              {restoreOpen ? (
                <Card style={{ gap: space.md }}>
                  <Text style={type.small}>
                    {account.configured ? 'Bring back a journey you exported from Equilibrium.' : "Bring back a journey you exported from Equilibrium. Signing in to an existing account isn't available in this preview; accounts aren't connected yet."}
                  </Text>
                  <RestorePanel context="onboarding" />
                </Card>
              ) : null}
            </View>
          </View>
        ) : null}

        {step === 1 ? (
          <View style={{ gap: space.xl }} testID="onboarding-name">
            <View style={{ gap: space.sm }}>
              <Text role="heading" aria-level={1} style={type.display}>
                What should we call you?
              </Text>
              <Text style={type.bodySoft}>Just for greetings. It stays with your journey and isn't shown to anyone.</Text>
            </View>
            <Field label="Your name" value={name} onChangeText={setName} placeholder="e.g. Maya" autoFocus autoComplete="given-name" returnKeyType="next" maxLength={60} testID="onboarding-name-input" />
            {showHandle ? (
              <Field
                label="Handle"
                optional
                value={handle}
                onChangeText={setHandle}
                placeholder="@yourname"
                autoCapitalize="none"
                autoCorrect={false}
                maxLength={31}
                helper="Reserved for possible community features later. Nobody can see it now."
              />
            ) : (
              <Button label="Add a handle (optional)" kind="quiet" small icon="plus" onPress={() => setShowHandle(true)} />
            )}
            <View style={{ gap: space.sm }}>
              <Text style={type.label} nativeID="age-label">
                Your age range
              </Text>
              <Text style={type.small}>So Equilibrium shows what's right for you. It stays with your journey on this device.</Text>
              <View role="radiogroup" aria-labelledby="age-label" aria-label="Your age range" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm, marginTop: 4 }}>
                {AGE_BRACKETS.map((b) => (
                  <Chip key={b.id} radio label={b.label} selected={age === b.id} onPress={() => setAge(b.id)} testID={`onboarding-age-${b.id}`} />
                ))}
              </View>
            </View>
            {minor ? (
              <Notice icon="heart" testID="onboarding-reflection-mode">
                {REFLECTION_MODE_NOTE}
              </Notice>
            ) : null}
            <View style={st.nav}>
              <Button label="Back" kind="quiet" onPress={() => setStep(0)} />
              <Button label="Continue" onPress={() => setStep(next(1))} disabled={!name.trim() || !age} iconRight="chevron" testID="onboarding-continue-1" />
            </View>
            {!name.trim() || !age ? <Text style={[type.small, { textAlign: 'right' }]}>Add a name and choose an age range to continue.</Text> : null}
          </View>
        ) : null}

        {step === 2 ? (
          <View style={{ gap: space.xl }} testID="onboarding-space">
            <View style={{ gap: space.sm }}>
              <Text role="heading" aria-level={1} style={type.display}>
                Where would you like to begin?
              </Text>
              <Text style={type.bodySoft}>A Space is a home for your check-ins, journal, Compass readings and gems. You can switch any time. Switching never shares anything.</Text>
            </View>
            <View role="radiogroup" aria-label="Starting Space" style={{ gap: space.md }}>
              {SPACES.map((sp) => {
                const sel = spaceId === sp.id;
                return (
                  <Pressable key={sp.id} role="radio" aria-checked={sel} aria-label={`${sp.name}. ${sp.blurb}`} onPress={() => setSpaceId(sp.id)} {...spaceKey(() => setSpaceId(sp.id))} style={(s: any) => [st.option, sel && st.optionSel, focusRing(s)]} testID={`onboarding-space-${sp.id}`}>
                    <View style={[st.radio, sel && st.radioSel]}>{sel ? <View style={st.radioDot} /> : null}</View>
                    <View style={{ flex: 1, gap: 4 }}>
                      <Text style={type.heading}>{sp.name}</Text>
                      <Text style={type.small}>{sp.blurb}</Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
            <View style={st.nav}>
              <Button label="Back" kind="quiet" onPress={() => setStep(prev(2))} />
              <Button label="Continue" onPress={() => setStep(next(2))} iconRight="chevron" testID="onboarding-continue-2" />
            </View>
          </View>
        ) : null}

        {step === 3 ? (
          <View style={{ gap: space.xl }} testID="onboarding-direction">
            <View style={{ gap: space.sm }}>
              <Text role="heading" aria-level={1} style={type.display}>
                Pick a starting direction
              </Text>
              <Text style={type.bodySoft}>Optional. Choose up to two. A direction is a practice orientation, not a diagnosis or an identity. You can change it any time.</Text>
            </View>
            <View style={{ gap: space.md }}>
              {DIRECTION_IDS.map((d) => {
                const info = DIRECTIONS[d];
                const sel = dirs.includes(d);
                return (
                  <Pressable key={d} role="checkbox" aria-checked={sel} aria-label={`${info.name}, ${info.verb}. ${info.purpose}`} onPress={() => toggleDir(d)} {...spaceKey(() => toggleDir(d))} style={(s: any) => [st.option, sel && st.optionSel, focusRing(s)]} testID={`onboarding-dir-${d}`}>
                    <View style={[st.box, sel && { backgroundColor: color.sage, borderColor: color.sage }]}>{sel ? <Icon name="check" size={16} color={color.onSage} strokeWidth={2.6} /> : null}</View>
                    <View style={{ flex: 1, gap: 2 }}>
                      <Text style={type.heading}>
                        {info.name} <Text style={[type.small, { color: color.gold, fontWeight: '700' }]}>· {info.verb.toUpperCase()}</Text>
                      </Text>
                      <Text style={type.small}>{info.purpose}</Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
            {error && minor ? <Notice tone="caution">{error}</Notice> : null}
            <View style={st.nav}>
              <Button label="Back" kind="quiet" onPress={() => setStep(prev(3))} />
              {minor ? (
                <Button label={dirs.length ? 'Go to Today' : 'Skip for now'} onPress={finish} iconRight="chevron" testID="onboarding-finish" />
              ) : (
                <Button label={dirs.length ? 'Continue' : 'Skip for now'} onPress={() => setStep(4)} iconRight="chevron" testID="onboarding-continue-3" />
              )}
            </View>
          </View>
        ) : null}

        {step === 4 ? (
          <View style={{ gap: space.xl }} testID="onboarding-intake">
            <View style={{ gap: space.sm }}>
              <Text role="heading" aria-level={1} style={type.display}>
                Before any microdosing
              </Text>
              <Text style={type.bodySoft}>
                Optional, about two minutes. A few honest questions help Equilibrium point out what's worth care. You can answer later in You → Safety & Path.
              </Text>
            </View>
            <Notice tone="preview" title="Draft · pending specialist review">
              A transparent placeholder, not a medical check. It can't give clearance or permission, and it never chooses a dose. Answers stay on this device.
            </Notice>
            <IntakeQuestions answers={answers} experience={experience} onAnswers={setAnswers} onExperience={setExperience} />
            {error ? <Notice tone="caution">{error}</Notice> : null}
            <View style={st.nav}>
              <Button label="Back" kind="quiet" onPress={() => setStep(3)} />
              <Button label={intakeAnswered ? 'Save and go to Today' : 'Skip for now'} onPress={finish} iconRight="chevron" testID="onboarding-finish" />
            </View>
          </View>
        ) : null}
      </View>
    </ScrollView>
  );
}

/**
 * If the first build of Equilibrium kept a journey in this browser (same web address), offer to bring
 * a copy into v2. The first build's copy is only read, never changed.
 */
function V1ImportCard() {
  const store = useStore();
  const [found, setFound] = useState<Journey | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    AsyncStorage.getItem(V1_JOURNEY_KEY)
      .then((raw) => {
        if (!live || !raw) return;
        const check = checkBackup(JSON.parse(raw), { lenient: true });
        if (check.ok && check.journey.profile) setFound(check.journey);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);
  if (!found) return null;
  const n = found.checkins.filter((c) => !c.deletedAt).length + found.journal.filter((e) => !e.deletedAt).length + found.evidence.filter((e) => !e.deletedAt).length;
  return (
    <Card tone="sage" style={{ gap: space.md }} testID="v1-import">
      <Text style={type.heading}>Welcome back, {found.profile!.name}.</Text>
      <Text style={type.small}>
        Your journey from the first version of Equilibrium is on this device ({n} entr{n === 1 ? 'y' : 'ies'}). Bring a copy into v2 to keep going. The first version keeps its own copy, untouched.
      </Text>
      {error ? <Notice tone="caution">{error}</Notice> : null}
      <Button
        label="Bring my journey into v2"
        icon="download"
        onPress={async () => {
          const r = await store.replaceJourney(found);
          if (!r.ok) setError(r.error);
        }}
        testID="v1-import-go"
      />
    </Card>
  );
}

const st = StyleSheet.create({
  scroll: { paddingHorizontal: space.lg, flexGrow: 1 },
  inner: { width: '100%', maxWidth: 520, alignSelf: 'center', gap: space.xxl },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 32 },
  dots: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  dot: { height: 8, width: 8, borderRadius: 4, backgroundColor: color.border },
  loopIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: color.sageWash, alignItems: 'center', justifyContent: 'center' },
  nav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  check: { flexDirection: 'row', gap: space.md, alignItems: 'center', padding: space.lg, borderRadius: radius.md, borderWidth: 1.5, borderColor: color.controlBorder, backgroundColor: color.paper },
  box: { width: 26, height: 26, borderRadius: 8, borderWidth: 1.75, borderColor: color.controlBorder, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paperStrong },
  option: { flexDirection: 'row', gap: space.md, alignItems: 'center', padding: space.lg, borderRadius: radius.lg, borderWidth: 1.5, borderColor: color.border, backgroundColor: color.paper },
  optionSel: { borderColor: color.sage, backgroundColor: color.paperStrong, borderWidth: 2 },
  radio: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.75, borderColor: color.controlBorder, alignItems: 'center', justifyContent: 'center' },
  radioSel: { borderColor: color.sage },
  radioDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: color.sage },
});
