// Slider sound for the web build, made with the Web Audio API — no audio files. Each feeling has
// its own voice (see feelSoundParams.ts) that follows the slider while it moves and fades out
// shortly after it stops. Quiet by design; off with the speaker button or You → Preferences.
import type { CheckInDimension } from '../domain/scales';
import { feelParams, type ConnectionParams, type EnergyParams, type FeelParams, type MoodParams } from './feelSoundParams';

type AC = AudioContext;
const AudioCtor: (new () => AC) | undefined =
  typeof window !== 'undefined' ? ((window as any).AudioContext || (window as any).webkitAudioContext) : undefined;

export const soundSupported = !!AudioCtor;

let enabled = true;
let ctx: AC | null = null;
let master: GainNode | null = null;
let active: { dim: CheckInDimension; voice: Voice } | null = null;
let idle: ReturnType<typeof setTimeout> | null = null;

export function setSoundEnabled(v: boolean) {
  enabled = v;
  if (!v) feelEnd();
}

function ensure(): AC | null {
  if (!enabled || !AudioCtor) return null;
  try {
    if (!ctx) {
      ctx = new AudioCtor();
      const comp = ctx.createDynamicsCompressor();
      master = ctx.createGain();
      master.gain.value = 0.16;
      master.connect(comp);
      comp.connect(ctx.destination);
      if (typeof document !== 'undefined') document.addEventListener('visibilitychange', () => document.hidden && feelEnd());
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  } catch {
    return null;
  }
}

/** Call from a pointer-down or key-down so the browser lets audio start (Safari needs a gesture). */
export function primeSound() {
  ensure();
}

interface Voice {
  set(p: FeelParams, at: number): void;
  release(at: number): void;
}

const TC = 0.025; // glide time constant, seconds

function osc(c: AC, type: OscillatorType, freq: number): OscillatorNode {
  const o = c.createOscillator();
  o.type = type;
  o.frequency.value = freq;
  return o;
}

function gain(c: AC, v: number): GainNode {
  const g = c.createGain();
  g.gain.value = v;
  return g;
}

function voiceShell(c: AC, oscs: OscillatorNode[], out: GainNode) {
  out.connect(master!);
  oscs.forEach((o) => o.start());
  return {
    release(at: number) {
      out.gain.cancelScheduledValues(at);
      out.gain.setValueAtTime(out.gain.value, at);
      out.gain.setTargetAtTime(0, at, 0.09);
      oscs.forEach((o) => o.stop(at + 0.7));
      oscs[0].onended = () => {
        try {
          out.disconnect();
        } catch {}
      };
    },
  };
}

function moodVoice(c: AC, p0: MoodParams): Voice {
  const out = gain(c, 0);
  const filter = c.createBiquadFilter();
  filter.type = 'lowpass';
  filter.Q.value = 0.7;
  filter.frequency.value = p0.cutoff;
  const root = osc(c, 'sine', p0.freq);
  const body = osc(c, 'triangle', p0.freq);
  const third = osc(c, 'sine', p0.third);
  const shimmer = osc(c, 'sine', p0.freq * 2);
  const gBody = gain(c, 0.25);
  const gThird = gain(c, 0.55);
  const gShimmer = gain(c, p0.shimmer);
  root.connect(filter);
  body.connect(gBody).connect(filter);
  third.connect(gThird).connect(filter);
  shimmer.connect(gShimmer).connect(filter);
  filter.connect(out);
  const shell = voiceShell(c, [root, body, third, shimmer], out);
  return {
    set(p, at) {
      const m = p as MoodParams;
      root.frequency.setTargetAtTime(m.freq, at, TC);
      body.frequency.setTargetAtTime(m.freq, at, TC);
      third.frequency.setTargetAtTime(m.third, at, TC);
      shimmer.frequency.setTargetAtTime(m.freq * 2, at, TC);
      gShimmer.gain.setTargetAtTime(m.shimmer, at, 0.05);
      filter.frequency.setTargetAtTime(m.cutoff, at, 0.04);
      out.gain.setTargetAtTime(m.gain * 0.5, at, 0.03);
    },
    release: shell.release,
  };
}

function energyVoice(c: AC, p0: EnergyParams): Voice {
  const out = gain(c, 0);
  const filter = c.createBiquadFilter();
  filter.type = 'lowpass';
  filter.Q.value = 1.2;
  filter.frequency.value = p0.cutoff;
  const hum = osc(c, 'triangle', p0.freq);
  const edge = osc(c, 'sawtooth', p0.freq);
  const gEdge = gain(c, p0.edge * 0.5);
  // Tremolo: an LFO added to a gain of (1 − depth/2), so loudness swings between 1 − depth and 1.
  const trem = gain(c, 1 - p0.lfoDepth / 2);
  const lfo = osc(c, 'sine', p0.lfoRate);
  const lfoAmt = gain(c, p0.lfoDepth / 2);
  lfo.connect(lfoAmt).connect(trem.gain);
  hum.connect(filter);
  edge.connect(gEdge).connect(filter);
  filter.connect(trem).connect(out);
  const shell = voiceShell(c, [hum, edge, lfo], out);
  return {
    set(p, at) {
      const e = p as EnergyParams;
      hum.frequency.setTargetAtTime(e.freq, at, TC);
      edge.frequency.setTargetAtTime(e.freq, at, TC);
      gEdge.gain.setTargetAtTime(e.edge * 0.5, at, 0.05);
      filter.frequency.setTargetAtTime(e.cutoff, at, 0.04);
      lfo.frequency.setTargetAtTime(e.lfoRate, at, 0.05);
      lfoAmt.gain.setTargetAtTime(e.lfoDepth / 2, at, 0.05);
      trem.gain.setTargetAtTime(1 - e.lfoDepth / 2, at, 0.05);
      out.gain.setTargetAtTime(e.gain * 0.5, at, 0.03);
    },
    release: shell.release,
  };
}

function connectionVoice(c: AC, p0: ConnectionParams): Voice {
  const out = gain(c, 0);
  const filter = c.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 3000;
  filter.connect(out);
  // Voices sit apart (left and right) when isolated and meet in the center when connected.
  const pan = (v: number): { node: AudioNode; param?: AudioParam } => {
    if (typeof (c as any).createStereoPanner !== 'function') return { node: filter };
    const sp = c.createStereoPanner();
    sp.pan.value = v;
    sp.connect(filter);
    return { node: sp, param: sp.pan };
  };
  const self = osc(c, 'sine', p0.root);
  const partner = osc(c, 'sine', p0.partner);
  const octave = osc(c, 'sine', p0.root * 2);
  const third = osc(c, 'sine', p0.root * 2 * Math.pow(2, 4 / 12));
  const gPartner = gain(c, p0.partnerGain);
  const gOctave = gain(c, p0.octaveGain);
  const gThird = gain(c, p0.thirdGain);
  const panSelf = pan(-p0.spread);
  const panPartner = pan(p0.spread);
  self.connect(panSelf.node);
  partner.connect(gPartner).connect(panPartner.node);
  octave.connect(gOctave).connect(filter);
  third.connect(gThird).connect(filter);
  const shell = voiceShell(c, [self, partner, octave, third], out);
  return {
    set(p, at) {
      const n = p as ConnectionParams;
      partner.frequency.setTargetAtTime(n.partner, at, TC);
      gPartner.gain.setTargetAtTime(n.partnerGain, at, 0.05);
      gOctave.gain.setTargetAtTime(n.octaveGain, at, 0.06);
      gThird.gain.setTargetAtTime(n.thirdGain, at, 0.06);
      panSelf.param?.setTargetAtTime(-n.spread, at, 0.05);
      panPartner.param?.setTargetAtTime(n.spread, at, 0.05);
      out.gain.setTargetAtTime(n.gain * 0.45, at, 0.03);
    },
    release: shell.release,
  };
}

function makeVoice(c: AC, p: FeelParams): Voice {
  if (p.kind === 'mood') return moodVoice(c, p);
  if (p.kind === 'energy') return energyVoice(c, p);
  return connectionVoice(c, p);
}

function armIdle(ms: number) {
  if (idle) clearTimeout(idle);
  idle = setTimeout(feelEnd, ms);
}

/** The slider moved to `level` (0–100). Starts or retunes that feeling's voice. */
export function feelMove(dim: CheckInDimension, level: number) {
  const c = ensure();
  if (!c || !master) return;
  const now = c.currentTime;
  const p = feelParams(dim, level / 100);
  if (active && active.dim !== dim) {
    active.voice.release(now);
    active = null;
  }
  try {
    if (!active) active = { dim, voice: makeVoice(c, p) };
    active.voice.set(p, now);
  } catch {
    active = null;
  }
  armIdle(1100); // holding still for a moment lets the sound rest
}

/** A single keyboard or accessibility step: a short sound that fades on its own. */
export function feelNudge(dim: CheckInDimension, level: number) {
  feelMove(dim, level);
  armIdle(450);
}

/** The slider was let go. */
export function feelEnd() {
  if (idle) {
    clearTimeout(idle);
    idle = null;
  }
  if (active && ctx) active.voice.release(ctx.currentTime);
  active = null;
}
