// Web: the Sanctuary's spring-water loop (public/audio, made by scripts/make-spring-water.py),
// played with Web Audio so the loop has no gap. Fades in and out; stops when the tab is hidden
// or the rest screen closes. A RELATIVE address, so it works at any site path.
import { useEffect } from 'react';

const AudioCtor: (new () => AudioContext) | undefined =
  typeof window !== 'undefined' ? ((window as any).AudioContext || (window as any).webkitAudioContext) : undefined;

export const restSoundSupported = !!AudioCtor;

let ctx: AudioContext | null = null;
let buffer: Promise<AudioBuffer | null> | null = null;

function load(c: AudioContext): Promise<AudioBuffer | null> {
  if (!buffer) {
    buffer = fetch('audio/spring-water.mp3')
      .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(new Error(String(r.status)))))
      .then((b) => c.decodeAudioData(b))
      .catch(() => {
        buffer = null;
        return null;
      });
  }
  return buffer;
}

export function useRestSound(on: boolean) {
  useEffect(() => {
    if (!on || !AudioCtor) return;
    let stopped = false;
    let src: AudioBufferSourceNode | null = null;
    let gain: GainNode | null = null;
    try {
      ctx = ctx ?? new AudioCtor();
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    } catch {
      return;
    }
    const c = ctx;
    load(c).then((b) => {
      if (stopped || !b) return;
      gain = c.createGain();
      gain.gain.setValueAtTime(0, c.currentTime);
      gain.gain.linearRampToValueAtTime(0.5, c.currentTime + 1.5);
      gain.connect(c.destination);
      src = c.createBufferSource();
      src.buffer = b;
      src.loop = true;
      src.connect(gain);
      src.start();
    });
    const stop = () => {
      stopped = true;
      if (src && gain) {
        const s = src;
        const g = gain;
        g.gain.cancelScheduledValues(c.currentTime);
        g.gain.setValueAtTime(g.gain.value, c.currentTime);
        g.gain.linearRampToValueAtTime(0, c.currentTime + 0.6);
        setTimeout(() => {
          try {
            s.stop();
            g.disconnect();
          } catch {}
        }, 700);
      }
    };
    const onHide = () => document.hidden && c.suspend().catch(() => {});
    const onShow = () => !document.hidden && c.resume().catch(() => {});
    const vis = () => (document.hidden ? onHide() : onShow());
    document.addEventListener('visibilitychange', vis);
    return () => {
      document.removeEventListener('visibilitychange', vis);
      stop();
    };
  }, [on]);
}
