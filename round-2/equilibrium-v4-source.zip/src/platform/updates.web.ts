import { useEffect, useState } from 'react';

// public/index.html sets this flag and fires the event when a newer service worker takes over
// while the app is already open (see the registration script there).
const ready = () => typeof window !== 'undefined' && !!(window as any).__companionUpdateReady;

export function useUpdateReady(): boolean {
  const [isReady, setReady] = useState(ready);
  useEffect(() => {
    const on = () => setReady(true);
    window.addEventListener('companion-update-ready', on);
    return () => window.removeEventListener('companion-update-ready', on);
  }, []);
  return isReady;
}

/** Load the new version. Saved entries live in storage, so nothing is lost. */
export function applyUpdate() {
  window.location.reload();
}
