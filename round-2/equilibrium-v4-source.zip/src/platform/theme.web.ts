// Web: the choice lives in this browser's storage (not in the journey, so each device can differ).
// Styles are built when the app loads, so a change takes effect by reloading the page — entries are
// already saved, and any unsaved write is flushed by the store's page-hide handler first.
import { THEME_KEY, ThemeChoice } from '../theme/tokens';

export const themeChoiceSupported = true;

export function setThemeChoice(choice: ThemeChoice): boolean {
  try {
    window.localStorage.setItem(THEME_KEY, choice);
  } catch {
    return false;
  }
  setTimeout(() => window.location.reload(), 150);
  return true;
}
