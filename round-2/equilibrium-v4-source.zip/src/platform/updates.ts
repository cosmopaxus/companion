// Native builds update through the app stores (or Expo updates later); nothing to announce here.
export function useUpdateReady(): boolean {
  return false;
}
export function applyUpdate() {}
