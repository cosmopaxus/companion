// iOS/Android: Equilibrium follows the phone's own light or dark setting for now.
// (Choosing per app needs a storage read before the first style is built — a next step.)
import type { ThemeChoice } from '../theme/tokens';

export const themeChoiceSupported = false;

export function setThemeChoice(_choice: ThemeChoice): boolean {
  return false;
}
