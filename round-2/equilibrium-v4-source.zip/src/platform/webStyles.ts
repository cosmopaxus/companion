import { Platform } from 'react-native';
import { color } from '../theme/tokens';

/** Web-only global CSS: visible keyboard focus, no rings after pointer clicks, calm text rendering. */
export function installWebStyles() {
  if (Platform.OS !== 'web' || typeof document === 'undefined') return;
  if (document.getElementById('companion-web-styles')) return;
  const el = document.createElement('style');
  el.id = 'companion-web-styles';
  el.textContent = `
    @font-face { font-family: Cinzel; src: url(fonts/cinzel-700.woff2) format('woff2'); font-weight: 100 900; font-style: normal; font-display: swap; }
    @font-face { font-family: Nunito; src: url(fonts/nunito-400.woff2) format('woff2'); font-weight: 100 500; font-style: normal; font-display: swap; }
    @font-face { font-family: Nunito; src: url(fonts/nunito-600.woff2) format('woff2'); font-weight: 600; font-style: normal; font-display: swap; }
    @font-face { font-family: Nunito; src: url(fonts/nunito-700.woff2) format('woff2'); font-weight: 700 900; font-style: normal; font-display: swap; }
    html, body { background: ${color.canvas}; -webkit-font-smoothing: antialiased; }
    [role="button"]:focus-visible, [role="link"]:focus-visible, [role="tab"]:focus-visible,
    [role="radio"]:focus-visible, [role="checkbox"]:focus-visible, [role="switch"]:focus-visible, [role="slider"]:focus-visible,
    a:focus-visible, button:focus-visible {
      outline: 2px solid ${color.actionText} !important; outline-offset: 2px; border-radius: 12px;
    }
    *:focus:not(:focus-visible) { outline: none; }
    textarea, input { caret-color: ${color.actionText}; }
    ::selection { background: ${color.sageWash}; }
    @media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; } }
  `;
  document.head.appendChild(el);
}
