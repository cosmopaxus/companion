// iOS/Android: write the backup to the cache and open the share sheet (Save to Files, AirDrop,
// email…); restore by picking a JSON file with the system picker.
// Compiled and bundled for iOS/Android; not yet exercised on a physical device in this build.
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Clipboard from 'expo-clipboard';

export type ExportResult = { ok: true; method: 'download' | 'share' } | { ok: false; error: string };
export type PickResult = { ok: true; text: string; name?: string } | { ok: false; canceled?: boolean; error?: string };

export async function exportBackupFile(text: string, filename: string, mime = 'application/json'): Promise<ExportResult> {
  try {
    const file = new File(Paths.cache, filename);
    if (file.exists) file.delete();
    file.create();
    file.write(text);
    const json = mime === 'application/json';
    if (!(await Sharing.isAvailableAsync())) return { ok: false, error: json ? 'Sharing is not available on this device. Use "Copy backup text" instead.' : 'Sharing is not available on this device.' };
    await Sharing.shareAsync(file.uri, { mimeType: mime, dialogTitle: json ? 'Save your Equilibrium backup' : 'Save your journal', UTI: json ? 'public.json' : 'public.plain-text' });
    return { ok: true, method: 'share' };
  } catch {
    return { ok: false, error: mime === 'application/json' ? 'Could not prepare the backup file. Use "Copy backup text" instead.' : 'Could not prepare the file.' };
  }
}

export async function pickBackupFile(): Promise<PickResult> {
  try {
    const res = await File.pickFileAsync({ mimeTypes: ['application/json', 'text/plain'] } as any);
    if (!res || (res as any).canceled) return { ok: false, canceled: true };
    const picked: any = (res as any).result ?? res;
    const file: File = Array.isArray(picked) ? picked[0] : picked;
    const text = await file.text();
    return { ok: true, text, name: (file as any).name };
  } catch {
    return { ok: false, error: 'That file could not be opened.' };
  }
}

export async function copyText(text: string): Promise<boolean> {
  try {
    return await Clipboard.setStringAsync(text);
  } catch {
    return false;
  }
}

export const exportLabel = 'Save or share backup file';
export const pickLabel = 'Choose a backup file';
