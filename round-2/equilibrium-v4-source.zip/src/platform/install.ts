// Native apps are installed from a store or a build; nothing to do here.
export interface InstallState {
  supported: boolean;
  standalone: boolean;
  canPrompt: boolean;
  ios: boolean;
  prompt: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
}

export function useInstall(): InstallState {
  return { supported: false, standalone: true, canPrompt: false, ios: false, prompt: async () => 'unavailable' };
}

export function requestPersistentStorage() {}
