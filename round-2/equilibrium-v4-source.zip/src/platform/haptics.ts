import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

// Haptics are only used where supported (iOS/Android) and when the person has them on.
let enabled = true;

export function setHapticsEnabled(v: boolean) {
  enabled = v;
}

export const hapticsSupported = Platform.OS === 'ios' || Platform.OS === 'android';

export function tapFeedback() {
  if (!enabled || !hapticsSupported) return;
  Haptics.selectionAsync().catch(() => {});
}

export function successFeedback() {
  if (!enabled || !hapticsSupported) return;
  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
}
