// Native build: no slider sound yet (Web Audio isn't available in React Native). The slider still
// gives a light haptic tick as it crosses from one word to the next. See feelSound.web.ts.
import type { CheckInDimension } from '../domain/scales';

export const soundSupported = false;
export function setSoundEnabled(_v: boolean) {}
export function primeSound() {}
export function feelMove(_dim: CheckInDimension, _level: number) {}
export function feelNudge(_dim: CheckInDimension, _level: number) {}
export function feelEnd() {}
