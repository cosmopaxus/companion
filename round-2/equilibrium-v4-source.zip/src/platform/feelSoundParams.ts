// What each check-in feeling sounds like at a position t from 0 (low end) to 1 (high end).
// Pure numbers, so the mapping can be unit-tested without an audio device.
//
//   Mood        a two-note chord climbing a scale: low and minor with a muffled tone when heavy,
//               higher and major with an open, bright tone when bright.
//   Energy      a pulsing hum: low, slow and dull when depleted; higher, quick and buzzing when charged.
//   Connection  two voices: far apart in space and out of tune when isolated, moving to the center
//               and settling into a clean fifth, then a full chord, when connected.

import type { CheckInDimension } from '../domain/scales';

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const expMap = (lo: number, hi: number, t: number) => lo * Math.pow(hi / lo, clamp01(t));

// D minor pentatonic in the lower half, D major pentatonic in the upper half (semitones above D3).
const MOOD_STEPS = [0, 3, 5, 7, 10, 12, 14, 16, 19, 21, 24];
const D3 = 146.83;

export interface MoodParams { kind: 'mood'; freq: number; third: number; shimmer: number; cutoff: number; gain: number }
export interface EnergyParams { kind: 'energy'; freq: number; lfoRate: number; lfoDepth: number; cutoff: number; edge: number; gain: number }
export interface ConnectionParams { kind: 'connection'; root: number; partner: number; partnerGain: number; octaveGain: number; thirdGain: number; spread: number; gain: number }
export type FeelParams = MoodParams | EnergyParams | ConnectionParams;

export function moodParams(t: number): MoodParams {
  const k = clamp01(t);
  const step = MOOD_STEPS[Math.round(k * (MOOD_STEPS.length - 1))];
  const freq = D3 * Math.pow(2, step / 12);
  const thirdSemis = k < 0.5 ? 3 : 4; // minor third when heavy, major third when bright
  return {
    kind: 'mood',
    freq,
    third: freq * Math.pow(2, thirdSemis / 12),
    shimmer: clamp01((k - 0.6) / 0.4) * 0.3,
    cutoff: expMap(380, 5200, k),
    gain: 0.55 + 0.25 * k,
  };
}

export function energyParams(t: number): EnergyParams {
  const k = clamp01(t);
  return {
    kind: 'energy',
    freq: 98 * Math.pow(2, 2 * k), // G2 → G4
    lfoRate: expMap(0.6, 11, k),
    lfoDepth: 0.55 - 0.25 * k,
    cutoff: expMap(320, 4200, k),
    edge: 0.08 + 0.42 * k, // how much bright sawtooth is mixed in
    gain: 0.45 + 0.35 * k,
  };
}

export function connectionParams(t: number): ConnectionParams {
  const k = clamp01(t);
  const root = 196; // G3
  const detuneCents = Math.pow(1 - k, 1.5) * 70;
  return {
    kind: 'connection',
    root,
    partner: root * 1.5 * Math.pow(2, detuneCents / 1200),
    partnerGain: 0.25 + 0.55 * k,
    octaveGain: clamp01((k - 0.45) / 0.35) * 0.5,
    thirdGain: clamp01((k - 0.7) / 0.3) * 0.4,
    spread: (1 - k) * 0.75,
    gain: 0.6 + 0.2 * k,
  };
}

export function feelParams(dim: CheckInDimension, t: number): FeelParams {
  return dim === 'mood' ? moodParams(t) : dim === 'energy' ? energyParams(t) : connectionParams(t);
}
