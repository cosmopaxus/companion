// Native build: the Sanctuary's spring-water loop, played with expo-audio. The player is made when
// sound starts and released when it stops or the rest screen closes. See restSound.web.ts for web.
import { useEffect } from 'react';
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';

export const restSoundSupported = true;

const SPRING = require('../../public/audio/spring-water.mp3');

export function useRestSound(on: boolean) {
  useEffect(() => {
    if (!on) return;
    // Plays with the ringer switch off (the user turned it on) and mixes with other audio.
    setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'mixWithOthers' }).catch(() => {});
    const player = createAudioPlayer(SPRING);
    player.loop = true;
    player.volume = 0.55;
    player.play();
    return () => {
      player.pause();
      player.release();
    };
  }, [on]);
}
