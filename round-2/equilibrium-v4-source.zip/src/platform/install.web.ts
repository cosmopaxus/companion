// Web install support ("Add to Home Screen"). Chrome/Edge/Android fire `beforeinstallprompt`,
// which we keep so an Install button can use it; iOS Safari has no prompt, only Share → Add to Home Screen.
import { useEffect, useState } from 'react';

let deferred: any = null;
const listeners = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e: any) => {
    e.preventDefault();
    deferred = e;
    listeners.forEach((l) => l());
  });
  window.addEventListener('appinstalled', () => {
    deferred = null;
    listeners.forEach((l) => l());
  });
}

export interface InstallState {
  /** False inside hosts where installing makes no sense (e.g. the claude.ai preview frame). */
  supported: boolean;
  standalone: boolean;
  canPrompt: boolean;
  ios: boolean;
  prompt: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
}

function read(): Omit<InstallState, 'prompt'> {
  if (typeof window === 'undefined') return { supported: false, standalone: false, canPrompt: false, ios: false };
  const hosted = document.documentElement.getAttribute('data-host-safe-area') === '1';
  const standalone = window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true;
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  return { supported: !hosted, standalone, canPrompt: !!deferred, ios };
}

export function useInstall(): InstallState {
  const [s, setS] = useState(read);
  useEffect(() => {
    const l = () => setS(read());
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);
  return {
    ...s,
    prompt: async () => {
      if (!deferred) return 'unavailable';
      deferred.prompt();
      const choice = await deferred.userChoice.catch(() => ({ outcome: 'dismissed' }));
      deferred = null;
      listeners.forEach((l) => l());
      return choice?.outcome === 'accepted' ? 'accepted' : 'dismissed';
    },
  };
}

let asked = false;
/** Ask the browser to keep this site's storage (reduces eviction of a local-only journey). Best effort. */
export function requestPersistentStorage() {
  if (asked || typeof navigator === 'undefined' || !navigator.storage?.persist) return;
  asked = true;
  navigator.storage.persisted?.().then((already) => (already ? undefined : navigator.storage.persist())).catch(() => {});
}
