// Web: download a JSON file, or read one the person picks.
import * as Clipboard from 'expo-clipboard';

export type ExportResult = { ok: true; method: 'download' | 'share' } | { ok: false; error: string };
export type PickResult = { ok: true; text: string; name?: string } | { ok: false; canceled?: boolean; error?: string };

/**
 * When the app runs as a published claude.ai page, the viewer's frame blocks page-initiated downloads;
 * the host's `downloads` capability offers the file instead (the viewer confirms). Elsewhere, a normal download.
 */
async function hostDownloads(): Promise<any | null> {
  const claude = typeof window !== 'undefined' ? (window as any).claude : undefined;
  if (!claude || typeof claude.use !== 'function') return null;
  try {
    return await Promise.race([claude.use('downloads'), new Promise((r) => setTimeout(() => r(null), 4000))]);
  } catch {
    return null;
  }
}

export async function exportBackupFile(text: string, filename: string, mime = 'application/json'): Promise<ExportResult> {
  const host = await hostDownloads();
  if (host) {
    try {
      await host.save({ filename, data: text });
      return { ok: true, method: 'share' };
    } catch (e: any) {
      if (e?.code === 'declined') return { ok: false, error: 'Download canceled. Nothing was saved.' };
      if (e?.code === 'rate_limited') return { ok: false, error: 'A save prompt is already open. Try again in a moment.' };
      // Otherwise fall through to a plain download attempt.
    }
  }
  try {
    const blob = new Blob([text], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return { ok: true, method: 'download' };
  } catch {
    return { ok: false, error: mime === 'application/json' ? 'This browser blocked the download. Use "Copy backup text" instead.' : 'This browser blocked the download. Try again, or try another browser.' };
  }
}

export function pickBackupFile(): Promise<PickResult> {
  return new Promise((resolve) => {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/json,.json,text/plain';
      input.style.display = 'none';
      document.body.appendChild(input);
      const done = (r: PickResult) => {
        input.remove();
        resolve(r);
      };
      input.addEventListener('cancel', () => done({ ok: false, canceled: true }));
      input.addEventListener('change', () => {
        const file = input.files?.[0];
        if (!file) return done({ ok: false, canceled: true });
        if (file.size > 15 * 1024 * 1024) return done({ ok: false, error: 'That file is too large to be an Equilibrium backup.' });
        const reader = new FileReader();
        reader.onload = () => done({ ok: true, text: String(reader.result ?? ''), name: file.name });
        reader.onerror = () => done({ ok: false, error: 'That file could not be read.' });
        reader.readAsText(file);
      });
      input.click();
    } catch {
      resolve({ ok: false, error: 'This browser cannot open files here. Paste the backup text instead.' });
    }
  });
}

export async function copyText(text: string): Promise<boolean> {
  try {
    return await Clipboard.setStringAsync(text);
  } catch {
    return false;
  }
}

export const exportLabel = 'Download backup file';
export const pickLabel = 'Choose a backup file';
