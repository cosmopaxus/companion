import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import type { Evidence } from '../domain/types';
import { color } from '../theme/tokens';

/**
 * A field-notebook strip of marks, oldest → newest: ● win, ○ observation, ◇ setback.
 * Shape carries meaning (not only color). Evidence, not a percentage.
 */
export function EvidenceMarks({ evidence, max = 18 }: { evidence: Evidence[]; max?: number }) {
  const list = [...evidence].sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1)).slice(-max);
  if (!list.length) return null;
  const step = 16;
  const w = list.length * step;
  return (
    <View aria-hidden style={{ height: 14 }}>
      <Svg width={w} height={14}>
        {list.map((e, i) => {
          const x = i * step + 7;
          if (e.kind === 'win') return <Circle key={e.id} cx={x} cy={7} r={5} fill={color.sage} />;
          if (e.kind === 'observation') return <Circle key={e.id} cx={x} cy={7} r={4.3} fill="none" stroke={color.gold} strokeWidth={1.8} />;
          return <Path key={e.id} d={`M${x} 1.8 L${x + 5.2} 7 L${x} 12.2 L${x - 5.2} 7 Z`} fill="none" stroke={color.caution} strokeWidth={1.7} />;
        })}
      </Svg>
    </View>
  );
}
