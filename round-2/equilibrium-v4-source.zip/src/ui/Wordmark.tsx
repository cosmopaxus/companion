import React from 'react';
import { Text, View } from 'react-native';
import Svg, { Path, Circle } from 'react-native-svg';
import { color, serif } from '../theme/tokens';

/** Restrained lowercase wordmark with a small sprouting mark. */
export function Wordmark({ size = 22, tone = color.ink }: { size?: number; tone?: string }) {
  const m = size * 0.9;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: size * 0.28 }} aria-label="equilibrium" role="img">
      <Svg width={m} height={m} viewBox="0 0 24 24" aria-hidden>
        <Circle cx={12} cy={12} r={10.2} fill="none" stroke={color.goldDeco} strokeWidth={1.4} />
        <Path d="M12 18.5v-6.2" stroke={color.sage} strokeWidth={1.8} strokeLinecap="round" />
        <Path d="M12 12.6c0-3.1 2.1-5 5.2-5 0 3.1-2.1 5-5.2 5z" fill={color.sage} />
        <Path d="M12 14.4c0-2.3-1.6-3.8-4-3.8 0 2.3 1.6 3.8 4 3.8z" fill={color.sage2} />
      </Svg>
      <Text style={{ fontFamily: serif, fontSize: size, color: tone, letterSpacing: 0.2 }} aria-hidden>
        equilibrium
      </Text>
    </View>
  );
}
