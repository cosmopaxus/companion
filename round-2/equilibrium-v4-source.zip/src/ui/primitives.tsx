import React from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  PressableProps,
  StyleProp,
  StyleSheet,
  Text,
  TextProps,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';
import { color, radius, shadow, space, type, TOUCH } from '../theme/tokens';
import { Gem, Icon, IconName } from './Icon';

// ——— Text ———

type Variant = keyof typeof type;

export function T({ variant = 'body', style, ...rest }: TextProps & { variant?: Variant }) {
  const heading = variant === 'display' || variant === 'title' || variant === 'heading';
  return <Text role={heading ? 'heading' : undefined} {...rest} style={[type[variant] as TextStyle, style]} />;
}

// ——— Focus + press feedback shared by every control ———

export type PressState = { pressed: boolean; hovered?: boolean; focused?: boolean };

/**
 * Keyboard focus on web is drawn by a global :focus-visible rule (see platform/webStyles.ts),
 * so pointer users don't see rings after a click. Kept as a hook for per-control tweaks.
 */
export function focusRing(_s: PressState): ViewStyle {
  return {};
}

/** Space activates radios, checkboxes and switches on web (react-native-web only does this for role="button"). */
export function spaceKey(fn: () => void): { onKeyDown?: (e: any) => void } {
  if (Platform.OS !== 'web') return {};
  return {
    onKeyDown: (e: any) => {
      if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        fn();
      }
    },
  };
}

// ——— Buttons ———

type ButtonKind = 'primary' | 'secondary' | 'quiet' | 'danger' | 'gold' | 'urgent';

interface ButtonProps extends Omit<PressableProps, 'style' | 'children'> {
  label: string;
  kind?: ButtonKind;
  icon?: IconName;
  iconRight?: IconName;
  busy?: boolean;
  full?: boolean;
  small?: boolean;
  style?: StyleProp<ViewStyle>;
  accessibilityHint?: string;
  role?: 'button' | 'link';
  /** Painted academy: a small "+N" gem pill after the label (what this earns). Decoration; the toast says it too. */
  gems?: number;
}

export function Button({ label, kind = 'primary', icon, iconRight, busy, full, small, disabled, style, role = 'button', gems, ...rest }: ButtonProps) {
  const palette = {
    primary: { bg: color.action, fg: color.onAction, border: color.action, pressedBg: color.actionPressed, lip: color.actionLip },
    gold: { bg: color.gold, fg: color.paperStrong, border: color.gold, pressedBg: color.goldPressed, lip: color.goldLip },
    secondary: { bg: 'transparent', fg: color.actionText, border: color.actionText, pressedBg: color.actionWash, lip: color.actionText },
    quiet: { bg: 'transparent', fg: color.actionText, border: 'transparent', pressedBg: color.actionWash, lip: 'transparent' },
    danger: { bg: 'transparent', fg: color.caution, border: color.caution, pressedBg: color.cautionWash, lip: color.caution },
    urgent: { bg: color.caution, fg: color.paperStrong, border: color.caution, pressedBg: color.cautionPressed, lip: color.cautionLip },
  }[kind];
  const solid = kind === 'primary' || kind === 'gold' || kind === 'urgent';
  const isDisabled = disabled || busy;
  return (
    <Pressable
      role={role}
      aria-label={label}
      aria-disabled={isDisabled || undefined}
      accessibilityState={{ disabled: !!isDisabled, busy: !!busy }}
      disabled={isDisabled}
      hitSlop={small ? 6 : 0}
      {...rest}
      style={(s: any) => [
        styles.button,
        small && styles.buttonSmall,
        full && { alignSelf: 'stretch' },
        { backgroundColor: s.pressed ? palette.pressedBg : s.hovered && kind !== 'primary' && kind !== 'gold' && kind !== 'urgent' ? color.actionWash : palette.bg, borderColor: palette.border },
        // v3 frame: solid buttons sit on a lip and press down into it, like a game key.
        solid && { borderBottomWidth: s.pressed && !isDisabled ? 1.5 : 4.5, borderBottomColor: palette.lip, marginTop: s.pressed && !isDisabled ? 3 : 0 },
        kind === 'quiet' && styles.buttonQuiet,
        isDisabled && styles.disabled,
        focusRing(s),
        style,
      ]}
    >
      {busy ? <ActivityIndicator color={palette.fg} size="small" /> : icon ? <Icon name={icon} size={small ? 18 : 20} color={palette.fg} strokeWidth={2} /> : null}
      <Text style={[styles.buttonText, small && styles.buttonTextSmall, { color: palette.fg }]} numberOfLines={2}>
        {label}
      </Text>
      {gems ? (
        <View style={[styles.gemPill, solid ? styles.gemPillOnSolid : styles.gemPillOnLight]} aria-hidden testID="button-gems">
          <Gem size={13} tone={solid ? 'light' : 'gold'} />
          <Text style={[styles.gemPillText, { color: solid ? palette.fg : color.goldPressed }]}>+{gems}</Text>
        </View>
      ) : null}
      {iconRight ? <Icon name={iconRight} size={small ? 16 : 18} color={palette.fg} strokeWidth={2} /> : null}
    </Pressable>
  );
}

export function IconButton({ icon, label, onPress, tone = color.ink, size = 22, style, testID }: { icon: IconName; label: string; onPress: () => void; tone?: string; size?: number; style?: StyleProp<ViewStyle>; testID?: string }) {
  return (
    <Pressable
      testID={testID}
      role="button"
      aria-label={label}
      onPress={onPress}
      hitSlop={6}
      style={(s: any) => [styles.iconButton, (s.pressed || s.hovered) && { backgroundColor: color.actionWash }, focusRing(s), style]}
    >
      <Icon name={icon} size={size} color={tone} strokeWidth={2} />
    </Pressable>
  );
}

// ——— Surfaces ———

export function Card({ children, style, tone = 'paper', padded = true, testID }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; tone?: 'paper' | 'gold' | 'sage' | 'practice' | 'caution' | 'strong'; padded?: boolean; testID?: string }) {
  // Today's look: paper cards are nearly solid glass on a chunky lip; tinted cards keep their wash.
  const glass = tone === 'paper' || tone === 'strong';
  const bg = { paper: color.cardGlass, strong: color.cardGlass, gold: color.goldWash, sage: color.sageWash, practice: color.paperStrong, caution: color.cautionWash }[tone];
  return (
    <View
      testID={testID}
      style={[
        styles.card,
        shadow,
        { backgroundColor: bg },
        tone === 'gold' && { borderColor: color.goldBorder },
        tone === 'sage' && { borderColor: color.sageBorder },
        tone === 'caution' && { borderColor: color.cautionBorder },
        tone === 'practice' && styles.practiceCard,
        !padded && { padding: 0 },
        glass && { borderColor: color.cardEdge, borderBottomColor: color.lip },
        style,
      ]}
    >
      {children}
    </View>
  );
}

/** Small uppercase label. With `heading`, it is a level-2 heading for screen-reader navigation. */
export function Eyebrow({ children, style, tone, heading }: { children: React.ReactNode; style?: StyleProp<TextStyle>; tone?: string; heading?: boolean }) {
  return (
    <Text role={heading ? 'heading' : undefined} aria-level={heading ? 2 : undefined} style={[type.eyebrow, tone ? { color: tone } : null, style]}>
      {children}
    </Text>
  );
}

export function Divider({ style }: { style?: StyleProp<ViewStyle> }) {
  return <View style={[{ height: StyleSheet.hairlineWidth, backgroundColor: color.border, marginVertical: space.md }, style]} />;
}

export function Gap({ h = space.md }: { h?: number }) {
  return <View style={{ height: h }} />;
}

// ——— Chips, tags ———

export function Tag({ label, tone = 'neutral', icon }: { label: string; tone?: 'neutral' | 'sage' | 'gold' | 'caution' | 'practice'; icon?: IconName }) {
  const t = {
    neutral: { bg: color.canvas, fg: color.inkSoft, border: color.border },
    sage: { bg: color.sageWash, fg: color.sage, border: color.sageBorder },
    gold: { bg: color.goldWash, fg: color.gold, border: color.goldBorder },
    caution: { bg: color.cautionWash, fg: color.caution, border: color.cautionBorder },
    practice: { bg: color.goldWash, fg: color.gold, border: color.goldDeco },
  }[tone];
  return (
    <View style={[styles.tag, { backgroundColor: t.bg, borderColor: t.border }, tone === 'practice' && { borderStyle: 'dashed' }]}>
      {icon ? <Icon name={icon} size={14} color={t.fg} strokeWidth={2} /> : null}
      <Text style={[styles.tagText, { color: t.fg }]}>{label}</Text>
    </View>
  );
}

export function Chip({ label, selected, onPress, icon, accessibilityLabel, radio, testID }: { label: string; selected?: boolean; onPress: () => void; icon?: IconName; accessibilityLabel?: string; radio?: boolean; testID?: string }) {
  return (
    <Pressable
      testID={testID}
      role={radio ? 'radio' : 'button'}
      aria-pressed={radio ? undefined : selected}
      aria-checked={radio ? !!selected : undefined}
      aria-label={accessibilityLabel ?? label}
      onPress={onPress}
      {...(radio ? spaceKey(onPress) : {})}
      style={(s: any) => [
        styles.chip,
        selected ? { backgroundColor: color.action, borderColor: color.action } : { backgroundColor: s.hovered || s.pressed ? color.actionWash : color.paper },
        focusRing(s),
      ]}
    >
      {selected ? <Icon name="check" size={14} color={color.onAction} strokeWidth={2.4} /> : icon ? <Icon name={icon} size={14} color={color.actionText} strokeWidth={2} /> : null}
      <Text style={[styles.chipText, selected && { color: color.onAction }]}>{label}</Text>
    </Pressable>
  );
}

// ——— Notices ———

export function Notice({ children, tone = 'info', icon, title, action, testID }: { children?: React.ReactNode; tone?: 'info' | 'caution' | 'preview' | 'success'; icon?: IconName; title?: string; action?: React.ReactNode; testID?: string }) {
  const t = {
    info: { bg: color.paperStrong, border: color.border, fg: color.inkSoft, ic: color.sage2, def: 'info' as IconName },
    caution: { bg: color.cautionWash, border: color.cautionBorder, fg: color.caution, ic: color.caution, def: 'info' as IconName },
    preview: { bg: color.goldWash, border: color.goldBorder, fg: color.ink, ic: color.gold, def: 'sparkle' as IconName },
    success: { bg: color.sageWash, border: color.sageBorder, fg: color.sage, ic: color.sage, def: 'check' as IconName },
  }[tone];
  return (
    <View testID={testID} style={[styles.notice, { backgroundColor: t.bg, borderColor: t.border }]} role={tone === 'caution' ? 'alert' : undefined}>
      <View style={{ paddingTop: 1 }}>
        <Icon name={icon ?? t.def} size={18} color={t.ic} strokeWidth={2} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        {title ? <Text style={[type.label, { color: tone === 'caution' ? color.caution : color.ink }]}>{title}</Text> : null}
        {children == null ? null : React.isValidElement(children) ? children : <Text style={[type.small, { color: tone === 'caution' ? color.caution : tone === 'success' ? color.sage : color.inkSoft }]}>{children}</Text>}
        {action ? <View style={{ marginTop: space.sm, flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>{action}</View> : null}
      </View>
    </View>
  );
}

// ——— Settings-style rows ———

export function Row({
  icon,
  title,
  detail,
  value,
  onPress,
  last,
  tone,
  right,
}: {
  icon?: IconName;
  title: string;
  detail?: string;
  value?: string;
  onPress?: () => void;
  last?: boolean;
  tone?: string;
  right?: React.ReactNode;
}) {
  const content = (
    <>
      {icon ? (
        <View style={styles.rowIcon}>
          <Icon name={icon} size={20} color={tone ?? color.sage} strokeWidth={1.9} />
        </View>
      ) : null}
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={[type.label, tone ? { color: tone } : null]}>{title}</Text>
        {detail ? <Text style={type.small}>{detail}</Text> : null}
      </View>
      {value ? <Text style={[type.small, { maxWidth: 150, textAlign: 'right' }]}>{value}</Text> : null}
      {right}
      {onPress ? <Icon name="chevron" size={18} color={color.inkSoft} /> : null}
    </>
  );
  if (!onPress) return <View style={[styles.row, !last && styles.rowBorder]}>{content}</View>;
  return (
    <Pressable
      role="button"
      aria-label={value ? `${title}, ${value}` : title}
      onPress={onPress}
      style={(s: any) => [styles.row, !last && styles.rowBorder, (s.pressed || s.hovered) && { backgroundColor: color.canvas }, focusRing(s)]}
    >
      {content}
    </Pressable>
  );
}

export function Section({ title, children, style, caption }: { title?: string; caption?: string; children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[{ gap: space.sm }, style]}>
      {title ? (
        <Eyebrow heading style={{ marginLeft: 4 }}>
          {title}
        </Eyebrow>
      ) : null}
      <Card padded={false} style={{ overflow: 'hidden' }}>
        {children}
      </Card>
      {caption ? <Text style={[type.small, { marginHorizontal: 4 }]}>{caption}</Text> : null}
    </View>
  );
}

export function Toggle({ value, onChange, label, disabled, testID }: { value: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean; testID?: string }) {
  return (
    <Pressable
      testID={testID}
      role="switch"
      aria-checked={value}
      aria-label={label}
      aria-disabled={disabled || undefined}
      disabled={disabled}
      onPress={() => onChange(!value)}
      {...spaceKey(() => !disabled && onChange(!value))}
      hitSlop={8}
      style={(s: any) => [styles.toggle, { backgroundColor: value ? color.action : color.controlBorder }, disabled && styles.disabled, focusRing(s)]}
    >
      <View style={[styles.knob, { transform: [{ translateX: value ? 20 : 0 }] }]}>
        {value ? <Icon name="check" size={14} color={color.action} strokeWidth={2.6} /> : null}
      </View>
    </Pressable>
  );
}

export const styles = StyleSheet.create({
  button: {
    minHeight: 52,
    paddingHorizontal: 22,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.sm,
    alignSelf: 'flex-start',
  },
  buttonSmall: { minHeight: 44, paddingHorizontal: 14 },
  buttonQuiet: { paddingHorizontal: 12 },
  gemPill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 },
  gemPillOnSolid: { backgroundColor: 'rgba(255,255,255,0.16)' },
  gemPillOnLight: { backgroundColor: color.goldWash },
  gemPillText: { fontSize: 13, lineHeight: 17, fontWeight: '800' },
  buttonText: { fontSize: 16, fontWeight: '600', letterSpacing: 0.1, textAlign: 'center' },
  buttonTextSmall: { fontSize: 14.5 },
  disabled: { opacity: 0.45 },
  iconButton: { width: TOUCH, height: TOUCH, borderRadius: radius.pill, alignItems: 'center', justifyContent: 'center' },
  card: {
    borderRadius: 22,
    borderWidth: 1,
    borderBottomWidth: 4,
    borderColor: color.border,
    padding: space.xl,
  },
  practiceCard: { borderStyle: 'dashed', borderColor: color.goldDeco, borderWidth: 1.5 },
  tag: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill, borderWidth: 1, alignSelf: 'flex-start' },
  tagText: { fontSize: 13, fontWeight: '600', lineHeight: 17 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44, paddingHorizontal: 14, borderRadius: radius.pill, borderWidth: 1, borderColor: color.controlBorder },
  chipText: { fontSize: 14.5, color: color.ink, fontWeight: '500' },
  notice: { flexDirection: 'row', gap: space.md, padding: space.lg, borderRadius: radius.md, borderWidth: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: 14, minHeight: 60 },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
  rowIcon: { width: 36, height: 36, borderRadius: radius.pill, backgroundColor: color.canvas, alignItems: 'center', justifyContent: 'center' },
  toggle: { width: 50, height: 30, borderRadius: radius.pill, padding: 3, justifyContent: 'center' },
  knob: { width: 24, height: 24, borderRadius: 12, backgroundColor: color.paperStrong, alignItems: 'center', justifyContent: 'center' },
});
