// Small pieces for the game layer: progress bars, medallions, stat tiles and element levels.
// Shape and words carry meaning as well as color, so nothing depends on color alone.

import React from 'react';
import { StyleSheet, Text, View, ViewStyle, StyleProp } from 'react-native';
import type { ElementId, TierId } from '../domain/types';
import { ELEMENTS } from '../domain/harmony';
import type { ElementPractice } from '../domain/paths';
import { color, elementColor, elementText, elementWash, radius, serif, space, type } from '../theme/tokens';
import { ElementGlyph, Icon, IconName } from './Icon';

export function ProgressBar({ value, max, tone = color.sage, height = 8, label, testID }: { value: number; max: number; tone?: string; height?: number; label?: string; testID?: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  return (
    <View role="progressbar" aria-valuemin={0} aria-valuemax={max} aria-valuenow={value} aria-label={label} testID={testID} style={[st.track, { height, borderRadius: height / 2 }]}>
      <View style={{ width: `${pct * 100}%`, height, borderRadius: height / 2, backgroundColor: tone }} />
    </View>
  );
}

export type NodeState = 'done' | 'now' | 'open' | 'locked' | 'outline';

/** A lesson medallion on the path. Done: filled with a check. Now: gold ring. Open: outlined. Locked/outline: dashed. */
export function Medallion({ state, icon, element, size = 60 }: { state: NodeState; icon?: IconName; element?: ElementId; size?: number }) {
  const base: ViewStyle = { width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center' };
  if (state === 'done')
    return (
      <View style={[base, { backgroundColor: color.sage, borderWidth: 3, borderColor: color.sageBorder }]}>
        <Icon name="check" size={size * 0.42} color={color.onSage} strokeWidth={2.8} />
      </View>
    );
  if (state === 'now')
    return (
      <View style={[base, { width: size + 12, height: size + 12, borderRadius: (size + 12) / 2, borderWidth: 3, borderColor: color.goldDeco, backgroundColor: color.goldWash }]}>
        <View style={[base, { backgroundColor: color.paperStrong, borderWidth: 2, borderColor: color.gold }]}>
          {element ? <ElementGlyph element={element} size={size * 0.45} color={elementText[element]} /> : <Icon name={icon ?? 'star'} size={size * 0.42} color={color.gold} strokeWidth={2} />}
        </View>
      </View>
    );
  if (state === 'open')
    return (
      <View style={[base, { backgroundColor: color.paperStrong, borderWidth: 2, borderColor: color.sage2 }]}>
        {element ? <ElementGlyph element={element} size={size * 0.42} color={elementText[element]} /> : <Icon name={icon ?? 'leaf'} size={size * 0.4} color={color.sage2} strokeWidth={2} />}
      </View>
    );
  return (
    <View style={[base, { backgroundColor: color.canvas, borderWidth: 2, borderStyle: 'dashed', borderColor: color.controlBorder }]}>
      <Icon name={state === 'locked' ? 'lock' : 'leaf'} size={size * 0.36} color={color.inkSoft} strokeWidth={1.8} />
    </View>
  );
}

const TIER_ICON: Record<TierId, IconName> = { foundation: 'leaf', acolyte: 'observation', initiate: 'compass', adept: 'star' };

export function TierBadge({ tier, size = 40, open = true }: { tier: TierId; size?: number; open?: boolean }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center', backgroundColor: open ? color.goldWash : color.canvas, borderWidth: 1.5, borderColor: open ? color.goldDeco : color.controlBorder, borderStyle: open ? 'solid' : 'dashed' }}>
      <Icon name={TIER_ICON[tier]} size={size * 0.5} color={open ? color.gold : color.inkSoft} strokeWidth={1.9} />
    </View>
  );
}

export function StatTile({ label, value, sub, icon, testID, style }: { label: string; value: string | number; sub?: string; icon?: IconName; testID?: string; style?: StyleProp<ViewStyle> }) {
  return (
    <View role="img" style={[st.tile, style]} testID={testID} aria-label={`${label}: ${value}${sub ? `, ${sub}` : ''}`}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        {icon ? <Icon name={icon} size={16} color={color.sage2} strokeWidth={2} /> : null}
        <Text style={[type.small, { flex: 1 }]} numberOfLines={1}>
          {label}
        </Text>
      </View>
      <Text style={st.tileValue}>{value}</Text>
      {sub ? <Text style={[type.small, { fontSize: 12.5, lineHeight: 16 }]}>{sub}</Text> : null}
    </View>
  );
}

/** One element's practice level. Only grows: a level is earned and never taken back. */
export function ElementLevel({ element, practice, testID }: { element: ElementId; practice: ElementPractice; testID?: string }) {
  const name = ELEMENTS[element].name;
  return (
    <View role="img" style={[st.elRow, { backgroundColor: elementWash[element] }]} testID={testID} aria-label={`${name}: level ${practice.level}. ${practice.count} practice${practice.count === 1 ? '' : 's'}. ${practice.perLevel - practice.intoLevel} to the next level.`}>
      <View style={st.elGlyph}>
        <ElementGlyph element={element} size={22} color={elementText[element]} />
      </View>
      <View style={{ flex: 1, gap: 6 }}>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <Text style={[type.label, { color: elementText[element] }]}>
            {name} · Level {practice.level}
          </Text>
          <Text style={[type.small, { fontSize: 12.5 }]}>
            {practice.count} practice{practice.count === 1 ? '' : 's'}
          </Text>
        </View>
        <ProgressBar value={practice.intoLevel} max={practice.perLevel} tone={elementColor[element]} height={7} label={`${name} progress to level ${practice.level + 1}`} />
      </View>
    </View>
  );
}

export function RankMark({ initial, size = 64 }: { initial: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center', backgroundColor: color.sage, borderWidth: 3, borderColor: color.goldDeco }}>
      <Text style={{ fontFamily: serif, fontSize: size * 0.44, color: color.onSage }}>{initial}</Text>
    </View>
  );
}

const st = StyleSheet.create({
  track: { width: '100%', backgroundColor: color.border, overflow: 'hidden' },
  tile: { flexGrow: 1, flexBasis: 140, minWidth: 130, gap: 2, padding: space.md, borderRadius: radius.md, backgroundColor: color.canvas, borderWidth: 1, borderColor: color.border },
  tileValue: { fontFamily: serif, fontSize: 28, lineHeight: 34, color: color.ink },
  elRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.md, borderRadius: radius.md },
  elGlyph: { width: 40, height: 40, borderRadius: 20, backgroundColor: color.paperStrong, alignItems: 'center', justifyContent: 'center' },
});

