import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Line, Polygon } from 'react-native-svg';
import type { ElementId } from '../domain/types';
import { ELEMENTS } from '../domain/harmony';
import { color, elementColor, elementText, sans } from '../theme/tokens';
import { ElementGlyph } from './Icon';

// Fire and Water sit opposite each other, as do Air and Earth — the classical arrangement.
const DIRS: Record<ElementId, [number, number]> = { fire: [0, -1], air: [1, 0], water: [0, 1], earth: [-1, 0] };
const ORDER: ElementId[] = ['fire', 'air', 'water', 'earth'];

interface Props {
  values: Record<ElementId, number>;
  size?: number;
  labels?: boolean;
  previous?: Record<ElementId, number>;
}

export function Compass({ values, size = 220, labels = true, previous }: Props) {
  const pad = labels ? 46 : 6;
  const box = size;
  const R = (box - pad * 2) / 2;
  const c = box / 2;
  const pt = (el: ElementId, v: number) => {
    const [dx, dy] = DIRS[el];
    const r = (Math.max(0, Math.min(100, v)) / 100) * R;
    return [c + dx * r, c + dy * r] as const;
  };
  const poly = ORDER.map((el) => pt(el, values[el]).join(',')).join(' ');
  const prevPoly = previous ? ORDER.map((el) => pt(el, previous[el]).join(',')).join(' ') : null;
  const summary = ORDER.map((el) => `${ELEMENTS[el].name} ${values[el]}`).join(', ');

  return (
    <View role="img" aria-label={`Compass compass. ${summary}. 50 means pressure and resource are even.`} style={{ width: box, height: box, alignSelf: 'center' }}>
      <Svg width={box} height={box}>
        <Circle cx={c} cy={c} r={R} fill={color.paperStrong} stroke={color.border} strokeWidth={1.5} />
        <Circle cx={c} cy={c} r={R * 0.75} fill="none" stroke={color.border} strokeWidth={1} strokeDasharray="3 5" />
        <Circle cx={c} cy={c} r={R * 0.5} fill="none" stroke={color.controlBorder} strokeWidth={1.2} />
        <Circle cx={c} cy={c} r={R * 0.25} fill="none" stroke={color.border} strokeWidth={1} strokeDasharray="3 5" />
        <Line x1={c} y1={c - R} x2={c} y2={c + R} stroke={color.border} strokeWidth={1} />
        <Line x1={c - R} y1={c} x2={c + R} y2={c} stroke={color.border} strokeWidth={1} />
        {prevPoly ? <Polygon points={prevPoly} fill="none" stroke={color.controlBorder} strokeWidth={1.5} strokeDasharray="4 4" /> : null}
        <Polygon points={poly} fill={color.sage} fillOpacity={0.14} stroke={color.sage} strokeWidth={2} strokeLinejoin="round" />
        {ORDER.map((el) => {
          const [x, y] = pt(el, values[el]);
          return <Circle key={el} cx={x} cy={y} r={labels ? 6 : 3.5} fill={elementColor[el]} stroke={color.paperStrong} strokeWidth={2} />;
        })}
      </Svg>
      {labels ? (
        <>
          <Text style={[st.even, { left: c + R * 0.36, top: c - R * 0.5 - 16 }]} aria-hidden>
            even
          </Text>
          {ORDER.map((el) => {
            const [dx, dy] = DIRS[el];
            const lx = c + dx * (R + 26);
            const ly = c + dy * (R + 24);
            return (
              <View key={el} style={[st.label, { left: lx - 34, top: ly - 20 }]} aria-hidden>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
                  <ElementGlyph element={el} size={13} color={elementText[el]} />
                  <Text style={[st.labelName, { color: elementText[el] }]}>{ELEMENTS[el].name}</Text>
                </View>
                <Text style={st.labelValue}>{values[el]}</Text>
              </View>
            );
          })}
        </>
      ) : null}
    </View>
  );
}

const st = StyleSheet.create({
  label: { position: 'absolute', width: 68, alignItems: 'center' },
  labelName: { fontFamily: sans, fontSize: 12.5, fontWeight: '700' },
  labelValue: { fontFamily: sans, fontSize: 15, fontWeight: '700', color: color.ink },
  even: { position: 'absolute', fontFamily: sans, fontSize: 11, color: color.inkSoft, fontStyle: 'italic' },
});
