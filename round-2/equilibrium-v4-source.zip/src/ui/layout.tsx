import React, { createContext, useContext, useEffect, useRef } from 'react';
import { useInsets } from './insets';
import { Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View, KeyboardAvoidingView, useWindowDimensions } from 'react-native';
import { color, CONTENT_MAX, radius, space, type } from '../theme/tokens';
import { IconButton } from './primitives';
import { useNav } from '../state/nav';
import { useReducedMotion } from '../state/motion';
import { registerSheet } from '../state/sheets';
import { AcademyChip, BackChip, GemChip, GlassBackdrop, glassSpace, HallChip, HomeHallChip, StreakChip, TitleHalo } from './academy/Glass';
import { FROST_READ, WINDOW, WindowKind } from '../theme/paintings';
import { hallInk, useHallInk } from './academy/GlassParts';
import { OVERLAY_RIGHT, useArtOverlay, useArtScreen } from '../state/artChrome';
import type { HallId } from '../theme/academy';

export const LayoutCtx = createContext<{ wide: boolean; bottomClearance: number }>({ wide: false, bottomClearance: 96 });
export const useLayout = () => useContext(LayoutCtx);

interface ScreenProps {
  children: React.ReactNode;
  title?: string;
  eyebrow?: string;
  subtitle?: string;
  /** Stack screens show a back button; tab screens do not. */
  back?: boolean;
  backLabel?: string;
  headerRight?: React.ReactNode;
  scrollRef?: React.RefObject<ScrollView | null>;
  testID?: string;
  maxWidth?: number;
  /** v3: an illustrated header (a HallHero) that replaces the plain title block. */
  hero?: React.ReactNode;
  /** v3: a wing's background texture, drawn behind the content. */
  texture?: React.ReactNode;
  /** Oct 14 art treatment: a clear window onto the hall's art that melts into frosted glass. */
  glass?: boolean;
  /** Which window: Home (the academy at sunrise, a taller window) or a hall (the default). */
  art?: WindowKind;
  /** Full-bleed content at the very top of the page (the full-screen path map), before the title. */
  bleed?: React.ReactNode;
  /** A screen that always stands in one hall, whatever hall someone is in (the check-in: the Moon Pool). */
  hall?: HallId;
  /** A test id for the title itself (when it carries live content, like the Compass reading word). */
  titleTestID?: string;
}

export function Screen({ children, title, eyebrow, subtitle, back, backLabel = 'Back', headerRight, scrollRef, testID, maxWidth, hero, texture, glass, art = 'hall', titleTestID, hall: fixedHall, bleed }: ScreenProps) {
  const { bottomClearance, wide } = useLayout();
  const currentInk = useHallInk().ink;
  useArtScreen(!!glass);
  const overlay = useArtOverlay();
  const pageInsets = useInsets('page');
  const hallInkNow = fixedHall ? hallInk(fixedHall) : currentInk;
  const nav = useNav();
  const localRef = useRef<ScrollView>(null);
  const ref = scrollRef ?? localRef;
  const lastTick = useRef(nav.tabTick);
  const backRef = useRef<any>(null);
  // A pushed screen takes focus (web) so keyboard and screen-reader users land on the new page.
  useEffect(() => {
    if (back && Platform.OS === 'web') setTimeout(() => backRef.current?.focus?.(), 60);
  }, [back]);
  useEffect(() => {
    if (!back && nav.tabTick !== lastTick.current) {
      lastTick.current = nav.tabTick;
      ref.current?.scrollTo({ y: 0, animated: true });
    }
  }, [nav.tabTick, back, ref]);

  // When the chips wrap to a second row (a phone), the title keeps its place on the art.
  const [chipH, setChipH] = React.useState<number>(glassSpace.chipRow);
  return (
    <ScrollView
      ref={ref as any}
      testID={testID}
      style={{ flex: 1 }}
      contentContainerStyle={[st.scroll, { paddingBottom: bottomClearance, paddingTop: (wide ? space.xxl : space.lg) + (overlay ? pageInsets.top : 0) }]}
      keyboardShouldPersistTaps="handled"
      keyboardDismissMode={Platform.OS === 'ios' ? 'interactive' : 'on-drag'}
      automaticallyAdjustKeyboardInsets
    >
      {glass ? <GlassBackdrop kind={art} hall={fixedHall} /> : texture}
      {bleed ? <View style={{ marginTop: -((wide ? space.xxl : space.lg) + (overlay ? pageInsets.top : 0)), marginBottom: space.xl }}>{bleed}</View> : null}
      <View style={[st.inner, maxWidth ? { maxWidth } : null]}>
        {glass ? (
          <View onLayout={(e) => setChipH(Math.max(glassSpace.chipRow, Math.round(e.nativeEvent.layout.height)))} style={[st.chipRow, overlay && { paddingRight: OVERLAY_RIGHT }, { marginBottom: Math.max(space.lg, WINDOW[art].titleTop - (wide ? space.xxl : space.lg) - chipH) }]}>
            {back ? <BackChip label={backLabel} onPress={nav.pop} innerRef={backRef} /> : null}
            {art === 'home' ? (
              <>
                <AcademyChip />
                <HomeHallChip />
                <StreakChip />
              </>
            ) : (
              <HallChip hall={fixedHall} />
            )}
            {back ? headerRight : null}
            {overlay ? null : <GemChip />}
          </View>
        ) : back ? (
          <View style={st.backRow}>
            <Pressable ref={backRef} role="button" aria-label={backLabel} onPress={nav.pop} hitSlop={8} style={(s: any) => [st.backBtn, (s.hovered || s.pressed) && { backgroundColor: color.actionWash }]}>
              <Text style={st.backText}>‹  {backLabel}</Text>
            </Pressable>
            {headerRight}
          </View>
        ) : null}
        {hero ? <View style={{ marginBottom: space.lg }}>{hero}</View> : null}
        {title && !hero ? (
          <TitleWrap glass={glass} art={art}>
            {eyebrow ? <Text style={[type.eyebrow, glass && { color: art === 'hall' ? hallInkNow : color.goldPressed }]} testID="screen-eyebrow">{eyebrow}</Text> : null}
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: space.md }}>
              <Text role="heading" aria-level={1} style={[type.display, { flex: 1 }]} testID={titleTestID}>
                {title}
              </Text>
              {!back ? headerRight : null}
            </View>
            {subtitle ? <Text style={type.bodySoft}>{subtitle}</Text> : null}
          </TitleWrap>
        ) : null}
        <View style={{ gap: space.xl }}>{children}</View>
      </View>
    </ScrollView>
  );
}

function TitleWrap({ glass, art = 'hall', children }: { glass?: boolean; art?: WindowKind; children: React.ReactNode }) {
  if (!glass) return <View style={{ gap: 6, marginBottom: space.xl }}>{children}</View>;
  // The title starts at WINDOW.titleTop, on its halo; the header holds at least down to where the
  // reading wash is reached, so everything below it sits on frosted glass, never on the clear art.
  return (
    <View style={{ marginBottom: space.lg, minHeight: WINDOW[art].clear + FROST_READ - WINDOW[art].titleTop - space.lg }}>
      <TitleHalo testID="title-halo">
        <View style={{ gap: 6 }}>{children}</View>
      </TitleHalo>
    </View>
  );
}

export function Sheet({ visible, onClose, title, children, footer, testID }: { visible: boolean; onClose: () => void; title: string; children: React.ReactNode; footer?: React.ReactNode; testID?: string }) {
  const { width } = useWindowDimensions();
  const insets = useInsets('overlay');
  const reduce = useReducedMotion();
  const centered = width >= 720;
  useEffect(() => {
    if (!visible) return;
    const unregister = registerSheet();
    let onKey: ((e: KeyboardEvent) => void) | undefined;
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      onKey = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopImmediatePropagation();
          onClose();
        }
      };
      window.addEventListener('keydown', onKey, true);
    }
    return () => {
      unregister();
      if (onKey) window.removeEventListener('keydown', onKey, true);
    };
  }, [visible, onClose]);
  return (
    <Modal visible={visible} transparent animationType={reduce ? 'none' : centered ? 'fade' : 'slide'} onRequestClose={onClose} statusBarTranslucent>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <View style={[st.sheetRoot, centered && { justifyContent: 'center', alignItems: 'center', padding: space.xl }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessible={false} focusable={false} aria-hidden tabIndex={-1 as any}>
            <View style={[StyleSheet.absoluteFill, { backgroundColor: color.scrim }]} />
          </Pressable>
          <View
            role="dialog"
            aria-modal
            aria-label={title}
            testID={testID}
            style={[st.sheet, centered ? st.sheetCentered : { paddingBottom: Math.max(insets.bottom, space.lg) }]}
          >
            <View style={st.sheetHeader}>
              <Text role="heading" style={[type.title, { flex: 1 }]}>
                {title}
              </Text>
              <IconButton icon="close" label="Close" onPress={onClose} />
            </View>
            <ScrollView style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: space.xl, paddingBottom: space.lg, gap: space.lg }} keyboardShouldPersistTaps="handled">
              {children}
            </ScrollView>
            {footer ? <View style={st.sheetFooter}>{footer}</View> : null}
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const st = StyleSheet.create({
  scroll: { paddingHorizontal: space.lg, flexGrow: 1 },
  inner: { width: '100%', maxWidth: CONTENT_MAX, alignSelf: 'center' },
  chipRow: { flexDirection: 'row', alignItems: 'center', gap: space.sm, flexWrap: 'wrap', minHeight: 44 },
  backRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: space.md, marginLeft: -8 },
  backBtn: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 10, borderRadius: radius.pill },
  backText: { fontSize: 16, color: color.actionText, fontWeight: '700' },
  sheetRoot: { flex: 1, justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: color.paper,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    maxHeight: '92%',
    width: '100%',
    borderWidth: 1,
    borderColor: color.border,
  },
  sheetCentered: { borderRadius: radius.xl, maxWidth: 560, maxHeight: '88%', paddingBottom: space.sm },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', paddingLeft: space.xl, paddingRight: space.md, paddingTop: space.lg, paddingBottom: space.sm },
  sheetFooter: { paddingHorizontal: space.xl, paddingTop: space.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: color.border, gap: space.sm },
});
