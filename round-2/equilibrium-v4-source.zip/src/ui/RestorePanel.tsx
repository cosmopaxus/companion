import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { checkBackupText, RestoreCheck } from '../domain/backup';
import { mergeJourneys } from '../domain/merge';
import { formatShortDate } from '../domain/time';
import { counts } from '../domain/selectors';
import { balanceFor } from '../domain/gems';
import { useStore } from '../state/store';
import { pickBackupFile, pickLabel } from '../platform/backupIO';
import { color, space, type } from '../theme/tokens';
import { Button, Card, Notice } from './primitives';
import { Field } from './controls';

/**
 * Validated restore. Nothing changes until the whole file checks out and the person confirms.
 * Guest mode replaces the local journey (with a one-step undo). Signed-in mode merges by id.
 */
export function RestorePanel({ onRestored, context = 'data' }: { onRestored?: (name?: string) => void; context?: 'data' | 'onboarding' }) {
  const store = useStore();
  const [pasteOpen, setPasteOpen] = useState(false);
  const [text, setText] = useState('');
  const [check, setCheck] = useState<RestoreCheck | null>(null);
  const [fileName, setFileName] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const merge = store.accountKey !== 'guest';

  const runCheck = (raw: string, name?: string) => {
    setDone(null);
    setError(null);
    setFileName(name);
    setCheck(checkBackupText(raw));
  };

  const choose = async () => {
    setError(null);
    const r = await pickBackupFile();
    if (r.ok) runCheck(r.text, r.name);
    else if (!r.canceled) setError(r.error ?? 'That file could not be opened.');
  };

  const confirm = async () => {
    if (!check || !check.ok) return;
    setBusy(true);
    const next = merge ? mergeJourneys(store.journey, check.journey) : { ...check.journey, activeSpaceId: check.journey.activeSpaceId };
    const res = await store.replaceJourney(next);
    setBusy(false);
    if (res.ok) {
      setDone(merge ? 'Backup merged into your journey.' : 'Journey restored on this device.');
      setCheck(null);
      setText('');
      setPasteOpen(false);
      onRestored?.(check.name);
    } else setError(res.error);
  };

  const cur = counts(store.journey);
  const showCurrent = context === 'data' && !!store.journey.profile;
  const inc = check && check.ok ? check.journey : null;
  const rows: [string, string, string][] = inc
    ? [
        ['Check-ins', String(cur.checkins), String(check && check.ok ? check.counts.checkins : 0)],
        ['Journal entries', String(cur.journal), String(check && check.ok ? check.counts.journal : 0)],
        ['Journey areas', String(cur.areas), String(check && check.ok ? check.counts.areas : 0)],
        ['Evidence', String(cur.evidence), String(check && check.ok ? check.counts.evidence : 0)],
        ['Compass readings', String(cur.harmony), String(check && check.ok ? check.counts.harmony : 0)],
        ['Gems · Personal', String(balanceFor(store.journey.gems, 'personal')), String(balanceFor(inc.gems, 'personal'))],
        ['Gems · Be Well', String(balanceFor(store.journey.gems, 'bewell')), String(balanceFor(inc.gems, 'bewell'))],
      ]
    : [];

  return (
    <View style={{ gap: space.lg }}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
        <Button label={pickLabel} icon="upload" kind="secondary" onPress={choose} testID="restore-choose" />
        <Button label={pasteOpen ? 'Hide paste box' : 'Paste backup text'} kind="quiet" onPress={() => setPasteOpen((v) => !v)} testID="restore-paste-toggle" />
      </View>
      {pasteOpen ? (
        <View style={{ gap: space.sm }}>
          <Field label="Backup text" value={text} onChangeText={setText} multiline minHeight={120} placeholder='Paste the full contents of a companion-backup file, starting with {"format":"companion.backup"…' testID="restore-text" autoCorrect={false} autoCapitalize="none" />
          <Button label="Check this backup" kind="secondary" small onPress={() => runCheck(text)} disabled={!text.trim()} testID="restore-check" />
        </View>
      ) : null}

      {error ? <Notice tone="caution" title="Nothing was changed">{error}</Notice> : null}

      {check && !check.ok ? (
        <Notice tone="caution" title="This backup can't be restored — nothing was changed">
          <View style={{ gap: 4 }} testID="restore-errors">
            {check.errors.map((e, i) => (
              <Text key={i} style={[type.small, { color: color.caution }]}>
                • {e}
              </Text>
            ))}
          </View>
        </Notice>
      ) : null}

      {check && check.ok ? (
        <Card tone="strong" style={{ gap: space.md }}>
          <Text style={type.heading}>This backup looks good</Text>
          <Text style={type.small}>
            {[fileName, check.name ? `Journey of ${check.name}` : null, check.exportedAt ? `saved ${formatShortDate(check.exportedAt)}` : null].filter(Boolean).join(' · ')}
          </Text>
          <View testID="restore-summary" style={{ gap: 6 }}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={[type.small, { flex: 1.4 }]} />
              {showCurrent ? <Text style={[type.small, { flex: 1, textAlign: 'right', fontWeight: '700' }]}>On this device</Text> : null}
              <Text style={[type.small, { flex: 1, textAlign: 'right', fontWeight: '700', color: color.ink }]}>In the backup</Text>
            </View>
            {rows.map(([labelText, cur, inc]) => (
              <View key={labelText} style={{ flexDirection: 'row', alignItems: 'baseline' }}>
                <Text style={[type.body, { flex: 1.4 }]}>{labelText}</Text>
                {showCurrent ? <Text style={[type.body, { flex: 1, textAlign: 'right', color: color.inkSoft }]}>{cur}</Text> : null}
                <Text style={[type.body, { flex: 1, textAlign: 'right', fontWeight: '700' }]}>{inc}</Text>
              </View>
            ))}
          </View>
          {context === 'data' ? (
            <Notice tone={merge ? 'info' : 'caution'}>
              {merge
                ? 'Entries will be merged into your account by id. Nothing already in your journey is removed.'
                : 'Restoring replaces the journey on this device, including anything written since this backup was made. You can undo this once, right after.'}
            </Notice>
          ) : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            <Button label={merge ? 'Merge into my journey' : context === 'onboarding' ? 'Restore this journey' : 'Replace my journey'} onPress={confirm} busy={busy} testID="restore-confirm" />
            <Button label="Cancel" kind="quiet" onPress={() => setCheck(null)} />
          </View>
        </Card>
      ) : null}

      {done ? <Notice tone="success">{done}</Notice> : null}
    </View>
  );
}
