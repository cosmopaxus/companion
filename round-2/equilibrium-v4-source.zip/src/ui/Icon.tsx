import React from 'react';
import Svg, { Circle, Path, G, Rect } from 'react-native-svg';
import type { ElementId, EvidenceKind } from '../domain/types';
import { color } from '../theme/tokens';

export type IconName =
  | 'today'
  | 'home'
  | 'journey'
  | 'connect'
  | 'journal'
  | 'you'
  | 'back'
  | 'close'
  | 'chevron'
  | 'chevronDown'
  | 'plus'
  | 'check'
  | 'info'
  | 'lock'
  | 'download'
  | 'upload'
  | 'compass'
  | 'map'
  | 'sparkle'
  | 'trash'
  | 'edit'
  | 'cloud'
  | 'device'
  | 'heart'
  | 'shield'
  | 'leaf'
  | 'swap'
  | 'win'
  | 'observation'
  | 'setback'
  | 'sound'
  | 'soundOff'
  | 'minus'
  | 'calendar'
  | 'grid'
  | 'flag'
  | 'badge'
  | 'moon'
  | 'sun'
  | 'search'
  | 'key'
  | 'star'
  | 'path'
  | 'seal'
  | 'lamp'
  | 'quill'
  | 'crest';

interface Props {
  name: IconName;
  size?: number;
  color?: string;
  strokeWidth?: number;
  filled?: boolean;
}

/** Hand-drawn line icons on a 24 grid. Decorative by default — pair with a text label. */
export function Icon({ name, size = 24, color: c = color.ink, strokeWidth = 1.75, filled = false }: Props) {
  const p = { stroke: c, strokeWidth, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none' };
  const fillSoft = filled ? c : 'none';
  let body: React.ReactNode = null;
  switch (name) {
    case 'today':
      body = (
        <G {...p}>
          <Path d="M3 18.5h18" />
          <Path d="M6.5 18.5a5.5 5.5 0 0 1 11 0" fill={filled ? c : 'none'} />
          <Path d="M12 5.5v2.2M5.3 9.3l1.5 1.5M18.7 9.3l-1.5 1.5M2.8 14.2h2M19.2 14.2h2" />
        </G>
      );
      break;
    case 'home':
      body = (
        <G {...p}>
          <Path d="M3.8 11.2L12 4.5l8.2 6.7" />
          <Path d="M6 9.6V19.5h12V9.6" fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M9.2 19.5a2.8 2.8 0 0 1 5.6 0" />
          <Path d="M12 12.6v1.2M9.6 13.6l.7.7M14.4 13.6l-.7.7" />
        </G>
      );
      break;
    case 'journey':
      body = (
        <G {...p}>
          <Path d="M6 19.5c0-3.6 3.2-4.3 6-6.2s6-3.1 6-7.3" />
          <Circle cx={6} cy={19.5} r={1.8} fill={filled ? c : color.paper} />
          <Path d="M18 6V2.8l3 1.3-3 1.3" fill={filled ? c : 'none'} />
        </G>
      );
      break;
    case 'connect':
      body = (
        <G {...p}>
          <Circle cx={9} cy={12} r={5.5} fill={filled ? c : 'none'} fillOpacity={filled ? 0.25 : 0} />
          <Circle cx={15} cy={12} r={5.5} />
        </G>
      );
      break;
    case 'journal':
      body = (
        <G {...p}>
          <Path d="M12 6.8C10 5.3 7.2 4.8 4 5.2v13.2c3.2-.4 6 .1 8 1.6 2-1.5 4.8-2 8-1.6V5.2c-3.2-.4-6 .1-8 1.6z" fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M12 6.8V20" />
        </G>
      );
      break;
    case 'you':
      body = (
        <G {...p}>
          <Circle cx={12} cy={8.2} r={3.6} fill={fillSoft} fillOpacity={filled ? 0.25 : 0} />
          <Path d="M4.8 20c1.2-3.7 3.9-5.6 7.2-5.6s6 1.9 7.2 5.6" />
        </G>
      );
      break;
    case 'seal':
      body = (
        <G {...p}>
          <Circle cx={12} cy={12} r={8.2} fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M12 6.6l1.5 3.9 3.9 1.5-3.9 1.5-1.5 3.9-1.5-3.9-3.9-1.5 3.9-1.5z" />
        </G>
      );
      break;
    case 'lamp':
      body = (
        <G {...p}>
          <Path d="M9 4.5h6l1.8 4.5H7.2z" />
          <Path d="M7.2 9h9.6l-1.6 6.5H8.8z" fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M12 15.5v3.5M9 19.5h6" />
        </G>
      );
      break;
    case 'quill':
      body = (
        <G {...p}>
          <Path d="M19.5 4.5C12 5.5 8 10 6.5 17.5c4.5-1 9.5-4.5 13-13z" fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M6.5 17.5 4 20M10 12.5l4 1" />
        </G>
      );
      break;
    case 'crest':
      body = (
        <G {...p}>
          <Path d="M12 3.5l7 2.6v5.4c0 4.4-3 7.6-7 9-4-1.4-7-4.6-7-9V6.1z" fill={filled ? c : 'none'} fillOpacity={filled ? 0.18 : 0} />
          <Path d="M12 8v7M9 10.5c1 .9 2 1.3 3 1.3s2-.4 3-1.3" />
        </G>
      );
      break;
    case 'back':
      body = <Path {...p} d="M15 5l-7 7 7 7" />;
      break;
    case 'close':
      body = <Path {...p} d="M6 6l12 12M18 6L6 18" />;
      break;
    case 'chevron':
      body = <Path {...p} d="M9 5l7 7-7 7" />;
      break;
    case 'chevronDown':
      body = <Path {...p} d="M6 9l6 6 6-6" />;
      break;
    case 'plus':
      body = <Path {...p} d="M12 5v14M5 12h14" />;
      break;
    case 'check':
      body = <Path {...p} d="M5 12.5l4.5 4.5L19 7.5" />;
      break;
    case 'info':
      body = (
        <G {...p}>
          <Circle cx={12} cy={12} r={9} />
          <Path d="M12 11v5.5M12 7.6v.1" />
        </G>
      );
      break;
    case 'lock':
      body = (
        <G {...p}>
          <Rect x={5} y={10.5} width={14} height={10} rx={2.5} />
          <Path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" />
        </G>
      );
      break;
    case 'download':
      body = <Path {...p} d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19.5h14" />;
      break;
    case 'upload':
      body = <Path {...p} d="M12 15V4M7.5 8.5L12 4l4.5 4.5M5 19.5h14" />;
      break;
    case 'compass':
      body = (
        <G {...p}>
          <Circle cx={12} cy={12} r={9} />
          <Path d="M12 5.5l2.2 6.5L12 18.5 9.8 12z" fill={filled ? c : 'none'} />
        </G>
      );
      break;
    case 'map':
      body = (
        <G {...p}>
          <Path d="M3.5 6.5l5-2 7 2.5 5-2v13l-5 2-7-2.5-5 2z" />
          <Path d="M8.5 4.5v13M15.5 7v13" />
        </G>
      );
      break;
    case 'sparkle':
      body = (
        <G {...p}>
          <Path d="M12 3.5l1.6 5.2 5.2 1.6-5.2 1.6L12 17.1l-1.6-5.2-5.2-1.6 5.2-1.6z" fill={fillSoft} />
          <Path d="M19 16v4M17 18h4" />
        </G>
      );
      break;
    case 'grid':
      body = (
        <G {...p}>
          <Rect x={4} y={4} width={7} height={7} rx={1.8} />
          <Rect x={13} y={4} width={7} height={7} rx={1.8} />
          <Rect x={4} y={13} width={7} height={7} rx={1.8} />
          <Rect x={13} y={13} width={7} height={7} rx={1.8} />
        </G>
      );
      break;
    case 'minus':
      body = <Path {...p} d="M5 12h14" />;
      break;
    case 'calendar':
      body = (
        <G {...p}>
          <Rect x={4} y={5.5} width={16} height={14.5} rx={2.5} />
          <Path d="M4 10h16M8.5 3.5v4M15.5 3.5v4" />
        </G>
      );
      break;
    case 'sound':
      body = (
        <G {...p}>
          <Path d="M4.5 9.5h3l4.5-4v13l-4.5-4h-3z" />
          <Path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" />
        </G>
      );
      break;
    case 'soundOff':
      body = (
        <G {...p}>
          <Path d="M4.5 9.5h3l4.5-4v13l-4.5-4h-3z" />
          <Path d="M16 9.5l5 5M21 9.5l-5 5" />
        </G>
      );
      break;
    case 'trash':
      body = <Path {...p} d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l1 12.5h9L17.5 7M10 10.5v6M14 10.5v6" />;
      break;
    case 'edit':
      body = <Path {...p} d="M15.5 4.5l4 4L9 19H5v-4zM13.5 6.5l4 4" />;
      break;
    case 'cloud':
      body = <Path {...p} d="M7 18.5h10a4 4 0 0 0 .6-7.95A5.5 5.5 0 0 0 7 9.5a4.5 4.5 0 0 0 0 9z" />;
      break;
    case 'device':
      body = (
        <G {...p}>
          <Rect x={7} y={3} width={10} height={18} rx={2.5} />
          <Path d="M11 17.5h2" />
        </G>
      );
      break;
    case 'heart':
      body = <Path {...p} d="M12 19.5s-7.5-4.4-7.5-10A4.2 4.2 0 0 1 12 7a4.2 4.2 0 0 1 7.5 2.5c0 5.6-7.5 10-7.5 10z" />;
      break;
    case 'shield':
      body = <Path {...p} d="M12 3.5l7 2.7v5.3c0 4.4-3 7.7-7 9-4-1.3-7-4.6-7-9V6.2z" />;
      break;
    case 'leaf':
      body = (
        <G {...p}>
          <Path d="M5 19c0-8 5-13.5 14-14 0 9-5.5 14-14 14z" />
          <Path d="M5 19l7-7" />
        </G>
      );
      break;
    case 'swap':
      body = <Path {...p} d="M7 7h11l-3-3M17 17H6l3 3" />;
      break;
    case 'win':
      body = (
        <G {...p}>
          <Path d="M12 20.5v-8.5" />
          <Path d="M12 12c0-4 2.8-6.5 7-6.5 0 4-2.8 6.5-7 6.5z" fill={fillSoft} />
          <Path d="M12 14.5c0-3-2.1-5-5.5-5 0 3 2.1 5 5.5 5z" fill={fillSoft} />
        </G>
      );
      break;
    case 'observation':
      body = (
        <G {...p}>
          <Path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" />
          <Circle cx={12} cy={12} r={2.6} fill={fillSoft} />
        </G>
      );
      break;
    case 'flag':
      body = (
        <G {...p}>
          <Path d="M6 21V4" />
          <Path d="M6 4.5h11.5l-2.6 4 2.6 4H6" fill={filled ? c : 'none'} fillOpacity={filled ? 0.22 : 0} />
        </G>
      );
      break;
    case 'badge':
      body = (
        <G {...p}>
          <Circle cx={12} cy={9.5} r={5.5} fill={filled ? c : 'none'} fillOpacity={filled ? 0.2 : 0} />
          <Path d="M8.8 14l-1.6 6.5L12 18l4.8 2.5-1.6-6.5" />
          <Path d="M12 7.2l.8 1.6 1.7.2-1.2 1.2.3 1.7-1.6-.8-1.6.8.3-1.7-1.2-1.2 1.7-.2z" />
        </G>
      );
      break;
    case 'moon':
      body = <Path {...p} d="M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z" fill={fillSoft} fillOpacity={filled ? 0.2 : 0} />;
      break;
    case 'sun':
      body = (
        <G {...p}>
          <Circle cx={12} cy={12} r={4} fill={fillSoft} fillOpacity={filled ? 0.25 : 0} />
          <Path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7" />
        </G>
      );
      break;
    case 'search':
      body = (
        <G {...p}>
          <Circle cx={10.5} cy={10.5} r={6} />
          <Path d="M15 15l5 5" />
        </G>
      );
      break;
    case 'key':
      body = (
        <G {...p}>
          <Circle cx={8} cy={14} r={4} />
          <Path d="M11 11l8.5-8.5M16.5 5.5l2.5 2.5M14 8l2 2" />
        </G>
      );
      break;
    case 'star':
      body = <Path {...p} d="M12 3.8l2.5 5.1 5.6.8-4 4 1 5.6-5.1-2.7-5.1 2.7 1-5.6-4-4 5.6-.8z" fill={fillSoft} fillOpacity={filled ? 0.25 : 0} />;
      break;
    case 'path':
      body = (
        <G {...p}>
          <Circle cx={6} cy={19} r={2} />
          <Circle cx={12} cy={11.5} r={2} />
          <Circle cx={18} cy={5} r={2} fill={fillSoft} />
          <Path d="M7.6 17.6l2.8-4.6M13.6 10.1l2.8-3.6" strokeDasharray="2 2.4" />
        </G>
      );
      break;
    case 'setback':
      body = <Path {...p} d="M5 7h9.5a4.5 4.5 0 0 1 0 9H8M11 12.5L7.5 16l3.5 3.5" />;
      break;
  }
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessible={false} importantForAccessibility="no" aria-hidden>
      {body}
    </Svg>
  );
}

export const EVIDENCE_ICON: Record<EvidenceKind, IconName> = { win: 'win', observation: 'observation', setback: 'setback' };
export const EVIDENCE_COLOR: Record<EvidenceKind, string> = { win: color.sage, observation: color.gold, setback: color.caution };

/** Faceted gem. */
export function Gem({ size = 18, tone = 'gold' }: { size?: number; tone?: 'gold' | 'light' | 'muted' }) {
  const main = tone === 'light' ? color.goldWash : tone === 'muted' ? color.controlBorder : color.goldDeco;
  const line = tone === 'light' ? color.gold : tone === 'muted' ? color.paper : color.gold;
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessible={false} importantForAccessibility="no" aria-hidden>
      <Path d="M6.5 4h11l4 5.2L12 20.5 2.5 9.2z" fill={main} stroke={line} strokeWidth={1.4} strokeLinejoin="round" />
      <Path d="M2.8 9.2h18.4M9.2 4 12 9.2 14.8 4M12 9.2v11" stroke={line} strokeWidth={1.1} strokeLinejoin="round" fill="none" opacity={0.85} />
    </Svg>
  );
}

/**
 * Element marks. v3 replaced the classical alchemical triangles with Equilibrium's own hall marks
 * (original symbols, not one tradition's); the name stays so every screen keeps working.
 */
export function ElementGlyph({ element, size = 20, color: c }: { element: ElementId; size?: number; color?: string }) {
  return <HallMark element={element} size={size} color={c} />;
}

/**
 * Original hall marks for the four elements (v3): a flame, a wind-swept star, a crescent over a
 * ripple, and a sprout in a stone bed. Drawn for Equilibrium; not taken from any one tradition.
 */
export function HallMark({ element, size = 20, color: c }: { element: ElementId; size?: number; color?: string }) {
  const p = { stroke: c ?? color.ink, strokeWidth: 1.9, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none' };
  const d: Record<ElementId, React.ReactNode> = {
    fire: <Path {...p} d="M12 3.5c1 3.8 5.8 5.8 5.8 10.6a5.8 5.8 0 0 1-11.6 0c0-2.8 1.9-3.9 2.9-5.8 1 1.9 1.9 1.9 2.9 1-1-1.9-1-3.9 0-5.8z" />,
    air: (
      <G {...p}>
        <Circle cx={12} cy={8} r={2.8} />
        <Path d="M4 14h11.5a2.4 2.4 0 1 0-2.4-2.4M4 18h8.6a1.9 1.9 0 1 1-1.9 1.9" />
      </G>
    ),
    water: (
      <G {...p}>
        <Path d="M15 3.5a5.8 5.8 0 1 0 4.8 7.7 4.8 4.8 0 0 1-4.8-7.7z" />
        <Path d="M3 18c1.9-1.4 3.9-1.4 5.8 0s3.9 1.4 5.8 0 3.9-1.4 5.8 0" />
      </G>
    ),
    earth: (
      <G {...p}>
        <Path d="M4 13.5h16v4.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z" />
        <Path d="M12 13.5V6.5M12 9.5c-2.9 0-3.8-1.9-3.8-3.8 2.9 0 3.8 1.9 3.8 3.8zM12 8.5c0-1.9 1-3.8 3.8-3.8 0 1.9-1 3.8-3.8 3.8z" />
      </G>
    ),
  };
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessible={false} importantForAccessibility="no" aria-hidden>
      {d[element]}
    </Svg>
  );
}
