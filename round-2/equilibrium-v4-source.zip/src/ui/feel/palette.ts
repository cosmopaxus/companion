// Color for each check-in feeling, from its low end to its high end. Pure (no React Native),
// so it can be unit-tested. Text never uses these colors; they carry feeling, not meaning.

import type { CheckInDimension } from '../../domain/scales';

type Stops = readonly [string, string, string];

export const FEEL_STOPS: Record<CheckInDimension, Stops> = {
  // Heavy slate → dusk → sun gold
  mood: ['#66707F', '#A88E66', '#E2A21E'],
  // Ash violet → plum → ember
  energy: ['#5A5670', '#A0506C', '#EE6A2A'],
  // Cool mist → lavender → warm rose
  connection: ['#7B8997', '#957EA8', '#CF5F7D'],
};

function hexToRgb(h: string): [number, number, number] {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbToHex([r, g, b]: [number, number, number]): string {
  return '#' + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
}

export function mix(a: string, b: string, t: number): string {
  const x = hexToRgb(a);
  const y = hexToRgb(b);
  const k = Math.max(0, Math.min(1, t));
  return rgbToHex([x[0] + (y[0] - x[0]) * k, x[1] + (y[1] - x[1]) * k, x[2] + (y[2] - x[2]) * k]);
}

/** The color of a feeling at a level from 0 to 100. */
export function feelColor(dim: CheckInDimension, level: number): string {
  const [lo, mid, hi] = FEEL_STOPS[dim];
  const t = Math.max(0, Math.min(100, level)) / 100;
  return t <= 0.5 ? mix(lo, mid, t * 2) : mix(mid, hi, (t - 0.5) * 2);
}

export function withAlpha(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Text color for each feeling's value ("Good · 68") on a card: deep enough for 4.5:1, Day and Night. */
export const FEEL_TEXT: Record<CheckInDimension, { day: string; night: string }> = {
  mood: { day: '#7A5A0E', night: '#F0C878' },
  energy: { day: '#A8431A', night: '#F2A27A' },
  connection: { day: '#A3375B', night: '#F0A2BC' },
};

/** The slider card takes this much of the feeling's color, so the card follows the reading too. */
export const FEEL_CARD_TINT = 0.07;
