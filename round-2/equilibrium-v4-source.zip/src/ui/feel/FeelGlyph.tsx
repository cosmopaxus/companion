import React from 'react';
import Svg, { Circle, ClipPath, Defs, G, Line, Path, Rect } from 'react-native-svg';
import type { CheckInDimension } from '../../domain/scales';
import { feelColor, mix } from './palette';
import { color } from '../../theme/tokens';

// One small picture per feeling. Each is drawn from the level (0–100), so it changes as the slider moves:
//   Mood        a sun that sinks under cloud when heavy and rises with rays when bright
//   Energy      a pulse that is nearly flat when depleted and tall and quick when charged
//   Connection  two circles far apart when isolated that move together and overlap when connected
// Decorative: the slider's label and spoken value carry the meaning.

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export function FeelGlyph({ dim, level, size = 64 }: { dim: CheckInDimension; level?: number; size?: number }) {
  const unset = level === undefined;
  const lv = unset ? 50 : level;
  const t = lv / 100;
  const c = unset ? color.controlBorder : feelColor(dim, lv);
  return (
    <Svg width={size} height={size} viewBox="0 0 64 64" aria-hidden opacity={unset ? 0.55 : 1}>
      {dim === 'mood' ? <Mood t={t} c={c} /> : dim === 'energy' ? <Energy t={t} c={c} /> : <Connection t={t} c={c} />}
    </Svg>
  );
}

function Mood({ t, c }: { t: number; c: string }) {
  const clipId = `mood-sky-${React.useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const horizon = 47;
  const r = 9 + 4 * t;
  const cy = 58 - 32 * t;
  const rayK = clamp01((t - 0.3) / 0.7);
  const cloud = clamp01(1 - t / 0.5);
  const rays = Array.from({ length: 8 }, (_, i) => {
    const a = (i / 8) * Math.PI * 2 - Math.PI / 2;
    const r0 = r + 3;
    const r1 = r0 + 2 + 7 * rayK;
    return { x1: 32 + Math.cos(a) * r0, y1: cy + Math.sin(a) * r0, x2: 32 + Math.cos(a) * r1, y2: cy + Math.sin(a) * r1 };
  });
  return (
    <>
      <Defs>
        <ClipPath id={clipId}>
          <Rect x={0} y={0} width={64} height={horizon} />
        </ClipPath>
      </Defs>
      <G clipPath={`url(#${clipId})`}>
        {rayK > 0
          ? rays.map((l, i) => <Line key={i} {...l} stroke={c} strokeWidth={2.4} strokeLinecap="round" opacity={rayK} />)
          : null}
        <Circle cx={32} cy={cy} r={r} fill={c} />
      </G>
      <Line x1={8} y1={horizon} x2={56} y2={horizon} stroke={mix(c, color.ink, 0.45)} strokeWidth={2} strokeLinecap="round" opacity={0.55} />
      {cloud > 0 ? (
        <G opacity={cloud * 0.92}>
          <Circle cx={24} cy={35} r={7} fill="#8C929C" />
          <Circle cx={33} cy={31} r={9} fill="#8C929C" />
          <Circle cx={42} cy={36} r={6} fill="#8C929C" />
          <Rect x={17} y={35} width={31} height={8} rx={4} fill="#8C929C" />
        </G>
      ) : null}
    </>
  );
}

function Energy({ t, c }: { t: number; c: string }) {
  const amp = 1.5 + 15 * Math.pow(t, 1.1);
  const cycles = 0.75 + 2.75 * t;
  const x0 = 6;
  const span = 52;
  let d = '';
  for (let i = 0; i <= 104; i++) {
    const u = i / 104;
    const x = x0 + u * span;
    const env = Math.sin(Math.PI * u);
    const y = 32 - amp * env * Math.sin(2 * Math.PI * cycles * u);
    d += `${i === 0 ? 'M' : 'L'}${x.toFixed(2)} ${y.toFixed(2)}`;
  }
  return (
    <>
      {t > 0.05 ? <Path d={d} stroke={c} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.2 * t} /> : null}
      <Path d={d} stroke={c} strokeWidth={2.6 + 1.2 * t} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <Circle cx={x0} cy={32} r={2.4} fill={c} />
      <Circle cx={x0 + span} cy={32} r={2.4} fill={c} />
    </>
  );
}

function Connection({ t, c }: { t: number; c: string }) {
  const r = 9 + 3 * t;
  const dist = 40 - 28 * t;
  const x1 = 32 - dist / 2;
  const x2 = 32 + dist / 2;
  const gap = dist - 2 * r;
  const thread = clamp01((t - 0.1) / 0.35);
  const halo = clamp01((t - 0.78) / 0.22);
  return (
    <>
      {halo > 0 ? <Circle cx={32} cy={32} r={dist / 2 + r + 5} stroke={c} strokeWidth={1.6} fill="none" opacity={halo * 0.45} /> : null}
      {gap > 1 && thread > 0 ? (
        <Line x1={x1 + r} y1={32} x2={x2 - r} y2={32} stroke={c} strokeWidth={2} strokeLinecap="round" strokeDasharray={t < 0.45 ? '2 4' : undefined} opacity={thread} />
      ) : null}
      <Circle cx={x1} cy={32} r={r} fill={c} opacity={0.82} />
      <Circle cx={x2} cy={32} r={r} fill={mix(c, color.paper, 0.25)} opacity={0.8} stroke={c} strokeWidth={1.5} />
    </>
  );
}
