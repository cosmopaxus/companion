import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { color, radius, space, type } from '../theme/tokens';
import { IconButton } from './primitives';
import type { IconName } from './Icon';

/** A value with − and + buttons. The value is announced with the label. */
export function Stepper({
  label,
  value,
  min,
  max,
  onChange,
  format = (v) => String(v),
  decIcon = 'minus',
  incIcon = 'plus',
  helper,
  testID,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
  decIcon?: IconName;
  incIcon?: IconName;
  helper?: string;
  testID?: string;
}) {
  const shown = format(value);
  return (
    <View style={st.row} testID={testID}>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={type.label}>{label}</Text>
        {helper ? <Text style={type.small}>{helper}</Text> : null}
      </View>
      <View style={st.control}>
        <IconButton icon={decIcon} label={`${label}: decrease (now ${shown})`} onPress={() => onChange(Math.max(min, value - 1))} tone={value <= min ? color.controlBorder : color.sage} size={20} testID={testID ? `${testID}-dec` : undefined} />
        <Text style={st.value} aria-live="polite" testID={testID ? `${testID}-value` : undefined}>
          {shown}
        </Text>
        <IconButton icon={incIcon} label={`${label}: increase (now ${shown})`} onPress={() => onChange(Math.min(max, value + 1))} tone={value >= max ? color.controlBorder : color.sage} size={20} testID={testID ? `${testID}-inc` : undefined} />
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  control: { flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: color.controlBorder, borderRadius: radius.pill, backgroundColor: color.paperStrong, paddingHorizontal: 4 },
  value: { ...type.label, minWidth: 44, textAlign: 'center' },
});
