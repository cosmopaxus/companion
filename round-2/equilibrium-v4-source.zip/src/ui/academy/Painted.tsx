// The painted academy behind a glass screen ("window into glass", Oct 14 art treatment).
// Layers, from the back (see theme/paintings.ts): the pre-blurred painting across the page, the
// clear painting in a window at the top with slow ambient motion, the frosted copy melting in
// over FADE px, the cream or night wash, and a soft shade under the chips.
// Everything here is decoration: hidden from screen readers, never takes a tap, and every bit of
// motion stops under reduced motion (the painting stays as a still image).

import React, { useEffect, useMemo, useState } from 'react';
import { Animated, Easing, Image, LayoutChangeEvent, Platform, StyleSheet, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Defs, G, LinearGradient, Path, RadialGradient, Rect, Stop } from 'react-native-svg';
import { useReducedMotion } from '../../state/motion';
import { color, isNight } from '../../theme/tokens';
import { HALO_CORE } from '../../theme/academy';
import {
  ArtGeometry,
  artGeometry,
  FADE,
  FADE_STRIPS,
  fadeStripOpacity,
  FROST_READ,
  NIGHT_VEIL,
  PAGE_TEXT,
  PaintingId,
  PAINTINGS,
  readingFromV,
  readingWash,
  SIDE_FEATHER,
  TOP_SHADE,
  pageWashAt,
  WINDOW,
  WindowKind,
} from '../../theme/paintings';
import { BLURRED, SHARP } from './paintingSources';
import { useBreath, useRise } from './Motion';

const native = Platform.OS !== 'web';
const hidden = { 'aria-hidden': true, accessible: false, importantForAccessibility: 'no-hide-descendants' as const };
let gid = 0;

/** Fills the page behind a glass screen. */
export function PaintedBackdrop({ painting, kind, testID = 'hall-hero' }: { painting: PaintingId; kind: WindowKind; testID?: string }) {
  const { width: windowW } = useWindowDimensions();
  const [w, setW] = useState(windowW);
  const reduce = useReducedMotion();
  const g = useMemo(() => artGeometry(w, painting, kind), [w, painting, kind]);
  const reading = useMemo(() => readingWash(painting, color.canvas, PAGE_TEXT.map((k) => color[k]), readingFromV(g, kind)), [painting, g, kind]);
  const clear = WINDOW[kind].clear;
  const onLayout = (e: LayoutChangeEvent) => {
    const nw = Math.round(e.nativeEvent.layout.width);
    if (nw > 0 && nw !== w) setW(nw);
  };
  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: color.canvas, overflow: 'hidden' }]} pointerEvents="none" testID={testID} onLayout={onLayout}>
      <View style={StyleSheet.absoluteFill} {...hidden}>
        {/* 1 · the frosted painting, behind the whole page */}
        <Frosted painting={painting} r={g.blur} />
        <EndFade top={g.blur.top + g.blur.height} />

        {/* 2 · the clear painting, in its window */}
        <View style={[st.abs, { left: g.box.left, top: 0, width: g.box.width, height: g.box.height, overflow: 'hidden' }]}>
          <SlowZoom painting={painting} still={reduce} g={g} />
          {reduce ? null : <Ambience painting={painting} g={g} />}
          {isNight ? <View style={[StyleSheet.absoluteFill, { backgroundColor: NIGHT_VEIL.rgb, opacity: NIGHT_VEIL.alpha }]} /> : null}
        </View>

        {/* 3 · on wide screens the window's sides melt into its own frosted twin */}
        {g.box.left > 0 ? <SideFeathers painting={painting} g={g} /> : null}

        {/* …and its bottom melts into it too, in thin steps */}
        {Array.from({ length: FADE_STRIPS }, (_, i) => {
          const h = FADE / FADE_STRIPS;
          const top = clear + i * h;
          return (
            <View key={i} style={[st.abs, { left: 0, right: 0, top, height: Math.ceil(h) + (i === FADE_STRIPS - 1 ? 1 : 0), overflow: 'hidden', opacity: fadeStripOpacity(i) }]}>
              <Frosted painting={painting} r={{ ...g.blur, top: g.blur.top - top }} />
            </View>
          );
        })}

        {/* 4 · the wash */}
        <Wash top={clear} reading={reading} kind={kind} />
        <View style={[st.abs, { left: 0, right: 0, top: clear + FROST_READ, bottom: 0, backgroundColor: color.canvas, opacity: reading }]} />

        {/* 5 · a soft shade under the chips */}
        <TopShade />
      </View>
    </View>
  );
}

/** The frosted twin at `r`, with a mirrored copy on each side so it never ends in a seam. */
function Frosted({ painting, r }: { painting: PaintingId; r: { left: number; top: number; width: number; height: number } }) {
  return (
    <>
      <Image source={BLURRED[painting]} style={[st.abs, r]} resizeMode="cover" fadeDuration={0} />
      <Image source={BLURRED[painting]} style={[st.abs, { ...r, left: r.left - r.width, transform: [{ scaleX: -1 }] }]} resizeMode="cover" fadeDuration={0} />
      <Image source={BLURRED[painting]} style={[st.abs, { ...r, left: r.left + r.width, transform: [{ scaleX: -1 }] }]} resizeMode="cover" fadeDuration={0} />
    </>
  );
}

function SlowZoom({ painting, still, g }: { painting: PaintingId; still: boolean; g: ArtGeometry }) {
  const [v] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (still) {
      v.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 28000, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
        Animated.timing(v, { toValue: 0, duration: 28000, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [still, v]);
  const p = PAINTINGS[painting];
  return (
    <Animated.Image
      source={SHARP[painting]}
      resizeMode="cover"
      fadeDuration={0}
      testID="painting"
      style={[
        st.abs,
        {
          left: g.sharp.left - g.box.left,
          top: g.sharp.top,
          width: g.sharp.width,
          height: g.sharp.height,
          transformOrigin: `${p.origin[0] * 100}% ${p.origin[1] * 100}%`,
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, 1.07] }) }],
        },
      ]}
    />
  );
}

/** Below the end of the painting the page is the canvas color: fade into it rather than stop. */
function EndFade({ top }: { top: number }) {
  const [id] = useState(() => `endfade-${++gid}`);
  const H = 180;
  return (
    <>
      <Svg width="100%" height={H} style={[st.abs, { left: 0, right: 0, top: top - H }]}>
        <Defs>
          <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
            <Stop offset={0} stopColor={color.canvas} stopOpacity={0} />
            <Stop offset={1} stopColor={color.canvas} stopOpacity={1} />
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width="100%" height={H} fill={`url(#${id})`} />
      </Svg>
      <View style={[st.abs, { left: 0, right: 0, top, bottom: 0, backgroundColor: color.canvas }]} />
    </>
  );
}

function SideFeathers({ painting, g }: { painting: PaintingId; g: ArtGeometry }) {
  const n = 16;
  const sw = SIDE_FEATHER / n;
  const strips: React.ReactNode[] = [];
  for (let j = 0; j < n; j++) {
    const opacity = 1 - (j + 0.5) / n;
    for (const side of [0, 1]) {
      const left = side === 0 ? g.box.left + j * sw : g.box.left + g.box.width - (j + 1) * sw;
      strips.push(
        <View key={`${side}-${j}`} style={[st.abs, { left: Math.floor(left), top: 0, width: Math.ceil(sw) + 1, height: g.box.height, overflow: 'hidden', opacity }]}>
          <Image source={BLURRED[painting]} style={[st.abs, { ...g.sharp, left: g.sharp.left - Math.floor(left) }]} resizeMode="cover" fadeDuration={0} />
        </View>,
      );
    }
  }
  return <>{strips}</>;
}

function Wash({ top, reading, kind }: { top: number; reading: number; kind: WindowKind }) {
  const [id] = useState(() => `wash-${++gid}`);
  const steps: number[] = [];
  for (let y = 0; y <= FROST_READ; y += 5) steps.push(y);
  return (
    <Svg width="100%" height={FROST_READ} style={[st.abs, { left: 0, right: 0, top }]}>
      <Defs>
        <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          {steps.map((y) => (
            <Stop key={y} offset={y / FROST_READ} stopColor={color.canvas} stopOpacity={pageWashAt(y, reading, kind, HALO_CORE)} />
          ))}
        </LinearGradient>
      </Defs>
      <Rect x={0} y={0} width="100%" height={FROST_READ} fill={`url(#${id})`} />
    </Svg>
  );
}

function TopShade() {
  const [id] = useState(() => `shade-${++gid}`);
  return (
    <Svg width="100%" height={TOP_SHADE.height} style={[st.abs, { left: 0, right: 0, top: 0 }]}>
      <Defs>
        <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <Stop offset={0} stopColor={TOP_SHADE.rgb} stopOpacity={TOP_SHADE.alpha} />
          <Stop offset={1} stopColor={TOP_SHADE.rgb} stopOpacity={0} />
        </LinearGradient>
      </Defs>
      <Rect x={0} y={0} width="100%" height={TOP_SHADE.height} fill={`url(#${id})`} />
    </Svg>
  );
}

// ——— Ambient life in each painting ———
// Positions come from the mockups (04–08), in the mockup's own px, and are mapped onto the
// painting wherever the crop and screen width put it.

type Pt = [number, number];
interface Scene {
  /** The mockup's painting box: left, top, width (px on a 390 px phone). */
  frame: [number, number, number];
  rays?: { at: Pt; r: number };
  glows?: { at: Pt; r: number; tint: string; peak: number; d: number; flicker?: boolean; delay?: number }[];
  beams?: { at: Pt; w: number; h: number; skew: number; tint: string; peak: number }[];
  dots?: { at: Pt[]; size: number; core: string; halo: string; d: number; travel: Pt; kind: 'rise' | 'twinkle' }[];
}

const HALL_FRAME = (top: number): [number, number, number] => [0, top, 390];

const SCENES: Partial<Record<PaintingId, Scene>> = {
  'academy-at-sunrise': {
    frame: [-52, 0, 474],
    rays: { at: [339, 178], r: 150 },
    glows: [{ at: [339, 178], r: 60, tint: '#FFF8E2', peak: 0.95, d: 6000 }],
    dots: [{ at: [[60, 250], [118, 300], [176, 230], [236, 280], [300, 240], [350, 270]], size: 4, core: '#FFF6D6', halo: '#FFE8A0', d: 7000, travel: [0, -110], kind: 'rise' }],
  },
  'hall-fire-the-forge': {
    frame: HALL_FRAME(-247),
    beams: [{ at: [150, -20], w: 120, h: 260, skew: -12, tint: '#FFE2AA', peak: 0.7 }],
    glows: [{ at: [178, 196], r: 70, tint: '#FFC46E', peak: 0.55, d: 2600, flicker: true }],
    dots: [{ at: [[160, 196], [176, 200], [192, 194], [170, 204], [186, 198], [200, 202]], size: 5, core: '#FFD08A', halo: '#FF963C', d: 3400, travel: [14, -120], kind: 'rise' }],
  },
  'hall-air-the-observatory': {
    frame: HALL_FRAME(-73),
    dots: [{ at: [[150, 62], [206, 44], [252, 76], [182, 96], [232, 118], [120, 150], [300, 160]], size: 5, core: '#FFFFFF', halo: '#C8D7FF', d: 3200, travel: [0, 0], kind: 'twinkle' }],
  },
  'hall-water-the-moon-pool': {
    frame: HALL_FRAME(-40),
    glows: [
      { at: [261, 99], r: 55, tint: '#F0ECFF', peak: 0.75, d: 6000 },
      { at: [65, 134], r: 24, tint: '#FFD68C', peak: 0.85, d: 2600, flicker: true },
      { at: [93, 82], r: 24, tint: '#FFD68C', peak: 0.85, d: 2600, flicker: true, delay: 700 },
      { at: [163, 129], r: 24, tint: '#FFD68C', peak: 0.85, d: 2600, flicker: true, delay: 1300 },
      { at: [347, 129], r: 24, tint: '#FFD68C', peak: 0.85, d: 2600, flicker: true, delay: 400 },
    ],
    dots: [{ at: [[52, 200], [110, 150], [250, 190], [318, 240], [350, 160]], size: 4, core: '#C9FFF0', halo: '#6EF0CD', d: 6500, travel: [18, -60], kind: 'rise' }],
  },
  'hall-earth-the-herb-garden': {
    frame: HALL_FRAME(-60),
    beams: [{ at: [200, 40], w: 90, h: 320, skew: 18, tint: '#FFF4BE', peak: 0.55 }],
    dots: [{ at: [[60, 220], [130, 180], [210, 240], [290, 200], [340, 250]], size: 4, core: '#FFF2B0', halo: '#E6DC78', d: 6000, travel: [30, -70], kind: 'rise' }],
  },
};

function Ambience({ painting, g }: { painting: PaintingId; g: ArtGeometry }) {
  const scene = SCENES[painting];
  if (!scene) return null;
  const [fl, ft, fw] = scene.frame;
  const k = g.sharp.width / fw;
  // Mockup px → px inside the window box.
  const X = (x: number) => g.sharp.left - g.box.left + (x - fl) * k;
  const Y = (y: number) => g.sharp.top + (y - ft) * k;
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" testID="hall-ambience">
      {scene.beams?.map((b, i) => <Beam key={`b${i}`} left={X(b.at[0])} top={Y(b.at[1])} w={b.w * k} h={b.h * k} skew={b.skew} tint={b.tint} peak={b.peak} />)}
      {scene.rays ? <Rays cx={X(scene.rays.at[0])} cy={Y(scene.rays.at[1])} r={scene.rays.r * k} /> : null}
      {scene.glows?.map((o, i) => <Glow key={`g${i}`} cx={X(o.at[0])} cy={Y(o.at[1])} r={o.r * k} tint={o.tint} peak={o.peak} d={o.d} flicker={o.flicker} delay={o.delay ?? 0} />)}
      {scene.dots?.flatMap((set, s) =>
        set.at.map((p, i) => (
          <Dot key={`d${s}-${i}`} x={X(p[0])} y={Y(p[1])} size={set.size * Math.max(1, k * 0.9)} core={set.core} halo={set.halo} d={set.d} delay={Math.round((i * set.d) / set.at.length)} travel={[set.travel[0] * k, set.travel[1] * k]} kind={set.kind} />
        )),
      )}
    </View>
  );
}

function Dot({ x, y, size, core, halo, d, delay, travel, kind }: { x: number; y: number; size: number; core: string; halo: string; d: number; delay: number; travel: Pt; kind: 'rise' | 'twinkle' }) {
  const rise = useRise(d, kind === 'rise', delay);
  const tw = useBreath(d, kind === 'twinkle', delay);
  const v = kind === 'rise' ? rise : tw;
  const opacity = kind === 'rise' ? v.interpolate({ inputRange: [0, 0.15, 0.8, 1], outputRange: [0, 1, 0.7, 0] }) : v.interpolate({ inputRange: [0, 1], outputRange: [0.2, 1] });
  const transform =
    kind === 'rise'
      ? [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, travel[0]] }) }, { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, travel[1]] }) }]
      : [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.6, 1] }) }];
  const H = size * 4;
  return (
    <Animated.View style={[st.abs, { left: x - H / 2, top: y - H / 2, width: H, height: H, alignItems: 'center', justifyContent: 'center', opacity, transform }]}>
      <View style={{ position: 'absolute', width: H, height: H, borderRadius: H / 2, backgroundColor: halo, opacity: 0.28 }} />
      <View style={{ position: 'absolute', width: size * 2, height: size * 2, borderRadius: size, backgroundColor: halo, opacity: 0.5 }} />
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: core }} />
    </Animated.View>
  );
}

function Glow({ cx, cy, r, tint, peak, d, flicker, delay }: { cx: number; cy: number; r: number; tint: string; peak: number; d: number; flicker?: boolean; delay: number }) {
  const v = useBreath(d, true, delay);
  const [id] = useState(() => `glow-${++gid}`);
  return (
    <Animated.View
      style={[
        st.abs,
        {
          left: cx - r,
          top: cy - r,
          width: r * 2,
          height: r * 2,
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: flicker ? [0.7, 1] : [0.55, 1] }),
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: flicker ? [0.96, 1.05] : [0.9, 1.1] }) }],
        },
      ]}
    >
      <Svg width={r * 2} height={r * 2}>
        <Defs>
          <RadialGradient id={id} cx="50%" cy="50%" r="50%">
            <Stop offset={0} stopColor={tint} stopOpacity={peak} />
            <Stop offset={1} stopColor={tint} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx={r} cy={r} r={r} fill={`url(#${id})`} />
      </Svg>
    </Animated.View>
  );
}

function Beam({ left, top, w, h, skew, tint, peak }: { left: number; top: number; w: number; h: number; skew: number; tint: string; peak: number }) {
  const v = useBreath(7000, true);
  const [id] = useState(() => `beam-${++gid}`);
  return (
    <Animated.View style={[st.abs, { left, top, width: w, height: h, opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] }), transform: [{ skewX: `${skew}deg` }] }]}>
      <Svg width={w} height={h}>
        <Defs>
          <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
            <Stop offset={0} stopColor={tint} stopOpacity={0} />
            <Stop offset={0.42} stopColor={tint} stopOpacity={peak * 0.6} />
            <Stop offset={1} stopColor={tint} stopOpacity={0} />
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width={w} height={h} fill={`url(#${id})`} />
      </Svg>
    </Animated.View>
  );
}

/** Slow-turning rays of morning light (Home). */
function Rays({ cx, cy, r }: { cx: number; cy: number; r: number }) {
  const [v] = useState(() => new Animated.Value(0));
  const [id] = useState(() => `rays-${++gid}`);
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration: 90000, easing: Easing.linear, useNativeDriver: native }));
    loop.start();
    return () => loop.stop();
  }, [v]);
  const wedges = useMemo(() => {
    let d = '';
    for (let a = 0; a < 360; a += 17) {
      const t0 = (a * Math.PI) / 180;
      const t1 = ((a + 5) * Math.PI) / 180;
      d += `M${r} ${r}L${r + r * Math.cos(t0)} ${r + r * Math.sin(t0)}L${r + r * Math.cos(t1)} ${r + r * Math.sin(t1)}Z`;
    }
    return d;
  }, [r]);
  return (
    <Animated.View style={[st.abs, { left: cx - r, top: cy - r, width: r * 2, height: r * 2, transform: [{ rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] }]}>
      <Svg width={r * 2} height={r * 2}>
        <Defs>
          <RadialGradient id={id} cx="50%" cy="50%" r="50%">
            <Stop offset={0.1} stopColor="#FFF3CE" stopOpacity={0.22} />
            <Stop offset={1} stopColor="#FFF3CE" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <G>
          <Path d={wedges} fill={`url(#${id})`} />
        </G>
      </Svg>
    </Animated.View>
  );
}

const st = StyleSheet.create({
  abs: { position: 'absolute' },
});
