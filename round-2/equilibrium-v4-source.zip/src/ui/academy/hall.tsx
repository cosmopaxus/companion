import React, { createContext, useContext } from 'react';
import { currentLessonId, currentTier, LESSON_BY_ID } from '../../domain/paths';
import { useStore } from '../../state/store';
import { isNight, serif } from '../../theme/tokens';
import { BUILDINGS, BuildingId, HALLS, HallId, Mode, resolveHall, WingId } from '../../theme/academy';

export interface HallState {
  hall: HallId;
  building: BuildingId;
  mode: Mode;
}

/** Where someone stands in the academy right now: their hall (element) and building (tier). */
export function useHall(): HallState {
  const { journey } = useStore();
  const lessonId = currentLessonId(journey);
  const element = lessonId ? LESSON_BY_ID[lessonId]?.element : undefined;
  return { hall: resolveHall(journey.prefs.hall, element), building: currentTier(journey) as BuildingId, mode: isNight ? 'night' : 'day' };
}

/** "Hall of Earth · The Herb Garden" — the lore name always comes with its plain label. */
export function hallLabel(h: HallId): string {
  return `${HALLS[h].element} · ${HALLS[h].name}`;
}

export function buildingLabel(b: BuildingId): string {
  return `${BUILDINGS[b].tier} · ${BUILDINGS[b].name}`;
}

// ——— Wings: each section's material ———

const WingCtx = createContext<WingId | null>(null);

export function WingProvider({ wing, children }: { wing: WingId; children: React.ReactNode }) {
  return <WingCtx.Provider value={wing}>{children}</WingCtx.Provider>;
}

/** The wing a component sits in, or null outside any wing (the v2 look). */
export function useWing(): WingId | null {
  return useContext(WingCtx);
}

/** Heading font. Since the Oct 14 art treatment every wing shares one: Cinzel. */
export function wingFont(_wing: WingId | null): string | undefined {
  return serif;
}
