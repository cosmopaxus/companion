// The painted art's files (scripts/make-art.py makes them from the build library's paintings).
// Kept apart from theme/paintings.ts so the data and math there stay testable without a bundler.
import type { ImageSourcePropType } from 'react-native';
import type { PaintingId } from '../../theme/paintings';

export const SHARP: Record<PaintingId, ImageSourcePropType> = {
  'academy-at-sunrise': require('../../../public/art/academy-at-sunrise.jpg'),
  'hall-fire-the-forge': require('../../../public/art/hall-fire-the-forge.jpg'),
  'hall-air-the-observatory': require('../../../public/art/hall-air-the-observatory.jpg'),
  'hall-water-the-moon-pool': require('../../../public/art/hall-water-the-moon-pool.jpg'),
  'hall-earth-the-herb-garden': require('../../../public/art/hall-earth-the-herb-garden.jpg'),
  'healing-sanctuary': require('../../../public/art/healing-sanctuary.jpg'),
  'hall-of-ascension': require('../../../public/art/hall-of-ascension.jpg'),
  'path-map-academy-grounds': require('../../../public/art/path-map-academy-grounds.jpg'),
};

/** Small pre-blurred copies: the frosted glass (phones have no backdrop blur, so it is baked in). */
export const BLURRED: Record<PaintingId, ImageSourcePropType> = {
  'academy-at-sunrise': require('../../../public/art/blur/academy-at-sunrise.jpg'),
  'hall-fire-the-forge': require('../../../public/art/blur/hall-fire-the-forge.jpg'),
  'hall-air-the-observatory': require('../../../public/art/blur/hall-air-the-observatory.jpg'),
  'hall-water-the-moon-pool': require('../../../public/art/blur/hall-water-the-moon-pool.jpg'),
  'hall-earth-the-herb-garden': require('../../../public/art/blur/hall-earth-the-herb-garden.jpg'),
  'healing-sanctuary': require('../../../public/art/blur/healing-sanctuary.jpg'),
  'hall-of-ascension': require('../../../public/art/blur/hall-of-ascension.jpg'),
  'path-map-academy-grounds': require('../../../public/art/blur/path-map-academy-grounds.jpg'),
};
