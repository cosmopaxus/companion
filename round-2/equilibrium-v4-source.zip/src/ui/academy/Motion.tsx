// v3 · Graphics & Interface, phase 3: motion. Built on React Native's own Animated (no new
// library). Every piece is decoration layered over the fixed frame: it never moves a control,
// never blocks a tap (pointerEvents none), and stops entirely under reduced motion.

import React, { useEffect, useState } from 'react';
import { Animated, Easing, Platform, StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { useReducedMotion } from '../../state/motion';
import { radius, space } from '../../theme/tokens';
import { duskStops, HALLS, HallId, Mode, ON_HALL } from '../../theme/academy';
import { Gem, Icon } from '../Icon';
import { useHall, wingFont } from './hall';

const native = Platform.OS !== 'web';

/** A 0 → 1 → 0 value that loops slowly while `on`; holds at 0 otherwise. */
export function useBreath(duration: number, on: boolean, delay = 0) {
  const [v] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (!on) {
      v.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(v, { toValue: 1, duration: duration / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
        Animated.timing(v, { toValue: 0, duration: duration / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [on, duration, delay, v]);
  return v;
}

/** A 0 → 1 value that repeats from 0 (for things that rise and fade). */
export function useRise(duration: number, on: boolean, delay = 0) {
  const [v] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (!on) {
      v.setValue(0);
      return;
    }
    const loop = Animated.loop(Animated.sequence([Animated.delay(delay), Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: native }), Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: native })]));
    loop.start();
    return () => loop.stop();
  }, [on, duration, delay, v]);
  return v;
}

const MOTES = [
  { x: 0.18, d: 7000, delay: 0, size: 5 },
  { x: 0.46, d: 8600, delay: 2400, size: 4 },
  { x: 0.72, d: 7600, delay: 1200, size: 6 },
  { x: 0.88, d: 9200, delay: 3600, size: 4 },
];

function Mote({ x, d, delay, size, tint, height }: { x: number; d: number; delay: number; size: number; tint: string; height: number }) {
  const v = useRise(d, true, delay);
  return (
    <Animated.View
      style={{
        position: 'absolute',
        left: `${x * 100}%`,
        bottom: 6,
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: tint,
        opacity: v.interpolate({ inputRange: [0, 0.15, 0.7, 1], outputRange: [0, 0.85, 0.5, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, -height * 0.9] }) }, { translateX: v.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, 6, -4] }) }],
      }}
    />
  );
}

/**
 * Ambient life in a hall header's art strip: a slow breath of light and a few motes rising —
 * sparks in the Forge, motes of starlight in the Observatory, bubbles in the Moon Pool, fireflies
 * in the Herb Garden. Kept below the text block, so text contrast never changes.
 */
export function HallAmbience({ hall, mode, height }: { hall: HallId; mode: Mode; height: number }) {
  const reduce = useReducedMotion();
  const breath = useBreath(7000, !reduce);
  if (reduce) return null;
  const light = HALLS[hall][mode][2];
  return (
    <View pointerEvents="none" aria-hidden accessible={false} importantForAccessibility="no-hide-descendants" style={[st.ambience, { height }]} testID="hall-ambience">
      <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: light, opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0, mode === 'day' ? 0.14 : 0.1] }) }]} />
      {MOTES.map((m, i) => (
        <Mote key={i} {...m} tint={hall === 'air' ? '#FFFFFF' : light} height={height} />
      ))}
    </View>
  );
}

/** A soft ring that breathes outward from "you are here" on the path map. */
export function HerePulse({ size, color: c }: { size: number; color: string }) {
  const reduce = useReducedMotion();
  const v = useRise(2800, !reduce);
  if (reduce) return null;
  return (
    <Animated.View
      pointerEvents="none"
      aria-hidden
      testID="here-pulse"
      style={{
        position: 'absolute',
        width: size,
        height: size,
        borderRadius: size / 2,
        borderWidth: 3,
        borderColor: c,
        opacity: v.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0, 0.6, 0] }),
        transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.85, 1.45] }) }],
      }}
    />
  );
}

/** The gem in a toast pops in once when gems are earned. */
export function GemPop({ size = 15, trigger }: { size?: number; trigger: number }) {
  const reduce = useReducedMotion();
  const [v] = useState(() => new Animated.Value(1));
  useEffect(() => {
    if (reduce) return;
    v.setValue(0.4);
    Animated.spring(v, { toValue: 1, friction: 4, tension: 160, useNativeDriver: native }).start();
  }, [trigger, reduce, v]);
  return (
    <Animated.View style={{ transform: [{ scale: v }] }}>
      <Gem size={size} />
    </Animated.View>
  );
}

export interface CelebrationMsg {
  id: number;
  kind: 'lesson' | 'badge';
  title: string;
}

const SPARKS = Array.from({ length: 10 }, (_, i) => (i * 360) / 10);

function Spark({ angle, v, tint }: { angle: number; v: Animated.Value; tint: string }) {
  const r = (angle * Math.PI) / 180;
  return (
    <Animated.View
      style={{
        position: 'absolute',
        width: 7,
        height: 7,
        borderRadius: 4,
        backgroundColor: tint,
        opacity: v.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0, 1, 0] }),
        transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.cos(r) * 46] }) }, { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.sin(r) * 46] }) }],
      }}
    />
  );
}

/**
 * A moment of recognition when a lesson is mastered or a seal (badge) is earned: a banner in the
 * hall's colors, a medallion that pops, and a burst of sparks. It never blocks a tap and leaves on
 * its own; under reduced motion it simply appears and fades with no burst.
 */
export function Celebration({ msg, top }: { msg: CelebrationMsg | null; top: number }) {
  const reduce = useReducedMotion();
  const { hall, mode } = useHall();
  // The banner shows the latest message until its animation says it's done.
  const [doneId, setDoneId] = useState<number | null>(null);
  const shown = msg && msg.id !== doneId ? msg : null;
  const [fade] = useState(() => new Animated.Value(0));
  const [pop] = useState(() => new Animated.Value(1));
  const [burst] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (!msg) return;
    const done = () => setDoneId(msg.id);
    fade.setValue(reduce ? 1 : 0);
    const out = Animated.timing(fade, { toValue: 0, duration: 400, delay: 3000, useNativeDriver: native });
    if (reduce) {
      out.start(done);
      return () => out.stop();
    }
    pop.setValue(0.3);
    burst.setValue(0);
    const run = Animated.sequence([
      Animated.parallel([
        Animated.timing(fade, { toValue: 1, duration: 220, useNativeDriver: native }),
        Animated.spring(pop, { toValue: 1, friction: 4, tension: 140, useNativeDriver: native }),
        Animated.timing(burst, { toValue: 1, duration: 900, delay: 120, easing: Easing.out(Easing.quad), useNativeDriver: native }),
      ]),
      out,
    ]);
    run.start(done);
    return () => run.stop();
  }, [msg, reduce, fade, pop, burst]);
  if (!shown) return null;
  const stops = duskStops(hall, mode);
  const light = HALLS[hall][mode][2];
  const eyebrow = shown.kind === 'lesson' ? 'Lesson mastered' : 'Seal earned · Badge';
  return (
    <View pointerEvents="none" style={[st.celebrationWrap, { top }]} role="status" aria-live="polite" testID="celebration">
      <Animated.View style={[st.celebration, { opacity: fade }]}>
        <View style={StyleSheet.absoluteFill} aria-hidden>
          <Svg width="100%" height="100%">
            <Defs>
              <LinearGradient id="celebration-g" x1="0" y1="0" x2="1" y2="1">
                {stops.map((s, i) => (
                  <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={1} />
                ))}
              </LinearGradient>
            </Defs>
            <Rect x={0} y={0} width="100%" height="100%" fill="url(#celebration-g)" />
          </Svg>
        </View>
        <View style={st.medalBox} aria-hidden>
          {reduce ? null : SPARKS.map((a) => <Spark key={a} angle={a} v={burst} tint={light} />)}
          <Animated.View style={[st.medal, { borderColor: light, transform: [{ scale: pop }] }]}>
            <Icon name={shown.kind === 'lesson' ? 'check' : 'seal'} size={24} color={ON_HALL.title} strokeWidth={2.6} />
          </Animated.View>
        </View>
        <View style={{ flex: 1, gap: 2 }}>
          <Text style={st.eyebrow}>{eyebrow}</Text>
          <Text style={[st.title, { fontFamily: wingFont('academy') }]} numberOfLines={2}>
            {shown.title}
          </Text>
        </View>
      </Animated.View>
    </View>
  );
}

const st = StyleSheet.create({
  ambience: { position: 'absolute', left: 0, right: 0, bottom: 0, overflow: 'hidden' },
  celebrationWrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center', paddingHorizontal: space.lg },
  celebration: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: space.md, paddingHorizontal: space.lg, borderRadius: radius.lg, overflow: 'hidden', maxWidth: 460, width: '100%' },
  medalBox: { width: 56, height: 56, alignItems: 'center', justifyContent: 'center' },
  medal: { width: 48, height: 48, borderRadius: 24, borderWidth: 3, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.22)' },
  eyebrow: { fontSize: 12, lineHeight: 16, fontWeight: '700', letterSpacing: 1.2, textTransform: 'uppercase', color: ON_HALL.soft },
  title: { fontSize: 20, lineHeight: 25, fontWeight: '800', color: ON_HALL.title },
});
