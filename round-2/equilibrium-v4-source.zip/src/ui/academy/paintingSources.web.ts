// Web: the paintings are served from public/art with RELATIVE addresses, so the app works at any
// address (the site root, /companion/, a folder) — see scripts/package-pages.mjs. Phones bundle them
// (paintingSources.ts).
import type { ImageSourcePropType } from 'react-native';
import { PAINTINGS, PaintingId } from '../../theme/paintings';

const ids = Object.keys(PAINTINGS) as PaintingId[];
const map = (dir: string) => Object.fromEntries(ids.map((id) => [id, { uri: `${dir}${id}.jpg` }])) as Record<PaintingId, ImageSourcePropType>;

export const SHARP = map('art/');
export const BLURRED = map('art/blur/');
