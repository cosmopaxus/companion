import React, { useState } from 'react';
import { LayoutChangeEvent, StyleSheet, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { color } from '../../theme/tokens';
import { BuildingId, duskStops, HALLS, HallId, mix, Mode } from '../../theme/academy';
import { Building } from './HallArt';

let gid = 0;

/**
 * The lit band at the top of an open region of the grounds: the hall's dusk gradient (safe for
 * light text anywhere) with that tier's building in silhouette along its foot.
 */
export function RegionSky({ hall, building, mode }: { hall: HallId; building: BuildingId; mode: Mode }) {
  const [size, setSize] = useState({ w: 360, h: 120 });
  const [id] = useState(() => `sky-${++gid}`);
  const stops = duskStops(hall, mode);
  const fill = mix(HALLS[hall][mode][0], '#000000', 0.35);
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" aria-hidden accessible={false} importantForAccessibility="no-hide-descendants" onLayout={(e: LayoutChangeEvent) => setSize({ w: Math.max(1, Math.round(e.nativeEvent.layout.width)), h: Math.max(1, Math.round(e.nativeEvent.layout.height)) })}>
      <Svg width="100%" height={size.h}>
        <Defs>
          <LinearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            {stops.map((s, i) => (
              <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={1} />
            ))}
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width="100%" height={size.h} fill={`url(#${id})`} />
        <Building building={building} w={size.w} h={size.h} fill={fill} />
      </Svg>
    </View>
  );
}

/** An unlit region: stone-colored, with the building drawn faintly, for paths not open yet. */
export function RegionStone({ building }: { building: BuildingId }) {
  const [size, setSize] = useState({ w: 360, h: 100 });
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" aria-hidden accessible={false} importantForAccessibility="no-hide-descendants" onLayout={(e: LayoutChangeEvent) => setSize({ w: Math.max(1, Math.round(e.nativeEvent.layout.width)), h: Math.max(1, Math.round(e.nativeEvent.layout.height)) })}>
      <Svg width="100%" height={size.h} opacity={0.35}>
        <Building building={building} w={size.w} h={size.h} fill={color.controlBorder} />
      </Svg>
    </View>
  );
}
