import React, { useState } from 'react';
import { LayoutChangeEvent, StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import Svg, { Circle, Defs, G, LinearGradient, Path, Pattern, Rect, Stop } from 'react-native-svg';
import { BuildingId, duskStops, HALLS, HallId, HERO_ART, heroStops, mix, Mode } from '../../theme/academy';

// The hall gradient with its building (tier) and props (element). Everything here is decoration:
// it is hidden from screen readers, and text is laid over the dark top zone by the caller.

let gid = 0;

function Gradient({ hall, mode, id, textPx }: { hall: HallId; mode: Mode; id: string; textPx: number }) {
  const stops = heroStops(hall, mode, textPx);
  return (
    <Defs>
      <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        {stops.map((s, i) => (
          <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={1} />
        ))}
      </LinearGradient>
    </Defs>
  );
}

/** Silhouette color: the hall's darkest shade, deeper at night. */
function ink(hall: HallId, mode: Mode): string {
  const dark = HALLS[hall].day[0];
  return mode === 'day' ? dark : mix(dark, '#000000', 0.45);
}

export function Building({ building, w, h, fill }: { building: BuildingId; w: number; h: number; fill: string }) {
  const base = h;
  switch (building) {
    case 'foundation': {
      // A colonnade: a low wall pierced by round-topped arches, light showing through.
      const aw = 40;
      const pier = 14;
      const n = Math.ceil(w / (aw + pier)) + 1;
      const wallTop = base - 62;
      const archTop = base - 52;
      let d = `M0 ${wallTop}H${w}V${base}H0Z`;
      for (let i = 0; i < n; i++) {
        const x = i * (aw + pier) + pier / 2;
        d += `M${x} ${base}V${archTop + aw / 2}A${aw / 2} ${aw / 2} 0 0 1 ${x + aw} ${archTop + aw / 2}V${base}Z`;
      }
      return (
        <G>
          <Path d={d} fill={fill} fillRule="evenodd" opacity={0.42} />
          <Rect x={0} y={wallTop - 5} width={w} height={5} fill={fill} opacity={0.55} />
        </G>
      );
    }
    case 'acolyte': {
      // Tall library windows with shelves.
      const ww = 34;
      const gap = 26;
      const n = Math.ceil(w / (ww + gap)) + 1;
      const top = base - 64;
      let d = '';
      let shelves = '';
      for (let i = 0; i < n; i++) {
        const x = i * (ww + gap) + 6;
        d += `M${x} ${base}V${top + 17}A17 17 0 0 1 ${x + ww} ${top + 17}V${base}Z`;
        shelves += `M${x + 4} ${base - 18}H${x + ww - 4}M${x + 4} ${base - 34}H${x + ww - 4}`;
      }
      return (
        <G>
          <Path d={d} fill={fill} opacity={0.3} />
          <Path d={shelves} stroke={fill} strokeWidth={2} opacity={0.5} />
          <Rect x={0} y={base - 6} width={w} height={6} fill={fill} opacity={0.75} />
        </G>
      );
    }
    case 'initiate': {
      // A tower rising over a low wall.
      const tx = Math.min(w * 0.38, 150);
      return (
        <G>
          <Path d={`M0 ${base}V${base - 22}H${w}V${base}Z`} fill={fill} opacity={0.45} />
          <Path d={`M${tx} ${base}V${base - 84}L${tx + 22} ${base - 104}L${tx + 44} ${base - 84}V${base}Z`} fill={fill} opacity={0.75} />
          <Rect x={tx + 17} y={base - 72} width={10} height={20} rx={5} fill={mix(fill, '#FFFFFF', 0.55)} opacity={0.5} />
        </G>
      );
    }
    case 'adept': {
      // A vaulted dome on its drum.
      const cx = Math.min(w * 0.36, 160);
      return (
        <G>
          <Path d={`M0 ${base}V${base - 16}H${w}V${base}Z`} fill={fill} opacity={0.45} />
          <Path d={`M${cx - 54} ${base}V${base - 38}H${cx + 54}V${base}Z`} fill={fill} opacity={0.7} />
          <Path d={`M${cx - 46} ${base - 38}A46 46 0 0 1 ${cx + 46} ${base - 38}Z`} fill={fill} opacity={0.8} />
          <Path d={`M${cx} ${base - 84}V${base - 96}`} stroke={fill} strokeWidth={3} strokeLinecap="round" />
        </G>
      );
    }
  }
}

function Props({ hall, w, h, fill, mode }: { hall: HallId; w: number; h: number; fill: string; mode: Mode }) {
  const light = HALLS[hall][mode][2];
  const x = w - 120; // props live at the right, clear of the title
  const b = h;
  switch (hall) {
    case 'earth':
      return (
        <G>
          <Path d={`M${x} ${b}V${b - 22}H${x + 104}V${b}Z`} fill={fill} opacity={0.85} />
          {[10, 26, 42, 60, 76, 92].map((dx, i) => {
            const tall = i % 2 ? 26 : 38;
            const sx = x + dx;
            return <Path key={i} d={`M${sx} ${b - 22}Q${sx - 9} ${b - 22 - tall * 0.6} ${sx} ${b - 22 - tall}Q${sx + 9} ${b - 22 - tall * 0.6} ${sx} ${b - 22}Z`} fill={fill} opacity={0.9} />;
          })}
        </G>
      );
    case 'fire':
      return (
        <G>
          <Path d={`M${x + 8} ${b - 30}H${x + 92}L${x + 80} ${b - 18}H${x + 20}Z`} fill={fill} />
          <Path d={`M${x + 38} ${b - 18}H${x + 62}L${x + 68} ${b}H${x + 32}Z`} fill={fill} opacity={0.9} />
          {[
            [52, 46, 2.4],
            [66, 58, 1.8],
            [40, 62, 1.6],
            [76, 44, 2],
            [58, 72, 1.4],
          ].map(([dx, dy, r], i) => (
            <Circle key={i} cx={x + dx} cy={b - dy} r={r} fill={light} />
          ))}
        </G>
      );
    case 'air':
      return (
        <G>
          <Path d={`M${x + 20} ${b}V${b - 34}A34 34 0 0 1 ${x + 88} ${b - 34}V${b}Z`} fill={fill} opacity={0.9} />
          <Rect x={x + 48} y={b - 78} width={40} height={10} rx={5} transform={`rotate(-28 ${x + 68} ${b - 73})`} fill={fill} />
          {[
            [w - 30, 26],
            [w - 64, 16],
            [w - 96, 34],
            [w - 48, 44],
          ].map(([cx, cy], i) => (
            <Circle key={i} cx={cx} cy={cy} r={1.4} fill="#FFFFFF" opacity={0.85} />
          ))}
        </G>
      );
    case 'water':
      return (
        <G>
          <Circle cx={w - 40} cy={32} r={13} fill={light} opacity={0.9} />
          <Circle cx={w - 34} cy={28} r={11} fill={HALLS[hall][mode][0]} />
          {[0, 12, 24].map((dy, i) => (
            <Path key={i} d={`M${x} ${b - 10 - dy}q13 -6 26 0t26 0t26 0t26 0`} stroke={fill} strokeWidth={2.4} fill="none" opacity={0.8 - i * 0.2} strokeLinecap="round" />
          ))}
        </G>
      );
  }
}

/** The full hall scene: gradient, building and props. Fills its parent, behind a text block of `textPx`. */
export function HallScene({ hall, building, mode, textPx, style }: { hall: HallId; building: BuildingId; mode: Mode; textPx: number; style?: StyleProp<ViewStyle> }) {
  const [size, setSize] = useState({ w: 360, h: textPx + HERO_ART });
  const [id] = useState(() => `hall-${++gid}`);
  const fill = ink(hall, mode);
  const { w } = size;
  const height = size.h;
  return (
    <View
      style={[StyleSheet.absoluteFill, style]}
      onLayout={(e: LayoutChangeEvent) => setSize({ w: Math.max(1, Math.round(e.nativeEvent.layout.width)), h: Math.max(1, Math.round(e.nativeEvent.layout.height)) })}
      aria-hidden
      accessible={false}
      importantForAccessibility="no-hide-descendants"
      pointerEvents="none"
    >
      <Svg width="100%" height={height}>
        <Gradient hall={hall} mode={mode} id={id} textPx={textPx} />
        <Rect x={0} y={0} width="100%" height={height} fill={`url(#${id})`} />
        <Building building={building} w={w} h={height} fill={fill} />
        <Props hall={hall} w={w} h={height} fill={fill} mode={mode} />
      </Svg>
    </View>
  );
}

/** A dusk band: the hall's dark color easing toward its mid color, edged with the full hall gradient. */
export function DuskScene({ hall, mode, height }: { hall: HallId; mode: Mode; height: number }) {
  const [w, setW] = useState(360);
  const [id] = useState(() => `dusk-${++gid}`);
  const stops = duskStops(hall, mode);
  const [d, m, l] = HALLS[hall][mode];
  const edge = [0, 0.5, 1].map((offset, i) => ({ offset, color: [d, m, l][i] }));
  return (
    <View
      style={StyleSheet.absoluteFill}
      onLayout={(e: LayoutChangeEvent) => setW(Math.max(1, Math.round(e.nativeEvent.layout.width)))}
      aria-hidden
      accessible={false}
      importantForAccessibility="no-hide-descendants"
      pointerEvents="none"
    >
      <Svg width="100%" height={height}>
        <Defs>
          <LinearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            {stops.map((s, i) => (
              <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={1} />
            ))}
          </LinearGradient>
          <LinearGradient id={`${id}-edge`} x1="0" y1="0" x2="1" y2="0">
            {edge.map((s, i) => (
              <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={1} />
            ))}
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width="100%" height={height} fill={`url(#${id})`} />
        <Rect x={0} y={height - 5} width={w} height={5} fill={`url(#${id}-edge)`} />
      </Svg>
    </View>
  );
}

/** Small scenery along a trail, in the empty space beside each lesson: herbs, lamps, stones or stars. */
export function GroundsDecor({ building, spots, tint }: { building: BuildingId; spots: { x: number; y: number }[]; tint: string }) {
  return (
    <G opacity={0.5}>
      {spots.map(({ x, y }, i) => {
        switch (building) {
          case 'foundation':
            return i % 2 ? (
              <G key={i}>
                <Path d={`M${x} ${y + 14}V${y}`} stroke={tint} strokeWidth={3} strokeLinecap="round" />
                <Circle cx={x} cy={y - 8} r={12} fill={tint} />
              </G>
            ) : (
              <Path key={i} d={`M${x - 10} ${y + 12}Q${x - 14} ${y - 4} ${x - 6} ${y - 12}Q${x - 4} ${y} ${x} ${y + 12}M${x} ${y + 12}Q${x + 2} ${y - 6} ${x + 8} ${y - 14}Q${x + 14} ${y - 2} ${x + 10} ${y + 12}Z`} fill={tint} />
            );
          case 'acolyte':
            return (
              <G key={i}>
                <Path d={`M${x} ${y + 16}V${y - 8}`} stroke={tint} strokeWidth={3} strokeLinecap="round" />
                <Path d={`M${x - 7} ${y - 8}H${x + 7}L${x + 5} ${y - 20}H${x - 5}Z`} fill={tint} />
              </G>
            );
          case 'initiate':
            return <Path key={i} d={`M${x - 8} ${y + 14}L${x - 6} ${y - 14}Q${x} ${y - 20} ${x + 6} ${y - 14}L${x + 8} ${y + 14}Z`} fill={tint} />;
          case 'adept':
            return <Path key={i} d={`M${x} ${y - 12}L${x + 3.5} ${y - 3.5}L${x + 12} ${y}L${x + 3.5} ${y + 3.5}L${x} ${y + 12}L${x - 3.5} ${y + 3.5}L${x - 12} ${y}L${x - 3.5} ${y - 3.5}Z`} fill={tint} />;
        }
      })}
    </G>
  );
}

/** A faint dotted ground behind a wing's content, tinted by the hall. */
export function WingTexture({ hall, mode }: { hall: HallId; mode: Mode }) {
  const [id] = useState(() => `tex-${++gid}`);
  const dot = mode === 'day' ? HALLS[hall].day[1] : HALLS[hall].day[2];
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" aria-hidden accessible={false} importantForAccessibility="no-hide-descendants">
      <Svg width="100%" height="100%">
        <Defs>
          <Pattern id={id} x={0} y={0} width={26} height={26} patternUnits="userSpaceOnUse">
            <Circle cx={13} cy={13} r={2.2} fill={dot} opacity={mode === 'day' ? 0.13 : 0.1} />
          </Pattern>
        </Defs>
        <Rect x={0} y={0} width="100%" height="100%" fill={`url(#${id})`} />
      </Svg>
    </View>
  );
}
