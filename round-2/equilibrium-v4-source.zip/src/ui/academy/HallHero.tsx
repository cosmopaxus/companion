import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { space } from '../../theme/tokens';
import { HALLS, ON_HALL } from '../../theme/academy';
import { useHall } from './hall';


/**
 * The top of a glass card that belongs to the hall (the check-in): a thin edge in the hall's full
 * gradient along the card's top, with the card's heading below it in ordinary ink.
 */
export function HallBand({ children, testID }: { children: React.ReactNode; testID?: string }) {
  const { hall, mode } = useHall();
  const [id] = useState(() => `edge-${++gid}`);
  const [d, m, l] = HALLS[hall][mode];
  return (
    <View testID={testID} style={{ gap: 4 }}>
      <View style={st.edge} aria-hidden accessible={false} importantForAccessibility="no-hide-descendants">
        <Svg width="100%" height={6}>
          <Defs>
            <LinearGradient id={id} x1="0" y1="0" x2="1" y2="0">
              <Stop offset={0} stopColor={d} />
              <Stop offset={0.5} stopColor={m} />
              <Stop offset={1} stopColor={l} />
            </LinearGradient>
          </Defs>
          <Rect x={0} y={0} width="100%" height={6} fill={`url(#${id})`} />
        </Svg>
      </View>
      {children}
    </View>
  );
}

let gid = 0;

export const onHall = StyleSheet.create({
  eyebrow: { fontSize: 12, lineHeight: 16, fontWeight: '700', letterSpacing: 1.2, textTransform: 'uppercase', color: ON_HALL.soft },
  title: { fontSize: 24, lineHeight: 30, color: ON_HALL.title, fontWeight: '800' },
  body: { fontSize: 14, lineHeight: 20, color: ON_HALL.soft },
});

const st = StyleSheet.create({
  edge: { height: 6, marginHorizontal: -space.xl, marginTop: -space.xl, marginBottom: space.md, borderTopLeftRadius: 21, borderTopRightRadius: 21, overflow: 'hidden' },
});
