import React from 'react';
import { Text, View } from 'react-native';
import type { Level } from '../domain/types';
import { CHECKIN_SCALES, CheckInDimension, levelWord } from '../domain/scales';
import { color, isNight, space, type } from '../theme/tokens';
import { Field } from './controls';
import { FeelSlider } from './feel/FeelSlider';
import { feelColor, FEEL_CARD_TINT, FEEL_TEXT, mix, withAlpha } from './feel/palette';
import { FeelGlyph } from './feel/FeelGlyph';

export interface CheckInValue {
  mood?: Level;
  energy?: Level;
  connection?: Level;
  note?: string;
}

const DIMS: CheckInDimension[] = ['mood', 'energy', 'connection'];

/** The three 0–100 feeling sliders plus an optional note. Used by Today and by the practice lesson. */
export function CheckInForm({ value, onChange, idPrefix = 'checkin', noteLabel = 'Note', notePlaceholder = 'Anything you want to remember about this moment?', compact }: { value: CheckInValue; onChange: (v: CheckInValue) => void; idPrefix?: string; noteLabel?: string; notePlaceholder?: string; compact?: boolean }) {
  return (
    <View style={{ gap: compact ? space.sm + 2 : space.md }}>
      {DIMS.map((d) => (
        <FeelSlider key={d} dim={d} value={value[d]} onChange={(r) => onChange({ ...value, [d]: r })} testID={`${idPrefix}-${d}`} />
      ))}
      {compact ? null : <View style={{ height: space.sm }} />}
      <Field label={noteLabel} optional value={value.note ?? ''} onChangeText={(t) => onChange({ ...value, note: t })} multiline minHeight={compact ? 52 : 84} placeholder={notePlaceholder} maxLength={2000} testID={`${idPrefix}-note`} />
    </View>
  );
}

export function checkInComplete(v: CheckInValue): v is Required<Pick<CheckInValue, 'mood' | 'energy' | 'connection'>> & CheckInValue {
  return v.mood !== undefined && v.energy !== undefined && v.connection !== undefined;
}

export function CheckInSummary({ mood, energy, connection }: { mood: Level; energy: Level; connection: Level }) {
  const item = (d: CheckInDimension, v: Level) => (
    <View key={d} style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
      <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: feelColor(d, v) }} />
      <Text style={[type.small, { color: color.inkSoft }]}>{CHECKIN_SCALES[d].label}</Text>
      <Text style={[type.label, { fontSize: 14 }]}>
        {v} <Text style={[type.small, { fontSize: 13 }]}>{levelWord(d, v)}</Text>
      </Text>
    </View>
  );
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', columnGap: space.lg, rowGap: 2 }}>
      {item('mood', mood)}
      {item('energy', energy)}
      {item('connection', connection)}
    </View>
  );
}

/** The three readings as tiles (mockup 04): a picture, the name, and the value with its word. */
export function CheckInTiles({ mood, energy, connection, compact }: { mood: Level; energy: Level; connection: Level; compact?: boolean }) {
  const tile = (d: CheckInDimension, v: Level) => {
    const c = feelColor(d, v);
    return (
      <View key={d} style={{ flex: 1, minWidth: 92, alignItems: 'center', gap: compact ? 0 : 2, paddingVertical: compact ? 5 : space.sm, paddingHorizontal: 4, borderRadius: 14, backgroundColor: mix(color.paperStrong, c, FEEL_CARD_TINT * 2), borderWidth: 1, borderColor: withAlpha(c, 0.3) }} testID={`checkin-tile-${d}`}>
        <FeelGlyph dim={d} level={v} size={compact ? 22 : 30} />
        <Text style={[type.small, { fontSize: 12.5, lineHeight: 16, color: color.inkSoft }]}>{CHECKIN_SCALES[d].label}</Text>
        <Text style={{ fontSize: 14, lineHeight: 18, fontWeight: '800', color: FEEL_TEXT[d][isNight ? 'night' : 'day'], textAlign: 'center' }}>
          {v} · {levelWord(d, v)}
        </Text>
      </View>
    );
  };
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
      {tile('mood', mood)}
      {tile('energy', energy)}
      {tile('connection', connection)}
    </View>
  );
}
