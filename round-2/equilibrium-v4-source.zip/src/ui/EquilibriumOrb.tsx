import React, { useEffect, useId, useState } from 'react';
import { Animated, Easing, Platform, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Defs, G, Path, RadialGradient, Stop } from 'react-native-svg';
import type { ElementId } from '../domain/types';
import { ELEMENTS } from '../domain/harmony';
import { color, elementColor, elementText, sans } from '../theme/tokens';
import { useReducedMotion } from '../state/motion';
import { ElementGlyph } from './Icon';

// The Compass orb: four lobes — Fire above, Air right, Water below, Earth left (the classical
// arrangement; opposites face each other). Each lobe reaches out as far as that element's balance.
// When the elements are matched the orb is a soft, even bloom; when they pull apart it turns lopsided.
// It breathes slowly when in step and a little faster when in discord. Faint outlines behind it are
// your recent readings, so the shift over time shows in the same picture.

const ANGLE: Record<ElementId, number> = { fire: -90, air: 0, water: 90, earth: 180 };
const ORDER: ElementId[] = ['fire', 'air', 'water', 'earth'];

function radiusFor(v: number, R: number) {
  return R * (0.32 + 0.68 * (Math.max(0, Math.min(100, v)) / 100));
}

/** A smooth closed outline through eight points: one per element, and a gentle waist between each. */
export function orbPath(values: Record<ElementId, number>, cx: number, cy: number, R: number): string {
  const pts: [number, number][] = [];
  ORDER.forEach((el, i) => {
    const next = ORDER[(i + 1) % 4];
    const a = (ANGLE[el] * Math.PI) / 180;
    const r = radiusFor(values[el], R);
    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    const am = ((ANGLE[el] + 45) * Math.PI) / 180;
    const rm = ((radiusFor(values[el], R) + radiusFor(values[next], R)) / 2) * 0.9;
    pts.push([cx + Math.cos(am) * rm, cy + Math.sin(am) * rm]);
  });
  // Closed Catmull–Rom spline as cubic Béziers.
  const n = pts.length;
  let d = `M${pts[0][0].toFixed(2)} ${pts[0][1].toFixed(2)}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n];
    const p1 = pts[i];
    const p2 = pts[(i + 1) % n];
    const p3 = pts[(i + 2) % n];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += ` C${c1[0].toFixed(2)} ${c1[1].toFixed(2)} ${c2[0].toFixed(2)} ${c2[1].toFixed(2)} ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
  }
  return `${d} Z`;
}

/** Breathing pace: calm when the elements move together, quicker when they pull apart. */
export function breathFor(spread: number): { ms: number; amp: number } {
  if (spread < 15) return { ms: 7000, amp: 0.014 };
  if (spread < 30) return { ms: 5200, amp: 0.018 };
  if (spread < 50) return { ms: 4000, amp: 0.024 };
  return { ms: 3000, amp: 0.03 };
}

interface Props {
  values: Record<ElementId, number>;
  /** Earlier readings, oldest first, drawn as faint outlines. */
  history?: Record<ElementId, number>[];
  size?: number;
  labels?: boolean;
  animate?: boolean;
  testID?: string;
}

export function EquilibriumOrb({ values, history = [], size = 240, labels = true, animate = true, testID }: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const reduce = useReducedMotion();
  const moving = animate && !reduce;
  const pad = labels ? 44 : 4;
  const R = (size - pad * 2) / 2;
  const c = size / 2;
  const list = ORDER.map((el) => values[el]);
  const spread = Math.max(...list) - Math.min(...list);
  const { ms, amp } = breathFor(spread);

  const [breath] = useState(() => new Animated.Value(0.5));
  const [turn] = useState(() => new Animated.Value(0));
  useEffect(() => {
    if (!moving) {
      breath.setValue(0.5);
      turn.setValue(0);
      return;
    }
    const native = Platform.OS !== 'web';
    const b = Animated.loop(
      Animated.sequence([
        Animated.timing(breath, { toValue: 1, duration: ms / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
        Animated.timing(breath, { toValue: 0, duration: ms / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: native }),
      ]),
    );
    const t = Animated.loop(Animated.timing(turn, { toValue: 1, duration: 90000, easing: Easing.linear, useNativeDriver: native }));
    b.start();
    t.start();
    return () => {
      b.stop();
      t.stop();
    };
  }, [moving, ms, breath, turn]);

  const scale = breath.interpolate({ inputRange: [0, 1], outputRange: [1 - amp, 1 + amp] });
  const rotate = turn.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const summary = ORDER.map((el) => `${ELEMENTS[el].name} ${values[el]}`).join(', ');
  const evenR = radiusFor(50, R);

  return (
    <View role="img" aria-label={`Compass. ${summary}. 50 is even: what you have meets what is asked.`} style={{ width: size, height: size, alignSelf: 'center' }} testID={testID}>
      {/* Still layer: the field, the even ring, and earlier readings. */}
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Defs>
          <RadialGradient id={`field-${uid}`} cx="50%" cy="50%" r="50%">
            <Stop offset="0" stopColor={color.orbField0} />
            <Stop offset="1" stopColor={color.orbField1} />
          </RadialGradient>
        </Defs>
        <Circle cx={c} cy={c} r={R} fill={`url(#field-${uid})`} stroke={color.border} strokeWidth={1.2} />
        <Circle cx={c} cy={c} r={evenR} fill="none" stroke={color.goldDeco} strokeWidth={1.2} strokeDasharray="2 5" opacity={0.9} />
        {history.map((h, i) => (
          <Path key={i} d={orbPath(h, c, c, R)} fill="none" stroke={color.sage2} strokeWidth={1} opacity={0.12 + (0.28 * (i + 1)) / Math.max(1, history.length)} />
        ))}
      </Svg>

      {/* A slowly turning ring of points, like a dial at rest. */}
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { transform: [{ rotate }] }]}>
        <Svg width={size} height={size}>
          {Array.from({ length: 24 }, (_, i) => {
            const a = (i / 24) * Math.PI * 2;
            return <Circle key={i} cx={c + Math.cos(a) * (R - 5)} cy={c + Math.sin(a) * (R - 5)} r={i % 6 === 0 ? 1.6 : 0.9} fill={color.goldDeco} opacity={0.55} />;
          })}
        </Svg>
      </Animated.View>

      {/* The breathing bloom. */}
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { transform: [{ scale }] }]}>
        <Svg width={size} height={size}>
          <Defs>
            <RadialGradient id={`bloom-${uid}`} cx="50%" cy="50%" r="50%">
              <Stop offset="0" stopColor={color.orbBloom0} />
              <Stop offset="0.55" stopColor={color.orbBloom1} />
              <Stop offset="1" stopColor={color.orbBloom2} />
            </RadialGradient>
            {ORDER.map((el) => (
              <RadialGradient key={el} id={`aura-${el}-${uid}`} cx="50%" cy="50%" r="50%">
                <Stop offset="0" stopColor={elementColor[el]} stopOpacity={0.55} />
                <Stop offset="1" stopColor={elementColor[el]} stopOpacity={0} />
              </RadialGradient>
            ))}
          </Defs>
          {ORDER.map((el) => {
            const a = (ANGLE[el] * Math.PI) / 180;
            const r = radiusFor(values[el], R);
            return <Circle key={el} cx={c + Math.cos(a) * r * 0.8} cy={c + Math.sin(a) * r * 0.8} r={R * 0.5} fill={`url(#aura-${el}-${uid})`} />;
          })}
          <Path d={orbPath(values, c, c, R)} fill={`url(#bloom-${uid})`} fillOpacity={0.9} stroke={color.gold} strokeWidth={1.4} strokeLinejoin="round" />
          <G>
            {ORDER.map((el) => {
              const a = (ANGLE[el] * Math.PI) / 180;
              const r = radiusFor(values[el], R);
              return <Circle key={el} cx={c + Math.cos(a) * r} cy={c + Math.sin(a) * r} r={labels ? 5 : 3.2} fill={elementColor[el]} stroke={color.paperStrong} strokeWidth={2} />;
            })}
          </G>
          <Circle cx={c} cy={c} r={labels ? 4 : 2.6} fill={color.gold} />
        </Svg>
      </Animated.View>

      {labels ? (
        <>
          <Text style={[st.even, { left: c + evenR * 0.72 + 2, top: c - evenR * 0.72 - 16 }]} aria-hidden>
            even
          </Text>
          {ORDER.map((el) => {
            const a = (ANGLE[el] * Math.PI) / 180;
            const lx = c + Math.cos(a) * (R + 24);
            const ly = c + Math.sin(a) * (R + 22);
            return (
              <View key={el} style={[st.label, { left: lx - 34, top: ly - 20 }]} aria-hidden>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
                  <ElementGlyph element={el} size={13} color={elementText[el]} />
                  <Text style={[st.labelName, { color: elementText[el] }]}>{ELEMENTS[el].name}</Text>
                </View>
                <Text style={st.labelValue}>{values[el]}</Text>
              </View>
            );
          })}
        </>
      ) : null}
    </View>
  );
}

const st = StyleSheet.create({
  label: { position: 'absolute', width: 68, alignItems: 'center' },
  labelName: { fontFamily: sans, fontSize: 12.5, fontWeight: '700' },
  labelValue: { fontFamily: sans, fontSize: 15, fontWeight: '700', color: color.ink },
  even: { position: 'absolute', fontFamily: sans, fontSize: 11, color: color.gold, fontStyle: 'italic' },
});
