import React from 'react';
import { Text } from 'react-native';
import { type } from '../theme/tokens';
import { Sheet } from './layout';
import { Button } from './primitives';

/** Explicit confirmation for destructive actions. Never a browser alert (which would block the page). */
export function ConfirmSheet({ visible, title, body, confirmLabel, onConfirm, onCancel, danger = true, children }: { visible: boolean; title: string; body: string; confirmLabel: string; onConfirm: () => void; onCancel: () => void; danger?: boolean; children?: React.ReactNode }) {
  return (
    <Sheet
      visible={visible}
      onClose={onCancel}
      title={title}
      testID="confirm-sheet"
      footer={
        <>
          <Button label={confirmLabel} kind={danger ? 'danger' : 'primary'} full onPress={onConfirm} testID="confirm-yes" />
          <Button label="Cancel" kind="quiet" full onPress={onCancel} />
        </>
      }
    >
      <Text style={type.bodySoft}>{body}</Text>
      {children}
    </Sheet>
  );
}
