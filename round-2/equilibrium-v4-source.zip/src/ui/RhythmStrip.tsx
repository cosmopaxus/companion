import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { DayInfo, DayKind } from '../domain/protocols';
import { DAY_LABEL, formatDay, weekdayOf, WEEKDAY_SHORT } from '../domain/protocols';
import { color, sans, space, type } from '../theme/tokens';

// Activation days are filled gold circles, integration days open sage circles, rest days dashed.
// Shape carries the meaning as well as color.

function Mark({ kind, size = 26 }: { kind: DayKind; size?: number }) {
  const base = { width: size, height: size, borderRadius: size / 2 };
  if (kind === 'activation') return <View style={[base, { backgroundColor: color.goldDeco, borderWidth: 2, borderColor: color.gold }]} />;
  if (kind === 'integration') return <View style={[base, { borderWidth: 2, borderColor: color.sage2, backgroundColor: color.paperStrong }]} />;
  if (kind === 'rest') return <View style={[base, { borderWidth: 2, borderStyle: 'dashed', borderColor: color.controlBorder }]} />;
  return <View style={[base, { borderWidth: 1, borderColor: color.border, backgroundColor: color.canvas }]} />;
}

export function RhythmStrip({ days, today, testID }: { days: DayInfo[]; today?: string; testID?: string }) {
  const summary = days.map((d) => `${formatDay(d.day)}: ${DAY_LABEL[d.kind].toLowerCase()}`).join('; ');
  const rows = [days.slice(0, 7), days.slice(7, 14)].filter((r) => r.length);
  return (
    <View style={{ gap: space.sm }} role="img" aria-label={`Next ${days.length} days. ${summary}`} testID={testID}>
      {rows.map((row, ri) => (
        <View key={ri} style={st.row}>
          {row.map((d) => {
            const isToday = d.day === today;
            return (
              <View key={d.day} style={st.cell} testID={testID ? `${testID}-${d.kind}` : undefined}>
                <Text style={[st.wd, isToday && { color: color.ink, fontWeight: '700' }]}>{isToday ? 'Today' : WEEKDAY_SHORT[weekdayOf(d.day)]}</Text>
                <View style={[st.ring, isToday && { borderColor: color.ink }]}>
                  <Mark kind={d.kind} />
                </View>
                <Text style={st.num}>{+d.day.slice(8)}</Text>
              </View>
            );
          })}
        </View>
      ))}
      <View style={st.legend} aria-hidden>
        {(['activation', 'integration', 'rest'] as DayKind[])
          .filter((k) => k !== 'rest' || days.some((d) => d.kind === 'rest'))
          .map((k) => (
            <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Mark kind={k} size={14} />
              <Text style={type.small}>{DAY_LABEL[k]}</Text>
            </View>
          ))}
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  cell: { alignItems: 'center', gap: 4, width: 42 },
  wd: { fontFamily: sans, fontSize: 11, lineHeight: 14, color: color.inkSoft, letterSpacing: 0.2 },
  ring: { padding: 3, borderRadius: 20, borderWidth: 1.5, borderColor: 'transparent' },
  num: { fontFamily: sans, fontSize: 12, lineHeight: 16, color: color.inkSoft },
  legend: { flexDirection: 'row', flexWrap: 'wrap', columnGap: space.lg, rowGap: 4, marginTop: 2 },
});
