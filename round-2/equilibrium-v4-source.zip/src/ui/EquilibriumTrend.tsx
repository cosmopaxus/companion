import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Line, Path } from 'react-native-svg';
import type { ElementId } from '../domain/types';
import { ELEMENT_IDS } from '../domain/types';
import type { TrendPoint } from '../domain/equilibrium';
import { spreadWord } from '../domain/equilibrium';
import { BAND_LABEL, bandFor, ELEMENTS } from '../domain/harmony';
import { formatShortDate } from '../domain/time';
import { color, elementColor, sans, space, type } from '../theme/tokens';
import { Button, focusRing } from './primitives';
import { ElementGlyph } from './Icon';

// Small multiples: one row for the overall balance and one per element, all on the same 0–100
// scale with the same readings along the bottom, so the shape of each line compares directly.
// Tap or hover a reading to see every value at that point; a table view lists the same numbers.

const ROW_H = 44;
const LABEL_W = 132;

type Series = { key: 'overall' | ElementId; name: string; stroke: string; get: (p: TrendPoint) => number };

const SERIES: Series[] = [
  { key: 'overall', name: 'Overall', stroke: color.ink, get: (p) => p.overall },
  ...ELEMENT_IDS.map((el) => ({ key: el, name: ELEMENTS[el].name, stroke: elementColor[el], get: (p: TrendPoint) => p.values[el] })),
];

const signed = (n: number) => (n === 0 ? '±0' : `${n > 0 ? '+' : '−'}${Math.abs(n)}`);

export function EquilibriumTrend({ points, testID }: { points: TrendPoint[]; testID?: string }) {
  const [w, setW] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const i = sel ?? points.length - 1;
  const p = points[i];
  const first = points[0];
  const x = (k: number) => (points.length === 1 ? w / 2 : 6 + (k / (points.length - 1)) * (w - 12));
  const y = (v: number) => 4 + (1 - v / 100) * (ROW_H - 8);

  if (table) {
    return (
      <View style={{ gap: space.sm }} testID={testID}>
        <Button label="Show chart" small kind="quiet" onPress={() => setTable(false)} style={{ alignSelf: 'flex-end' }} />
        <View role="table" aria-label="Compass readings over time" testID={testID ? `${testID}-table` : undefined}>
          <View role="row" style={[st.tRow, { borderBottomWidth: 1 }]}>
            {['Reading', 'Overall', ...ELEMENT_IDS.map((el) => ELEMENTS[el].name), 'Spread'].map((h) => (
              <Text key={h} role="columnheader" style={[st.tCell, h === 'Reading' && st.tFirst, type.label, { fontSize: 12.5 }]}>
                {h}
              </Text>
            ))}
          </View>
          {[...points].reverse().map((pt) => (
            <View key={pt.id} role="row" style={st.tRow}>
              <Text role="rowheader" style={[st.tCell, st.tFirst, type.small, { color: color.ink }]}>
                {formatShortDate(pt.at)}
              </Text>
              <Text role="cell" style={[st.tCell, type.small, { color: color.ink }]}>
                {pt.overall}
              </Text>
              {ELEMENT_IDS.map((el) => (
                <Text key={el} role="cell" style={[st.tCell, type.small, { color: color.ink }]}>
                  {pt.values[el]}
                </Text>
              ))}
              <Text role="cell" style={[st.tCell, type.small]}>
                {pt.spread}
              </Text>
            </View>
          ))}
        </View>
      </View>
    );
  }

  return (
    <View style={{ gap: space.sm }} testID={testID}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.sm }}>
        <View style={{ flex: 1 }} aria-live="polite" testID={testID ? `${testID}-readout` : undefined}>
          <Text style={type.label}>
            {formatShortDate(p.at)}
            {i === points.length - 1 ? ' · latest' : ''}
          </Text>
          <Text style={type.small}>
            Overall {p.overall} · {BAND_LABEL[bandFor(p.overall)]} · spread {p.spread}, {spreadWord(p.spread).toLowerCase()}
          </Text>
        </View>
        <Button label="Show table" small kind="quiet" onPress={() => setTable(true)} testID={testID ? `${testID}-toggle` : undefined} />
      </View>

      <View>
        {SERIES.map((s) => {
          const vals = points.map(s.get);
          const d = vals.map((v, k) => `${k === 0 ? 'M' : 'L'}${x(k).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
          const change = vals[vals.length - 1] - vals[0];
          return (
            <View key={s.key} style={st.row}>
              <View style={st.label}>
                {s.key === 'overall' ? <View style={[st.key, { backgroundColor: s.stroke }]} /> : <ElementGlyph element={s.key} size={14} color={s.stroke} />}
                <View style={{ flex: 1 }}>
                  <Text style={[type.label, { fontSize: 14 }]} numberOfLines={1}>
                    {s.name} <Text style={type.small}>{s.get(p)}</Text>
                  </Text>
                  {points.length > 1 ? (
                    <Text style={[type.small, { fontSize: 12, lineHeight: 15 }]} testID={testID ? `${testID}-${s.key}-change` : undefined}>
                      {signed(change)} since {formatShortDate(first.at)}
                    </Text>
                  ) : null}
                </View>
              </View>
              <View style={{ flex: 1, height: ROW_H }} onLayout={s.key === 'overall' ? (e) => setW(e.nativeEvent.layout.width) : undefined}>
                {w > 0 ? (
                  <Svg width={w} height={ROW_H}>
                    <Line x1={0} x2={w} y1={y(50)} y2={y(50)} stroke={color.border} strokeWidth={1} />
                    {sel !== null ? <Line x1={x(i)} x2={x(i)} y1={0} y2={ROW_H} stroke={color.controlBorder} strokeWidth={1} /> : null}
                    {vals.length > 1 ? <Path d={d} stroke={s.stroke} strokeWidth={2} fill="none" strokeLinecap="round" strokeLinejoin="round" /> : null}
                    <Circle cx={x(i)} cy={y(vals[i])} r={4} fill={s.stroke} stroke={color.paper} strokeWidth={2} />
                  </Svg>
                ) : null}
              </View>
            </View>
          );
        })}
        {/* Hit areas: one column per reading, across every row. */}
        {w > 0 ? (
          <View style={[st.hits, { left: LABEL_W + space.sm, width: w }]}>
            {points.map((pt, k) => (
              <Pressable
                key={pt.id}
                role="button"
                aria-label={`Reading ${formatShortDate(pt.at)}: overall ${pt.overall}, ${ELEMENT_IDS.map((el) => `${ELEMENTS[el].name} ${pt.values[el]}`).join(', ')}`}
                onPress={() => setSel(k)}
                {...(Platform.OS === 'web' ? { onHoverIn: () => setSel(k), onHoverOut: () => setSel(null) } : {})}
                style={(st2: any) => [{ flex: 1 }, focusRing(st2)]}
                testID={testID ? `${testID}-point-${k}` : undefined}
              />
            ))}
          </View>
        ) : null}
      </View>
      <View style={[st.row, { height: 16 }]} aria-hidden>
        <View style={{ width: LABEL_W }} />
        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={st.axis}>{formatShortDate(first.at)}</Text>
          {points.length > 1 ? <Text style={st.axis}>{formatShortDate(points[points.length - 1].at)}</Text> : null}
        </View>
      </View>
      <Text style={[type.small, { fontSize: 12.5 }]}>The faint line in each row is 50, even. Readings in this Space, up to the last twelve.</Text>
    </View>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: space.sm, height: ROW_H + 6 },
  label: { width: LABEL_W, flexDirection: 'row', alignItems: 'center', gap: 6 },
  key: { width: 12, height: 2, borderRadius: 1 },
  hits: { position: 'absolute', top: 0, bottom: 0, flexDirection: 'row' },
  axis: { fontFamily: sans, fontSize: 11, lineHeight: 14, color: color.inkSoft },
  tRow: { flexDirection: 'row', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border, paddingVertical: 6 },
  tCell: { flex: 1, textAlign: 'right' },
  tFirst: { flex: 1.4, textAlign: 'left' },
});
