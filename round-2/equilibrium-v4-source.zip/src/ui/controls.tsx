import React, { forwardRef, useRef, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import type { Rating } from '../domain/types';
import { color, radius, sans, space, type } from '../theme/tokens';
import { focusRing } from './primitives';
import { Icon, IconName } from './Icon';
import { tapFeedback } from '../platform/haptics';

const RATINGS: Rating[] = [1, 2, 3, 4, 5];

/**
 * ARIA radio-group keyboard pattern on web: the group is one Tab stop (the selected option, or the
 * first); arrow keys move and select; Home/End jump; Space selects the focused option.
 */
function useRovingRadios<V>(values: V[], value: V | undefined, onChange: (v: V) => void) {
  const refs = useRef<any[]>([]);
  const stop = value !== undefined && values.includes(value) ? value : values[0];
  const keyProps = (i: number) => {
    if (Platform.OS !== 'web') return {};
    return {
      tabIndex: (values[i] === stop ? 0 : -1) as 0 | -1,
      onKeyDown: (e: any) => {
        let next: number | null = null;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') next = (i + 1) % values.length;
        else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') next = (i - 1 + values.length) % values.length;
        else if (e.key === 'Home') next = 0;
        else if (e.key === 'End') next = values.length - 1;
        else if (e.key === ' ' || e.key === 'Spacebar') {
          e.preventDefault();
          onChange(values[i]);
          return;
        }
        if (next !== null) {
          e.preventDefault();
          onChange(values[next]);
          refs.current[next]?.focus?.();
        }
      },
    };
  };
  const refFor = (i: number) => (el: any) => {
    refs.current[i] = el;
  };
  return { keyProps, refFor };
}

interface RatingProps {
  label: string;
  question?: string;
  value?: Rating;
  onChange: (r: Rating) => void;
  anchors: Record<Rating, string>;
  accent?: string;
  textOnAccent?: string;
  compact?: boolean;
  hideLabel?: boolean;
  testID?: string;
}

/** A 1–5 radio group. Selection is shown by fill, weight, a check mark and the spoken/visible anchor word — never color alone. */
export function RatingScale({ label, question, value, onChange, anchors, accent = color.sage, textOnAccent = color.onSage, compact, hideLabel, testID }: RatingProps) {
  const roving = useRovingRadios<Rating>(RATINGS, value, onChange);
  return (
    <View style={{ gap: compact ? 6 : space.sm }} testID={testID}>
      {!hideLabel ? (
        <View style={s.ratingHeader}>
          <View style={{ flex: 1 }}>
            <Text style={type.label}>{label}</Text>
            {question ? <Text style={type.small}>{question}</Text> : null}
          </View>
          <Text style={[s.valueText, { color: value ? accent : color.inkSoft }]} aria-live="polite">
            {value ? `${value} · ${anchors[value]}` : 'Not chosen'}
          </Text>
        </View>
      ) : null}
      <View role="radiogroup" aria-label={label} style={s.ratingRow}>
        {RATINGS.map((r, i) => {
          const selected = value === r;
          return (
            <Pressable
              key={r}
              ref={roving.refFor(i)}
              {...roving.keyProps(i)}
              role="radio"
              aria-checked={selected}
              aria-label={`${label}: ${r} of 5, ${anchors[r]}`}
              testID={testID ? `${testID}-${r}` : undefined}
              onPress={() => {
                tapFeedback();
                onChange(r);
              }}
              style={(st: any) => [
                s.ratingItem,
                compact && { minHeight: 44 },
                selected
                  ? { backgroundColor: accent, borderColor: accent }
                  : { backgroundColor: st.hovered || st.pressed ? color.canvas : color.paperStrong, borderColor: color.controlBorder },
                focusRing(st),
              ]}
            >
              <Text style={[s.ratingNum, selected ? { color: textOnAccent, fontWeight: '700' } : null]}>{r}</Text>
              {selected ? (
                <View style={s.ratingCheck}>
                  <Icon name="check" size={11} color={accent} strokeWidth={3} />
                </View>
              ) : null}
            </Pressable>
          );
        })}
      </View>
      <View style={s.anchorRow} aria-hidden>
        <Text style={s.anchor}>{anchors[1]}</Text>
        <Text style={[s.anchor, { textAlign: 'right' }]}>{anchors[5]}</Text>
      </View>
    </View>
  );
}

interface FieldProps extends TextInputProps {
  label?: string;
  helper?: string;
  error?: string;
  optional?: boolean;
  minHeight?: number;
}

export const Field = forwardRef<TextInput, FieldProps>(function Field({ label, helper, error, optional, minHeight, style, multiline, ...rest }, ref) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ gap: 6 }}>
      {label ? (
        <Text style={type.label}>
          {label}
          {optional ? <Text style={[type.small, { fontWeight: '400' }]}>  optional</Text> : null}
        </Text>
      ) : null}
      <TextInput
        ref={ref}
        placeholderTextColor={color.placeholder}
        multiline={multiline}
        aria-label={rest['aria-label'] ?? label}
        {...rest}
        onFocus={(e) => {
          setFocused(true);
          rest.onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          rest.onBlur?.(e);
        }}
        style={[
          s.input,
          multiline && { minHeight: minHeight ?? 110, textAlignVertical: 'top', paddingTop: 14 },
          focused && s.inputFocused,
          !!error && { borderColor: color.caution },
          Platform.OS === 'web' ? ({ outlineStyle: 'none' } as any) : null,
          style,
        ]}
      />
      {error ? (
        <Text style={[type.small, { color: color.caution }]} role="alert">
          {error}
        </Text>
      ) : helper ? (
        <Text style={type.small}>{helper}</Text>
      ) : null}
    </View>
  );
});

export interface SegmentOption<V extends string> {
  value: V;
  label: string;
  icon?: IconName;
  helper?: string;
  tone?: string;
}

/** Large, labeled choice buttons (radio semantics). */
export function Segmented<V extends string>({ label, options, value, onChange, testID }: { label: string; options: SegmentOption<V>[]; value?: V; onChange: (v: V) => void; testID?: string }) {
  const selectedOpt = options.find((o) => o.value === value);
  const roving = useRovingRadios<V>(options.map((o) => o.value), value, onChange);
  return (
    <View style={{ gap: space.sm }}>
      <View role="radiogroup" aria-label={label} style={s.segRow}>
        {options.map((o, i) => {
          const selected = value === o.value;
          const tone = o.tone ?? color.sage;
          return (
            <Pressable
              key={o.value}
              ref={roving.refFor(i)}
              {...roving.keyProps(i)}
              role="radio"
              aria-checked={selected}
              aria-label={o.helper ? `${o.label}. ${o.helper}` : o.label}
              testID={testID ? `${testID}-${o.value}` : undefined}
              onPress={() => {
                tapFeedback();
                onChange(o.value);
              }}
              style={(st: any) => [
                s.segItem,
                selected ? { borderColor: tone, backgroundColor: color.paperStrong, borderWidth: 2 } : { borderColor: color.controlBorder, backgroundColor: st.hovered ? color.canvas : color.paper },
                focusRing(st),
              ]}
            >
              {o.icon ? <Icon name={o.icon} size={22} color={selected ? tone : color.inkSoft} strokeWidth={selected ? 2.2 : 1.8} filled={selected} /> : null}
              <Text style={[s.segLabel, selected && { color: tone, fontWeight: '700' }]}>{o.label}</Text>
              {selected ? <View style={[s.segBar, { backgroundColor: tone }]} /> : null}
            </Pressable>
          );
        })}
      </View>
      {selectedOpt?.helper ? <Text style={type.small}>{selectedOpt.helper}</Text> : null}
    </View>
  );
}

/** A compact two-or-three-way switch for views within a screen (radio semantics, arrow keys move). */
export function PillSwitch<V extends string>({ label, options, value, onChange, testID }: { label: string; options: { value: V; label: string; icon?: IconName }[]; value: V; onChange: (v: V) => void; testID?: string }) {
  const roving = useRovingRadios<V>(options.map((o) => o.value), value, onChange);
  return (
    <View role="radiogroup" aria-label={label} style={s.pillRow}>
      {options.map((o, i) => {
        const on = o.value === value;
        return (
          <Pressable
            key={o.value}
            ref={roving.refFor(i)}
            {...roving.keyProps(i)}
            role="radio"
            aria-checked={on}
            aria-label={o.label}
            testID={testID ? `${testID}-${o.value}` : undefined}
            onPress={() => {
              tapFeedback();
              onChange(o.value);
            }}
            style={(st: any) => [s.pillItem, on ? { backgroundColor: color.sage } : st.hovered ? { backgroundColor: color.sageWash } : null, focusRing(st)]}
          >
            {o.icon ? <Icon name={o.icon} size={18} color={on ? color.onSage : color.sage} strokeWidth={2} /> : null}
            <Text style={[s.pillText, { color: on ? color.onSage : color.sage }]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  ratingHeader: { flexDirection: 'row', alignItems: 'flex-end', gap: space.md },
  valueText: { fontFamily: sans, fontSize: 14, fontWeight: '700' },
  ratingRow: { flexDirection: 'row', gap: 8 },
  ratingItem: {
    flex: 1,
    minHeight: 50,
    borderRadius: radius.md,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ratingNum: { fontFamily: sans, fontSize: 18, color: color.ink, fontWeight: '500' },
  ratingCheck: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: color.paperStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  anchorRow: { flexDirection: 'row', justifyContent: 'space-between' },
  anchor: { fontFamily: sans, fontSize: 13, color: color.inkSoft, flex: 1 },
  input: {
    fontFamily: sans,
    fontSize: 16,
    lineHeight: 23,
    color: color.ink,
    backgroundColor: color.paperStrong,
    borderWidth: 1.5,
    borderColor: color.controlBorder,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    minHeight: 50,
  },
  inputFocused: { borderColor: color.sage, borderWidth: 2, paddingHorizontal: 13.5 },
  segRow: { flexDirection: 'row', gap: 8 },
  segItem: { flex: 1, minHeight: 72, borderRadius: radius.md, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, paddingHorizontal: 4, overflow: 'hidden' },
  segLabel: { fontFamily: sans, fontSize: 14, color: color.ink, fontWeight: '500', textAlign: 'center' },
  segBar: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 4 },
  pillRow: { flexDirection: 'row', alignSelf: 'flex-start', padding: 4, gap: 4, borderRadius: radius.pill, borderWidth: 1, borderColor: color.border, backgroundColor: color.paper },
  pillItem: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44, paddingHorizontal: 18, borderRadius: radius.pill },
  pillText: { fontFamily: sans, fontSize: 15, fontWeight: '700' },
});
