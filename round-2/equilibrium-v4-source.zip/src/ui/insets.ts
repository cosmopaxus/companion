import { Platform } from 'react-native';
import { EdgeInsets, useSafeAreaInsets } from 'react-native-safe-area-context';

const ZERO: EdgeInsets = { top: 0, bottom: 0, left: 0, right: 0 };

/** True when the hosting page already pads the root by the safe-area insets (the published preview does). */
function hostPadsSafeArea(): boolean {
  return Platform.OS === 'web' && typeof document !== 'undefined' && document.documentElement.getAttribute('data-host-safe-area') === '1';
}

/**
 * Safe-area insets for in-page layout. Full-screen overlays (the guide, bottom sheets) sit above the
 * host's padding, so they pass `overlay` to always get the real insets.
 */
export function useInsets(kind: 'page' | 'overlay' = 'page'): EdgeInsets {
  const real = useSafeAreaInsets();
  return kind === 'page' && hostPadsSafeArea() ? ZERO : real;
}
