import React from 'react';
import { Text, View } from 'react-native';
import type { Experience, IntakeAnswer } from '../domain/types';
import { EXPERIENCE_OPTIONS, INTAKE_QUESTIONS } from '../domain/intake';
import { color, space, type } from '../theme/tokens';
import { Card, Chip, Notice } from './primitives';

const ANSWERS: { id: IntakeAnswer; label: string }[] = [
  { id: 'yes', label: 'Yes' },
  { id: 'no', label: 'No' },
  { id: 'skip', label: 'Prefer not to say' },
];

/** The Safety & Path questions, controlled. Used in onboarding (adults) and in You → Safety & Path. */
export function IntakeQuestions({
  answers,
  experience,
  onAnswers,
  onExperience,
}: {
  answers: Partial<Record<string, IntakeAnswer>>;
  experience?: Experience;
  onAnswers: (a: Partial<Record<string, IntakeAnswer>>) => void;
  onExperience: (e: Experience) => void;
}) {
  return (
    <View style={{ gap: space.md }}>
      <Card style={{ gap: space.md }} testID="intake-experience">
        <Text style={type.label}>Have you microdosed before?</Text>
        <View role="radiogroup" aria-label="Have you microdosed before?" style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
          {EXPERIENCE_OPTIONS.map((o) => (
            <Chip key={o.id} radio label={o.label} selected={experience === o.id} onPress={() => onExperience(o.id)} />
          ))}
        </View>
      </Card>
      <Text style={[type.small, { color: color.ink }]}>Does any of this apply to you right now?</Text>
      {INTAKE_QUESTIONS.map((q) => (
        <Card key={q.id} style={{ gap: space.sm }} testID={`intake-${q.id}`}>
          <Text style={type.label}>{q.text}</Text>
          <Text style={type.small}>{q.detail}</Text>
          <View role="radiogroup" aria-label={q.text} style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap', marginTop: 4 }}>
            {ANSWERS.map((a) => (
              <Chip key={a.id} radio label={a.label} selected={answers[q.id] === a.id} onPress={() => onAnswers({ ...answers, [q.id]: a.id })} />
            ))}
          </View>
        </Card>
      ))}
      {answers.crisis_now === 'yes' ? (
        <Notice tone="caution" title="You don't have to hold this alone" testID="intake-crisis-now">
          If you might harm yourself or you're in danger, please reach out now: call or text 988 in the US, or call 911 or your local emergency number.
        </Notice>
      ) : null}
    </View>
  );
}
