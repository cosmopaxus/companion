# Equilibrium (formerly Companion) v3 · Graphics & Interface — handoff

October 14, 2026 · Expo SDK 57 · React Native 0.86 · TypeScript (strict)

v3 builds on v2 without rewriting it (v2's commits stay in this repository's history). Its focus is the graphics pass Cosmo asked for: a wellness app crossed with a game, in the look of a mystery-school academy, still clear and easy to use.

## New names (Oct 14)

- The app is **Equilibrium** (formerly Companion). The elemental reading is **Compass** (formerly Equilibrium, before that Harmony).
- Changed: every name a person sees — screens, buttons, the wordmark, the page title, the installed app's name, backup messages, the About screen.
- Kept on purpose, so nothing breaks: storage keys (`companion.v2.*`), backup and journey formats (`companion.backup`, `companion.journey`), caches (`companion2-*`), code names (`harmony`, `EquilibriumScreen`, `equilibrium.ts`, test ids), and the native app ids (`org.evokemagic.companion.alpha`; changing those makes a different app in the stores, so decide before the first store build).
- Bardon's phrase stays as written: the Initiate outline lesson is still "Equilibrium of the soul".
- Sections below and older handoffs keep the old names where they describe history.

## Today's look (Oct 14 art treatment)

Follows `equilibrium-ui-art-treatment.md` in the project. It replaces the three-wing idea: one look everywhere, and only the hall's art, accent colors and motion change.

| Piece | What it does |
| --- | --- |
| Type | Cinzel (headings) and Nunito (all other text) across the app. Web: self-hosted, trimmed to Latin (`public/fonts`, 50 KB for four files). Phones: embedded at build time by the `expo-font` plugin in `app.json` (Nunito regular and bold, Cinzel bold; 87 KB). Expo Go shows system fonts; a development or store build shows these. |
| Frame | Indigo buttons (`#4B3A8F`, white text, a darker lip they press into), indigo chips, toggles, tabs, focus rings and links. Gold stays for recognition. |
| Cards | Nearly solid glass (`rgba(255,252,245,.92)`), a white edge and a chunky 4 px bottom lip, on every screen. |
| Window into glass | Home, Compass, Journal and lessons open on the hall's art: clear at the top with dark-glass chips (hall name, back), melting into frosted glass from 170 px. The title sits on a soft canvas halo (88% across its core). Everything below the title starts under the art, on fully frosted glass. |
| Check-in | A glass card with a thin edge in the hall's full gradient along its top. |
| Removed | The rounded hall header from phase 1, the dotted wing texture, the Fraunces heading font. |

**Still to come with the painted art:** the paintings themselves (the hall gradients and silhouettes stand in), the path map and celebrations as full-screen art with text only on solid pills, and the blurred copy of the painting behind each page (a soft wash of the hall's color stands in).

**Kept as is:** gems stay in the app bar rather than a second chip on the art; the path map keeps its phase 2 grounds until its painting exists.

## Decisions (Oct 14)

- **Three layers on a fixed frame.** Section → *wing* (material, heading font, texture). Tier → *building* (Courtyard, Library, Tower, Sanctum). Element → *hall* (gradient, accent, props, later sound). The frame — tab bar, buttons, body text, sizes, layout — never changes between themes.
- **Wings:** proposed (Bright Academy, Lamplit Manuscript, Night Observatory), then replaced the same day by the art treatment's one look everywhere (see "Today's look").
- **Halls** use Cosmo's four gradients exactly: Fire · The Forge, Air · The Observatory, Water · The Moon Pool, Earth · The Herb Garden.
- **Which hall:** the element of the lesson you're on. Foundation lessons have no element, so they rest in the Herb Garden. You → Preferences → *Your hall* can keep one hall instead.
- **Text on gradients** sits only where it passes 4.5:1. No single text color passes across a whole dark-to-light gradient, so the light end is for illustration only.

## Phase 1 · Foundation (this build)

| Piece | What it does |
| --- | --- |
| Hall header (Home) | The hall gradient with its building and props; date, greeting (the page's heading) and hall name in the dark sky. Height = text + a fixed art strip, so nothing jumps while the page settles. |
| Check-in band | A *dusk* band: the hall's dark color easing toward its mid color, never reaching the light end, so text is safe anywhere on it. A thin full-gradient edge below. |
| Frame | Solid buttons (primary, gold, urgent) sit on a darker lip and press down into it. Sizes unchanged. |
| Academy cards | Cards on Home sit on a solid lip (rounder corners); a faint dotted texture in the hall's color sits behind them. |
| Icons | New: seal, lamp, quill, crest, and four original hall marks (flame; wind and star; crescent over a ripple; sprout in a stone bed). |
| Hall choice | Saved with the journey (`prefs.hall`, optional), restored from backups, merged like other preferences. Older backups restore untouched; an unknown value is dropped, never fatal. |
| Heading font | Fraunces ExtraBold, subset to Latin, self-hosted as `public/fonts/companion-academy.woff2` (16 KB; OFL license alongside). Web only; native uses the system serif until `expo-font` is approved. No Google Fonts request. |

**Files:** `src/theme/academy.ts` (pure data: halls, buildings, wings, gradient math, contrast), `src/ui/academy/` (`hall.tsx` hooks and wing context; `HallArt.tsx` scenes and texture; `HallHero.tsx` header and band), changes in `primitives.tsx` (button lip, wing-aware Card), `layout.tsx` (`hero`, `texture`), `Today.tsx`, `You.tsx`, `Icon.tsx`, `palettes.ts` (lip tokens).

**Kept on purpose:** storage keys stay `companion.v2.*`, so v3 can replace v2 at the same address without anyone losing data. No schema change.

## Phase 2 · Path map (this build)

| Piece | What it does |
| --- | --- |
| Academy grounds | Each path is a region of the grounds: Foundation · The Courtyard, Acolyte · The Library, Initiate · The Tower, Adept · The Sanctum. |
| Lit and unlit | An open path has a lit sky (the hall's dusk gradient with its building in silhouette, names in white). A path not open yet is unlit stone, dashed, its building drawn faintly. |
| The road | The trail walks on a wide road one shade deeper than the grounds; walked stretches are solid, the rest dotted. |
| Scenery | Herbs and trees in the Courtyard, lamps by the Library, standing stones at the Tower, stars at the Sanctum, in the empty side of each row (only when there's room clear of the labels). |
| You are here | A soft gold glow around the medallion, the "You are here" label and the open-quest flag. |
| Original element marks | The classical alchemical triangles are replaced everywhere by Companion's own hall marks (medallions, character sheet). |
| Academy wing | The Path view's cards sit on the Academy lip, like Home's. |

**Files:** `src/ui/academy/Grounds.tsx` (`RegionSky`, `RegionStone`), `GroundsDecor` and exported `Building` in `HallArt.tsx`, `groundsWash` / `groundsRoad` in `academy.ts`, regions in `src/screens/path/PathMap.tsx`, `ElementGlyph` → `HallMark` in `Icon.tsx`.

## Phase 3 · Motion (this build)

All motion uses React Native's own `Animated` (no new library). It is decoration only: it never moves a control, never blocks a tap, and stops completely under reduced motion (system setting or You → Preferences).

| Piece | What it does |
| --- | --- |
| Hall ambience | In Home's art strip: a slow breath of light (7 s) and four motes rising — sparks in the Forge, starlight in the Observatory, bubbles in the Moon Pool, fireflies in the Herb Garden. Below the text, so contrast never changes. |
| You-are-here pulse | A soft gold ring breathes outward from the current lesson on the path map (2.8 s). The button itself never moves. |
| Gem moment | The gem in a "+2" toast pops in with a spring. |
| Celebrations | Mastering a lesson or earning a seal (badge) shows a banner in the hall's colors: "Lesson mastered" or "Seal earned · Badge", the name, a medallion that pops and a burst of sparks. It passes taps through and leaves after about 3.5 s. Milestones found when the app opens (earned earlier) are recorded quietly, not celebrated. Under reduced motion the banner appears and fades with no burst. |

**Files:** `src/ui/academy/Motion.tsx` (`HallAmbience`, `HerePulse`, `GemPop`, `Celebration`), the celebration trigger in `AppShell.tsx` (next to `recordMilestones`), `toast.tsx` (gem pop).

## Tests

- **Unit (vitest): 139 passed** — v2's 102 plus 37 new (Phase 2 adds grounds contrast in Day and Night; the rename adds a guard that the old app name never reaches what a person sees; today's look adds indigo contrast, the title halo over every hall's art, the chips, the frosted page and the halo geometry): every hall's text zone at 4.5:1 for any text height (80–520 px) in Day and Night; the dusk band edge to edge; smoothness (≥17 stops, no step a viewer would read as a band); Night dimmer than Day; button lips; hall rules; the hall choice through backup, merge and bad values.
- **Browser (Playwright, phone and desktop): 110 passed, 2 skipped** (the account tests, which need a demo backend). One v2 test was changed: the slider-drag test now scrolls the slider on screen first, because Home's header sits above the check-in. 7 new v3 scenarios run at both sizes: the Herb Garden on Foundation, choosing and clearing a hall (survives reload), saving a check-in from the banded card, Night, under 18, no layout jump, the grounds (four buildings, "you are here" still a working button), and three for motion: a seal's celebration that passes taps through and leaves on its own, reduced motion (no ambience or pulse, the moment still announced), and the pulse never moving the lesson button; plus one for today's look: content starts below the art and the title has its halo.
- **Checks:** `tsc --noEmit` and `expo lint` clean. iOS and Android bundles export.
- **Size:** web JS 1,060 KB → 1,095 KB (+35 KB); fonts 50 KB on the web, 87 KB on phones. One dependency made direct: `expo-font`, which already shipped inside Expo.
- **Note:** under heavy parallel load (4 workers) v2's guide test can time out in this environment; it passes at the default 2 workers and alone.

## Not done / next

- **Native fonts:** done (see "Today's look"). Verified by a trial prebuild: Android gets a Nunito family (400, 700) and Cinzel (700); iOS lists all three in `UIAppFonts`. Nunito's 600 weight is web-only; phones round it to the nearest embedded weight.
- **Hall sound:** ambient sound per hall.
- **Dither:** not added; only if banding shows on a real phone.
- **No physical-device pass** yet (same as v2).
