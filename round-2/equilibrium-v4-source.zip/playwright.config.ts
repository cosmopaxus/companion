import { defineConfig } from '@playwright/test';

// Runs the acceptance scenarios against the static web export (`npm run build:web`).
// Phone and desktop are viewport emulations in Chromium — not a substitute for a physical iPhone test.
export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  expect: { timeout: 7_000 },
  fullyParallel: true,
  workers: 2,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:8081',
    testIdAttribute: 'data-testid',
    trace: 'retain-on-failure',
  },
  projects: [
    { name: 'phone', use: { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true } },
    { name: 'desktop', use: { viewport: { width: 1366, height: 860 } } },
  ],
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : { command: 'npx serve -s dist -l 8081', port: 8081, reuseExistingServer: true, timeout: 30_000 },
});
