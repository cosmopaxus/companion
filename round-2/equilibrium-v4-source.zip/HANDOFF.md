# Companion alpha — Claude build: handoff

September 30, 2026 · Expo SDK 57 · React Native 0.86 · TypeScript (strict)

This build answers the *Companion — product, experience, and build brief* written for Claude Fable. It was made in a Claude session configured as `claude-opus-5-5` (the model serving a turn can differ), so label it that way in the comparison. It is an independent first concept: the reference alpha was not opened before or during the build. It couldn't be reached from the build workspace anyway (the host was blocked), so the interaction-coverage comparison the brief suggests still needs doing (see §6).

## Update: Home, Equilibrium, rhythm and day notes (September 30, 2026)

The dashboard is now **Home**: the first tab and the screen the app opens on. Today's pieces and the dashboard's pieces live together, so there is no longer a separate Dashboard page.

- **Home.** On a phone, top to bottom: the first-steps card (until dismissed), your rhythm (adults with a protocol), the check-in, today so far, Equilibrium, the last 7 days and this week's counts, your direction, practice what matters, and the full timeline. On screens 1240px and wider it's two columns. The tab reads "Home" with a new house icon; the internal tab id stays `today`.
- **Rhythm on Home.** The card says what today is (activation day 1 of 3, integration day, rest period), what tomorrow is, the next activation when it isn't tomorrow, and a 7-day strip. On integration days it offers a journal prompt, "What's shifting for me?".
- **Note today.** One note per day: Taken, Skipped or Integration day; when taken, what you took and your amount (prefilled from your protocol, editable, optional) with the "start low, go slow" line; and how it went. Edit or remove it any time. Day notes go into the timeline, backups and sync. They never earn gems and are adults only.
- **Harmony is now Equilibrium,** with meaning. The page names your state (In equilibrium, Evenly stretched, Nearly balanced, Some discord, In discord) in a sentence; shows the **overall** (the plain average of the four balances) and the **spread** (highest minus lowest, the measure of discord); explains what 50, above 50 and below 50 mean; and suggests **where to begin**: practices for your lowest element (to come back toward even, or to keep it steady), and, when one element is well resourced, how to put it to good use. Each practice can become a Journey area or a journal prompt in one tap.
- **The Equilibrium orb.** A soft four-lobed bloom in the brand's gold and sage: Fire top, Air right, Water bottom, Earth left, each lobe reaching as far as that balance. A dashed gold ring marks even; faint outlines are your earlier readings, so growth shows in the same picture. It breathes slowly when the elements are in step and a little faster when they pull apart. Reduced motion stops it.
- **The trend.** Small multiples on one 0–100 scale (overall plus each element) across your last twelve readings, with change since the first, a tap or hover readout and a table view.
- **"New version ready."** The installed web app now checks for an update every 30 minutes and whenever it comes back on screen. When a new version has been published, a banner offers Refresh or Later.
- **Unchanged underneath.** The reading still uses pressure and resource 1–5 and the same balance formula; code names (`harmony`) stay so existing backups and synced data load untouched.
- **Tests.** 64 unit tests and 64 browser tests pass, plus the 2 account tests. New tests cover the Equilibrium states, practices and trend, day notes (adult-only, one per day, amount kept only when taken, delete, backup, merge, timeline), Home for adults and under-18s, Note today, the Equilibrium page, and the update banner.

## Update: Dashboard (September 30, 2026)

*Superseded the same day: the dashboard became Home (above).*

A separate Dashboard page brings everything into one place. Today's layout is unchanged apart from a small "Dashboard" button by the greeting. The page also opens from You → Your practice.

- **Your rhythm today** (adults): activation, integration or rest day; the protocol's name; the next activation day; and the next seven days. With no protocol, it links to choosing one.
- **Last 7 days:** one small chart per feeling (mood, energy, connection), with the same scale and days for each.
  - Bars are the day's average of your own check-in readings. Days with no check-in show an empty mark and never an invented value.
  - Tapping or hovering a day shows that day's numbers and words, next to each feeling's picture.
  - A table view lists the same numbers.
- **This week:** counts of check-ins, journal entries, Journey evidence (wins, observations and setbacks) and Harmony readings. Counts only; nothing is scored.
- **Your timeline:** everything recorded, newest first, grouped by day, with filters for All, Check-ins, Journal, Harmony, Journey and Protocol.
  - Check-ins and journal follow the active Space; Journey and protocol events are account-wide. Under 18 there are no protocol items or filter.
  - Each item opens where it lives.
  - It shows 40 items at a time, with "show more".
- **Layout:** two columns on wide screens (rhythm, week and counts on the left; timeline on the right), one column on phones.
- **Tests.** 57 unit tests and 58 browser tests pass, plus the 2 account tests. New tests cover the feed (order, Spaces, deletions, under 18), daily averages, counts, and the Dashboard for adults and under-18s.

## Update: protocols (step 2 of 3, September 30, 2026)

- **Choose a protocol** (You → Microdosing → Your protocol; adults only). Five common schedules are offered:
  - one day on, two off ("often called the Fadiman protocol")
  - four on, three off ("often associated with Paul Stamets")
  - three on, two off
  - every other day
  - two days a week (Monday and Thursday by default, days changeable)

  **Create your own** allows 1–7 days on and 1–14 days off, or chosen weekdays with at least two integration days a week. The screen says these are common schedules, not recommendations.
- **Setup.** Name the protocol and choose a start date. The date stepper also goes backwards, for a rhythm you already follow. Optional regular rest weeks (practice N weeks, then rest M). Optional notes in your own words:
  - level (Micro, Minor or Not sure yet)
  - what you take, as labeled
  - your amount
  - intention

  A "start low, go slow" note sits next to the amount. Companion never suggests, calculates or converts an amount.
- **A preview of the first two weeks** marks activation days as filled gold circles, integration days as open sage circles, and rest days as dashed circles. Shape carries the meaning as well as color.
- **Your current protocol** shows today (for example "Activation day 1 of 3"), the next activation day and the next 14 days. You can edit, pause, resume (the rhythm restarts from today) or end it. Starting another protocol ends the current one, which moves to "Earlier protocols"; you can remove those from history.
- **Safety links.** If Safety & Path noted cautions, the protocol screen names them and suggests a clinician, but the choice stays the person's. After a crisis answer, the screen shows support first and hides the protocols. Under 18 there is no protocol at all. Choosing or following a protocol never earns gems.
- **Data.** Protocols are account-wide (the same in every Space) and are validated in backups. Older backups without them still restore. They merge by id across devices, with one current protocol. Day math uses calendar days, so daylight saving never shifts the rhythm.
- **Tests.** 54 unit tests and 54 browser tests pass, plus the 2 account tests. New protocol tests cover:
  - choosing a preset with notes, the 14-day counts, pause and resume, edit, changing protocols, reload, and no gems
  - a custom weekday rhythm with an earlier start and rest weeks
  - cautions named, and support first after a crisis answer
- **Next, step 3:** Today shows whether it's an activation or integration day, with a place to note each day (taken, skipped or off day; what; amount; how it went) and in-app reminders.

## Update: age ranges and Safety & Path (step 1 of 3, September 29, 2026)

This is the first of three planned steps: intake and age, then protocol choice, then rhythm tracking and reminders.

- **Age range replaces the 18+ checkbox.** Onboarding asks for Under 18, 18–24, 25–34, 35–44, 45–54, 55–64 or 65+. The answer is self-reported and stays on the device. Journeys from before this change read as "18 or older", and the profile offers a range to choose.
- **Under 18 is reflection mode.** Check-ins, Journey, Harmony, Journal, the guide, gems, support (988 and 911) and export all work. Hidden are the microdosing tools:
  - Safety & Path
  - the əvōke offering templates in Directions
  - the Be Well Space (the person stays in Personal)
  - the Fireside Project line
  - account sign-in
  - the upcoming protocol, dose-note and rhythm features
  Changing the range later asks for confirmation in either direction. Moving to under 18 keeps Be Well entries saved but out of view.
- **Safety & Path was rebuilt from the original alpha's screen**, in this build's design:
  - Major cautions: pregnancy or breastfeeding; a personal or family history of psychosis, schizophrenia or bipolar I; lithium.
  - Cautions: a significant heart condition or high blood pressure; an MAOI; an antidepressant or other psychiatric medication.
  - Support first: crisis or immediate danger.
  - It also asks "Have you microdosed before?" (not yet, a few times, a regular practice, or prefer not to say).
  - Results name major cautions separately and add "if you do choose to microdose, start low and go slow".
  - It never chooses a dose. It's still a placeholder that needs clinical and legal review.
- **Safety & Path is now an optional last onboarding step for adults**, and still available in You. A crisis answer shows 988/911 immediately and opens Support when onboarding finishes. If the questions change later, people who answered an older set are asked to review.
- **Tests.** 46 unit tests (age rules, legacy migration, intake scoring and review) and 48 browser tests pass. The browser tests include under-18 onboarding and hiding, confirming an age change, the intake in onboarding with major cautions, and a crisis answer during onboarding. The 2 account tests against the demo backend pass too. One older restore test was hardened against a timing flake under parallel load.

## Update: check-in sliders (September 29, 2026)

Asked for in an artifact comment: 1–5 check-in ratings become granular sliders, each feeling gets its own graphics, and color and sound follow the slider from the low end to the high end.

- **Scale.** Mood, energy and connection are whole numbers from 0 to 100, marked `scale: 100`. 0–100 was chosen over 1–100 so older 1–5 check-ins convert exactly (1→0, 3→50, 5→100, the same mapping Harmony uses). Conversion happens wherever a journey is read: device load, restore, and synced copies. The number is always shown with one of the familiar five words (Heavy / Low / Okay / Good / Bright, and so on), in bands of 20.
- **Pictures.** Mood is a sun that sinks under cloud when heavy and rises with rays when bright. Energy is a pulse, nearly flat when depleted and tall and quick when charged. Connection is two circles, far apart when isolated, that move together and overlap inside a halo when connected. The track, the thumb and a light wash on each slider take the feeling's color: slate → gold, ash violet → ember, cool mist → rose.
- **Sound (web).** Made live with Web Audio, no audio files, and quiet. Mood is a two-note chord that climbs from a muffled minor third to a bright major third. Energy is a hum that pulses slowly and dully when depleted, quickly and with more edge when charged. Connection is two voices, apart and out of tune when isolated, that move to the center and settle into a clean fifth, then a full chord. A speaker button on the check-in card and You → Preferences → Sound turn it off; the choice is saved with the journey. Native builds have no sound yet; they give a haptic tick each time the word changes.
- **Interaction.** Drag sideways or tap the line. On touch screens, a vertical swipe that starts on a slider scrolls the page and changes nothing. Keyboard: arrows ±1, Shift+arrow or Page Up/Down ±10, Home/End. Screen readers get a named slider with a spoken value ("72 of 100, Good") and ±5 adjust actions. Save stays disabled until all three have been set, so an untouched slider never records a value.
- **Support notice.** Offered when mood is below 20, the band the old "1" covered.
- **Tests.** 39 unit tests pass: 0–100 validation, conversion from 1–5, the band words, colors, and the sound mapping. 42 browser tests pass, including new drag/tap and sound tests that record the tones the app requests. iOS and Android bundles still compile.
- **Not yet checked.** The sound on a real phone (iPhone's silent switch mutes web audio) and the drag-versus-scroll feel on real touch screens. Harmony still uses 1–5; moving it to sliders changes its formula, so it's the next module decision (see `MODULES.md`).
- **Publishing.** The GitHub Pages package now uses relative paths, so it works whichever folder it's uploaded to.

## 1. Runnable app and preview

| What | Where |
| --- | --- |
| Hosted web preview | The **Companion** page in your claude.ai artifacts, visible to your organization. Data stays in each viewer's browser. |
| Public web app | **https://cosmopaxus.github.io/companion/**, served by GitHub Pages from the `cosmopaxus/companion` repository (`main`, root). Anyone with the link can open and install it. Update it by uploading a new `companion-github-pages.zip`'s contents to the top level of the repository. |
| Source | `companion-alpha-source.zip`. `README.md` has setup, the build and test commands, and the steps to connect Supabase. |
| Native | The same codebase exports iOS and Android Hermes bundles (`npm run build:native`). It hasn't been installed on a device. |

## 2. Design interpretation

The model is a **field journal with a quiet compass**: warm paper, botanical green for actions, gold only for recognition, and serif headings. It stays substantial, but never clinical and never game-like. Every screen answers the one question from the brief's information architecture and gives the next small action.

**Major departures from the brief, and why**

1. **A lighter first session.** The sequence is welcome, then name with an 18+ confirmation, then Space, then up to two optional starting directions, then Today. The Safety & Path intake moved out of the required sequence into You → *Optional depth*, and the last onboarding step points to it. It is a placeholder that still needs specialist review, and the app serves ordinary wellness without it, so it shouldn't gate first use. The adult confirmation stays in onboarding.
2. **The guide is a separate practice space, not coach marks on the real tabs.** It opens as a full-screen *map* of five stops. A persistent gold "Practice mode" strip and dashed practice cards mark it, so practice can never leak into real history. Each lesson runs *why → example → try → learned*. A lesson counts as complete when you reach *Learned*, so closing there still counts. You resume at the exact step, a replay starts the practice fresh, and the 5-gem gift is granted once, to Personal. The guide ends on **Check in for real**.
3. **The check-in collapses after saving.** It becomes a confirmation panel showing the ratings, the note, which check-in of the day it was, and the gems. *Check in again* reopens the form. Check-ins can now be deleted from *Today so far* and from a check-in history page. The brief didn't ask for this, but a mis-tap otherwise stays forever.
4. **Evidence is drawn as a notebook strip:** ● win, ○ observation, ◇ setback. The marks differ in shape, not only in color, and appear in time order. There are no percentages anywhere. The win count counts wins only.
5. **Harmony is a compass.** Fire sits opposite Water and Air opposite Earth. The 50 ring is labeled *even*, the shape updates live, and each element gets a plain word and sentence (*Strained / Stretched / Even / Supported / Resourced*). A reading page compares each element with the previous reading. The default stays at the midpoint (it shows 50, as the acceptance tests require), but saving a reading you haven't touched asks you to confirm "Everything is still at the midpoint". That keeps unconsidered readings out of the record.
6. **Directions show their arithmetic.** You get +3 for each chosen direction, +1 for each Journey area in that direction, and +1 more for high impact. Ties go to the direction chosen first. The Directions screen draws the scores as bars. Choosing a third direction explains the limit rather than silently dropping the first one.
7. **The gem ledger explains every line with its source**, for example "Win · A steadier sleep rhythm" or the first words of a journal entry. It also says what is never rewarded.
8. **Connect is an honest preview plus a real action.** It lists what is planned, then offers what is available now: practicing the personal *Connect direction* through a Journey area or a journal prompt. That keeps the tab and the direction from being confused.
9. **Desktop gets a left rail and, on wide screens, a two-column Today.** Phone keeps the five-tab bottom bar.
10. **Navigation is state-driven, not Expo Router.** One static bundle then runs anywhere, including a hosted page whose URL path the app doesn't control. The cost is no deep links yet.
11. **Project vocabulary applies.** User-facing copy says əvōke *offerings* (the brand's rule), not "products". Support templates are named but labeled *Template not available in this alpha*.
12. **The palette was tuned for contrast.** Secondary text is darkened to `#625D53` (at least 4.5:1 on the sage and gold washes). New tokens: `controlBorder #9A907F` (3:1 input and rating borders), `fireText #8F5323` for small Fire text, and `cautionWash`.

**Assumptions I made** (the brief leaves them open)

- Adults self-confirm as 18+; there is no age verification.
- Up to two starting directions.
- Journey areas are account-wide, and an evidence gem goes to the Space that was active when the evidence was recorded.
- Gems stay when their source is deleted. They recognize that you showed up.
- Deletes are tombstones. A deleted journal entry's tombstone drops the text.
- When two devices edit the same record, the later `updatedAt` wins. On a tie, the delete wins.
- Guest restore replaces the journey with one undo; signed-in restore merges by id (as the brief specifies).
- Crisis resources are US-first: 911, 988, and Fireside Project (62-FIRESIDE, 623-473-7433, checked against a 211 listing today), plus findahelpline.com. Numbers are also shown as text, because phone links can be inert inside the hosted viewer.

## 3. Feature status

| Area | Status | Notes |
| --- | --- | --- |
| Onboarding (name, optional handle, age range, Space, directions, optional Safety & Path) | **Working** | Under 18 skips Space and Safety & Path. Restore from a backup on the welcome screen. |
| Home: rhythm and day notes, check-ins (0–100 feeling sliders with pictures, color and sound), today list and history with delete, Equilibrium, last 7 days, counts, direction, top priorities, timeline | **Working** | Opens first. Several check-ins per day; readings earn the same gems whether low or high. Sound is web-only. |
| Journey: areas, ranking, easy wins, evidence of three kinds, win count | **Working** | Edit and remove areas and evidence. |
| Equilibrium (formerly Harmony): animated orb, state in words, overall and spread, practices, trend, readings | **Working** | Uses the existing formula exactly. |
| Journal: prompts, drafts kept, edit and delete, Space-scoped | **Working** | Empty saves blocked; saving an unchanged edit doesn't mark it edited. |
| Spaces (Personal / Be Well) | **Working** | Be Well is a local label only and joins nothing. |
| Gems and ledger | **Working** | Deterministic ids; can never double-award. |
| Guided first steps | **Working** | Resumable and replayable; gift granted once. |
| Export / validated restore / undo / erase | **Working** | Web: file download, or the claude.ai *downloads* prompt when hosted; copy-text fallback. |
| Recovery from unreadable saved data | **Working** | Bad records set aside; the original is quarantined, never overwritten. |
| Blocked-storage mode | **Working** | The app keeps working in memory and says so wherever it would otherwise say "saved". |
| Age ranges and under-18 reflection mode | **Working** | Self-reported; hides microdosing tools, Be Well, offering templates, Fireside and sign-in under 18. |
| Update notice for the installed web app | **Working** | Refresh or Later; checks every 30 minutes and on return. |
| Protocols (common schedules or your own, notes, pause/resume, history) | **Working** | Adults only; never suggests an amount; never rewarded with gems. |
| Safety & Path intake | **Preview** | Adults only; optional onboarding step. Major and other cautions, experience, crisis leads with support. Needs clinical and legal review. |
| Support resources | **Working** | Separate from wellness features. |
| Connect (Pulse, gatherings) | **Preview** | Described, clearly labeled, no live controls. |
| Accounts and phone ⇄ web sync | **Blocked** | Sign-in UI, sync engine and Supabase adapter plus SQL are written. Tested against an in-memory backend only; no Supabase project existed. |
| Native share-sheet export, file-picker restore, haptics | **Built, untested** | Compiles for iOS and Android; not exercised on a device. |
| əvōke support templates, reminders and notifications, research | **Not built** | Out of scope, and labeled in the app's About screen. |

## 4. Tests and known limitations

**Passed**

- **Unit tests (vitest): 57 passed.**
  - Harmony math, including the two acceptance cases: midpoint = 50; resource 5 / pressure 3 = 75.
  - Ranking, the win count, and Space scoping.
  - The gift granted once, even when the guide is completed in Be Well and then replayed.
  - Merge and tombstones; backup validation (bad ratings, orphan evidence, duplicate ids, unknown fields dropped).
  - Sync engine: two devices, offline then reconnect, a concurrent write caught between fetch and write, the later edit winning, deletes propagating, the gift granted once across devices, a second account seeing nothing, and no writes when nothing changed.
- **Browser tests (Playwright, Chromium): 58 passed** (plus 2 account tests against the demo backend).
  - 28 scenarios plus the install/offline check, each run at phone size (390×844, touch emulation) and desktop size (1366×860). They cover the brief's §13 scenarios 1–10 and 12, plus blocked storage, corrupted-storage recovery, partial salvage, the crisis answer, check-in deletion, a draft surviving reload, and restore undo.
  - The account UI against the demo backend, at both sizes: guest import only by choice, a separate cache per account, and signing out exposing nothing.
- **Code checks.** `tsc --noEmit` and `expo lint` are clean; one lint rule is turned off, with the reason in `eslint.config.js`. iOS and Android bundles export.
- **Independent review.** A separate agent tested the app by hand and read the code. It reported 27 issues. All were fixed except the toast briefly covering Today's *Add evidence* button; taps still pass through the toast.

**Not tested**

- A physical iPhone or Android device. Phone viewports in Chromium are not a device test.
- VoiceOver and TalkBack. Only the roles and labels in the page structure were checked: radio groups with arrow keys, headings, and descriptive control labels.
- A live Supabase project.
- The hosted page running inside the claude.ai viewer. I published it, but its first run inside the viewer, including the download prompt, was not exercised. The same bundle did run locally inside a simulated publish skeleton.

**Limitations**

- No dark mode.
- No deep links or browser-history back. Escape and the Android back button are handled.
- No trend views yet.
- English only, 12-hour times.
- Web bundle is about 850 KB.

## 5. Screenshots

In `companion-screenshots/`, with phone (390×844 @2x) and desktop (1440×900 @2x) versions of each:

- welcome, onboarding
- Today (first visit, filled check-in, with Journey data)
- guide (map, why, try, learned, celebration)
- check-in sliders at the low and high ends (21, 22)
- age range with the under-18 note (23), Safety & Path in onboarding (24), You with age and Safety & Path (25), the Safety & Path result (26)
- protocol choice (27), setup (28), current protocol (29)
- Dashboard (30), last 7 days (31), timeline (32) — before it became Home
- Home (33), Home's Equilibrium card (34), Note today (35), Equilibrium (36), where to begin (37), trend (38); desktop Home (39) and Equilibrium (40)
- Journey, area detail
- Harmony, reading
- Journal, Connect, You, Gems, Space sheet

`companion-contact-sheet.png` puts 14 phone screens on one page.

## 6. Recommended next steps, in priority order

1. **Connect Supabase and run scenario 11 on real hardware.** Sign in with the same account on a phone and a laptop, add entries on both, go offline and reconnect, make concurrent edits, then prove a second account sees nothing. The schema, RLS and adapter are ready. Only credentials and an email template are missing.
2. **Do a physical-device pass on iOS and Android.** Check the keyboard, safe areas, share-sheet export, file-picker restore, haptics, and VoiceOver/TalkBack on the check-in and the guide.
3. **Get specialist review of Safety & Path and the support content**, and localize crisis resources by region.
4. **Compare interaction coverage with the reference alpha**, now that this concept is independent, and note gaps both ways.
5. **Build "what changed" views that still use no scores:** a weekly look back that quotes your own evidence. (Equilibrium per element over time is done.)
9. **Reminders:** in-app first for activation and integration days; phone notifications with the native app.
6. **Add a dark "night journal" theme.** All colors already come from one token file.
7. **Add deep links and web history** once hosting is settled.
8. **Add journal search**, and export the journal alone as Markdown.
