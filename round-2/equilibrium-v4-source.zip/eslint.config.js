// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require("eslint-config-expo/flat");

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ["dist/*", "dist-demo/*", "dist-native/*", "test-results/*", "playwright-report/*"],
  },
  {
    rules: {
      // React Native <Text> renders apostrophes and quotes literally; there are no HTML entities to escape.
      "react/no-unescaped-entities": "off",
    },
  },
]);
