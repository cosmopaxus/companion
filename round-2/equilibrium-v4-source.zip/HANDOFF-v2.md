# Companion v2 — Claude build: handoff

October 14, 2026 · Expo SDK 57 · React Native 0.86 · TypeScript (strict)

v2 is built on top of the September 30 alpha, not a rewrite. The alpha's source is the first commit in this repository's history (`v1 baseline as received`), and everything it did still works. v2 was planned from the Companion idea board (tree and path map) and Cosmo's choices on October 14:

- **Focus:** the game layer, paths of mastery, and three quick wins.
- **Placement:** Journey opens on the path map, with areas one tap away.
- **Character sheet:** counts only things that build. Equilibrium stays separate and unchanged, to be reworked later.
- **Readiness:** 14 of the last 21 days, 2 goals reached, and the path's lessons mastered.
- **Lessons:** Claude drafts Foundation and Acolyte, for review. Initiate and Adept are outlines.

## What's new

| Area | What it does |
| --- | --- |
| **Journey → Path** | Opens on a "From your teacher" card, the path map, character sheet and inventory cards, and open quests. **Areas** is the alpha's Journey, unchanged. |
| **Paths of mastery** | **Foundation** (7 lessons: show up, name what matters, set and reach a goal, an honest inventory, keep a rhythm, look back) is open from the start. **Acolyte** (7 lessons, in the spirit of Bardon's first step: watching the mind, the bright and shadow mirrors, conscious breath, the mindful meal, the kept word, the evening review) is offered when ready, or opened early by a sincere seeker who says what draws them. **Initiate** and **Adept** show their outline and open when their lessons are written. |
| **The teacher** | Points to the next lesson. Offers the next path only when the pupil is ready. "Not yet" lets the offer rest for 7 days, with Begin still there. When every open lesson is walked and the next path is still an outline, it says so. |
| **Path map** | A winding trail of medallions: mastered (filled, check), you are here (gold ring), open (outlined), not open yet or in preparation (dashed). A mastered path folds up. Open quests show at "you are here". |
| **Goals as quests** | Set one (title, why, element, Journey area). Reach it with a line about what it took (+3 gems, once ever per goal). Let it go at no cost, reopen it, or delete it. |
| **Character sheet** | Rank, days practiced, longest rhythm, goals reached, lessons mastered, wins, reflections. **Practice by element** gives one level per five practices, from lessons that train an element and goals reached that call on it. |
| **Inventory** | Goals reached (with their line), and 18 badges, earned or still to earn. |
| **Weekly look-back** | Days you showed up, your wins, observations and setbacks quoted, goals reached and set, path practice, and counts. No scores. Ends with "Looking back on this week, what changed?" in the journal. |
| **Journal** | Search (every word; ignores case and accents) and **Export as Markdown** (exports what's shown). |
| **Night theme** | You → Preferences → Appearance: Day, Night or Match device (web). Every text pair is contrast-tested in both palettes. Phones follow the phone's setting. |
| **Bring in the alpha** | If the alpha kept a journey in this browser, the welcome screen offers to copy it in, and You → Your data offers to merge it later. The alpha's copy is only read. |

### Rules kept on purpose

- **Nothing on the character sheet or in the inventory reads how a check-in felt.** A low and a high reading count the same.
- **Nothing is taken back.** Lessons mastered and badges earned are recorded the first time they happen. Element levels and goals reached come from gem records, which are never removed. Removing a practice or reopening a goal changes none of them.
- **Dosing never counts.** Protocols and day notes are not practice and earn nothing.
- **Mastery means different days.** "I practiced today" counts once per lesson per day (1 gem each).
- **A goal counts toward a path only from its first reach**, so reopening can't recount it.

### Data and safety for the alpha

- v2 journeys are **schema version 2**. v2 reads version-1 journeys and backups and upgrades them. The alpha refuses version 2 ("Unsupported journey schema version") instead of silently dropping v2's records. This also holds for a synced copy, if both builds were ever pointed at the same Supabase project: the alpha's sync stops with "couldn't be read" and writes nothing.
- v2 stores its journey under `companion.v2.*` and its caches as `companion2-*`, so v1 and v2 can share a `github.io` address. Publish v2 to its own repository (see README), not inside the alpha's `/companion/` folder.

## Tests

- **Unit (vitest): 102 passed.** That is the alpha's 65 plus 37 new ones covering:
  - goals, practice logs and gems
  - every lesson measure
  - readiness, invitations, "Not yet" and seekers; outline paths staying closed
  - "nothing is taken back"
  - backup round-trips, alpha backups, strict restore checks, merge
  - the timeline, the look-back, journal search and export
  - Day and Night contrast
  - lesson content
- **Browser (Playwright, phone and desktop): 88 passed, 2 skipped.** The skipped ones are the alpha's account tests, skipped unless a demo backend is built. The alpha's scenarios were updated only to tap **Areas** in Journey and the renamed "About this version" row. The 12 new v2 scenarios each run at both sizes:
  - the path and teacher
  - goals through to inventory and character sheet
  - a seeker opening Acolyte and practicing
  - readiness and the invitation
  - "Not yet"
  - journal lessons
  - the look-back
  - search and export
  - Night persisting
  - alpha import, at onboarding and later
  - under 18
- **Checks:** `tsc --noEmit` and `expo lint` are clean.
- **Independent review:** a separate agent read the diff and drove the app in both themes. Every bug it reported is fixed:
  - stats that could go backwards
  - outline paths that could be opened
  - gem toasts that overstated
  - goals that could be recounted
  - the shared-sync risk
  - restore strictness
  - the "Not yet" contradiction
  - several accessibility labels

## Not tested / open

- **No physical iPhone or Android pass** (same as the alpha). Native builds follow the phone's light or dark setting; choosing per app on phones needs a synchronous store and is a next step.
- **Lesson text is a draft.** Foundation and Acolyte are written in Companion's own words, inspired by Bardon. They are not quotations, and they want Cosmo's review. Initiate and Adept are outlines only.
- **Equilibrium is unchanged.** Its rework (soul mirror and elemental balance) is a separate decision. The Acolyte mirror lessons are a natural bridge to it.
- **"Match device"** is checked when Companion opens, not while it's open.
- **Accounts and sync** are still not connected.
