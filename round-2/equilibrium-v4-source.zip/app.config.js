// Extends app.json. COMPANION_BASE_URL lets the web build live under a sub-path
// (e.g. GitHub Pages project sites: COMPANION_BASE_URL=/companion). Leave unset for a site root.
module.exports = ({ config }) => ({
  ...config,
  experiments: {
    ...(config.experiments ?? {}),
    ...(process.env.COMPANION_BASE_URL ? { baseUrl: process.env.COMPANION_BASE_URL } : {}),
  },
});
