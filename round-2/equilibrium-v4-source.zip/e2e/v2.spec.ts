import { test, expect, Page } from '@playwright/test';
import fs from 'node:fs';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
import { localDayKey } from '../src/domain/time';
import { LESSON_BY_ID } from '../src/domain/paths';
import { LOOKBACK_PROMPT } from '../src/domain/lookback';

// v2 scenarios: paths of mastery, the game layer, the weekly look-back, journal search and
// export, the Night theme, and bringing in a first-version journey. Synthetic data only.

async function onboard(page: Page, name = 'Test Person') {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill(name);
  await page.getByTestId('onboarding-age-25-34').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
}

const gems = async (page: Page) => Number((await page.getByTestId('gem-pill-count').innerText()).trim());

async function openPath(page: Page) {
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('journey-path')).toBeVisible();
}

/** The page's theme, read safely while a reload may be in flight. */
const themeAttr = (page: Page) => page.evaluate(() => document.documentElement.getAttribute('data-theme')).catch(() => null);

async function back(page: Page) {
  await page.getByRole('button', { name: /^(Back|Journey|Foundation|Acolyte)$/ }).first().click();
}

/** Seed this browser with a journey before the app loads (only if none is stored yet). */
async function seed(page: Page, key: string, journey: unknown) {
  await page.addInitScript(
    ([k, v]) => {
      if (!localStorage.getItem(k)) localStorage.setItem(k, v);
    },
    [key, JSON.stringify(journey)] as [string, string],
  );
}

/** A journey that has walked every Foundation lesson, practicing on each of the last 16 days. */
function readyForAcolyte(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 15 * DAY);
  start.setHours(12, 0, 0, 0);
  const at = (n: number, m = 0) => new Date(start.getTime() + n * DAY + m * 60000);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_ready'), { name: 'Ready Person', ageBracket: '35-44', spaceId: 'personal', directions: [] }, at(0));
  for (let n = 0; n < 16; n++) j = ops.addCheckIn(j, { mood: 50, energy: 50, connection: 50 }, at(n), `chk_${n}`);
  j = ops.addArea(j, { name: 'Sleep', impact: 4, difficulty: 2 }, at(1), 'area_1');
  for (let i = 0; i < 3; i++) j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: `Win ${i}` }, at(2, i), `ev_${i}`);
  j = ops.addGoal(j, { title: 'Walk daily' }, at(3), 'goal_1');
  j = ops.addGoal(j, { title: 'Call home' }, at(3, 5), 'goal_2');
  j = ops.reachGoal(j, 'goal_1', undefined, at(5));
  j = ops.reachGoal(j, 'goal_2', undefined, at(8));
  j = ops.addJournal(j, 'Strengths and habits.', (LESSON_BY_ID['f-honest-inventory'].measure as any).prompt, at(4), 'jnl_1');
  j = ops.addJournal(j, 'Steadier.', LOOKBACK_PROMPT, at(9), 'jnl_2');
  return j;
}

test('path · Journey opens on the path; the teacher points to the first lesson; areas are one tap away', async ({ page }) => {
  await onboard(page);
  await expect(page.getByTestId('home-teacher-card')).toContainText('Show up');
  await openPath(page);
  await expect(page.getByTestId('journey-view-path')).toHaveAttribute('aria-checked', 'true');
  await expect(page.getByTestId('teacher-card')).toContainText('Check in on five different days.');
  await expect(page.getByTestId('map-tier-foundation')).toContainText('0 of 7 lessons mastered');
  await expect(page.getByTestId('map-lesson-f-show-up')).toHaveAccessibleName(/You are here/);
  await expect(page.getByTestId('map-tier-acolyte')).toContainText('Open to seekers');
  await page.getByTestId('journey-view-areas').click();
  await expect(page.getByTestId('journey-empty')).toBeVisible();
  await page.getByTestId('journey-view-path').click();
  await expect(page.getByTestId('path-map')).toBeVisible();
});

test('goal · set a quest, reach it with a line, and find it in the inventory and character sheet; gems once', async ({ page }) => {
  await onboard(page);
  await openPath(page);
  await page.getByTestId('quest-add').click();
  await page.getByTestId('goal-title').fill('Walk every morning this week');
  await page.getByTestId('goal-element-earth').click();
  await page.getByTestId('goal-save').click();
  await expect(page.getByTestId('quest-0')).toContainText('Walk every morning this week');
  expect(await gems(page)).toBe(0);

  await page.getByTestId('quest-0').click();
  await page.getByTestId('goal-reach').click();
  await page.getByTestId('goal-reflection').fill('Shoes by the door the night before');
  await page.getByTestId('goal-reach-confirm').click();
  await expect(page.getByTestId('goal-sheet')).toHaveCount(0);
  expect(await gems(page)).toBe(3);
  await expect(page.getByTestId('quests')).toContainText('Open quests · 0');

  await page.getByTestId('open-inventory').click();
  await expect(page.getByTestId('inventory-goal')).toContainText('Walk every morning this week');
  await expect(page.getByTestId('inventory-goal')).toContainText('Shoes by the door the night before');
  await expect(page.getByTestId('badge-quest-complete')).toBeVisible();
  await expect(page.getByTestId('badge-locked-three-quests')).toBeVisible();
  await back(page);

  await page.getByTestId('open-character').click();
  await expect(page.getByTestId('character-rank')).toHaveText('Seeker');
  await expect(page.getByTestId('stat-goals')).toContainText('1');
  await expect(page.getByTestId('element-earth')).toContainText('1 practice');
  await back(page);

  // Reopening and reaching again never earns twice.
  await page.getByTestId('tab-today').click();
  await page.getByTestId('dash-filter-path').click();
  await expect(page.getByTestId('dash-item-path')).toHaveCount(2);
  await page.getByTestId('dash-item-path').first().click();
  await page.getByTestId('goal-reopen').click();
  await openPath(page);
  await page.getByTestId('quest-0').click();
  await page.getByTestId('goal-reach').click();
  await page.getByTestId('goal-reach-confirm').click();
  expect(await gems(page)).toBe(3);
});

test('path · a sincere seeker opens Acolyte, practices once a day, and it shows on the map', async ({ page }) => {
  await onboard(page);
  await openPath(page);
  await page.getByTestId('map-tier-acolyte').click();
  await expect(page.getByTestId('screen-tier')).toBeVisible();
  await expect(page.getByTestId('tier-readiness')).toContainText('Goals reached on this path: 0 of 2');
  await page.getByTestId('tier-seeker').click();
  await page.getByTestId('tier-seeker-why').fill('hm');
  await expect(page.getByTestId('tier-seeker-open')).toBeDisabled();
  await page.getByTestId('tier-seeker-why').fill('I want to understand my own mind.');
  await page.getByTestId('tier-seeker-open').click();
  await expect(page.getByTestId('tier-open')).toContainText('as a sincere seeker');
  await page.getByTestId('tier-lesson-a-watch-mind').click();
  await expect(page.getByTestId('screen-lesson')).toContainText('Watching the mind');
  await page.getByTestId('lesson-note').fill('Busy, then quieter');
  await page.getByTestId('lesson-log').click();
  await expect(page.getByTestId('lesson-logged-today')).toBeVisible();
  await expect(page.getByTestId('lesson-progress-label')).toHaveText('1 of 5 days');
  await expect(page.getByTestId('lesson-log-list')).toContainText('Busy, then quieter');
  expect(await gems(page)).toBe(1);
  await page.reload();
  await openPath(page);
  await expect(page.getByTestId('map-tier-acolyte')).toContainText('Open');
  await page.getByTestId('map-lesson-a-watch-mind').click();
  await expect(page.getByTestId('lesson-logged-today')).toBeVisible();
  expect(await gems(page)).toBe(1);
});

test('path · when the pupil is ready, the teacher offers the next path', async ({ page }) => {
  await seed(page, 'companion.v2.journey.guest', readyForAcolyte());
  await page.goto('/');
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await openPath(page);
  await expect(page.getByTestId('teacher-invite')).toHaveText('You’re ready for the Acolyte path.');
  await expect(page.getByTestId('map-tier-foundation')).toContainText('Mastered');
  await expect(page.getByTestId('map-tier-acolyte')).toContainText('Ready for you');
  await page.getByTestId('teacher-begin').click();
  await expect(page.getByTestId('teacher-card')).toContainText('Watching the mind');
  await page.getByTestId('open-character').click();
  await expect(page.getByTestId('character-rank')).toHaveText('Acolyte');
  await expect(page.getByTestId('stat-lessons')).toContainText('7');
});

test('lesson · a journal lesson fills its prompt, and saving the entry masters it', async ({ page }) => {
  await onboard(page);
  await openPath(page);
  await page.getByTestId('map-lesson-f-honest-inventory').click();
  await page.getByTestId('lesson-journal').click();
  await expect(page.getByTestId('screen-journal')).toBeVisible();
  await expect(page.getByTestId('journal-composer')).toContainText('Three strengths I have, and three habits I’d like to change');
  await page.getByTestId('journal-input').fill('Patient, curious, loyal. Late nights, doom scrolling, skipping lunch.');
  await page.getByTestId('journal-save').click();
  await openPath(page);
  await expect(page.getByTestId('map-lesson-f-honest-inventory')).toHaveAccessibleName(/Mastered/);
  await expect(page.getByTestId('map-tier-foundation')).toContainText('1 of 7 lessons mastered');
});

test('look-back · the week in your own words, then a prompt to write what changed', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journey').click();
  await page.getByTestId('journey-view-areas').click();
  await page.getByTestId('journey-add-empty').click();
  await page.getByTestId('area-name').fill('Steadier sleep');
  await page.getByTestId('area-impact-4').click();
  await page.getByTestId('area-difficulty-2').click();
  await page.getByTestId('area-save').click();
  await page.getByTestId('evidence-kind-win').click();
  await page.getByTestId('evidence-text').fill('Lights out by eleven, three nights running');
  await page.getByTestId('evidence-save').click();
  await page.getByTestId('tab-today').click();
  await page.getByTestId('open-lookback').click();
  await expect(page.getByTestId('lookback-days')).toContainText('You showed up on 1 of 7 days.');
  await expect(page.getByTestId('lookback-wins')).toContainText('Lights out by eleven, three nights running');
  await expect(page.getByTestId('lookback-wins')).toContainText('Steadier sleep');
  await expect(page.getByTestId('lookback-next')).toBeDisabled();
  // A brand-new journey has no earlier weeks to page back to.
  await expect(page.getByTestId('lookback-prev')).toBeDisabled();
  await page.getByTestId('lookback-write').click();
  await expect(page.getByTestId('journal-composer')).toContainText('Looking back on this week, what changed?');
});

test('journal · search every word, and export what you see as Markdown', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journal').click();
  for (const t of ['Café by the river. Felt calm.', 'Argued about the rent.', 'River walk again, calm and slow.']) {
    await page.getByTestId('journal-input').fill(t);
    await page.getByTestId('journal-save').click();
    await expect(page.getByTestId('journal-saved')).toBeVisible();
  }
  await expect(page.getByTestId('journal-count')).toHaveText('3 entries in Personal');
  await page.getByTestId('journal-search').fill('river CALM');
  await expect(page.getByTestId('journal-count')).toHaveText('2 of 3 entries match');
  await expect(page.getByTestId('journal-entry')).toHaveCount(2);
  await page.getByTestId('journal-search').fill('cafe');
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  const [download] = await Promise.all([page.waitForEvent('download'), page.getByTestId('journal-export').click()]);
  expect(download.suggestedFilename()).toMatch(/^companion-journal-\d{4}-\d{2}-\d{2}\.md$/);
  const md = fs.readFileSync((await download.path())!, 'utf8');
  expect(md).toContain('# Journal · Test Person');
  expect(md).toContain('Café by the river. Felt calm.');
  expect(md).not.toContain('Argued about the rent.');
  await page.getByTestId('journal-search').fill('zzz');
  await expect(page.getByTestId('journal-no-match')).toBeVisible();
  await page.getByTestId('journal-search-clear').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(3);
});

test('appearance · Night is remembered on this device and leaves entries untouched', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('Written by day.');
  await page.getByTestId('journal-save').click();
  await page.getByTestId('tab-you').click();
  await expect(page.getByTestId('appearance-day')).toHaveAttribute('aria-checked', 'true');
  await page.getByTestId('appearance-night').click();
  await expect.poll(() => themeAttr(page), { timeout: 10_000 }).toBe('night');
  await expect(page.getByTestId('screen-today')).toBeVisible();
  expect(await page.evaluate(() => getComputedStyle(document.body).backgroundColor)).toBe('rgb(18, 25, 21)');
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('Written by day.');
  await page.reload();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.getAttribute('data-theme'))).toBe('night');
  await page.getByTestId('tab-you').click();
  await expect(page.getByTestId('appearance-night')).toHaveAttribute('aria-checked', 'true');
  await page.getByTestId('appearance-day').click();
  await expect.poll(() => themeAttr(page), { timeout: 10_000 }).toBe('day');
  await expect(page.getByTestId('screen-today')).toBeVisible();
});

test('v1 · a first-version journey on this device can be brought in as a copy, leaving the original untouched', async ({ page }) => {
  const T = new Date(Date.now() - 3 * 86400000);
  let j: any = ops.completeOnboarding(ops.emptyJourney(T, 'jrn_v1'), { name: 'Maya', ageBracket: '25-34', spaceId: 'personal', directions: [] }, T);
  j = ops.addCheckIn(j, { mood: 60, energy: 60, connection: 60 }, T, 'chk_v1');
  j = ops.addJournal(j, 'From the first version.', undefined, T, 'jnl_v1');
  delete j.goals;
  delete j.practiceLogs;
  delete j.paths;
  j.schemaVersion = 1;
  const raw = JSON.stringify(j);
  await seed(page, 'companion.v1.journey.guest', j);
  await page.goto('/');
  await expect(page.getByTestId('v1-import')).toContainText('Welcome back, Maya.');
  await page.getByTestId('v1-import-go').click();
  await expect(page.getByText(/Good (morning|afternoon|evening), Maya\./)).toBeVisible();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('From the first version.');
  expect(await page.evaluate(() => localStorage.getItem('companion.v1.journey.guest'))).toBe(raw);
  await openPath(page);
  await expect(page.getByTestId('map-tier-foundation')).toBeVisible();
});

test('path · "Not yet" lets the offer rest, and the path can still begin', async ({ page }) => {
  await seed(page, 'companion.v2.journey.guest', readyForAcolyte());
  await page.goto('/');
  await openPath(page);
  await page.getByTestId('teacher-not-yet').click();
  await expect(page.getByTestId('teacher-invite')).toHaveText('The Acolyte path is ready when you are.');
  await expect(page.getByTestId('teacher-not-yet')).toHaveCount(0);
  await page.getByTestId('teacher-begin').click();
  await expect(page.getByTestId('teacher-card')).toContainText('Watching the mind');
});

test('v1 · a first-version journey can also be merged later from Your data', async ({ page }) => {
  const T = new Date(Date.now() - 2 * 86400000);
  let j: any = ops.completeOnboarding(ops.emptyJourney(T, 'jrn_v1b'), { name: 'Maya', ageBracket: '25-34', spaceId: 'personal', directions: [] }, T);
  j = ops.addJournal(j, 'An old entry from the first version.', undefined, T, 'jnl_old');
  delete j.goals;
  delete j.practiceLogs;
  delete j.paths;
  j.schemaVersion = 1;
  await seed(page, 'companion.v1.journey.guest', j);
  await onboard(page, 'New Me');
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('A new entry in v2.');
  await page.getByTestId('journal-save').click();
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /^Your data/ }).click();
  await page.getByTestId('v1-merge-go').click();
  await expect(page.getByTestId('v1-merge')).toContainText('Merged.');
  await back(page);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(2);
  await expect(page.getByTestId('journal-stream')).toContainText('An old entry from the first version.');
});

test('path · under 18 walks the same paths (no microdosing anywhere on them)', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Sam');
  await page.getByTestId('onboarding-age-under18').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-finish').click();
  await openPath(page);
  await expect(page.getByTestId('teacher-card')).toContainText('Show up');
  await expect(page.getByTestId('path-map')).not.toContainText(/microdos|dose|protocol/i);
  expect(localDayKey(new Date())).toMatch(/^\d{4}-\d{2}-\d{2}$/);
});

test('painted · the invitation opens in the Hall of Ascension; entering opens the path, staying lets it rest', async ({ page }) => {
  await seed(page, 'companion.v2.journey.guest', readyForAcolyte());
  await page.goto('/');
  await openPath(page);
  await page.getByTestId('teacher-invitation').click();
  await expect(page.getByTestId('screen-invitation')).toBeVisible();
  await expect(page.getByTestId('invitation-title')).toHaveText('The Acolyte path is open to you');
  await expect(page.getByTestId('invitation-place')).toHaveText('Hall of Ascension');
  // Staying is the teacher's "Not yet": the offer rests, the path stays openable.
  await page.getByTestId('invitation-stay').click();
  await expect(page.getByTestId('teacher-invite')).toHaveText('The Acolyte path is ready when you are.');
  await page.getByTestId('teacher-invitation').click();
  await page.getByTestId('invitation-enter').click();
  await expect(page.getByTestId('teacher-card')).toContainText('Watching the mind');
  await expect(page.getByTestId('map-tier-acolyte')).toContainText('Open');
});
