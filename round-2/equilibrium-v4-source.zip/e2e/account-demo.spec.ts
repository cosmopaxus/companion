import { test, expect, Page } from '@playwright/test';

// Account UI against the in-memory DEMO backend (EXPO_PUBLIC_COMPANION_DEMO_BACKEND=1 build).
// Proves the guest-import choice, per-account local caches and sign-out isolation in the UI.
// It does NOT prove real cross-device sync — that needs a live Supabase project.
const DEMO = process.env.E2E_DEMO_URL;
test.skip(!DEMO, 'Set E2E_DEMO_URL to a demo-backend build to run account UI tests.');
test.use({ baseURL: DEMO });

async function onboard(page: Page, name: string) {
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill(name);
  await page.getByTestId('onboarding-age-25-34').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
}
async function journal(page: Page, text: string) {
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill(text);
  await page.getByTestId('journal-save').click();
  await expect(page.getByTestId('journal-saved')).toBeVisible();
}
async function openAccount(page: Page) {
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Account & sync/ }).click();
}
async function signIn(page: Page, email: string) {
  await page.getByTestId('account-email').fill(email);
  await page.getByTestId('account-send').click();
  await page.getByTestId('account-code').fill('123456');
  await page.getByTestId('account-verify').click();
}

test('guest import is a choice; each account keeps its own cache; sign-out exposes nothing', async ({ page }) => {
  await page.goto('/');
  await onboard(page, 'Guest A');
  await journal(page, 'written as a guest');

  // Sign in as A and choose to bring the guest journey along.
  await openAccount(page);
  await signIn(page, 'a@example.com');
  await expect(page.getByText('Bring your guest journey?')).toBeVisible();
  await page.getByTestId('import-yes').click();
  await expect(page.getByTestId('sync-status')).toContainText('Synced', { timeout: 10_000 });
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('written as a guest');

  // Sign out: the guest copy moved into A's account, so this device's guest journey is empty.
  await openAccount(page);
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByTestId('onboarding-welcome')).toBeVisible();

  // A second person: guest journey, then account B, keeping the guest journey separate.
  await onboard(page, 'Guest B');
  await journal(page, 'guest B note');
  await openAccount(page);
  await signIn(page, 'b@example.com');
  await page.getByTestId('import-no').click();
  await expect(page.getByTestId('onboarding-welcome')).toBeVisible(); // B's account is new and empty
  await onboard(page, 'Account B');
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(0); // none of A's, none of guest B's

  // Sign out of B: guest B's separate journey is back, untouched.
  await openAccount(page);
  await page.getByRole('button', { name: 'Sign out' }).click();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  await expect(page.getByTestId('journal-entry')).toContainText('guest B note');

  // Signing back in as A restores A's journey (not B's, not the guest's).
  await openAccount(page);
  await signIn(page, 'a@example.com');
  await page.getByTestId('import-no').click();
  await expect(page.getByTestId('sync-status')).toContainText('Synced', { timeout: 10_000 });
  await page.getByTestId('tab-today').click();
  await expect(page.getByText(/Guest A\./)).toBeVisible();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  await expect(page.getByTestId('journal-entry')).toContainText('written as a guest');
});
