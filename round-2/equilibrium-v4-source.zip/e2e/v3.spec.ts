import { test, expect, Page } from '@playwright/test';

// v3 · Graphics & Interface, phase 1: the hall header on Home, the check-in's hall band, and the
// hall choice in You → Preferences. Synthetic data only.

async function onboard(page: Page, name = 'Test Person', age = '25-34') {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill(name);
  await page.getByTestId(`onboarding-age-${age}`).click();
  await page.getByTestId('onboarding-continue-1').click();
  if (age !== 'under18') {
    await page.getByTestId('onboarding-continue-2').click();
    await page.getByTestId('onboarding-continue-3').click();
  }
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
}

/** Painted academy (decided Oct 14): the check-in has its own screen, opened from Home's card. */
async function openCheckIn(page: Page) {
  if (await page.getByTestId('checkin-mood').isVisible()) return;
  const again = page.getByTestId('checkin-again');
  if (await again.isVisible()) await again.click();
  else await page.getByTestId('checkin-open').click();
  await expect(page.getByTestId('checkin-mood')).toBeVisible();
}

/** The visible back button (glass screens show a round chip; its name is still "Back"). */
async function goBack(page: Page) {
  const chip = page.getByTestId('back-chip').filter({ visible: true });
  if (await chip.count()) await chip.last().click();
  else await page.getByRole('button', { name: 'Back', exact: true }).filter({ visible: true }).last().click();
}

test('hall · Home opens on the academy at sunrise, with the greeting as the page heading; halls start in the Herb Garden', async ({ page }) => {
  await onboard(page, 'Maya');
  const hero = page.getByTestId('hall-hero');
  await expect(hero).toBeVisible();
  await expect(page.getByRole('heading', { level: 1 })).toHaveText(/Good (morning|afternoon|evening), Maya\./);
  await expect(page.getByTestId('hero-place')).toHaveText('Foundation');
  await expect(page.getByTestId('home-hall')).toHaveText('Herb Garden');
  // Gems on the art: a chip in the window on wide screens; on phones the floating top bar's gem chip.
  await expect(page.getByTestId(test.info().project.name === 'phone' ? 'top-bar-on-art' : 'art-gems')).toBeVisible();
  await expect(page.getByTestId('painting')).toBeVisible();
  await expect(page.getByTestId('checkin-band')).toBeVisible();
  await expect(page.getByRole('heading', { level: 2, name: 'Today’s check-in' })).toBeVisible();
  // The art is decoration: hidden from screen readers.
  expect(await hero.locator('[aria-hidden="true"] img, [aria-hidden="true"] svg').count()).toBeGreaterThan(0);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('hero-hall')).toHaveText('Earth · The Herb Garden');
});

test("hall · choosing a hall in You changes Home's hall, each screen keeps its own, and following the lesson brings it back", async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-you').click();
  await page.getByTestId('hall-fire').click();
  await expect(page.getByTestId('hall-fire')).toHaveAttribute('aria-checked', 'true');
  await expect(page.getByTestId('hall-choice')).toContainText('Fire · The Forge. Kept by you.');
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('home-hall')).toHaveText('Forge');
  await page.reload();
  await expect(page.getByTestId('home-hall')).toHaveText('Forge');
  // The Journal is always the Herb Garden, whatever hall is chosen.
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('hero-hall')).toHaveText('Earth · The Herb Garden');
  await page.getByTestId('tab-you').click();
  await page.getByTestId('hall-lesson').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('home-hall')).not.toHaveText('Forge');
});

test('hall · the check-in opens from the hall band card, saves on its own screen, and Home confirms it', async ({ page }) => {
  await onboard(page);
  await openCheckIn(page);
  await expect(page.getByRole('heading', { level: 1, name: 'How are you right now?' })).toBeVisible();
  for (const d of ['mood', 'energy', 'connection']) {
    const s = page.getByTestId(`checkin-${d}`);
    await s.scrollIntoViewIfNeeded();
    await s.focus();
    await page.keyboard.press('End');
  }
  await page.getByTestId('checkin-save').click();
  await expect(page.getByTestId('checkin-saved')).toBeVisible();
});

test('hall · Night keeps the hall and its text', async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('companion.v2.theme', 'night'));
  await onboard(page);
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'night');
  await expect(page.getByTestId('hero-place')).toHaveText('Foundation');
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('hero-hall')).toHaveText('Earth · The Herb Garden');
});

test('hall · under 18 gets the same academy, with nothing adult-only added', async ({ page }) => {
  await onboard(page, 'Sam', 'under18');
  await expect(page.getByTestId('hall-hero')).toBeVisible();
  await expect(page.getByText(/protocol/i)).toHaveCount(0);
});

test('hall · the header and check-in keep their place while the page settles (no layout jump)', async ({ page }) => {
  await onboard(page);
  const card = page.getByTestId('checkin-card');
  const first = (await card.boundingBox())!.y;
  await page.waitForTimeout(600);
  const later = (await card.boundingBox())!.y;
  expect(Math.abs(later - first)).toBeLessThanOrEqual(1);
});

test('grounds · the path map is academy grounds: a lit Courtyard, unlit buildings further on', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('path-map')).toBeVisible();
  await expect(page.getByTestId('region-foundation')).toBeVisible();
  await expect(page.getByRole('heading', { level: 2, name: 'Foundation path · The Courtyard' })).toHaveCount(1);
  await expect(page.getByTestId('map-tier-foundation')).toContainText('The Courtyard');
  await expect(page.getByTestId('map-tier-acolyte')).toContainText('The Library');
  await expect(page.getByTestId('map-tier-initiate')).toContainText('The Tower');
  await expect(page.getByTestId('map-tier-adept')).toContainText('The Sanctum');
  // Lessons are still real buttons on the grounds, and "you are here" is marked.
  const here = page.getByRole('button', { name: /You are here/ });
  await expect(here).toHaveCount(1);
  await here.click();
  await expect(page.getByTestId('screen-lesson')).toBeVisible();
});

async function checkInAll(page: Page) {
  await openCheckIn(page);
  for (const d of ['mood', 'energy', 'connection']) {
    const s = page.getByTestId(`checkin-${d}`);
    await s.scrollIntoViewIfNeeded();
    await s.focus();
    await page.keyboard.press('End');
  }
  await page.getByTestId('checkin-save').click();
}

test('motion · earning a seal gets a celebration that never blocks the page', async ({ page }) => {
  await onboard(page);
  await expect(page.getByTestId('hall-ambience')).toHaveCount(1);
  await checkInAll(page);
  const c = page.getByTestId('celebration');
  await expect(c).toContainText('Seal earned · Badge');
  await expect(c).toContainText('First light');
  // Taps pass straight through it, and it leaves on its own.
  await page.getByTestId('checkin-again').click();
  await expect(c).toHaveCount(0, { timeout: 8000 });
});

test('motion · reduced motion keeps the moment but stops the movement', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await onboard(page);
  await expect(page.getByTestId('hall-ambience')).toHaveCount(0);
  await checkInAll(page);
  await expect(page.getByTestId('celebration')).toContainText('First light');
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('path-map')).toBeVisible();
  await expect(page.getByTestId('here-pulse')).toHaveCount(0);
});

test('motion · the you-are-here pulse sits on the map without moving the lesson button', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('here-pulse')).toHaveCount(1);
  const here = page.getByRole('button', { name: /You are here/ });
  const a = (await here.boundingBox())!;
  await page.waitForTimeout(700);
  const b = (await here.boundingBox())!;
  expect(Math.abs(a.x - b.x) + Math.abs(a.y - b.y)).toBeLessThanOrEqual(1);
});

test('glass · content starts below the art, on frosted glass, and the title has its halo', async ({ page }) => {
  await onboard(page);
  const art = (await page.getByTestId('hall-hero').boundingBox())!;
  const card = (await page.getByTestId('checkin-card').boundingBox())!;
  expect(card.y).toBeGreaterThanOrEqual(art.y + 300);
  await expect(page.getByTestId('title-halo')).toBeVisible();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('hero-place')).toHaveCount(1); // Home stays mounted…
  await expect(page.getByTestId('hero-hall')).toHaveCount(1); // …and Journal opens in its hall
  const halo = page.getByTestId('title-halo').last();
  await expect(halo).toContainText('Today’s page');
});

test('painted · reduced motion stops all ambient motion: no particles, and the painting holds still', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await onboard(page);
  await expect(page.getByTestId('hall-ambience')).toHaveCount(0);
  const art = page.getByTestId('painting');
  await expect(art).toBeVisible();
  const read = () => art.evaluate((el) => getComputedStyle(el).transform);
  const a = await read();
  await page.waitForTimeout(1500);
  expect(await read()).toBe(a);
  expect(a === 'none' || a === 'matrix(1, 0, 0, 1, 0, 0)').toBe(true);
});

test('painted · with motion on, the painting slowly zooms and never moves the page', async ({ page }) => {
  await onboard(page);
  const art = page.getByTestId('painting');
  const heading = page.getByRole('heading', { level: 1 });
  const h1 = (await heading.boundingBox())!;
  const read = () => art.evaluate((el) => getComputedStyle(el).transform);
  const a = await read();
  await page.waitForTimeout(2500);
  expect(await read()).not.toBe(a);
  const h2 = (await heading.boundingBox())!;
  expect(Math.abs(h1.y - h2.y)).toBeLessThanOrEqual(1);
});

test('painted · piece 2: hall eyebrow, lesson pips, journal date tiles and gem pills', async ({ page }) => {
  await onboard(page);
  await openCheckIn(page);
  await expect(page.getByTestId('checkin-save').getByTestId('button-gems')).toContainText('+2');
  await goBack(page);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('screen-eyebrow').last()).toHaveText('Grimoire · Personal');
  await page.getByTestId('journal-input').fill('A page for the tile.');
  await expect(page.getByTestId('journal-save').getByTestId('button-gems')).toContainText('+1');
  await page.getByTestId('journal-save').click();
  const month = new Date().toLocaleString('en-US', { month: 'short' }).toUpperCase();
  await expect(page.getByTestId('journal-entry')).toContainText(month);
  await expect(page.getByRole('heading', { name: 'Earlier pages' })).toBeVisible();
  await page.getByTestId('tab-journey').click();
  await page.getByRole('button', { name: /You are here/ }).click();
  const pips = page.getByTestId('lesson-progress').getByRole('progressbar');
  await expect(pips).toHaveAttribute('aria-valuemax', '5');
});

test('painted · piece 3: a 2-minute rest in the Sanctuary breathes, pauses and finishes, recording nothing', async ({ page }) => {
  await onboard(page);
  const before = await page.evaluate(() => localStorage.getItem('companion.v2.journey.guest'));
  await page.getByTestId('rest-open').click();
  await expect(page.getByTestId('screen-rest')).toBeVisible();
  await expect(page.getByTestId('rest-cue')).toHaveText('Breathe in');
  await expect(page.getByTestId('rest-cue')).toHaveText('Breathe out', { timeout: 6000 });
  await expect(page.getByTestId('rest-left')).not.toHaveText('2:00 left');
  await page.getByTestId('rest-pause').click();
  await expect(page.getByTestId('rest-cue')).toHaveText('Paused');
  const held = await page.getByTestId('rest-left').innerText();
  await page.waitForTimeout(1500);
  await expect(page.getByTestId('rest-left')).toHaveText(held);
  await page.getByTestId('rest-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem('companion.v2.journey.guest'))).toBe(before);
});

test('rest · the spring-water sound plays on the rest screen, can be switched off, and changes no saved data', async ({ page }) => {
  await onboard(page);
  const before = await page.evaluate(() => localStorage.getItem('companion.v2.journey.guest'));
  const audio = page.waitForResponse((r) => r.url().endsWith('audio/spring-water.mp3'));
  await page.getByTestId('rest-open').click();
  const res = await audio;
  expect(res.status()).toBe(200);
  const sw = page.getByTestId('rest-sound');
  await expect(sw).toHaveAttribute('aria-checked', 'true');
  await sw.click();
  await expect(sw).toHaveAttribute('aria-checked', 'false');
  await page.getByTestId('rest-finish').click();
  expect(await page.evaluate(() => localStorage.getItem('companion.v2.journey.guest'))).toBe(before);
});

test('rest · with slider sound off in You, the rest starts quiet', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-today').click();
  await page.getByTestId('checkin-open').click();
  await page.getByTestId('checkin-sound').click();
  await goBack(page);
  await page.getByTestId('rest-open').click();
  await expect(page.getByTestId('rest-sound')).toHaveAttribute('aria-checked', 'false');
});

test('painted · piece 3: under reduced motion the breath orb holds still and only its words change', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await onboard(page);
  await page.getByTestId('rest-open').click();
  const orb = page.getByTestId('rest-orb');
  const t1 = await orb.evaluate((el) => getComputedStyle(el).transform);
  await expect(page.getByTestId('rest-cue')).toHaveText('Breathe out', { timeout: 6000 });
  expect(await orb.evaluate((el) => getComputedStyle(el).transform)).toBe(t1);
  await expect(page.getByTestId('art-ambience')).toHaveCount(0);
});

test('painted · piece 3: the path map is drawn on the academy grounds, with the Sanctuary one tap away', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('grounds-map')).toBeVisible();
  await expect(page.getByTestId('map-lesson-f-show-up')).toHaveAccessibleName(/You are here/);
  await expect(page.getByTestId('map-next-tier')).toHaveAccessibleName(/Acolyte path/);
  await page.getByTestId('map-sanctuary').click();
  await expect(page.getByTestId('screen-rest')).toBeVisible();
});

test('painted · the check-in always opens in the Moon Pool, whatever hall you keep', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-you').click();
  await page.getByTestId('hall-fire').click();
  await page.getByTestId('tab-today').click();
  await openCheckIn(page);
  await expect(page.getByTestId('hero-hall').filter({ visible: true })).toHaveText('Water · The Moon Pool');
  const art = page.getByTestId('screen-checkin').locator('..').getByTestId('painting');
  expect(await art.first().evaluate((el) => el.outerHTML)).toContain('hall-water-the-moon-pool');
});

test('painted · on phones the art runs to the top; the Space and gem chips float over it, and plain screens keep the bar', async ({ page }, info) => {
  test.skip(info.project.name !== 'phone', 'phones only; wide screens use the side rail');
  await onboard(page);
  await expect(page.getByTestId('top-bar-on-art')).toBeVisible();
  await expect(page.getByTestId('space-pill')).toHaveAccessibleName('Space: Personal. Change Space');
  await page.getByTestId('tab-journey').click();
  await expect(page.getByTestId('grounds-hero')).toBeVisible();
  await expect(page.getByTestId('top-bar-on-art')).toBeVisible();
  await expect(page.getByTestId('grounds-progress')).toHaveText('Foundation · 0 of 7');
  await page.getByTestId('tab-you').click();
  await expect(page.getByTestId('top-bar-on-art')).toHaveCount(0);
  await expect(page.getByTestId('space-pill')).toContainText('Personal');
});
