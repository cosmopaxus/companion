import { test, expect } from '@playwright/test';

// The web build is an installable, offline-capable web app (PWA).
test('manifest, icons and service worker make it installable; it opens offline after the first visit', async ({ page, context }) => {
  await page.goto('./'); // relative, so the same test runs against a build served from a sub-folder
  const manifestHref = await page.locator('link[rel="manifest"]').getAttribute('href');
  expect(manifestHref).toBeTruthy();
  const manifest = await (await page.request.get(new URL(manifestHref!, page.url()).toString())).json();
  expect(manifest.name).toBe('Equilibrium v3 · Graphics & Interface'); // the build's name says what it focused on
  expect(manifest.display).toBe('standalone');
  const sizes = manifest.icons.map((i: any) => i.sizes);
  expect(sizes).toEqual(expect.arrayContaining(['192x192', '512x512']));
  for (const icon of manifest.icons) expect((await page.request.get(new URL(icon.src, page.url()).toString())).ok()).toBe(true);

  // Service worker takes control.
  await page.waitForFunction(async () => (await navigator.serviceWorker.getRegistration())?.active?.state === 'activated', null, { timeout: 15_000 });
  // A reload right as the worker finishes activating can still come back uncontrolled; reload until it's in control.
  await expect
    .poll(
      async () => {
        await page.reload();
        return page.evaluate(() => !!navigator.serviceWorker.controller);
      },
      { timeout: 30_000 },
    )
    .toBe(true);

  // Start a journey, go offline, reload: the app and the saved journey are still there.
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Offline Person');
  await page.getByTestId('onboarding-age-25-34').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByText(/Offline Person\./)).toBeVisible();
  await page.getByTestId('checkin-open').click();
  for (const d of ['mood', 'energy', 'connection']) {
    await page.getByTestId(`checkin-${d}`).focus();
    await page.getByTestId(`checkin-${d}`).press('End');
  }
  await page.getByTestId('checkin-save').click();
  await expect(page.getByTestId('checkin-saved')).toBeVisible();
  await context.setOffline(false);
});
