import { test, expect, Page, Locator } from '@playwright/test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Acceptance scenarios from the Equilibrium brief (§13), using synthetic data only.

async function onboard(page: Page, name = 'Test Person', opts: { space?: 'personal' | 'bewell'; dir?: string } = {}) {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill(name);
  await page.getByTestId('onboarding-age-25-34').click();
  await page.getByTestId('onboarding-continue-1').click();
  if (opts.space === 'bewell') await page.getByTestId('onboarding-space-bewell').click();
  await page.getByTestId('onboarding-continue-2').click();
  if (opts.dir) await page.getByTestId(`onboarding-dir-${opts.dir}`).click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
}

const gems = async (page: Page) => Number((await page.getByTestId('gem-pill-count').innerText()).trim());

/** Set a 0–100 feeling slider from the keyboard (Home, then Page Up ×10s and → ×1s). */
/** Painted academy (decided Oct 14): the check-in has its own screen, opened from Home's card. */
async function openCheckIn(page: Page) {
  if (await page.getByTestId('checkin-mood').isVisible()) return;
  const again = page.getByTestId('checkin-again');
  if (await again.isVisible()) await again.click();
  else await page.getByTestId('checkin-open').click();
  await expect(page.getByTestId('checkin-mood')).toBeVisible();
}

/** The visible back button (glass screens show a round chip; its name is still "Back"). */
async function goBack(page: Page) {
  const chip = page.getByTestId('back-chip').filter({ visible: true });
  if (await chip.count()) await chip.last().click();
  else await page.getByRole('button', { name: 'Back', exact: true }).filter({ visible: true }).last().click();
}

async function setLevel(scope: Page | Locator, testId: string, v: number) {
  const s = scope.getByTestId(testId);
  await s.focus();
  await s.press('Home');
  for (let i = 0; i < Math.floor(v / 10); i++) await s.press('PageUp');
  for (let i = 0; i < v % 10; i++) await s.press('ArrowRight');
  await expect(s).toHaveAttribute('aria-valuenow', String(v));
}

async function checkIn(page: Page, m: number, e: number, c: number, note?: string) {
  await openCheckIn(page);
  await setLevel(page, 'checkin-mood', m);
  await setLevel(page, 'checkin-energy', e);
  await setLevel(page, 'checkin-connection', c);
  if (note) await page.getByTestId('checkin-note').fill(note);
  await page.getByTestId('checkin-save').click();
  await expect(page.getByTestId('checkin-saved')).toBeVisible();
}

async function switchSpace(page: Page, space: 'personal' | 'bewell') {
  await page.getByTestId('space-pill').click();
  await page.getByTestId(`space-${space}`).click();
  await expect(page.getByTestId('space-pill')).toContainText(space === 'personal' ? 'Personal' : 'Be Well');
}

/** Journey opens on the Path (v2); areas are one tap away. */
async function openAreas(page: Page) {
  await page.getByTestId('tab-journey').click();
  await page.getByTestId('journey-view-areas').click();
  await expect(page.getByTestId('journey-areas')).toBeVisible();
}

async function addArea(page: Page, name: string, impact: number, difficulty: number) {
  await openAreas(page);
  const add = page.getByTestId('journey-add');
  if (await add.isVisible()) await add.click();
  else await page.getByTestId('journey-add-empty').click();
  await page.getByTestId('area-name').fill(name);
  await page.getByTestId(`area-impact-${impact}`).click();
  await page.getByTestId(`area-difficulty-${difficulty}`).click();
  await page.getByTestId('area-save').click();
  await expect(page.getByTestId('screen-area')).toBeVisible();
}

async function lesson(page: Page, id: string, doTry: () => Promise<void>) {
  const g = page.getByTestId('guide');
  await expect(g.getByTestId(`lesson-${id}`)).toBeVisible();
  await g.getByTestId('lesson-next').click(); // why → example
  await g.getByTestId('lesson-next').click(); // example → try
  await expect(g.getByTestId('lesson-next')).toBeDisabled();
  await doTry();
  await g.getByTestId('lesson-next').click(); // try → learned
  await expect(g.getByTestId('lesson-learned')).toBeVisible();
  await g.getByTestId('lesson-finish').click();
}

test('1 · a new visitor understands Equilibrium and reaches Today without buying anything', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('A practice for becoming.')).toBeVisible();
  await expect(page.getByText(/No account or purchase needed/)).toBeVisible();
  await onboard(page, 'Maya');
  await expect(page.getByText(/Good (morning|afternoon|evening), Maya\./)).toBeVisible();
  await expect(page.getByTestId('guide-card')).toBeVisible();
  expect(await gems(page)).toBe(0);
});

test('2 · the five-part guide teaches every section, stays separate from real history, resumes, and rewards once', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('guide-start').click();
  const g = page.getByTestId('guide');
  await expect(g.getByTestId('guide-hub')).toBeVisible();
  await g.getByTestId('guide-continue').click();

  await lesson(page, 'today', async () => {
    await setLevel(g, 'practice-checkin-mood', 50);
    await setLevel(g, 'practice-checkin-energy', 72);
    await setLevel(g, 'practice-checkin-connection', 31);
    await g.getByTestId('practice-checkin-save').click();
  });

  // Close mid-lesson (at "Try"), reload, and resume at the same step.
  await g.getByTestId('lesson-next').click();
  await g.getByTestId('lesson-next').click();
  await expect(g.getByTestId('lesson-try')).toBeVisible();
  await g.getByTestId('guide-close').click();
  await page.reload();
  await expect(page.getByTestId('guide-card')).toContainText('1 of 5');
  await page.getByTestId('guide-start').click();
  await expect(g.getByTestId('lesson-journey')).toBeVisible();
  await expect(g.getByTestId('lesson-try')).toBeVisible();
  await g.getByRole('radio', { name: 'A steadier sleep rhythm' }).click();
  await g.getByTestId('practice-evidence-kind-win').click();
  await g.getByTestId('practice-evidence-text').fill('I took a ten-minute walk');
  await g.getByTestId('practice-evidence-save').click();
  await g.getByTestId('lesson-next').click();
  await g.getByTestId('lesson-finish').click();

  await lesson(page, 'connect', async () => {
    await g.getByRole('radio', { name: 'Anyone in Connect' }).click();
    await expect(g.getByTestId('lesson-next')).toBeDisabled();
    await g.getByRole('radio', { name: 'Only me' }).click();
  });
  await lesson(page, 'journal', async () => {
    await g.getByTestId('practice-journal-text').fill('Today I noticed the rain on the window.');
    await g.getByTestId('practice-journal-save').click();
  });
  await lesson(page, 'you', async () => {
    await g.getByRole('radio', { name: 'Be Well' }).click();
    await g.getByTestId('practice-gem').click();
  });

  await expect(g.getByTestId('guide-celebrate')).toBeVisible();
  await g.getByTestId('celebrate-checkin').click();
  await expect(page.getByTestId('guide')).toBeHidden();

  // Exactly the one-time reward, in Personal; practice created no real history.
  expect(await gems(page)).toBe(5);
  await expect(page.getByTestId('today-so-far')).toHaveCount(0);
  await expect(page.getByTestId('guide-card')).toHaveCount(0);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByText('Your journal is empty — and private.')).toBeVisible();
  await openAreas(page);
  await expect(page.getByTestId('journey-empty')).toBeVisible();

  // Reload keeps completion; replaying a lesson never re-awards.
  await page.reload();
  expect(await gems(page)).toBe(5);
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /First steps/ }).click();
  await expect(g.getByTestId('guide-hub')).toContainText("You've walked the whole map");
  await g.getByTestId('guide-lesson-today').click();
  await g.getByTestId('lesson-next').click();
  await g.getByTestId('lesson-next').click();
  await expect(g.getByTestId('lesson-next')).toBeDisabled(); // replay starts the practice fresh
  await setLevel(g, 'practice-checkin-mood', 4);
  await setLevel(g, 'practice-checkin-energy', 0);
  await setLevel(g, 'practice-checkin-connection', 12);
  await g.getByTestId('practice-checkin-save').click();
  await g.getByTestId('lesson-next').click();
  await g.getByTestId('lesson-finish').click();
  await expect(g.getByTestId('guide-hub')).toBeVisible();
  await g.getByTestId('guide-close').click();
  expect(await gems(page)).toBe(5);
  await page.getByTestId('gem-pill').click();
  await expect(page.getByTestId('gem-tx')).toHaveCount(1);
});

test('3 · real check-ins save with a note, reward 2 gems, allow several per day, and survive reload', async ({ page }) => {
  await onboard(page);
  await openCheckIn(page);
  await expect(page.getByTestId('checkin-save')).toBeDisabled();
  await checkIn(page, 28, 45, 63, 'Slow start; coffee helped.');
  await expect(page.getByTestId('checkin-saved')).toContainText('1st check-in today');
  expect(await gems(page)).toBe(2);
  await page.getByTestId('checkin-again').click();
  await checkIn(page, 100, 91, 84);
  await expect(page.getByTestId('checkin-saved')).toContainText('2nd check-in today');
  expect(await gems(page)).toBe(4);
  await page.reload();
  await expect(page.getByTestId('today-so-far')).toContainText('2 check-ins');
  await expect(page.getByTestId('today-so-far')).toContainText('Slow start; coffee helped.');
  expect(await gems(page)).toBe(4);
});

test('4 · Journey ranks areas transparently and keeps win / observation / setback evidence', async ({ page }) => {
  await onboard(page);
  await addArea(page, 'Finish the zine', 3, 1);
  await addArea(page, 'Steadier sleep', 5, 2);
  await addArea(page, 'More patience', 5, 4);
  await openAreas(page);
  await expect(page.getByTestId('area-card-0')).toContainText('Steadier sleep');
  await expect(page.getByTestId('area-card-0')).toContainText('Easy win');
  await expect(page.getByTestId('area-card-1')).toContainText('More patience');
  await expect(page.getByTestId('area-card-2')).toContainText('Finish the zine');

  await page.getByTestId('area-card-0').click();
  for (const [kind, text] of [
    ['win', 'Lights out by 11'],
    ['observation', 'Coffee after 2pm hurts'],
    ['setback', 'Up past 1am on Friday'],
  ]) {
    await page.getByTestId(`evidence-kind-${kind}`).click();
    await page.getByTestId('evidence-text').fill(text);
    await page.getByTestId('evidence-save').click();
    await expect(page.getByTestId('evidence-saved')).toBeVisible();
  }
  await expect(page.getByTestId('stat-win')).toHaveText('1');
  await expect(page.getByTestId('stat-observation')).toHaveText('1');
  await expect(page.getByTestId('stat-setback')).toHaveText('1');
  const items = page.getByTestId('evidence-item');
  await expect(items).toHaveCount(3);
  await expect(items.nth(0)).toContainText('Setback');
  await expect(items.nth(1)).toContainText('Observation');
  await expect(items.nth(2)).toContainText('Win');
  expect(await gems(page)).toBe(3);
  await page.reload();
  await openAreas(page);
  await expect(page.getByTestId('area-card-0')).toContainText('1 win');
  await expect(page.getByTestId('area-card-0')).toContainText('1 observation · 1 setback');
});

test('5 · Compass shows 50 at midpoint, 75 for resource 5 / pressure 3, and saves the snapshot', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('harmony-open').click();
  for (const el of ['fire', 'air', 'water', 'earth']) await expect(page.getByTestId(`harmony-${el}-balance`)).toContainText('50');
  await page.getByTestId('harmony-fire-resource-5').click();
  await expect(page.getByTestId('harmony-fire-balance')).toContainText('75');
  await expect(page.getByTestId('harmony-fire-balance')).toContainText('Supported');
  await page.getByTestId('harmony-air-pressure-5').click();
  await expect(page.getByTestId('harmony-air-balance')).toContainText('25');
  await page.getByTestId('harmony-save').click();
  await expect(page.getByTestId('screen-harmony-reading')).toBeVisible();
  await expect(page.getByTestId('reading-fire')).toContainText('75 · Supported');
  await expect(page.getByTestId('reading-word')).toHaveText('In discord');
  await expect(page.getByTestId('reading-figures')).toContainText('Overall 50');
  await expect(page.getByTestId('eq-begin-main')).toContainText('Begin with Air');
  expect(await gems(page)).toBe(2);
  await page.reload();
  await expect(page.getByTestId('home-eq-word')).toHaveText('In discord');
  await expect(page.getByTestId('equilibrium-open')).toHaveAccessibleName(/Begin with Air/);
});

test('6 · a journal entry saves once, clears the editor, survives reload; empty text cannot be saved', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-save')).toBeDisabled();
  await page.getByTestId('journal-input').fill('   ');
  await expect(page.getByTestId('journal-save')).toBeDisabled();
  await page.getByTestId('journal-input').fill('Walked the long way home and noticed the light.');
  await page.getByTestId('journal-save').click();
  await expect(page.getByTestId('journal-saved')).toBeVisible();
  await expect(page.getByTestId('journal-input')).toHaveValue('');
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  expect(await gems(page)).toBe(1);
  await page.reload();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  await expect(page.getByTestId('journal-entry')).toContainText('noticed the light');
});

test('6b · an unsaved journal draft survives reload', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('Half a thought');
  await page.waitForTimeout(700);
  await page.reload();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-input')).toHaveValue('Half a thought');
});

test('7 · Spaces scope check-ins, journal and gems; Journey areas are account-wide', async ({ page }) => {
  await onboard(page);
  await checkIn(page, 50, 50, 50);
  await addArea(page, 'Shared area', 4, 2);
  await page.getByTestId('tab-today').click();
  await switchSpace(page, 'bewell');
  expect(await gems(page)).toBe(0);
  await expect(page.getByTestId('today-so-far')).toHaveCount(0);
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('A Be Well reflection');
  await page.getByTestId('journal-save').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(1);
  await openAreas(page);
  await expect(page.getByTestId('area-card-0')).toContainText('Shared area');
  expect(await gems(page)).toBe(1);

  await switchSpace(page, 'personal');
  expect(await gems(page)).toBe(2);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toHaveCount(0);
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-so-far')).toContainText('1 check-in');
  await page.reload();
  await expect(page.getByTestId('space-pill')).toContainText('Personal');
});

test('8 · export produces a usable backup; valid restore works; invalid data changes nothing', async ({ page }, info) => {
  await onboard(page, 'Restore Tester');
  await checkIn(page, 72, 50, 33, 'backup me');
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('An entry worth keeping');
  await page.getByTestId('journal-save').click();
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Your data/ }).click();

  const [download] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-download').click()]);
  // Plain ASCII path: Chromium's file chooser drops files whose path contains the "·" in test names.
  const file = path.join(os.tmpdir(), `companion-backup-${info.project.name}-${Date.now()}.json`);
  await download.saveAs(file);
  const backup = JSON.parse(fs.readFileSync(file, 'utf8'));
  expect(backup.format).toBe('companion.backup');
  expect(backup.journey.checkins).toHaveLength(1);
  expect(backup.journey.journal[0].text).toBe('An entry worth keeping');

  // Invalid data: readable errors, journey untouched.
  await page.getByTestId('restore-paste-toggle').click();
  await page.getByTestId('restore-text').fill(JSON.stringify({ ...backup, journey: { ...backup.journey, checkins: [{ ...backup.journey.checkins[0], mood: 109 }] } }));
  await page.getByTestId('restore-check').click();
  await expect(page.getByTestId('restore-errors')).toContainText('0 to 100');
  await page.getByTestId('restore-text').fill('not a backup');
  await page.getByTestId('restore-check').click();
  await expect(page.getByTestId('restore-errors')).toContainText("isn't valid JSON");
  await expect(page.getByTestId('persist-status')).toContainText('1 check-ins · 1 journal entries');

  // Erase, then restore the exported file from the welcome screen.
  await page.getByTestId('erase-open').click();
  await page.getByTestId('confirm-yes').click();
  await expect(page.getByTestId('onboarding-welcome')).toBeVisible();
  await page.getByTestId('onboarding-restore').click();
  const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.getByTestId('restore-choose').click()]);
  await chooser.setFiles(file);
  await expect(page.getByTestId('restore-summary')).toContainText('Check-ins');
  await expect(page.getByTestId('restore-summary')).toContainText('In the backup');
  await page.getByTestId('restore-confirm').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await expect(page.getByText(/Restore Tester\./)).toBeVisible();
  expect(await gems(page)).toBe(3);
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('An entry worth keeping');
});

test('8b · restore replaces the guest journey and can be undone once', async ({ page }, info) => {
  await onboard(page, 'Original');
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('original entry');
  await page.getByTestId('journal-save').click();
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Your data/ }).click();
  const other = {
    format: 'companion.backup', version: 1, exportedAt: '2026-09-01T10:00:00.000Z', app: 'test',
    journey: {
      format: 'companion.journey', schemaVersion: 1, journeyId: 'jrn_other', createdAt: '2026-09-01T10:00:00.000Z', updatedAt: '2026-09-01T10:00:00.000Z', revision: 3,
      profile: { name: 'Other', ageConfirmed: true, chosenDirections: [], createdAt: '2026-09-01T10:00:00.000Z', updatedAt: '2026-09-01T10:00:00.000Z' },
      activeSpaceId: 'personal', checkins: [], areas: [], evidence: [], harmony: [], gems: [],
      journal: [{ id: 'j1', spaceId: 'personal', createdAt: '2026-09-01T10:00:00.000Z', updatedAt: '2026-09-01T10:00:00.000Z', text: 'restored entry' }],
    },
  };
  // The Your data screen may still be sliding in; retry the toggle until the text box shows.
  await expect(async () => {
    if (!(await page.getByTestId('restore-text').isVisible())) await page.getByTestId('restore-paste-toggle').click();
    await expect(page.getByTestId('restore-text')).toBeVisible({ timeout: 1000 });
  }).toPass();
  await page.getByTestId('restore-text').fill(JSON.stringify(other));
  await page.getByTestId('restore-check').click();
  await page.getByTestId('restore-confirm').click();
  await expect(page.getByTestId('restore-undo')).toBeVisible();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('restored entry');
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Your data/ }).click();
  await page.getByTestId('restore-undo').click();
  await expect(page.getByTestId('restore-undo')).toBeHidden();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('original entry');
});

test('9 · the gem ledger explains the balance', async ({ page }) => {
  await onboard(page);
  await checkIn(page, 50, 50, 50);
  await page.getByTestId('harmony-open').click();
  await page.getByTestId('harmony-save').click();
  await expect(page.getByText('Everything is still at the midpoint')).toBeVisible();
  await page.getByTestId('confirm-yes').click();
  await page.getByTestId('gem-pill').click();
  await expect(page.getByTestId('gem-balance')).toHaveText('4');
  const rows = page.getByTestId('gem-tx');
  await expect(rows).toHaveCount(2);
  await expect(rows.nth(0)).toContainText('Compass reading');
  await expect(rows.nth(1)).toContainText('Check-in');
});

test('10 · keyboard use, labels, and the tab bar never hides the last control', async ({ page }, info) => {
  await onboard(page);
  await openCheckIn(page);
  // The feelings are real sliders with names and spoken values, and work from the keyboard.
  const mood = page.getByRole('slider', { name: 'Mood' });
  await expect(mood).toHaveAttribute('aria-valuetext', /Not chosen/);
  await mood.focus();
  await page.keyboard.press('ArrowRight'); // the first step picks the midpoint
  await expect(mood).toHaveAttribute('aria-valuenow', '50');
  await page.keyboard.press('Shift+ArrowRight');
  await page.keyboard.press('ArrowLeft');
  await expect(mood).toHaveAttribute('aria-valuetext', '59 of 100, Okay');
  await page.keyboard.press('End');
  await expect(mood).toHaveAttribute('aria-valuetext', '100 of 100, Bright');
  // One Tab stop per slider.
  await page.keyboard.press('Tab');
  const energy = page.getByRole('slider', { name: 'Energy' });
  await expect(energy).toBeFocused();
  await page.keyboard.press('Home');
  await expect(energy).toHaveAttribute('aria-valuetext', '0 of 100, Depleted');
  await page.keyboard.press('PageUp');
  await expect(energy).toHaveAttribute('aria-valuenow', '10');
  const outline = await energy.evaluate((el) => getComputedStyle(el).outlineStyle);
  expect(outline).toBe('solid');
  await goBack(page);

  // Escape closes a sheet.
  await page.getByTestId('space-pill').click();
  await expect(page.getByTestId('space-sheet')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByTestId('space-sheet')).toBeHidden();

  // Scroll You to the very end: its last row must sit fully above the phone tab bar.
  await page.getByTestId('tab-you').click();
  const vp = page.viewportSize()!;
  await page.mouse.move(vp.width / 2, vp.height / 2);
  for (let i = 0; i < 6; i++) await page.mouse.wheel(0, 2000);
  await page.waitForTimeout(400);
  const last = await page.getByRole('button', { name: /About this version/ }).boundingBox();
  const vh = page.viewportSize()!.height;
  if (info.project.name === 'phone') {
    const bar = await page.getByRole('tablist', { name: 'Main' }).boundingBox();
    expect(last!.y + last!.height).toBeLessThanOrEqual(bar!.y);
  } else {
    expect(last!.y + last!.height).toBeLessThanOrEqual(vh);
  }
});

test('12 · unfinished features say so plainly', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-connect').click();
  await expect(page.getByText('Preview — nothing here is live yet')).toBeVisible();
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Account & sync/ }).click();
  await expect(page.getByText("Accounts aren't connected in this build")).toBeVisible();
  await goBack(page);
  await page.getByRole('button', { name: /About this version/ }).click();
  await expect(page.getByTestId('screen-about')).toContainText('Blocked');
  await expect(page.getByTestId('screen-about')).toContainText('Not built');
});

test('storage blocked → the app still works and says it is not saving', async ({ browser }, info) => {
  const context = await browser.newContext({ viewport: info.project.use.viewport ?? undefined });
  await context.addInitScript(() => {
    const block = () => {
      throw new DOMException('blocked', 'SecurityError');
    };
    Object.defineProperty(window, 'localStorage', { get: block, configurable: true });
  });
  const page = await context.newPage();
  await onboard(page, 'No Storage');
  await expect(page.getByText(/isn't letting Equilibrium save/)).toBeVisible();
  await checkIn(page, 50, 50, 50);
  expect(await gems(page)).toBe(2);
  await context.close();
});

test('recovery · unreadable saved data is kept aside, never silently overwritten', async ({ page }) => {
  await page.addInitScript(() => {
    if (!sessionStorage.getItem('seeded')) {
      localStorage.setItem('companion.v2.journey.guest', '{"format":"companion.journey", this is not json');
      sessionStorage.setItem('seeded', '1');
    }
  });
  await page.goto('/');
  await expect(page.getByText("Your saved journey couldn't be opened")).toBeVisible();
  const kept = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith('companion.v2.quarantine.guest')).map((k) => localStorage.getItem(k)));
  expect(kept.length).toBe(1);
  expect(kept[0]).toContain('this is not json');
});

test('recovery · one bad record is set aside and everything else loads', async ({ page }) => {
  await onboard(page, 'Salvage');
  await checkIn(page, 50, 50, 50, 'keep me');
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('also keep me');
  await page.getByTestId('journal-save').click();
  await page.waitForTimeout(400);
  await page.evaluate(() => {
    const k = 'companion.v2.journey.guest';
    const j = JSON.parse(localStorage.getItem(k)!);
    j.checkins[0].mood = 109; // corrupt one record
    localStorage.setItem(k, JSON.stringify(j));
  });
  await page.reload();
  await expect(page.getByTestId('recovery-banner')).toContainText('1 saved record');
  await expect(page.getByText(/Salvage\./)).toBeVisible();
  await page.getByTestId('tab-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('also keep me');
});

test('safety · a crisis answer leads with support, never "nothing flagged"', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Safety & Path/ }).click();
  for (const id of ['pregnancy', 'history_psychosis', 'lithium', 'heart', 'maoi', 'psych_meds']) await page.getByTestId(`intake-${id}`).getByRole('radio', { name: 'No', exact: true }).click();
  await page.getByTestId('intake-crisis_now').getByRole('radio', { name: 'Yes', exact: true }).click();
  await page.getByTestId('intake-save').click();
  await expect(page.getByTestId('intake-support')).toContainText('Support first');
  await expect(page.getByTestId('intake-result')).not.toContainText('Nothing flagged');
  await goBack(page);
  await expect(page.getByRole('button', { name: /Safety & Path/ })).toContainText('support options');
});

test('check-ins · a mis-tap can be deleted from today and from history', async ({ page }) => {
  await onboard(page);
  await checkIn(page, 3, 2, 1, 'oops');
  await page.getByTestId('checkin-again').click();
  await checkIn(page, 66, 61, 70);
  await expect(page.getByTestId('today-checkin')).toHaveCount(2);
  await page.getByRole('button', { name: /Delete the .* check-in/ }).last().click();
  await page.getByTestId('confirm-yes').click();
  await expect(page.getByTestId('today-checkin')).toHaveCount(1);
  await page.getByTestId('checkins-all').click();
  await expect(page.getByTestId('history-checkin')).toHaveCount(1);
  await page.reload();
  await expect(page.getByTestId('today-so-far')).toContainText('1 check-in');
});

test('sliders · drag or tap sets a 0–100 reading, and the picture, color and word follow it', async ({ page }, info) => {
  await onboard(page);
  await openCheckIn(page);
  const mood = page.getByTestId('checkin-mood');
  const block = page.getByTestId('checkin-mood-block');
  // v3: Home's hall header sits above the check-in, so bring the slider on screen before dragging.
  await block.scrollIntoViewIfNeeded();
  const box = (await mood.boundingBox())!;
  const y = box.y + box.height / 2;
  const at = (f: number) => box.x + 15 + f * (box.width - 30);
  const bg = () => block.evaluate((el) => getComputedStyle(el).backgroundColor);
  const glyph = () => block.locator('svg').first().innerHTML();

  // Drag from the heavy end to near the bright end.
  await page.mouse.move(at(0.05), y);
  await page.mouse.down();
  await page.mouse.move(at(0.1), y, { steps: 3 });
  const lowValue = Number(await mood.getAttribute('aria-valuenow'));
  expect(lowValue).toBeLessThanOrEqual(12);
  const lowBg = await bg();
  const lowGlyph = await glyph();
  await page.mouse.move(at(0.86), y, { steps: 12 });
  await page.mouse.up();
  const high = Number(await mood.getAttribute('aria-valuenow'));
  expect(Math.abs(high - 86)).toBeLessThanOrEqual(2);
  await expect(block).toContainText('Bright');
  expect(await bg()).not.toBe(lowBg);
  expect(await glyph()).not.toBe(lowGlyph);

  // A tap (touch on phone, click on desktop) jumps to that spot.
  if (info.project.name.includes('phone')) await page.touchscreen.tap(at(0.3), y);
  else await page.mouse.click(at(0.3), y);
  await expect.poll(async () => Math.abs(Number(await mood.getAttribute('aria-valuenow')) - 30)).toBeLessThanOrEqual(2);
  await expect(block).toContainText('Low');

  // Each feeling draws its own picture.
  const pics = await Promise.all(['mood', 'energy', 'connection'].map((d) => page.getByTestId(`checkin-${d}-block`).locator('svg').first().innerHTML()));
  expect(new Set(pics).size).toBe(3);

  await setLevel(page, 'checkin-energy', 7);
  await setLevel(page, 'checkin-connection', 93);
  await page.getByTestId('checkin-save').click();
  await expect(page.getByTestId('checkin-saved')).toContainText('Depleted');
  await expect(page.getByTestId('checkin-saved')).toContainText('93');
  await expect(page.getByTestId('checkin-saved')).toContainText('Connected');
});

test('sliders · each feeling has its own sound that follows the slider, and it can be turned off', async ({ page }) => {
  // Record the tones the app asks for, without needing speakers.
  await page.addInitScript(() => {
    const w = window as any;
    w.__tones = [];
    const AC = w.AudioContext;
    if (!AC) return;
    const orig = AC.prototype.createOscillator;
    AC.prototype.createOscillator = function (this: any) {
      const o = orig.call(this);
      const f = o.frequency;
      const set = f.setTargetAtTime.bind(f);
      f.setTargetAtTime = (v: number, t: number, c: number) => {
        w.__tones.push({ type: o.type, v });
        return set(v, t, c);
      };
      return o;
    };
  });
  await onboard(page);
  await openCheckIn(page);
  const tones = () => page.evaluate(() => (window as any).__tones as { type: string; v: number }[]);
  const mood = page.getByTestId('checkin-mood');
  await mood.focus();
  await mood.press('Home');
  const low = (await tones()).filter((t) => t.type === 'sine').map((t) => t.v);
  expect(low.length).toBeGreaterThan(0);
  await mood.press('End');
  const all = (await tones()).filter((t) => t.type === 'sine').map((t) => t.v);
  expect(Math.max(...all)).toBeGreaterThan(Math.max(...low) * 2); // brighter end sounds higher

  // Energy uses its own voice (a triangle hum with a sawtooth edge).
  await page.getByTestId('checkin-energy').focus();
  await page.getByTestId('checkin-energy').press('End');
  expect((await tones()).some((t) => t.type === 'sawtooth')).toBe(true);

  // Turn it off from the check-in card: no new tones.
  await page.getByTestId('checkin-sound').click();
  await expect(page.getByTestId('checkin-sound')).toHaveAttribute('aria-label', /off\. Turn it on/);
  const before = (await tones()).length;
  await page.getByTestId('checkin-connection').focus();
  await page.getByTestId('checkin-connection').press('End');
  await page.getByTestId('checkin-connection').press('Home');
  expect((await tones()).length).toBe(before);
  // The choice is saved with the journey.
  await page.reload();
  await openCheckIn(page);
  await expect(page.getByTestId('checkin-sound')).toHaveAttribute('aria-label', /off\. Turn it on/);
});

test('age · under 18 keeps every reflection feature and hides the microdosing tools', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Sam');
  await page.getByTestId('onboarding-age-under18').click();
  await expect(page.getByTestId('onboarding-reflection-mode')).toContainText('adults 18 and over');
  await page.getByTestId('onboarding-continue-1').click();
  // No Space step and no Safety & Path step: straight to directions, then Today.
  await expect(page.getByTestId('onboarding-direction')).toBeVisible();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await expect(page.getByTestId('space-pill')).toHaveCount(0);
  await expect(page.getByTestId('checkin-card')).toContainText('Personal');
  await checkIn(page, 60, 55, 70);

  await page.getByTestId('tab-you').click();
  await expect(page.getByTestId('you-age')).toContainText('Under 18');
  await expect(page.getByTestId('you-reflection-mode')).toBeVisible();
  await expect(page.getByRole('button', { name: /Safety & Path/ })).toHaveCount(0);
  await expect(page.getByRole('button', { name: /^Space/ })).toHaveCount(0);
  await expect(page.getByRole('button', { name: /Your protocol/ })).toHaveCount(0);

  await page.getByRole('button', { name: /^Support/ }).click();
  await expect(page.getByTestId('screen-support')).toContainText('988');
  await expect(page.getByTestId('support-fireside')).toHaveCount(0);
  await goBack(page);

  await page.getByRole('button', { name: /^Direction/ }).click();
  await page.getByRole('button', { name: 'Practice ideas' }).first().click();
  await expect(page.getByText(/Optional əvōke support/)).toHaveCount(0);
  await goBack(page);

  await page.getByRole('button', { name: /Account & sync/ }).click();
  await expect(page.getByTestId('screen-account')).toContainText(/adults 18 and over|aren't connected/);
  await goBack(page);

  // Changing to an adult range asks for confirmation, then shows the adult tools.
  await page.getByRole('button', { name: 'Edit' }).click();
  await page.getByTestId('profile-age-18-24').click();
  await page.getByTestId('profile-save').click();
  await expect(page.getByTestId('confirm-sheet')).toContainText("Confirm you're 18 or older");
  await page.getByTestId('confirm-yes').click();
  await expect(page.getByTestId('you-age')).toContainText('18–24');
  await expect(page.getByRole('button', { name: /Safety & Path/ })).toBeVisible();
  await expect(page.getByTestId('space-pill')).toBeVisible();
});

test('intake · adults can answer Safety & Path in onboarding, and major cautions are named', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Ari');
  await page.getByTestId('onboarding-age-35-44').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await expect(page.getByTestId('onboarding-intake')).toContainText('Before any microdosing');
  await expect(page.getByTestId('onboarding-finish')).toHaveText(/Skip for now/);
  await page.getByTestId('intake-experience').getByRole('radio', { name: 'A few times' }).click();
  for (const id of ['pregnancy', 'history_psychosis', 'maoi', 'psych_meds', 'crisis_now']) await page.getByTestId(`intake-${id}`).getByRole('radio', { name: 'No', exact: true }).click();
  await page.getByTestId('intake-lithium').getByRole('radio', { name: 'Yes', exact: true }).click();
  await page.getByTestId('intake-heart').getByRole('radio', { name: 'Yes', exact: true }).click();
  await expect(page.getByTestId('onboarding-finish')).toHaveText(/Save and go to Today/);
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await page.getByTestId('tab-you').click();
  await expect(page.getByRole('button', { name: /Safety & Path/ })).toContainText('2 factors worth discussing with a clinician, 1 of them a major caution');
  await page.getByRole('button', { name: /Safety & Path/ }).click();
  await expect(page.getByTestId('intake-result')).toContainText('Please talk with a clinician first');
  await expect(page.getByTestId('intake-result')).toContainText('start low and go slow');
  await expect(page.getByTestId('intake-result')).toContainText('a few times');
});

test('intake · a crisis answer during onboarding opens support first', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Jo');
  await page.getByTestId('onboarding-age-45-54').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('intake-crisis_now').getByRole('radio', { name: 'Yes', exact: true }).click();
  await expect(page.getByTestId('intake-crisis-now')).toContainText('988');
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-support')).toBeVisible();
});

async function openProtocol(page: Page) {
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Your protocol/ }).click();
  await expect(page.getByTestId('screen-protocol')).toBeVisible();
}

test('protocol · choose a common schedule, add your own notes, and see the rhythm', async ({ page }) => {
  await onboard(page);
  await openProtocol(page);
  await expect(page.getByTestId('protocol-intake-prompt')).toBeVisible();
  for (const id of ['one-two', 'four-three', 'three-two', 'every-other', 'two-a-week', 'custom']) await expect(page.getByTestId(`protocol-preset-${id}`)).toBeVisible();
  await expect(page.getByTestId('protocol-preset-one-two')).toContainText('Fadiman');

  await page.getByTestId('protocol-preset-three-two').click();
  await expect(page.getByTestId('screen-protocol-setup')).toBeVisible();
  await expect(page.getByTestId('protocol-start-low')).toContainText('Start low, go slow');
  await page.getByTestId('protocol-level-micro').click();
  await page.getByTestId('protocol-amount').fill('3 drops');
  await page.getByTestId('protocol-intention').fill('Steadier mornings');
  await page.getByTestId('protocol-save').click();

  await expect(page.getByTestId('protocol-today')).toContainText('Activation day 1 of 3');
  await expect(page.getByTestId('protocol-strip-activation')).toHaveCount(9); // 3 on, 2 off across 14 days
  await expect(page.getByTestId('protocol-strip-integration')).toHaveCount(5);
  await expect(page.getByTestId('protocol-notes')).toContainText('3 drops');
  await expect(page.getByTestId('protocol-notes')).toContainText('Steadier mornings');

  await page.getByTestId('protocol-pause').click();
  await expect(page.getByTestId('protocol-today')).toContainText('Paused');
  await page.getByTestId('protocol-resume').click();
  await expect(page.getByTestId('protocol-today')).toContainText('Activation day 1 of 3');

  await page.getByTestId('protocol-edit').click();
  await page.getByTestId('protocol-amount').fill('2 drops');
  await page.getByTestId('protocol-save').click();
  await expect(page.getByTestId('protocol-notes')).toContainText('2 drops');

  await page.getByTestId('protocol-change').click();
  await page.getByTestId('protocol-preset-one-two').click();
  await expect(page.getByTestId('screen-protocol-setup')).toContainText('Starting this ends “Three days on, two days off”');
  await page.getByTestId('protocol-save').click();
  await expect(page.getByTestId('protocol-current')).toContainText('One day on, two days off');
  await expect(page.getByTestId('protocol-past')).toHaveCount(1);

  await page.reload();
  await page.getByTestId('tab-you').click();
  await expect(page.getByRole('button', { name: /Your protocol/ })).toContainText('One day on, two days off · activation day today');
  expect(await gems(page)).toBe(0); // choosing a protocol is never rewarded
});

test('protocol · create your own with chosen weekdays, an earlier start and rest weeks', async ({ page }) => {
  await onboard(page);
  await openProtocol(page);
  await page.getByTestId('protocol-preset-custom').click();
  await page.getByTestId('protocol-name').fill('My weekday rhythm');
  await page.getByRole('radio', { name: /Chosen weekdays/ }).click();
  await page.getByTestId('protocol-weekday-3').click(); // add Wednesday to Mon + Thu
  for (let i = 0; i < 3; i++) await page.getByTestId('protocol-start-dec').click();
  await expect(page.getByTestId('protocol-start')).toContainText('3 days ago');
  await page.getByRole('switch', { name: 'Regular rest weeks' }).click();
  await page.getByTestId('protocol-cycle-weeks-inc').click();
  await expect(page.getByTestId('protocol-cycle-weeks-value')).toHaveText('5 wk');
  await page.getByTestId('protocol-save').click();
  await expect(page.getByTestId('protocol-current')).toContainText('My weekday rhythm');
  await expect(page.getByTestId('protocol-current')).toContainText('Activation on Mon, Wed, Thu');
  await expect(page.getByTestId('protocol-current')).toContainText('5 weeks, then 2 weeks rest');
});

test('protocol · cautions are named, and a crisis answer puts support first', async ({ page }) => {
  await onboard(page);
  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /Safety & Path/ }).click();
  await page.getByTestId('intake-lithium').getByRole('radio', { name: 'Yes', exact: true }).click();
  await page.getByTestId('intake-save').click();
  await page.getByTestId('intake-to-protocol').click();
  await expect(page.getByTestId('protocol-caution')).toContainText('Please talk with a clinician first');
  await expect(page.getByTestId('protocol-preset-one-two')).toBeVisible();
  await goBack(page);
  await page.getByTestId('intake-edit').click();
  await page.getByTestId('intake-crisis_now').getByRole('radio', { name: 'Yes', exact: true }).click();
  await page.getByTestId('intake-save').click();
  await goBack(page);
  await page.getByRole('button', { name: /Your protocol/ }).click();
  await expect(page.getByTestId('protocol-support-first')).toContainText('988');
  await expect(page.getByTestId('protocol-preset-one-two')).toHaveCount(0);
});

test('home · the dashboard is home: rhythm, the last 7 days and the timeline in one place', async ({ page }) => {
  await onboard(page);
  await expect(page.getByTestId('tab-today')).toHaveText(/Home/);
  await checkIn(page, 60, 55, 70, 'Slow start; coffee helped.');
  await page.getByTestId('tab-journal').click();
  await page.getByTestId('journal-input').fill('Walked the long way home.');
  await page.getByTestId('journal-save').click();
  await addArea(page, 'A steadier sleep rhythm', 5, 2);
  await openProtocol(page);
  await page.getByTestId('protocol-preset-one-two').click();
  await page.getByTestId('protocol-save').click();

  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await expect(page.getByTestId('open-dashboard')).toHaveCount(0);
  await expect(page.getByTestId('dash-rhythm-today')).toHaveText('Activation day');
  await expect(page.getByTestId('dash-rhythm-tomorrow')).toHaveText('Tomorrow: integration day');
  await expect(page.getByTestId('dash-week-readout')).toContainText('Today');
  await expect(page.getByTestId('dash-week-readout')).toContainText('1 check-in');
  await expect(page.getByTestId('dash-week-mood-value')).toHaveText('60 · Good');
  await expect(page.getByTestId('dash-week-connection-value')).toHaveText('70 · Close');
  // Tap a day with nothing recorded: the readout says so instead of inventing a value.
  await page.locator('[data-testid^="dash-bar-mood-"]').first().click();
  await expect(page.getByTestId('dash-week-readout')).toContainText('no check-in');
  await expect(page.getByTestId('dash-week-mood-value')).toHaveText('—');
  await page.getByTestId('dash-week-toggle').click();
  await expect(page.getByTestId('dash-week-table')).toContainText('60');

  await expect(page.getByTestId('dash-count-checkins')).toContainText('1');
  await expect(page.getByTestId('dash-count-journal')).toContainText('1');
  await expect(page.locator('[data-testid^="dash-item-"]')).toHaveCount(4);
  await expect(page.getByTestId('dash-item-protocol')).toContainText('Protocol started');
  await expect(page.getByTestId('dash-item-checkin')).toContainText('Slow start; coffee helped.');
  await page.getByTestId('dash-filter-journal').click();
  await expect(page.locator('[data-testid^="dash-item-"]')).toHaveCount(1);
  await page.getByTestId('dash-item-journal').click();
  await expect(page.getByTestId('journal-entry')).toContainText('Walked the long way home.');

  await page.getByTestId('tab-you').click();
  await page.getByRole('button', { name: /^Compass/ }).click();
  await expect(page.getByTestId('screen-equilibrium')).toBeVisible();
});

test('home · note today: taken with your own amount, edit, then remove; no gems', async ({ page }) => {
  await onboard(page);
  await openProtocol(page);
  await page.getByTestId('protocol-preset-one-two').click();
  await page.getByTestId('protocol-save').click();
  await page.getByTestId('tab-today').click();
  const before = await gems(page);

  await page.getByTestId('dash-note-today').click();
  await expect(page.getByTestId('day-note-sheet')).toBeVisible();
  await expect(page.getByTestId('day-note-taken')).toHaveAttribute('aria-checked', 'true');
  await expect(page.getByTestId('day-note-sheet')).toContainText('Start low, go slow');
  await page.getByTestId('day-note-amount').fill('2 drops');
  await page.getByTestId('day-note-text').fill('Calm, clear afternoon.');
  await page.getByTestId('day-note-save').click();
  await expect(page.getByTestId('day-note-sheet')).toHaveCount(0);
  await expect(page.getByTestId('dash-day-noted')).toContainText('Noted · Taken · 2 drops');
  await expect(page.getByTestId('dash-note-today')).toHaveCount(0);
  await expect(page.locator('[data-testid="dash-item-protocol"]').first()).toContainText('Day note · Taken');
  expect(await gems(page)).toBe(before);

  await page.reload();
  await page.getByTestId('dash-day-edit').click();
  await expect(page.getByTestId('day-note-amount')).toHaveValue('2 drops');
  await page.getByTestId('day-note-skipped').click();
  await expect(page.getByTestId('day-note-amount')).toHaveCount(0);
  await page.getByTestId('day-note-save').click();
  await expect(page.getByTestId('dash-day-noted')).toContainText('Noted · Skipped');
  await expect(page.getByTestId('dash-day-noted')).not.toContainText('2 drops');

  await page.getByTestId('dash-day-edit').click();
  await page.getByTestId('day-note-delete').click();
  await expect(page.getByTestId('dash-day-noted')).toHaveCount(0);
  await expect(page.getByTestId('dash-note-today')).toBeVisible();
});

test('equilibrium · what the numbers mean, where to begin, and the trend after two readings', async ({ page }) => {
  await onboard(page);
  await expect(page.getByTestId('harmony-card')).toContainText('Take your first reading');
  await page.getByTestId('harmony-open').click();
  await page.getByTestId('harmony-fire-resource-5').click();
  await page.getByTestId('harmony-air-pressure-5').click();
  await expect(page.getByTestId('harmony-live-word')).toContainText('In discord');
  await page.getByTestId('harmony-save').click();
  await expect(page.getByTestId('screen-harmony-reading')).toBeVisible();
  await goBack(page);

  await page.getByTestId('equilibrium-open').click();
  await expect(page.getByTestId('screen-equilibrium')).toBeVisible();
  await expect(page.getByTestId('eq-word')).toHaveText('In discord');
  await expect(page.getByTestId('eq-overall')).toContainText('50');
  await expect(page.getByTestId('eq-spread')).toContainText('50');
  await expect(page.getByTestId('eq-spread')).toContainText('Pulling apart');
  // Painted academy · piece 2: the four elements as bars, each with its number (Fire full, Air stretched).
  await expect(page.getByTestId('eq-elements-fire')).toContainText('75');
  await expect(page.getByTestId('eq-elements-air')).toContainText('25');
  await expect(page.getByRole('img', { name: 'Water: 50 of 100. Even is 50.' })).toBeVisible();
  await expect(page.getByTestId('eq-begin-main')).toContainText('Begin with Air');
  await expect(page.getByTestId('eq-begin-main')).toContainText('To come back toward even');
  await expect(page.getByTestId('eq-begin-draw')).toContainText('Draw on Fire');
  await expect(page.getByTestId('eq-trend-empty')).toBeVisible();
  await page.getByTestId('eq-meaning-toggle').click();
  await expect(page.getByTestId('eq-meaning')).toContainText('50 is even');
  await expect(page.getByTestId('eq-meaning-elements')).toContainText('→ 25, stretched');

  await page.getByTestId('eq-now').getByTestId('harmony-open').click();
  await page.getByTestId('harmony-save').click();
  await page.getByTestId('confirm-yes').click();
  await expect(page.getByTestId('reading-word')).toHaveText('In equilibrium');
  await goBack(page);
  await expect(page.getByTestId('eq-word')).toHaveText('In equilibrium');
  await expect(page.getByTestId('eq-trend-chart')).toBeVisible();
  await expect(page.getByTestId('eq-trend-chart-overall-change')).toContainText('±0');
  await expect(page.getByTestId('eq-trend-chart-air-change')).toContainText('+25');
  await page.getByTestId('eq-trend-chart-point-0').click();
  await expect(page.getByTestId('eq-trend-chart-readout')).toContainText('spread 50');
  await page.getByTestId('eq-trend-chart-toggle').click();
  await expect(page.getByTestId('eq-trend-chart-table')).toContainText('75');
  await expect(page.getByTestId('harmony-history').getByRole('button')).toHaveCount(2);
});

test('update · a new version shows a refresh banner that can wait', async ({ page }) => {
  await onboard(page);
  await expect(page.getByTestId('update-banner')).toHaveCount(0);
  await page.evaluate(() => {
    (window as any).__companionUpdateReady = true;
    window.dispatchEvent(new Event('companion-update-ready'));
  });
  await expect(page.getByTestId('update-banner')).toBeVisible();
  await expect(page.getByTestId('update-refresh')).toBeVisible();
  await page.getByTestId('update-later').click();
  await expect(page.getByTestId('update-banner')).toHaveCount(0);
});

test('home · under 18 shows reflection only: no rhythm card, no protocol filter', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Sam');
  await page.getByTestId('onboarding-age-under18').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-finish').click();
  await expect(page.getByTestId('screen-today')).toBeVisible();
  await expect(page.getByTestId('dash-rhythm')).toHaveCount(0);
  await expect(page.getByTestId('dash-note-today')).toHaveCount(0);
  await expect(page.getByTestId('dash-filter-protocol')).toHaveCount(0);
  await expect(page.getByTestId('dash-week-empty')).toBeVisible();
  await expect(page.getByTestId('dash-timeline-empty')).toContainText('Nothing recorded yet');
  await expect(page.getByTestId('harmony-card')).toBeVisible();
});
