-- Companion account storage (Supabase / Postgres).
-- One row per person holding their journey document. Row-level security means a signed-in
-- user can only ever read or write their own row. Never put the service-role key in the app.
--
-- STATUS: written for this build, not yet applied to a live project.

create table if not exists public.journeys (
  user_id uuid primary key references auth.users (id) on delete cascade,
  doc jsonb not null,
  revision integer not null default 1,
  updated_at timestamptz not null default now()
);

alter table public.journeys enable row level security;

create policy "journeys: owner can read"
  on public.journeys for select
  using (auth.uid() = user_id);

create policy "journeys: owner can insert"
  on public.journeys for insert
  with check (auth.uid() = user_id);

create policy "journeys: owner can update"
  on public.journeys for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "journeys: owner can delete"
  on public.journeys for delete
  using (auth.uid() = user_id);

-- Revision-checked save. Runs as the caller (security invoker), so RLS still applies.
-- expected_revision = null  → create; fails if a row already exists.
-- expected_revision = n     → update only if the stored revision is still n.
-- Returns the new revision, or raises 'revision_conflict' (HTTP 409 via PostgREST).
create or replace function public.save_journey(expected_revision integer, new_doc jsonb)
returns integer
language plpgsql
security invoker
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  new_rev integer;
begin
  if uid is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;

  if expected_revision is null then
    insert into public.journeys (user_id, doc, revision, updated_at)
    values (uid, new_doc, 1, now())
    on conflict (user_id) do nothing
    returning revision into new_rev;
  else
    update public.journeys
       set doc = new_doc, revision = revision + 1, updated_at = now()
     where user_id = uid and revision = expected_revision
    returning revision into new_rev;
  end if;

  if new_rev is null then
    raise exception 'revision_conflict' using errcode = '40001', hint = 'Fetch, merge and retry.';
  end if;
  return new_rev;
end;
$$;

grant execute on function public.save_journey(integer, jsonb) to authenticated;
