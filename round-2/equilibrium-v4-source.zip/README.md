# Equilibrium (formerly Companion) — v3 · Graphics & Interface (Claude build)

**v3** builds on v2 without rewriting it. Its focus is graphics and interface: an academy look with four element halls (Home, the check-in, the path map as academy grounds, and motion). It also carries the new names: the app is **Equilibrium** (formerly Companion) and the elemental reading is **Compass** (formerly Equilibrium, before that Harmony). See [HANDOFF-v3.md](./HANDOFF-v3.md).


A phone-first practice for becoming: notice where you are, choose what matters, practice a direction, and see what changes. One Expo / React Native codebase for iOS, Android and web.

**v2** builds on the September 30 alpha without rewriting it: paths of mastery, a game layer (path map, character sheet, inventory, goals as quests), a weekly look-back, journal search and Markdown export, and a Night theme. What changed, why, and what's still open: [HANDOFF-v2.md](./HANDOFF-v2.md). The alpha's own notes stay in [HANDOFF.md](./HANDOFF.md).

This is an independent interpretation of the *Companion — product, experience, and build brief* (September 29, 2026). The design reasoning, feature status and test results are in [HANDOFF.md](./HANDOFF.md).

## Run it

Requirements: Node 20+ (built with Node 22), npm.

```bash
npm install
npm run web            # Expo dev server in the browser
npm run ios            # Expo Go / simulator (macOS)
npm run android        # Expo Go / emulator
```

No account, key or backend is needed. Everything is saved on the device (AsyncStorage; localStorage on web).

The app is built in modules that can be tuned one at a time — see [MODULES.md](./MODULES.md).

### Build and test

```bash
npm run typecheck      # TypeScript, strict
npm run lint           # expo lint (eslint-config-expo, React Compiler rules)
npm test               # 57 unit tests: domain rules, merge, backup validation, sync engine, slider color/sound mapping
npm run build:web      # static web export → dist/
npm run serve:web      # serve dist/ on :8081
npm run e2e            # 58 Playwright tests (acceptance + PWA), phone 390×844 + desktop 1366×860
npm run build:native   # iOS + Android Hermes bundles → dist-native/ (proves native compile)
```

The account-UI test runs against an in-memory **demo** backend build, never shipped:

```bash
npm run build:web:demo && npx serve -s dist-demo -l 8082 &
E2E_DEMO_URL=http://localhost:8082 npx playwright test e2e/account-demo.spec.ts
```

> Changing `EXPO_PUBLIC_*` variables needs `--clear` (the build scripts pass it), or Metro serves a cached bundle with the old values.

## Install and offline

The web build is an installable web app: `public/manifest.webmanifest`, icons in `public/icons/` (regenerate with `npm run icons`), and `public/sw.js`, a small service worker that keeps the app shell available offline. Navigations are network-first, so a new version shows up on the next open. `scripts/postbuild-web.mjs` stamps each build's service worker with its id and precache list; the build scripts run it for you. Chromium reports no installability errors, and `e2e/pwa.spec.ts` checks the manifest, the service worker and an offline reload.

On iPhone: open the link in Safari → Share → Add to Home Screen. On Android/desktop Chrome: the Install button in You, or the browser menu. Installing also helps browsers keep the on-device journey (Safari may clear data for sites you haven't opened in a while).

## Publish on GitHub Pages (or any static host)

```bash
npm run build:pages     # → dist-pages/, works at any address
```

`dist-pages/` uses only relative paths, so the same files work at a site root, at `https://<user>.github.io/<repo>/`, or inside a folder of a repository. `_expo/` is renamed to `app/` (GitHub Pages' Jekyll step ignores folders that start with `_`), a `.nojekyll` marker is added, and the script fails the build if anything still points at the host root. To publish: upload the *contents* of `dist-pages/` to the top level of a public repository, then turn on **Settings → Pages → Deploy from a branch → main / (root)**.

**v2 next to the alpha.** Publish v2 to its own repository (for example `companion-v2`, served at `https://<user>.github.io/companion-v2/`), not inside the alpha's folder: the alpha's service worker controls everything under `/companion/`. Sharing the same `github.io` address is otherwise safe: v2 keeps its own storage (`companion.v2.*`) and caches (`companion2-*`), and offers to copy an alpha journey it finds in the same browser.

## Connecting accounts (Supabase)

Accounts and phone ⇄ web sync are written and tested against a fake backend, but **not connected**: no Supabase project existed for this build. To connect one:

1. Create a Supabase project. In **Auth → Providers → Email**, enable email sign-in and make the email template include the one-time code (`{{ .Token }}`), so people type a 6-digit code rather than follow a link.
2. Run [`supabase/schema.sql`](./supabase/schema.sql) in the SQL editor. It creates `public.journeys` (one row per person), row-level security limited to `auth.uid() = user_id`, and the revision-checked `save_journey` function.
3. Create `.env` next to `package.json`:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://<project>.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=<anon public key>
   ```
   Only the anon key goes in the app. It is public by design; RLS protects the rows. Never put the service-role key in the client.
4. Rebuild with `--clear`. The Account screen switches from "Accounts aren't connected in this build" to email-code sign-in.
5. Before calling it done, verify on two real devices (see HANDOFF.md → "What still needs a live backend").

## Layout

```
App.tsx                      providers: safe area → store → account → navigation → shell
src/domain/                  pure TypeScript, no React: types, ops, selectors, Harmony balance math,
                             Equilibrium, protocols, timeline, directions, gems, merge, backup
                             validation, intake
src/state/                   device storage, journey store, navigation, toast, motion
src/sync/                    RemoteStore contract, sync engine, Supabase + in-memory adapters, AccountProvider
src/platform/                haptics, backup file I/O, update notice, feeling sounds (web and native variants)
src/ui/                      tokens-driven components: controls, Equilibrium orb and trend, icons, sheets, layout
src/screens/                 Onboarding, Home (Today.tsx + HomeCards.tsx), Journey, AreaDetail, Connect,
                             Journal, You, Equilibrium, Harmony (take a reading), Protocol,
                             check-in history, data/account, Safety & Path, support, guide/
tests/                       vitest unit tests
e2e/                         Playwright acceptance tests
supabase/schema.sql          table, RLS policies, save_journey RPC
```

Navigation is state-driven rather than Expo Router, so one static bundle runs anywhere, including hosted previews whose URL path the app doesn't control. Deep links are listed as a next step.

## Data

One journey document per account cache: `companion.v1.journey.<guest | user:id>`. Every record has a stable id and ISO timestamps; deletes are tombstones. Gem transactions use ids derived from their source (`gem:checkin:<id>`, `gem:guide-complete`), so a replay, restore or sync can never award twice. Backups are `companion.backup` v1 JSON. Restore checks the whole file before anything changes, rebuilds records from known fields only, and keeps one undo. If saved data on the device can't be read, a copy is quarantined under `companion.v1.quarantine.*` and never overwritten.

Companion is for adults. It offers reflection and practice support, not medical advice, diagnosis, treatment or dosing guidance.
