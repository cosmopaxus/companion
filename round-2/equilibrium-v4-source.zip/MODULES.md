# Companion modules

> **Names (Oct 14, 2026):** the app is now **Equilibrium** (formerly Companion) and the elemental reading is **Compass** (formerly Equilibrium, before that Harmony). Sections below written before the rename keep the old names; code names are unchanged.

Companion is tuned one module at a time. Each entry lists where the module lives, the tests that guard it, and the knobs worth turning. Shared pieces (tokens, primitives, storage) sit at the bottom; changing those affects every module.

## 0. Home · *new Sept 30, replaces Today and the separate Dashboard*
- **What:** the screen the app opens on, and the first tab ("Home"). Phone order: first steps card, your rhythm (adults with a protocol), check-in, today so far, Equilibrium, the last 7 days and this week's counts, direction, practice what matters, timeline. At 1240px and wider: two columns (rhythm, check-in and practice on the left; Equilibrium, the week and the timeline on the right).
- **Files:** `src/screens/Today.tsx` (the Home screen; the tab id is still `today` so saved navigation keeps working), `src/screens/HomeCards.tsx` (`RhythmCard`, `WeekCard`, `CountsCard`, `TimelineCard`), `src/domain/timeline.ts` (`timeline`, `byDay`, `weekFeelings`, `weekCounts`).
- **Rules:** show only what was recorded; days without a check-in stay empty; counts, never scores; under 18 has no rhythm, day notes or protocol items.
- **Knobs:** card order in `Today.tsx`; which kinds appear in the feed and their wording; page size (40); the week chart's height (`BAR_AREA`).
- **Tests:** unit "Dashboard: timeline and the last seven days"; e2e "home ·".

## 1. Check-in (on Home) — feeling sliders · *revised Sept 29*
- **What:** three 0–100 sliders (mood, energy, connection), each with its own picture, color and sound, plus an optional note. Several per day; 2 gems each, whatever the reading.
- **Files:** `src/ui/feel/FeelSlider.tsx` (gesture, keyboard, accessibility), `src/ui/feel/FeelGlyph.tsx` (the three pictures), `src/ui/feel/palette.ts` (colors), `src/platform/feelSound.web.ts` + `feelSoundParams.ts` (sound), `src/ui/CheckInForm.tsx`, `src/screens/Today.tsx`, `src/screens/CheckInHistory.tsx`.
- **Data:** `CheckIn.mood/energy/connection` are whole numbers 0–100 with `scale: 100`. Older 1–5 check-ins convert when read (1→0, 3→50, 5→100) in `src/domain/backup.ts` (`readLevels`). Words come from `levelWord` in `src/domain/scales.ts` (five bands of 20).
- **Knobs:** color stops `FEEL_STOPS`; sound mapping per feeling in `feelSoundParams.ts`; overall volume `master.gain` in `feelSound.web.ts`; picture shapes in `FeelGlyph.tsx`; the support-notice threshold `HEAVY_MOOD_BELOW`.
- **Tests:** unit "Check-ins" and "Feeling sliders"; e2e 3, 10, "sliders · drag or tap…", "sliders · each feeling has its own sound…".
- **Open:** sound on native (web only today; native gives a haptic tick per word band); real-phone check of drag vs scroll; a "how this changed today" view.

## 1b. Protocols, rhythm and day notes · *Sept 30 (steps 2 and 3)*
- **What:** choose a common schedule or create your own rhythm of activation and integration days; start date; optional rest weeks; optional notes (level, what you take, amount, intention). On Home, the rhythm card shows today's day, tomorrow, the next activation and a 7-day strip; on integration days it offers a journal prompt ("What's shifting for me?"). **Note today** records taken / skipped / integration day, with what you took and your own amount (prefilled from the protocol, only kept when taken) and how it went. Adults only; support first after a crisis answer; no gems.
- **Files:** `src/domain/protocols.ts` (presets, calendar-day math `dayFor` / `upcoming` / `nextActivation`, `currentProtocol`, `START_LOW`), protocol and day-note ops in `src/domain/ops.ts` (`saveDayNote`, `deleteDayNote`; one note per day, id `day:YYYY-MM-DD`), `src/screens/Protocol.tsx`, `RhythmCard` + `NoteTodaySheet` in `src/screens/HomeCards.tsx`, `src/ui/RhythmStrip.tsx`, `src/ui/Stepper.tsx`.
- **Knobs:** the preset list and wording (`PROTOCOL_PRESETS`); the limits in `patternProblem`; the "start low, go slow" copy; the level descriptions; day-note labels (`DAY_NOTE_LABEL` in `timeline.ts`).
- **Tests:** unit "Protocols and rhythm", "Day notes"; e2e "protocol ·", "home · note today".
- **Next:** reminders (in-app first; phone notifications need the native app).

## 2. Equilibrium (formerly Harmony) · *revised Sept 30*
- **What:** a two-minute reading of pressure and resource (1–5 each) across Fire (will), Air (mind), Water (feeling) and Earth (form). Each element's balance is 0–100, 50 = even. The Equilibrium page explains what the numbers mean, names your state (In equilibrium · Evenly stretched · Nearly balanced · Some discord · In discord), gives the **overall** (plain average) and **spread** (highest − lowest), suggests where to begin (practices for the lowest element, and how to use a well-resourced one), and shows the trend across your last twelve readings.
- **Graphic:** `EquilibriumOrb` — a soft four-lobed bloom (Fire top, Air right, Water bottom, Earth left) whose lobes reach as far as each balance; a dashed gold ring marks even; faint outlines are earlier readings. It breathes slowly when in step and a little faster in discord, with a slowly turning dotted ring. Respects reduced motion.
- **Files:** `src/domain/equilibrium.ts` (`equilibriumOf`, `suggestions`, `PRACTICES`, `trend`, `trendChange`), `src/domain/harmony.ts` (balance math, unchanged), `src/ui/EquilibriumOrb.tsx`, `src/ui/EquilibriumTrend.tsx` (small multiples, tap/hover readout, table view), `src/screens/Equilibrium.tsx` (the page and the Home card), `src/screens/Harmony.tsx` (take a reading, and a reading's detail). Code names (`harmony`, `HarmonySnapshot`) stay so backups and sync keep working.
- **Knobs:** the state thresholds and sentences in `equilibriumOf`; `PRACTICES` per element and need; orb shape (`radiusFor`) and breathing (`breathFor`); trend length (12).
- **Tests:** unit "Harmony math", "Equilibrium"; e2e 5, 9, "equilibrium ·".
- **Open:** moving pressure and resource to sliders is a formula decision, so it's its own step.

## 3. Journey · *v2: opens on the Path*
- **What:** a Path | Areas switch. Path (default) is the teacher's note, the path map, character sheet and inventory cards, and open quests. Areas is the alpha's Journey unchanged. Other screens can ask for a view with `nav.requestFocus('journey:areas' | 'journey:path')`.
- **Files:** `src/screens/Journey.tsx`, `AreaDetail.tsx`, `AreaEditor.tsx`, `src/domain/selectors.ts` (ranking), `src/ui/EvidenceMarks.tsx`.
- **Tests:** unit "Journey areas and evidence"; e2e 4, 7, "path ·".

## 3b. Paths of mastery · *v2*
- **What:** four paths: Foundation (open from the start), Acolyte (offered when ready, or opened early by a sincere seeker), Initiate and Adept (outlines; they can't be opened until their lessons are written). Lessons are measured from real activity: check-in days, areas and evidence, goals, a journal entry with a set prompt, or "I practiced today" (once per lesson per day). The teacher's note offers the next path when the pupil is ready, rests for a week after "Not yet", and otherwise points to the next lesson.
- **Files:** `src/domain/paths.ts` (tiers, lesson text, progress, readiness, teacher), path and goal ops in `src/domain/ops.ts` (`openTier`, `deferInvitation`, `logPractice`, `unlogPractice`, `addGoal`, `reachGoal`, `releaseGoal`, `reopenGoal`, `recordMilestones`), `src/screens/path/` (`PathView`, `PathMap`, `LessonScreen`, `TierScreen`, `GoalSheet`).
- **Knobs:** `READINESS` (14 of 21 days, 2 goals), `INVITE_REST_DAYS` (7), `PRACTICES_PER_LEVEL` (5), and every lesson's text, measure and icon in `LESSONS`. Lesson text for Foundation and Acolyte is a draft for review.
- **Rules:** dosing (protocols, day notes) never counts as practice. A goal counts toward a path only from its first reach (its gem's time), so reopening can't recount it.
- **Tests:** unit "v2 · lesson progress", "v2 · readiness, invitations and opening paths"; e2e "path ·", "lesson ·".

## 3c. Character sheet and inventory · *v2*
- **What:** rank, what you've built (days practiced, longest rhythm, goals reached, lessons mastered, wins, reflections), practice by element (a level per five practices), goals reached and badges. Nothing reads how a check-in felt; Equilibrium stays on its own page.
- **Only builds:** lessons mastered and badges earned are recorded the first time (`paths.mastered`, `paths.badges`, by `recordMilestones`, run from `AppShell` after each change); element levels and goals reached come from gem records, which are never removed. Removing a practice or reopening a goal takes nothing back.
- **Files:** `src/domain/character.ts`, `src/screens/path/CharacterScreens.tsx`, `src/ui/game.tsx`.
- **Tests:** unit "v2 · character sheet and inventory", "v2 · nothing is taken back"; e2e "goal ·".

## 4. Journal · *v2: search and export*
- **Files:** `src/screens/Journal.tsx`, prompts in `src/domain/scales.ts`, search and Markdown in `src/domain/journalExport.ts`. A journal prompt can be passed in with `nav.requestFocus('journal:<prompt>')` (the prompt may contain colons).
- **Tests:** e2e 6, 6b, "journal ·"; unit "v2 · journal search and export".

## 4b. Weekly look-back · *v2*
- **What:** the seven days ending today (page back to the journey's start): days shown up, wins, observations and setbacks quoted in your words, goals reached and set, path practice, and counts. No scores, no feelings averaged.
- **Files:** `src/domain/lookback.ts`, `src/screens/LookBack.tsx`. Opened from Home → This week, and from the "Look back" lesson.
- **Tests:** unit "v2 · weekly look-back"; e2e "look-back ·".

## 5. First steps (guide)
- **Files:** `src/screens/guide/Guide.tsx`, `lessons.ts`. **Tests:** e2e 2.

## 6. Connect
- **Files:** `src/screens/Connect.tsx`. **Status:** honest preview; no live social features.

## 7. You, data and account
- **Files:** `src/screens/You.tsx`, `YouScreens.tsx`, `DataAccount.tsx`, `src/domain/backup.ts`, `src/sync/*`, `supabase/schema.sql`. **Tests:** unit backup + sync; e2e 8, 8b, 9, recovery, storage blocked.

## 8. Onboarding, age and Safety & Path · *revised Sept 29 (step 1 of 3)*
- **What:** name → age range → Space (adults) → directions → optional Safety & Path (adults). Under 18 is reflection mode.
- **Files:** `src/screens/Onboarding.tsx`, `src/domain/age.ts` (brackets, `isAdult`, reflection-mode note), `src/domain/intake.ts` (questions, levels, `INTAKE_VERSION`), `src/ui/IntakeQuestions.tsx` (shared form), `IntakeScreen`/`ProfileScreen` in `src/screens/YouScreens.tsx`.
- **Rules:** under 18 → no Safety & Path, no Be Well Space, no əvōke templates, no Fireside, no sign-in, no protocols, day notes or rhythm. Every adult-only surface checks `isAdult(journey)`.
- **Knobs:** the bracket list; question wording and levels (bump `INTAKE_VERSION` when they change so people review); the experience options.
- **Tests:** unit "Age ranges and reflection mode", "Safety & Path intake"; e2e "age ·", "intake ·", "safety ·".

## 9. Academy look · *v3 · Graphics & Interface, phases 1–3*
- **What:** three layers on a fixed frame. Section → wing (material, heading font, texture); tier → building (Courtyard, Library, Tower, Sanctum); element → hall (gradient, accent, props). Phase 1 puts Home and the check-in in the Academy wing; phase 2 turns the path map into academy grounds (one region per tier, lit when open); phase 3 adds motion (hall ambience, the you-are-here pulse, gem pop, celebrations), all off under reduced motion.
- **Files:** `src/theme/academy.ts` (halls, buildings, wings, `heroStops`, `duskStops`, `resolveHall`, contrast), `src/ui/academy/hall.tsx` (`useHall`, `WingProvider`, `wingFont`), `src/ui/academy/HallArt.tsx` (`HallScene`, `DuskScene`, `WingTexture`), `src/ui/academy/HallHero.tsx` (`HallHero`, `HallBand`), hall choice in `src/screens/You.tsx`.
- **Rules:** text on a hall gradient only behind the text block (dark zone) or on a dusk band; lore names always with a plain label; original symbols only; the frame never changes between themes.
- **Knobs:** the four gradients (`HALLS`), `HERO_ART`, `HERO_HOLD`, `HERO_RAMP_UNDER_TEXT`, `DUSK_REACH`, `DEFAULT_HALL`, building and prop drawings in `HallArt.tsx`, `WINGS` (card lip and radius, heading font).
- **Today's look (Oct 14 art treatment):** Cinzel + Nunito, indigo controls, glass cards; `Screen glass` gives Home, Compass, Journal and lessons the window-into-glass header (`src/ui/academy/Glass.tsx`: `GlassBackdrop`, `TitleHalo`, `HallChip`, `BackChip`; knobs `GLASS`, `HALO_CORE`, `HALO_SCALE`, `HALO_PLATEAU`, `CHIP_SHADE` in `academy.ts`). Fonts: `public/fonts` (web), `assets/fonts` + the `expo-font` plugin in `app.json` (phones).
- **Tests:** unit "v3 ·"; e2e "hall ·", "glass ·".

## Shared
- **Day and Night (v2):** `src/theme/palettes.ts` holds both palettes (pure data, contrast-tested in `tests/v2.test.ts`); `src/theme/tokens.ts` picks one at startup from the device choice (`companion.v2.theme` in browser storage: day, night or system). `src/platform/theme(.web).ts` saves a change and reloads. Phones follow the phone's own setting for now. `public/index.html` paints the right page color before the app loads.
- **Design system:** `src/theme/tokens.ts`, `src/ui/primitives.tsx`, `src/ui/controls.tsx`, `src/ui/layout.tsx`, `src/ui/Icon.tsx`.
- **App shell and navigation:** `App.tsx`, `src/AppShell.tsx`, `src/state/nav.tsx`, `src/state/store.tsx`.
- **Web app and publishing:** `public/` (manifest, service worker, page template), `scripts/` (postbuild, Pages packaging, icons).
- **Update notice:** `public/index.html` checks for a new version every 30 minutes and when the app comes back to the screen; when a new service worker takes over, `src/platform/updates.web.ts` shows a "new version ready" banner (Refresh / Later) in `AppShell`.
