import { describe, expect, it } from 'vitest';
import * as ops from '../src/domain/ops';
import { emptyMeta, syncOnce, SyncMeta } from '../src/sync/engine';
import { MemoryRemote, MemoryServer } from '../src/sync/memoryRemote';
import { gemBalance, journalFor, checkinsFor } from '../src/domain/selectors';
import { LESSON_IDS, type Journey } from '../src/domain/types';

const T0 = new Date('2026-09-29T16:00:00.000Z');
const at = (min: number) => new Date(T0.getTime() + min * 60000);

interface Device {
  remote: MemoryRemote;
  journey: Journey;
  meta: SyncMeta;
}

async function device(server: MemoryServer, email: string, journey: Journey = ops.emptyJourney(T0)): Promise<Device> {
  const remote = new MemoryRemote(server);
  const v = await remote.verifyCode(email, server.code);
  expect(v.ok).toBe(true);
  return { remote, journey, meta: emptyMeta() };
}

async function sync(d: Device) {
  const r = await syncOnce(d.journey, d.meta, d.remote, () => at(100));
  if (r.status === 'synced') {
    d.journey = r.journey;
    d.meta = r.meta;
  }
  return r.status;
}

const onboarded = (name = 'A') => ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_a'), { name, ageBracket: '25-34', spaceId: 'personal', directions: [] }, T0);

describe('Account sync (in-memory backend)', () => {
  it('the same account restores its journey on a second device', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', ops.addCheckIn(onboarded(), { mood: 3, energy: 3, connection: 3 }, at(1), 'c1'));
    expect(await sync(phone)).toBe('synced');
    const web = await device(server, 'a@example.com');
    expect(await sync(web)).toBe('synced');
    expect(web.journey.profile?.name).toBe('A');
    expect(checkinsFor(web.journey, 'personal').map((c) => c.id)).toEqual(['c1']);
  });

  it('entries created on both devices are all kept, and gems are never duplicated', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', onboarded());
    await sync(phone);
    const web = await device(server, 'a@example.com');
    await sync(web);
    phone.journey = ops.addCheckIn(phone.journey, { mood: 2, energy: 2, connection: 2 }, at(5), 'phone-c');
    web.journey = ops.addJournal(web.journey, 'from the laptop', undefined, at(6), 'web-j');
    await sync(phone);
    await sync(web);
    await sync(phone);
    for (const d of [phone, web]) {
      expect(checkinsFor(d.journey, 'personal').map((c) => c.id)).toEqual(['phone-c']);
      expect(journalFor(d.journey, 'personal').map((c) => c.id)).toEqual(['web-j']);
      expect(gemBalance(d.journey, 'personal')).toBe(3);
    }
  });

  it('offline edits stay local and sync after reconnecting', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', onboarded());
    await sync(phone);
    phone.remote.offline = true;
    phone.journey = ops.addJournal(phone.journey, 'written on a plane', undefined, at(10), 'plane');
    expect(await sync(phone)).toBe('offline');
    expect(journalFor(phone.journey, 'personal')).toHaveLength(1); // untouched locally
    expect(server.docs.get('u_1')!.journey.journal).toHaveLength(0);
    phone.remote.offline = false;
    expect(await sync(phone)).toBe('synced');
    expect(server.docs.get('u_1')!.journey.journal.map((j) => j.id)).toEqual(['plane']);
  });

  it('a concurrent write between fetch and write is detected, merged and retried', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', onboarded());
    await sync(phone);
    const web = await device(server, 'a@example.com');
    await sync(web);
    web.journey = ops.addJournal(web.journey, 'web entry', undefined, at(20), 'w1');
    phone.journey = ops.addJournal(phone.journey, 'phone entry', undefined, at(21), 'p1');
    // The web device lands its write in the gap between the phone's fetch and write.
    phone.remote.beforeWrite = async () => {
      await sync(web);
    };
    expect(await sync(phone)).toBe('synced');
    const ids = server.docs.get('u_1')!.journey.journal.map((j) => j.id).sort();
    expect(ids).toEqual(['p1', 'w1']);
    await sync(web);
    expect(journalFor(web.journey, 'personal').map((j) => j.id).sort()).toEqual(['p1', 'w1']);
  });

  it('concurrent edits of the same entry resolve to the later edit; deletes are not resurrected', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', ops.addJournal(onboarded(), 'v1', undefined, at(1), 'j1'));
    await sync(phone);
    const web = await device(server, 'a@example.com');
    await sync(web);
    phone.journey = ops.editJournal(phone.journey, 'j1', 'phone edit', at(30));
    web.journey = ops.editJournal(web.journey, 'j1', 'web edit (later)', at(31));
    await sync(phone);
    await sync(web);
    await sync(phone);
    expect(journalFor(phone.journey, 'personal')[0].text).toBe('web edit (later)');
    phone.journey = ops.deleteJournal(phone.journey, 'j1', at(40));
    await sync(phone);
    await sync(web);
    expect(journalFor(web.journey, 'personal')).toHaveLength(0);
  });

  it('first-steps gift is granted once even if both devices finish the guide', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', onboarded());
    await sync(phone);
    const web = await device(server, 'a@example.com');
    await sync(web);
    for (const l of LESSON_IDS) phone.journey = ops.completeLesson(phone.journey, l, at(50)).journey;
    for (const l of LESSON_IDS) web.journey = ops.completeLesson(web.journey, l, at(51)).journey;
    await sync(phone);
    await sync(web);
    await sync(phone);
    expect(phone.journey.gems.filter((g) => g.reason === 'guide-complete')).toHaveLength(1);
    expect(gemBalance(web.journey, 'personal')).toBe(5);
  });

  it("a second account sees none of the first account's data", async () => {
    const server = new MemoryServer();
    const a = await device(server, 'a@example.com', ops.addJournal(onboarded('A'), 'private to A', undefined, at(1)));
    await sync(a);
    const b = await device(server, 'b@example.com');
    const fetched = await b.remote.fetch();
    expect(fetched.ok && fetched.doc).toBeNull();
    await sync(b);
    expect(b.journey.profile).toBeNull();
    expect(b.journey.journal).toHaveLength(0);
    expect(server.docs.get('u_1')!.journey.journal).toHaveLength(1);
  });

  it('does nothing when neither side changed', async () => {
    const server = new MemoryServer();
    const phone = await device(server, 'a@example.com', onboarded());
    await sync(phone);
    const writes = server.writes;
    await sync(phone);
    await sync(phone);
    expect(server.writes).toBe(writes);
  });
});
