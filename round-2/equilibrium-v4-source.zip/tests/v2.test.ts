import { describe, expect, it } from 'vitest';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
import { localDayKey } from '../src/domain/time';
import { addDays } from '../src/domain/protocols';
import {
  bestWindow,
  currentLessonId,
  currentTier,
  daysInWindow,
  elementPractice,
  isMastered,
  lessonProgress,
  lessonsFor,
  LESSON_BY_ID,
  LESSONS,
  longestRun,
  practiceDays,
  readiness,
  READINESS,
  teacherNote,
  tierState,
} from '../src/domain/paths';
import { badges, characterStats, inventory } from '../src/domain/character';
import { lookBack, LOOKBACK_PROMPT } from '../src/domain/lookback';
import { journalMarkdown, searchJournal } from '../src/domain/journalExport';
import { checkBackup, checkBackupText, makeBackup } from '../src/domain/backup';
import { mergeJourneys, mergePaths } from '../src/domain/merge';
import { timeline } from '../src/domain/timeline';
import { GEM_AMOUNTS, GEM_REASON_LABEL } from '../src/domain/gems';
import { gemBalance } from '../src/domain/selectors';
import { palettes, elementWashes } from '../src/theme/palettes';

// Well in the past, so no test date is ever 'in the future' for the restore checks.
const T0 = new Date('2026-06-01T16:00:00.000Z');
const day = (n: number, minutes = 0) => new Date(T0.getTime() + n * 86400000 + minutes * 60000);
const dk = (n: number) => localDayKey(day(n));

function onboarded(): Journey {
  return ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_v2'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, T0);
}

const checkin = (j: Journey, n: number, m = 0) => ops.addCheckIn(j, { mood: 10, energy: 10, connection: 10 }, day(n, m), `chk_${n}_${m}`);
const lesson = (id: string) => LESSON_BY_ID[id];

/** A journey that has walked every Foundation lesson and practiced on days 0–15. */
function foundationWalked(): Journey {
  let j = onboarded();
  for (let n = 0; n < 16; n++) j = checkin(j, n);
  j = ops.addArea(j, { name: 'Sleep', impact: 4, difficulty: 2 }, day(1), 'area_1');
  for (let i = 0; i < 3; i++) j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: `Win ${i}` }, day(2, i), `ev_${i}`);
  j = ops.addGoal(j, { title: 'Walk daily', element: 'earth' }, day(3), 'goal_1');
  j = ops.addGoal(j, { title: 'Call home', element: 'water' }, day(3, 5), 'goal_2');
  j = ops.reachGoal(j, 'goal_1', 'Shoes by the door', day(6));
  j = ops.reachGoal(j, 'goal_2', undefined, day(9));
  j = ops.addJournal(j, 'Strong: patient. Change: phone at night.', lesson('f-honest-inventory').measure.type === 'journal' ? (lesson('f-honest-inventory').measure as any).prompt : '', day(4), 'jnl_inv');
  j = ops.addJournal(j, 'More steady than I thought.', LOOKBACK_PROMPT, day(10), 'jnl_lb');
  return j;
}

describe('v2 · empty journey and gem rules', () => {
  it('starts with no goals, no practice, and only Foundation open', () => {
    const j = onboarded();
    expect(j.goals).toEqual([]);
    expect(j.practiceLogs).toEqual([]);
    expect(j.paths.opened).toEqual({});
    expect(currentTier(j)).toBe('foundation');
    expect(tierState(j, 'foundation', dk(0))).toBe('open');
    expect(tierState(j, 'acolyte', dk(0))).toBe('seekable');
    expect(tierState(j, 'initiate', dk(0))).toBe('preparing');
  });
  it('labels the new gem reasons', () => {
    expect(GEM_AMOUNTS.practice).toBe(1);
    expect(GEM_AMOUNTS.goal).toBe(3);
    expect(GEM_REASON_LABEL.practice).toBeTruthy();
    expect(GEM_REASON_LABEL.goal).toBeTruthy();
  });
});

describe('v2 · goals', () => {
  it('validates, edits, and earns the goal gem exactly once', () => {
    let j = onboarded();
    expect(() => ops.addGoal(j, { title: '   ' })).toThrow(/Name your goal/);
    j = ops.addGoal(j, { title: 'Finish the zine', why: 'For me', element: 'fire' }, day(0), 'g1');
    j = ops.updateGoal(j, 'g1', { title: 'Finish the zine draft', element: 'fire' }, day(1));
    expect(j.goals[0].title).toBe('Finish the zine draft');
    j = ops.reachGoal(j, 'g1', 'Two hours a night', day(2));
    expect(j.goals[0]).toMatchObject({ status: 'reached', reflection: 'Two hours a night' });
    expect(gemBalance(j, 'personal')).toBe(3);
    j = ops.reopenGoal(j, 'g1', day(3));
    j = ops.reachGoal(j, 'g1', undefined, day(4));
    expect(gemBalance(j, 'personal')).toBe(3);
  });
  it('letting a goal go costs nothing, and deleting keeps the gem it earned', () => {
    let j = onboarded();
    j = ops.addGoal(j, { title: 'A' }, day(0), 'gA');
    j = ops.releaseGoal(j, 'gA', day(1));
    expect(j.goals[0].status).toBe('released');
    expect(gemBalance(j, 'personal')).toBe(0);
    j = ops.addGoal(j, { title: 'B' }, day(0), 'gB');
    j = ops.reachGoal(j, 'gB', undefined, day(1));
    j = ops.deleteGoal(j, 'gB', day(2));
    expect(j.goals.find((g) => g.id === 'gB')?.deletedAt).toBeTruthy();
    expect(gemBalance(j, 'personal')).toBe(3);
    expect(() => ops.reachGoal(j, 'gB')).toThrow(/no longer exists/);
  });
});

describe('v2 · path practice', () => {
  it('logs once per lesson per day, earns one gem per day, and only on open paths', () => {
    let j = onboarded();
    expect(() => ops.logPractice(j, 'a-watch-mind', dk(0), undefined, day(0))).toThrow(/Open the acolyte path/);
    expect(() => ops.logPractice(j, 'f-show-up', dk(0), undefined, day(0))).toThrow(/practiced another way/);
    j = ops.openTier(j, 'acolyte', 'seeker', 'I want to know my own mind.', dk(0), day(0));
    j = ops.logPractice(j, 'a-watch-mind', dk(0), 'busy', day(0));
    j = ops.logPractice(j, 'a-watch-mind', dk(0), 'quieter later', day(0, 30));
    expect(j.practiceLogs.filter((p) => !p.deletedAt)).toHaveLength(1);
    expect(j.practiceLogs[0].note).toBe('quieter later');
    expect(gemBalance(j, 'personal')).toBe(1);
    for (let n = 1; n < 5; n++) j = ops.logPractice(j, 'a-watch-mind', dk(n), undefined, day(n));
    expect(isMastered(j, lesson('a-watch-mind'))).toBe(true);
    j = ops.unlogPractice(j, 'a-watch-mind', dk(4), day(5));
    expect(lessonProgress(j, lesson('a-watch-mind'))).toMatchObject({ count: 4, mastered: false });
    expect(gemBalance(j, 'personal')).toBe(5);
  });
});

describe('v2 · lesson progress', () => {
  it('measures each Foundation lesson from what was actually done', () => {
    let j = onboarded();
    const p = (id: string) => lessonProgress(j, lesson(id));
    expect(p('f-show-up')).toMatchObject({ count: 0, target: 5, mastered: false });
    j = checkin(j, 0);
    j = checkin(j, 0, 60);
    expect(p('f-show-up').count).toBe(1);
    for (let n = 1; n < 5; n++) j = checkin(j, n);
    expect(p('f-show-up').mastered).toBe(true);
    j = ops.addArea(j, { name: 'Patience', impact: 3, difficulty: 3 }, day(1), 'ar');
    expect(p('f-name-what-matters')).toMatchObject({ count: 1, target: 4 });
    expect(p('f-first-goal').mastered).toBe(false);
    j = ops.addGoal(j, { title: 'G' }, day(1), 'g');
    expect(p('f-first-goal').mastered).toBe(true);
    expect(p('f-honest-inventory').mastered).toBe(false);
    j = ops.addJournal(j, 'text', (lesson('f-honest-inventory').measure as any).prompt, day(2), 'jn');
    expect(p('f-honest-inventory').mastered).toBe(true);
    expect(p('f-keep-rhythm')).toMatchObject({ count: 5, target: 7, mastered: false });
    expect(currentLessonId(j)).toBe('f-name-what-matters');
  });
  it('counts practice days from every kind of practice, never from dosing', () => {
    let j = onboarded();
    j = ops.startProtocol(j, { presetId: 'fadiman', name: 'One on, two off', pattern: { type: 'cycle', on: 1, off: 2 }, startDate: dk(0) }, day(0));
    j = ops.saveDayNote(j, { day: dk(0), status: 'taken', substance: 'x', amount: 'y' }, day(0));
    expect(practiceDays(j).size).toBe(0);
    j = ops.addJournal(j, 'hello', undefined, day(1), 'j1');
    j = ops.addGoal(j, { title: 'G' }, day(2), 'g1');
    expect(Array.from(practiceDays(j)).sort()).toEqual([dk(1), dk(2)]);
  });
  it('finds the best window, the window ending today, and the longest run', () => {
    const days = new Set([dk(0), dk(1), dk(2), dk(5), dk(6), dk(7), dk(8), dk(9), dk(20)]);
    expect(bestWindow(days, 10)).toBe(8);
    expect(daysInWindow(days, dk(9), 7)).toBe(5);
    expect(longestRun(days)).toBe(5);
    expect(longestRun(new Set())).toBe(0);
  });
});

describe('v2 · readiness, invitations and opening paths', () => {
  it('offers the next path only when lessons, days and goals are all there', () => {
    const j = foundationWalked();
    const today = dk(15);
    for (const l of lessonsFor('foundation')) expect([l.id, isMastered(j, l)]).toEqual([l.id, true]);
    const r = readiness(j, 'foundation', today);
    expect(r.days.count).toBeGreaterThanOrEqual(READINESS.days);
    expect(r.goals.count).toBe(2);
    expect(r.ready).toBe(true);
    expect(tierState(j, 'acolyte', today)).toBe('invited');
    const note = teacherNote(j, today);
    expect(note.kind).toBe('invite');
    // Thirty days later, without practice, the days are no longer steady: no invitation.
    expect(readiness(j, 'foundation', addDays(today, 30)).ready).toBe(false);
    expect(teacherNote(j, addDays(today, 30)).kind).toBe('consistency');
  });
  it('is not ready with one goal reached, even with lessons and days in place', () => {
    let j = foundationWalked();
    j = ops.reopenGoal(j, 'goal_2', day(11));
    expect(readiness(j, 'foundation', dk(15))).toMatchObject({ ready: false, goals: { count: 1, ok: false } });
    expect(() => ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15))).toThrow(/hasn’t been offered/);
  });
  it('opens when invited, records how, and moves the teacher on to the first Acolyte lesson', () => {
    let j = foundationWalked();
    j = ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15));
    expect(j.paths.opened.acolyte?.how).toBe('invited');
    expect(currentTier(j)).toBe('acolyte');
    const note = teacherNote(j, dk(15));
    expect(note.kind === 'lesson' && note.lesson.id).toBe('a-watch-mind');
  });
  it('lets a sincere seeker open the next path early, one path at a time', () => {
    let j = onboarded();
    expect(() => ops.openTier(j, 'acolyte', 'seeker', 'hm', dk(0), day(0))).toThrow(/what draws you/);
    expect(() => ops.openTier(j, 'initiate', 'seeker', 'I am ready for this now.', dk(0), day(0))).toThrow(/still being prepared/);
    j = ops.openTier(j, 'acolyte', 'seeker', 'I want to know my own mind.', dk(0), day(0));
    expect(j.paths.opened.acolyte).toMatchObject({ how: 'seeker', note: 'I want to know my own mind.' });
    // The teacher still points to the first unmastered lesson, Foundation first.
    expect(currentLessonId(j)).toBe('f-show-up');
  });
  it('lets an invitation rest after "Not yet", still ready to begin', () => {
    let j = foundationWalked();
    j = ops.deferInvitation(j, 'acolyte', day(15));
    expect(teacherNote(j, dk(15)).kind).toBe('resting');
    // The path stays openable while the invitation rests.
    expect(tierState(j, 'acolyte', dk(15))).toBe('invited');
    j = ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15));
    expect(currentTier(j)).toBe('acolyte');
  });
  it('keeps outline paths closed until their lessons exist', () => {
    let j = onboarded();
    j = ops.openTier(j, 'acolyte', 'seeker', 'Drawn to the mirror work.', dk(0), day(0));
    expect(tierState(j, 'initiate', dk(0))).toBe('preparing');
    expect(() => ops.openTier(j, 'initiate', 'seeker', 'Drawn to balancing the elements.', dk(0), day(0))).toThrow(/still being prepared/);
    expect(lessonsFor('initiate').every((l) => lessonProgress(j, l).label === 'In preparation')).toBe(true);
    expect(() => ops.logPractice(j, 'i-transform', dk(0), undefined, day(0))).toThrow();
  });
  it('says the next path is being prepared once every open lesson is walked', () => {
    let j = foundationWalked();
    j = ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15));
    for (const l of lessonsFor('acolyte')) {
      if (l.measure.type === 'logged') for (let n = 0; n < l.measure.days; n++) j = ops.logPractice(j, l.id, dk(16 + n), undefined, day(16 + n));
      if (l.measure.type === 'journal') j = ops.addJournal(j, 'Fire: will. Air: curious.', l.measure.prompt, day(17), `jnl_${l.id}`);
    }
    const note = teacherNote(j, dk(24));
    expect(note).toMatchObject({ kind: 'preparing', tier: 'initiate', after: 'acolyte' });
  });
  it('refuses practice dated in the future', () => {
    const j = ops.openTier(onboarded(), 'acolyte', 'seeker', 'Drawn to the work.', dk(0), day(0));
    expect(() => ops.logPractice(j, 'a-watch-mind', dk(1), undefined, day(0))).toThrow(/today or earlier/);
  });
  it('counts a goal toward a path only from its first reach, so reopening can’t recount it', () => {
    let j = onboarded();
    j = ops.addGoal(j, { title: 'Early' }, day(0), 'early');
    j = ops.reachGoal(j, 'early', undefined, day(1));
    j = ops.openTier(j, 'acolyte', 'seeker', 'Opening the next path now.', dk(2), day(2));
    j = ops.reopenGoal(j, 'early', day(3));
    j = ops.reachGoal(j, 'early', undefined, day(4));
    expect(readiness(j, 'acolyte', dk(4)).goals.count).toBe(0);
    expect(readiness(j, 'foundation', dk(4)).goals.count).toBe(1);
  });
});

describe('v2 · character sheet and inventory', () => {
  it('only counts what was done: stats ignore how a check-in felt', () => {
    let low = onboarded();
    let high = onboarded();
    for (let n = 0; n < 3; n++) {
      low = ops.addCheckIn(low, { mood: 0, energy: 0, connection: 0 }, day(n), `c${n}`);
      high = ops.addCheckIn(high, { mood: 100, energy: 100, connection: 100 }, day(n), `c${n}`);
    }
    expect(characterStats(low)).toEqual(characterStats(high));
    expect(characterStats(low)).toMatchObject({ daysPracticed: 3, longestRun: 3, rank: 'Seeker' });
  });
  it('levels elements from practices and goals reached with that element', () => {
    let j = ops.openTier(onboarded(), 'acolyte', 'seeker', 'Drawn to the work.', dk(0), day(0));
    for (let n = 0; n < 6; n++) j = ops.logPractice(j, 'a-kept-word', dk(n), undefined, day(n));
    j = ops.addGoal(j, { title: 'Run', element: 'fire' }, day(1), 'gf');
    j = ops.reachGoal(j, 'gf', undefined, day(2));
    const ep = elementPractice(j);
    expect(ep.fire).toMatchObject({ count: 7, level: 2, intoLevel: 2, perLevel: 5 });
    expect(ep.air).toMatchObject({ count: 0, level: 1 });
    expect(badges(j).find((b) => b.id === 'kindled')?.earned).toBe(true);
    expect(badges(j).find((b) => b.id === 'clear-sky')?.earned).toBe(false);
  });
  it('keeps goals reached and badges earned in the inventory, newest first', () => {
    const j = foundationWalked();
    const inv = inventory(j);
    expect(inv.filter((i) => i.kind === 'goal').map((i) => i.name).sort()).toEqual(['Call home', 'Walk daily']);
    const earned = badges(j).filter((b) => b.earned).map((b) => b.id);
    expect(earned).toEqual(expect.arrayContaining(['first-light', 'witness', 'first-win', 'quest-begun', 'quest-complete', 'steady', 'unbroken', 'lesson-mastered', 'foundation-laid']));
    expect(earned).not.toContain('three-quests');
    const dated = inv.filter((i) => i.at).map((i) => i.at!);
    expect(dated).toEqual([...dated].sort().reverse());
    // Items without a known date (e.g. "Steady") come after dated ones.
    expect(inv.findIndex((i) => !i.at)).toBeGreaterThan(inv.findIndex((i) => !!i.at));
    expect(characterStats(j)).toMatchObject({ goalsReached: 2, lessonsMastered: 7, wins: 3, reflections: 2 });
  });
});

describe('v2 · nothing is taken back', () => {
  it('keeps element levels when a practice is removed (they come from gems, which stay)', () => {
    let j = ops.openTier(onboarded(), 'acolyte', 'seeker', 'Drawn to the work.', dk(0), day(0));
    for (let n = 0; n < 5; n++) j = ops.logPractice(j, 'a-kept-word', dk(n), undefined, day(n));
    expect(elementPractice(j).fire.level).toBe(2);
    j = ops.unlogPractice(j, 'a-kept-word', dk(4), day(5));
    expect(elementPractice(j).fire).toMatchObject({ count: 5, level: 2 });
  });
  it('keeps a lesson mastered and badges earned once recorded, even if records are later removed', () => {
    let j = ops.openTier(onboarded(), 'acolyte', 'seeker', 'Drawn to the work.', dk(0), day(0));
    j = checkin(j, 0);
    for (let n = 0; n < 5; n++) j = ops.logPractice(j, 'a-watch-mind', dk(n), undefined, day(n));
    j = ops.recordMilestones(j, day(5));
    expect(j.paths.mastered['a-watch-mind']).toBeTruthy();
    expect(j.paths.badges['first-light']).toBe(day(0).toISOString());
    expect(ops.recordMilestones(j, day(6))).toBe(j);
    j = ops.unlogPractice(j, 'a-watch-mind', dk(4), day(6));
    j = ops.deleteCheckIn(j, 'chk_0_0', day(6));
    expect(isMastered(j, lesson('a-watch-mind'))).toBe(true);
    expect(lessonProgress(j, lesson('a-watch-mind')).label).toBe('Mastered');
    expect(badges(j).find((b) => b.id === 'first-light')).toMatchObject({ earned: true, earnedAt: day(0).toISOString() });
    expect(characterStats(j).lessonsMastered).toBe(1);
  });
  it('keeps a reached goal in the inventory after it is reopened, marked as reopened', () => {
    let j = onboarded();
    j = ops.addGoal(j, { title: 'Finish the zine', element: 'fire' }, day(0), 'g');
    j = ops.reachGoal(j, 'g', 'Late nights', day(1));
    j = ops.reopenGoal(j, 'g', day(2));
    const item = inventory(j).find((i) => i.id === 'g');
    expect(item).toMatchObject({ kind: 'goal', reopened: true, at: day(1).toISOString() });
    expect(characterStats(j).goalsReached).toBe(1);
    expect(elementPractice(j).fire.count).toBe(1);
    j = ops.deleteGoal(j, 'g', day(3));
    expect(inventory(j).some((i) => i.id === 'g')).toBe(false);
  });
});

describe('v2 · backups, merge and timeline', () => {
  it('round-trips goals, practice and opened paths', () => {
    let j = foundationWalked();
    j = ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15));
    j = ops.logPractice(j, 'a-watch-mind', dk(15), 'quiet', day(15));
    j = ops.deferInvitation(j, 'initiate', day(15));
    const r = checkBackupText(JSON.stringify(makeBackup(j)));
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.journey.goals).toEqual(j.goals);
    expect(r.journey.practiceLogs).toEqual(j.practiceLogs);
    expect(r.journey.paths).toEqual(j.paths);
  });
  it('restores a first-build backup with empty goals, practice and paths', () => {
    const j = foundationWalked() as any;
    const v1 = { ...j };
    delete v1.goals;
    delete v1.practiceLogs;
    delete v1.paths;
    v1.gems = v1.gems.filter((g: any) => g.reason !== 'goal');
    const r = checkBackup({ format: 'companion.backup', version: 1, exportedAt: T0.toISOString(), app: 'companion-alpha', journey: v1 });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.journey.goals).toEqual([]);
    expect(r.journey.practiceLogs).toEqual([]);
    expect(r.journey.paths.opened).toEqual({});
  });
  it('rejects unknown lessons and mismatched practice ids in a strict restore', () => {
    const j = onboarded() as any;
    const bad = { ...j, practiceLogs: [{ id: 'prc:nope:2026-10-01', lessonId: 'nope', day: '2026-10-01', spaceId: 'personal', createdAt: T0.toISOString(), updatedAt: T0.toISOString() }] };
    expect(checkBackup(bad).ok).toBe(false);
    const bad2 = { ...j, practiceLogs: [{ id: 'prc:a-watch-mind:2026-10-02', lessonId: 'a-watch-mind', day: '2026-10-01', spaceId: 'personal', createdAt: T0.toISOString() }] };
    expect(checkBackup(bad2).ok).toBe(false);
    const bad3 = { ...j, goals: [{ id: 'g', title: 'x', status: 'won', createdAt: T0.toISOString() }] };
    expect(checkBackup(bad3).ok).toBe(false);
  });
  it('rejects practice for closed paths, non-logged lessons, future days, and paths opened out of order', () => {
    const base = onboarded() as any;
    const t = T0.toISOString();
    const log = (lessonId: string, d: string) => ({ id: `prc:${lessonId}:${d}`, lessonId, day: d, spaceId: 'personal', createdAt: t, updatedAt: t });
    expect(checkBackup({ ...base, practiceLogs: [log('a-watch-mind', dk(0))] }).ok).toBe(false);
    expect(checkBackup({ ...base, practiceLogs: [log('f-show-up', dk(0))] }).ok).toBe(false);
    const open = { ...base, paths: { ...base.paths, opened: { acolyte: { at: t, how: 'seeker' } } } };
    expect(checkBackup({ ...open, practiceLogs: [log('a-watch-mind', dk(0))] }).ok).toBe(true);
    expect(checkBackup({ ...open, practiceLogs: [log('a-watch-mind', '2099-01-01')] }).ok).toBe(false);
    expect(checkBackup({ ...base, paths: { ...base.paths, opened: { adept: { at: t, how: 'seeker' } } } }).ok).toBe(false);
  });
  it('writes schema version 2, reads version 1, and keeps milestones through a backup', () => {
    let j = onboarded();
    j = checkin(j, 0);
    j = ops.recordMilestones(j, day(1));
    expect(j.schemaVersion).toBe(2);
    const r = checkBackupText(JSON.stringify(makeBackup(j)));
    expect(r.ok && r.journey.paths.badges['first-light']).toBe(day(0).toISOString());
    const v1 = { ...(j as any), schemaVersion: 1 };
    const r1 = checkBackup(v1);
    expect(r1.ok && r1.journey.schemaVersion).toBe(2);
    expect(checkBackup({ ...(j as any), schemaVersion: 3 }).ok).toBe(false);
  });
  it('merges goals and practice by id; an opened path stays open, earliest kept', () => {
    let a = onboarded();
    let b = onboarded();
    a = ops.addGoal(a, { title: 'From phone' }, day(1), 'ga');
    b = ops.addGoal(b, { title: 'From laptop' }, day(1), 'gb');
    a = ops.openTier(a, 'acolyte', 'seeker', 'Opened on the phone first.', dk(2), day(2));
    b = ops.openTier(b, 'acolyte', 'seeker', 'Opened on the laptop later.', dk(3), day(3));
    a = ops.logPractice(a, 'a-watch-mind', dk(2), undefined, day(2));
    b = ops.logPractice(b, 'a-watch-mind', dk(3), undefined, day(3));
    const m = mergeJourneys(a, b);
    expect(m.goals.map((g) => g.id).sort()).toEqual(['ga', 'gb']);
    expect(m.practiceLogs).toHaveLength(2);
    expect(m.paths.opened.acolyte?.note).toBe('Opened on the phone first.');
    expect(mergePaths(undefined, b.paths).opened.acolyte?.at).toBe(b.paths.opened.acolyte?.at);
    // Gems for both practices, never duplicated.
    expect(m.gems.filter((g) => g.reason === 'practice')).toHaveLength(2);
  });
  it('shows goals, practice and opened paths in the timeline', () => {
    let j = foundationWalked();
    j = ops.openTier(j, 'acolyte', 'invited', undefined, dk(15), day(15));
    j = ops.logPractice(j, 'a-watch-mind', dk(15), 'quiet', day(15, 10));
    const path = timeline(j, 'personal').filter((i) => i.kind === 'path');
    const titles = path.map((i) => i.title);
    expect(titles).toEqual(expect.arrayContaining(['Goal set', 'Goal reached', 'Practiced · Watching the mind', 'Acolyte path opened']));
    expect(path[0].title).toBe('Practiced · Watching the mind');
  });
});

describe('v2 · weekly look-back', () => {
  it('quotes the week’s evidence and counts days, with nothing scored', () => {
    const j = foundationWalked();
    const lb = lookBack(j, 'personal', dk(6));
    expect(lb.from).toBe(dk(0));
    expect(lb.daysShownUp).toBe(7);
    expect(lb.wins.map((w) => w.text)).toEqual(['Win 0', 'Win 1', 'Win 2']);
    expect(lb.wins[0].areaName).toBe('Sleep');
    expect(lb.goalsReached.map((g) => g.title)).toEqual(['Walk daily']);
    expect(lb.goalsSet).toHaveLength(2);
    expect(lb.checkins).toBe(7);
    expect(JSON.stringify(lb)).not.toMatch(/"mood"|"energy"|"connection"/);
    const empty = lookBack(j, 'personal', dk(60));
    expect(empty.empty).toBe(true);
  });
  it('keeps Space-scoped counts to the Space', () => {
    let j = ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_s'), { name: 'S', ageBracket: '25-34', spaceId: 'bewell', directions: [] }, T0);
    j = checkin(j, 0);
    expect(lookBack(j, 'personal', dk(0)).checkins).toBe(0);
    expect(lookBack(j, 'bewell', dk(0)).checkins).toBe(1);
  });
});

describe('v2 · journal search and export', () => {
  const entries = (() => {
    let j = onboarded();
    j = ops.addJournal(j, 'Café by the river. Felt calm.', 'A small thing that went well', day(0), 'a');
    j = ops.addJournal(j, 'Argued about the rent.', undefined, day(1), 'b');
    j = ops.addJournal(j, 'River walk again, calm and slow.', undefined, day(2), 'c');
    return j.journal;
  })();
  it('matches every word, ignoring case and accents, in text and prompt', () => {
    expect(searchJournal(entries, 'cafe').map((e) => e.id)).toEqual(['a']);
    expect(searchJournal(entries, 'RIVER calm').map((e) => e.id)).toEqual(['a', 'c']);
    expect(searchJournal(entries, 'went well').map((e) => e.id)).toEqual(['a']);
    expect(searchJournal(entries, '   ')).toHaveLength(3);
    expect(searchJournal(entries, 'river rent')).toHaveLength(0);
  });
  it('exports Markdown oldest first, grouped by day, text kept as written', () => {
    const md = journalMarkdown([...entries].reverse(), { name: 'Cosmo', now: day(3) });
    expect(md.startsWith('# Journal · Cosmo\n')).toBe(true);
    expect(md).toContain('3 entries.');
    expect(md.indexOf('Café by the river')).toBeLessThan(md.indexOf('Argued about the rent'));
    expect(md).toContain('*A small thing that went well*');
    expect(md).toMatch(/### \d{1,2}:\d{2} (am|pm) · Personal/);
    expect((md.match(/^## /gm) ?? []).length).toBe(3);
  });
});

describe('v2 · Day and Night palettes', () => {
  const lum = (h: string) => {
    const n = parseInt(h.slice(1), 16);
    const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => {
      const x = v / 255;
      return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  };
  const ratio = (a: string, b: string) => {
    const x = lum(a);
    const y = lum(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  };
  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: text, buttons and controls meet contrast minimums`, () => {
      const c = palettes[mode];
      const text: [string, string][] = [
        [c.ink, c.canvas], [c.ink, c.paper], [c.inkSoft, c.paper], [c.inkSoft, c.canvas], [c.inkSoft, c.sageWash], [c.inkSoft, c.goldWash],
        [c.sage, c.paper], [c.sage, c.sageWash], [c.onSage, c.sage], [c.gold, c.paper], [c.gold, c.goldWash], [c.paperStrong, c.gold],
        [c.caution, c.cautionWash], [c.caution, c.paper], [c.fireText, c.paper], [c.air, c.paper], [c.water, c.paper], [c.earth, c.paper], [c.onSage, c.ink],
      ];
      for (const [fg, bg] of text) expect([fg, bg, ratio(fg, bg) >= 4.5]).toEqual([fg, bg, true]);
      expect(ratio(c.controlBorder, c.paper)).toBeGreaterThanOrEqual(3);
      const w = elementWashes[mode];
      for (const [fg, bg] of [[c.fireText, w.fire], [c.airText, w.air], [c.water, w.water], [c.earthText, w.earth]]) expect([fg, bg, ratio(fg, bg) >= 4.5]).toEqual([fg, bg, true]);
    });
  }
});

describe('v2 · lesson content', () => {
  it('has unique ids, complete Foundation and Acolyte lessons, and outlines beyond', () => {
    expect(new Set(LESSONS.map((l) => l.id)).size).toBe(LESSONS.length);
    for (const t of ['foundation', 'acolyte'] as const) {
      for (const l of lessonsFor(t)) {
        expect(l.measure.type).not.toBe('outline');
        expect(l.why.length).toBeGreaterThan(40);
        expect(l.how.length).toBeGreaterThan(0);
      }
    }
    for (const t of ['initiate', 'adept'] as const) expect(lessonsFor(t).every((l) => l.measure.type === 'outline')).toBe(true);
    // One logged Acolyte practice trains each element.
    const els = lessonsFor('acolyte').filter((l) => l.measure.type === 'logged' && l.element).map((l) => l.element).sort();
    expect(els).toEqual(['air', 'earth', 'fire', 'water']);
  });
});
