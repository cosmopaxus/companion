import { describe, expect, it } from 'vitest';
import { contrast, HALL_IDS, HALO_CORE, mix } from '../src/theme/academy';
import { palettes } from '../src/theme/palettes';
import { ART_STATS } from '../src/theme/artStats';
import {
  ART_MAX_W,
  artGeometry,
  CHIP_GLASS,
  FADE,
  FADE_STRIPS,
  fadeStripOpacity,
  FROST_READ,
  HALL_PAINTING,
  HOME_PAINTING,
  PAGE_TEXT,
  PaintingId,
  PAINTINGS,
  READING_FLOOR,
  readingFromV,
  readingWash,
  blurExtremes,
  washAt,
  pageWashAt,
  TITLE_VEIL_LEAD,
  WINDOW,
  HALL_INK,
  HALL_TINT,
  coverRect,
  GROUNDS_SPOTS,
  ORB_ALPHA,
  PANEL_ALPHA,
  HEADER_SHADE,
} from '../src/theme/paintings';
import { FEEL_CARD_TINT, FEEL_STOPS, FEEL_TEXT, mix as feelMix } from '../src/ui/feel/palette';

// The painted academy (Oct 14 art treatment, "window into glass"). Contrast is checked against the
// lightest and darkest pixel of each real painting (scripts/make-art.py), so it holds anywhere the
// crop, the slow zoom or the screen width puts them.

const GLASS_PAINTINGS: PaintingId[] = [HOME_PAINTING, ...HALL_IDS.map((h) => HALL_PAINTING[h])];
const WIDTHS = [320, 360, 390, 430, 600, 768, 1024, 1440, 1920];

describe('painted academy · art and crop', () => {
  it('has a painting for Home and each hall, with stats from the real files', () => {
    for (const id of GLASS_PAINTINGS) {
      expect(ART_STATS[id]).toBeDefined();
      expect(PAINTINGS[id].alt.length).toBeGreaterThan(10);
    }
  });

  it('matches the mockups on a 390 px phone (hall paintings 390 × 695, shifted up as drawn)', () => {
    const fire = artGeometry(390, 'hall-fire-the-forge', 'hall');
    expect(fire.sharp.width).toBe(390);
    expect(Math.round(fire.sharp.height)).toBe(695);
    expect(Math.round(fire.sharp.top)).toBe(-247);
    expect(Math.round(artGeometry(390, 'hall-water-the-moon-pool', 'hall').sharp.top)).toBe(-40);
  });

  for (const w of WIDTHS) {
    it(`${w}px: the clear painting fills its window, and the frosted copy covers the page behind it`, () => {
      for (const id of GLASS_PAINTINGS) {
        for (const kind of ['home', 'hall'] as const) {
          const g = artGeometry(w, id, kind);
          expect(g.box.width).toBe(Math.min(w, ART_MAX_W));
          // No gap anywhere in the window.
          expect(g.sharp.left).toBeLessThanOrEqual(g.box.left + 0.01);
          expect(g.sharp.left + g.sharp.width).toBeGreaterThanOrEqual(g.box.left + g.box.width - 0.01);
          expect(g.sharp.top).toBeLessThanOrEqual(0);
          expect(g.sharp.top + g.sharp.height).toBeGreaterThanOrEqual(g.box.height);
          // The frosted twin plus its mirrored copies cover the page's width.
          expect(g.blur.left - g.blur.width).toBeLessThanOrEqual(0.01);
          expect(g.blur.left + 2 * g.blur.width).toBeGreaterThanOrEqual(w - 0.01);
          expect(g.blur.top + g.blur.height).toBeGreaterThanOrEqual(WINDOW[kind].clear + FROST_READ);
        }
      }
    });
  }

  it('melts in small steps, ending fully frosted at the bottom of the window', () => {
    expect(FADE).toBe(130);
    for (let i = 1; i < FADE_STRIPS; i++) expect(fadeStripOpacity(i) - fadeStripOpacity(i - 1)).toBeLessThanOrEqual(0.08);
    expect(fadeStripOpacity(FADE_STRIPS - 1)).toBe(1);
  });

  it('the title starts after the frost begins, with room for its veil to fade in', () => {
    for (const k of ['home', 'hall'] as const) expect(WINDOW[k].titleTop - WINDOW[k].clear).toBeGreaterThanOrEqual(TITLE_VEIL_LEAD);
  });
});

describe('painted academy · text over the art passes 4.5:1', () => {
  for (const mode of ['day', 'night'] as const) {
    const c = palettes[mode];
    const texts = PAGE_TEXT.map((k) => c[k]);

    it(`${mode}: chips (hall name, back, gems) keep their text readable over the lightest and darkest pixel of every painting`, () => {
      for (const id of GLASS_PAINTINGS) {
        for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark]) {
          const bg = mix(px, CHIP_GLASS.rgb, CHIP_GLASS.alpha);
          expect([id, px, contrast(CHIP_GLASS.text, bg) >= 4.5]).toEqual([id, px, true]);
        }
      }
    });

    it(`${mode}: the title halo keeps the eyebrow, heading and subtitle readable over any pixel`, () => {
      for (const id of GLASS_PAINTINGS) {
        for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark, ART_STATS[id].blurLight, ART_STATS[id].blurDark]) {
          const bg = mix(px, c.canvas, HALO_CORE);
          for (const fg of [c.ink, c.inkSoft, c.goldPressed]) expect([id, px, fg, contrast(fg, bg) >= 4.5]).toEqual([id, px, fg, true]);
        }
      }
    });

    it(`${mode}: text on the frosted page passes in every hall, at every width (reading wash at least ${READING_FLOOR * 100}%)`, () => {
      for (const id of GLASS_PAINTINGS) {
        for (const kind of ['home', 'hall'] as const) {
          for (const w of WIDTHS) {
            const g = artGeometry(w, id, kind);
            const a = readingWash(id, c.canvas, texts, readingFromV(g, kind));
            expect(a).toBeGreaterThanOrEqual(READING_FLOOR);
            expect(a).toBeLessThan(1);
            expect(washAt(FROST_READ, a)).toBeCloseTo(a, 5);
            // Below the painting the page is the wash color itself; everywhere above, check every band.
            for (const px of blurExtremes(id, readingFromV(g, kind))) {
              const bg = mix(px, c.canvas, a);
              for (const fg of texts) expect([id, mode, w, px, fg, contrast(fg, bg) >= 4.5]).toEqual([id, mode, w, px, fg, true]);
            }
          }
        }
      }
    });
  }

  for (const mode of ['day', 'night'] as const) {
    it(`${mode}: the title's veil keeps the title block readable from its top down to the reading wash`, () => {
      const c = palettes[mode];
      const texts = PAGE_TEXT.map((k) => c[k]);
      for (const id of GLASS_PAINTINGS) {
        for (const kind of ['home', 'hall'] as const) {
          const reading = readingWash(id, c.canvas, texts, readingFromV(artGeometry(390, id, kind), kind));
          // Where any of the clear painting still shows (above FADE), the veil is at full strength…
          for (let y = WINDOW[kind].titleTop - WINDOW[kind].clear; y <= FADE; y++) expect(pageWashAt(y, reading, kind, HALO_CORE)).toBeGreaterThanOrEqual(HALO_CORE - 1e-9);
          // …and below it, over the frosted copy alone, never less than the reading wash or the veil.
          for (let y = FADE; y <= FROST_READ; y++) expect(pageWashAt(y, reading, kind, HALO_CORE)).toBeGreaterThanOrEqual(Math.min(HALO_CORE, reading) - 1e-9);
          for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark]) {
            const bg = mix(px, c.canvas, HALO_CORE);
            for (const fg of [c.ink, c.inkSoft, c.goldPressed]) expect([id, kind, px, fg, contrast(fg, bg) >= 4.5]).toEqual([id, kind, px, fg, true]);
          }
        }
      }
    });
  }

  it('the wash rises steadily: none where the frost begins, 60% by 110 px, the reading wash by 200 px', () => {
    expect(washAt(0, 0.85)).toBe(0);
    expect(washAt(110, 0.85)).toBeCloseTo(0.6, 5);
    expect(washAt(200, 0.85)).toBeCloseTo(0.85, 5);
    for (let y = 1; y < 260; y++) expect(washAt(y, 0.85)).toBeGreaterThanOrEqual(washAt(y - 1, 0.85));
  });
});

describe('painted academy · piece 2 colors', () => {
  for (const mode of ['day', 'night'] as const) {
    const c = palettes[mode];
    it(`${mode}: each hall's ink passes on cards, on its own tint, and as the eyebrow on the title veil`, () => {
      for (const h of HALL_IDS) {
        const ink = HALL_INK[h][mode];
        const card = mode === 'day' ? mix(c.canvas, '#FFFCF5', 0.92) : c.paper;
        const backs = [c.paper, c.paperStrong, card, HALL_TINT[h][mode]];
        // On the page, hall ink is only used for the eyebrow, which sits at the title's top, on its veil.
        for (const id of GLASS_PAINTINGS) for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark]) backs.push(mix(px, c.canvas, HALO_CORE));
        for (const b of backs) expect([h, mode, b, contrast(ink, b) >= 4.5]).toEqual([h, mode, b, true]);
      }
    });
    it(`${mode}: each feeling's value text passes on the slider card`, () => {
      for (const d of ['mood', 'energy', 'connection'] as const) {
        const tinted = FEEL_STOPS[d].map((stop) => feelMix(c.paperStrong, stop, FEEL_CARD_TINT));
        for (const b of [c.paper, c.paperStrong, ...tinted]) expect([d, mode, b, contrast(FEEL_TEXT[d][mode], b) >= 4.5]).toEqual([d, mode, b, true]);
        // Labels and soft text on the tinted card too.
        for (const b of tinted) for (const fg of [c.ink, c.inkSoft]) expect([d, mode, b, fg, contrast(fg, b) >= 4.5]).toEqual([d, mode, b, fg, true]);
      }
    });
  }
});

describe('painted academy · piece 3: full-art screens', () => {
  const FULL: PaintingId[] = ['healing-sanctuary', 'hall-of-ascension', 'path-map-academy-grounds'];
  for (const mode of ['day', 'night'] as const) {
    const c = palettes[mode];
    it(`${mode}: the bottom panel keeps all its text readable over any pixel of the painting`, () => {
      for (const id of FULL) {
        for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark]) {
          const bg = mix(px, c.canvas, PANEL_ALPHA);
          for (const fg of PAGE_TEXT.map((k) => c[k])) expect([id, mode, px, fg, contrast(fg, bg) >= 4.5]).toEqual([id, mode, px, fg, true]);
        }
      }
    });
  }
  it('the breath orb keeps its words readable over the Sanctuary (Day; at Night it uses the same cream glass)', () => {
    const s = ART_STATS['healing-sanctuary'];
    for (const px of [s.sharpLight, s.sharpDark]) expect(contrast(palettes.day.sage, mix(px, '#FBF7EE', ORB_ALPHA))).toBeGreaterThanOrEqual(4.5);
  });
  it('chips and map pills on full art keep their text readable (white, cream and gold)', () => {
    for (const id of FULL)
      for (const px of [ART_STATS[id].sharpLight, ART_STATS[id].sharpDark]) {
        expect(contrast(CHIP_GLASS.text, mix(px, CHIP_GLASS.rgb, CHIP_GLASS.alpha))).toBeGreaterThanOrEqual(4.5);
        // The path map's pills are darker (86%) and also carry gold words.
        for (const fg of ['#FFFFFF', '#F3D88E', '#FBE7BE']) expect(contrast(fg, mix(px, CHIP_GLASS.rgb, 0.86))).toBeGreaterThanOrEqual(4.5);
      }
  });
  it('the painting always covers the screen, at any size', () => {
    for (const id of FULL) {
      for (const [w, h] of [[320, 568], [390, 844], [430, 932], [768, 1024], [1440, 900], [1920, 1080]]) {
        const r = coverRect(w, h, id);
        expect(r.left).toBeLessThanOrEqual(0.01);
        expect(r.top).toBeLessThanOrEqual(0.01);
        expect(r.left + r.width).toBeGreaterThanOrEqual(w - 0.01);
        expect(r.top + r.height).toBeGreaterThanOrEqual(h - 0.01);
      }
    }
  });
  it('the grounds have a platform for each of a path’s seven lessons, climbing from the gate', () => {
    expect(GROUNDS_SPOTS.lessons).toHaveLength(7);
    for (let i = 1; i < 7; i++) expect(GROUNDS_SPOTS.lessons[i][1]).toBeLessThan(GROUNDS_SPOTS.lessons[i - 1][1]);
    for (const [u, v] of [...GROUNDS_SPOTS.lessons, GROUNDS_SPOTS.next, GROUNDS_SPOTS.ascension, GROUNDS_SPOTS.sanctuary]) {
      // Away from the outer 8% of the painting (phones crop differently).
      expect(u).toBeGreaterThan(0.08);
      expect(u).toBeLessThan(0.92);
      expect(v).toBeGreaterThan(0.08);
      expect(v).toBeLessThan(0.92);
    }
  });
});

describe('painted academy · full-screen path map header', () => {
  it('keeps its title, progress and legend readable over the grounds painting', () => {
    const st = ART_STATS['path-map-academy-grounds'];
    for (const px of [st.sharpLight, st.sharpDark]) {
      // The text sits in the top 62% of the shade, where it is at least `mid` strong.
      const bg = mix(px, HEADER_SHADE.rgb, HEADER_SHADE.mid);
      for (const fg of ['#FFFFFF', '#F3D88E', '#F3E9FF']) expect([px, fg, contrast(fg, bg) >= 4.5]).toEqual([px, fg, true]);
      // The legend sits on its own dark pill (78%).
      expect(contrast('#FFFFFF', mix(px, CHIP_GLASS.rgb, 0.78))).toBeGreaterThanOrEqual(4.5);
    }
  });
});
