import { describe, expect, it } from 'vitest';
import * as ops from '../src/domain/ops';
import { balance, balances, bandFor, defaultRatings, summarize } from '../src/domain/harmony';
import { areaStats, checkinsFor, gemBalance, rankAreas, rankedAreas, todaysCheckins, journalFor, guideProgress } from '../src/domain/selectors';
import { computeDirection } from '../src/domain/directions';
import { mergeJourneys } from '../src/domain/merge';
import { checkBackup, checkBackupText, makeBackup } from '../src/domain/backup';
import { LESSON_IDS, type Journey } from '../src/domain/types';
import { levelFromRating, levelWord } from '../src/domain/scales';
import { isAdult } from '../src/domain/age';
import { byDay, timeline, weekCounts, weekFeelings } from '../src/domain/timeline';
import { localDayKey } from '../src/domain/time';
import { addDays, currentProtocol, dayFor, daysBetween, describePattern, nextActivation, pastProtocols, patternProblem, PROTOCOL_PRESETS, upcoming } from '../src/domain/protocols';
import { evaluateIntake, intakeSummary, INTAKE_VERSION } from '../src/domain/intake';
import { equilibriumOf, PRACTICES, suggestions, trend, trendChange } from '../src/domain/equilibrium';
import { feelColor, mix } from '../src/ui/feel/palette';
import { connectionParams, energyParams, moodParams } from '../src/platform/feelSoundParams';

const T0 = new Date('2026-09-29T16:00:00.000Z');
const at = (min: number) => new Date(T0.getTime() + min * 60000);

function onboarded(space: 'personal' | 'bewell' = 'personal'): Journey {
  return ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_test'), { name: 'Test Person', ageBracket: '25-34', spaceId: space, directions: ['center'] }, T0);
}

describe('Harmony math (preserves existing semantics)', () => {
  it('midpoint ratings display 50', () => {
    expect(balance({ pressure: 3, resource: 3 })).toBe(50);
    expect(Object.values(balances(defaultRatings()))).toEqual([50, 50, 50, 50]);
  });
  it('resource 5 with pressure 3 displays 75', () => {
    expect(balance({ pressure: 3, resource: 5 })).toBe(75);
  });
  it('covers the full range and bands', () => {
    expect(balance({ pressure: 5, resource: 1 })).toBe(0);
    expect(balance({ pressure: 1, resource: 5 })).toBe(100);
    expect(balance({ pressure: 4, resource: 3 })).toBe(38);
    expect(bandFor(0)).toBe('strained');
    expect(bandFor(38)).toBe('stretched');
    expect(bandFor(50)).toBe('even');
    expect(bandFor(75)).toBe('supported');
    expect(bandFor(88)).toBe('resourced');
  });
  it('summarizes most resourced and most stretched', () => {
    const r = defaultRatings();
    r.fire = { pressure: 3, resource: 5 };
    r.air = { pressure: 5, resource: 2 };
    const s = summarize(r);
    expect(s.mostResourced?.id).toBe('fire');
    expect(s.mostStretched?.id).toBe('air');
    expect(summarize(defaultRatings()).allEven).toBe(true);
  });
  it('saving a snapshot awards 2 gems in the active Space and copies ratings', () => {
    const r = defaultRatings();
    const j = ops.addHarmony(onboarded(), r, 'note', at(1), 'hrm_1');
    r.fire.resource = 5; // mutate after save — snapshot must not change
    expect(j.harmony[0].ratings.fire.resource).toBe(3);
    expect(gemBalance(j, 'personal')).toBe(2);
  });
});

describe('Check-ins', () => {
  it('saves multiple check-ins per day, 2 gems each, same for low and high ratings', () => {
    let j = onboarded();
    j = ops.addCheckIn(j, { mood: 0, energy: 3, connection: 12 }, at(1), 'c1');
    j = ops.addCheckIn(j, { mood: 100, energy: 97, connection: 88, note: '  fine  ' }, at(2), 'c2');
    expect(todaysCheckins(j, 'personal', at(3))).toHaveLength(2);
    expect(j.checkins[1].note).toBe('fine');
    expect(gemBalance(j, 'personal')).toBe(4);
  });
  it('stores whole-number readings from 0 to 100, marked scale 100', () => {
    const j = ops.addCheckIn(onboarded(), { mood: 0, energy: 50, connection: 100 }, at(1), 'c1');
    expect(j.checkins[0]).toMatchObject({ mood: 0, energy: 50, connection: 100, scale: 100 });
  });
  it('rejects out-of-range or fractional readings', () => {
    expect(() => ops.addCheckIn(onboarded(), { mood: -1, energy: 3, connection: 3 }, at(1))).toThrow();
    expect(() => ops.addCheckIn(onboarded(), { mood: 101, energy: 3, connection: 3 }, at(1))).toThrow();
    expect(() => ops.addCheckIn(onboarded(), { mood: 33.5, energy: 3, connection: 3 }, at(1))).toThrow();
    expect(() => ops.addCheckIn(onboarded(), { mood: NaN, energy: 3, connection: 3 }, at(1))).toThrow();
  });
  it('names each reading with the familiar five words', () => {
    expect([0, 19, 20, 39, 40, 59, 60, 79, 80, 100].map((v) => levelWord('mood', v))).toEqual(['Heavy', 'Heavy', 'Low', 'Low', 'Okay', 'Okay', 'Good', 'Good', 'Bright', 'Bright']);
    expect(levelWord('energy', 5)).toBe('Depleted');
    expect(levelWord('energy', 95)).toBe('Charged');
    expect(levelWord('connection', 10)).toBe('Isolated');
    expect(levelWord('connection', 90)).toBe('Connected');
  });
  it('converts check-ins saved on the old 1–5 scale when they are read (device, backup or sync)', () => {
    const j = ops.addCheckIn(onboarded(), { mood: 50, energy: 50, connection: 50 }, at(1), 'new');
    const raw = JSON.parse(JSON.stringify(makeBackup(j)));
    const old = { ...raw.journey.checkins[0], id: 'old', mood: 1, energy: 3, connection: 5 };
    delete old.scale;
    raw.journey.checkins.push(old);
    const r = checkBackup(raw);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.journey.checkins.find((c) => c.id === 'old')).toMatchObject({ mood: 0, energy: 50, connection: 100, scale: 100 });
      expect(r.journey.checkins.find((c) => c.id === 'new')).toMatchObject({ mood: 50, energy: 50, connection: 50, scale: 100 });
    }
    // Without the marker, a value above 5 can't be told apart from a bad old record, so it's refused.
    const bad = JSON.parse(JSON.stringify(raw));
    bad.journey.checkins[1] = { ...old, mood: 72 };
    expect(checkBackup(bad).ok).toBe(false);
    expect(levelFromRating(2)).toBe(25);
  });
});

describe('Journey areas and evidence', () => {
  it('ranks impact high→low, then difficulty low→high, stable by age', () => {
    const mk = (id: string, impact: any, difficulty: any, min: number) => ({ id, name: id, impact, difficulty, createdAt: at(min).toISOString(), updatedAt: at(min).toISOString() });
    const ranked = rankAreas([mk('a', 3, 1, 0), mk('b', 5, 4, 1), mk('c', 5, 2, 2), mk('d', 5, 2, 3), mk('e', 1, 1, 4)]);
    expect(ranked.map((a) => a.id)).toEqual(['c', 'd', 'b', 'a', 'e']);
  });
  it('records win, observation and setback; only wins count as wins; each earns 1 gem', () => {
    let j = ops.addArea(onboarded(), { name: 'A steadier sleep rhythm', impact: 5, difficulty: 2, direction: 'center' }, at(1), 'area1');
    j = ops.addEvidence(j, { areaId: 'area1', kind: 'win', text: 'Lights out by 11' }, at(2), 'e1');
    j = ops.addEvidence(j, { areaId: 'area1', kind: 'observation', text: 'Coffee after 2 hurts' }, at(3), 'e2');
    j = ops.addEvidence(j, { areaId: 'area1', kind: 'setback', text: 'Up till 1am' }, at(4), 'e3');
    const s = areaStats(j, 'area1');
    expect(s).toMatchObject({ wins: 1, observations: 1, setbacks: 1, total: 3 });
    expect(s.last?.id).toBe('e3');
    expect(gemBalance(j, 'personal')).toBe(3);
  });
  it('rejects empty evidence and evidence for a deleted area', () => {
    let j = ops.addArea(onboarded(), { name: 'x', impact: 3, difficulty: 3 }, at(1), 'a1');
    expect(() => ops.addEvidence(j, { areaId: 'a1', kind: 'win', text: '   ' }, at(2))).toThrow();
    j = ops.deleteArea(j, 'a1', at(3));
    expect(rankedAreas(j)).toHaveLength(0);
    expect(() => ops.addEvidence(j, { areaId: 'a1', kind: 'win', text: 'hi' }, at(4))).toThrow();
  });
  it('areas are account-wide while evidence gems follow the active Space', () => {
    let j = ops.addArea(onboarded(), { name: 'x', impact: 3, difficulty: 3 }, at(1), 'a1');
    j = ops.setActiveSpace(j, 'bewell', at(2));
    expect(rankedAreas(j)).toHaveLength(1);
    j = ops.addEvidence(j, { areaId: 'a1', kind: 'win', text: 'did it' }, at(3), 'e1');
    expect(gemBalance(j, 'bewell')).toBe(1);
    expect(gemBalance(j, 'personal')).toBe(0);
  });
});

describe('Journal', () => {
  it('saves once with 1 gem, trims, and refuses empty text', () => {
    let j = ops.addJournal(onboarded(), '  Noticed the light today.  ', 'What I want to remember', at(1), 'j1');
    expect(journalFor(j, 'personal')[0].text).toBe('Noticed the light today.');
    expect(gemBalance(j, 'personal')).toBe(1);
    expect(() => ops.addJournal(j, '   \n  ', undefined, at(2))).toThrow();
    j = ops.editJournal(j, 'j1', 'Edited', at(3));
    expect(journalFor(j, 'personal')[0].text).toBe('Edited');
    j = ops.deleteJournal(j, 'j1', at(4));
    expect(journalFor(j, 'personal')).toHaveLength(0);
    expect(j.journal[0].text).toBe(''); // tombstone drops the private text
    expect(gemBalance(j, 'personal')).toBe(1); // recognition of participation stays
  });
});

describe('Spaces', () => {
  it('scopes check-ins, journal, harmony and gems to the active Space', () => {
    let j = onboarded();
    j = ops.addCheckIn(j, { mood: 3, energy: 3, connection: 3 }, at(1), 'p1');
    j = ops.addJournal(j, 'personal entry', undefined, at(2), 'pj');
    j = ops.setActiveSpace(j, 'bewell', at(3));
    j = ops.addCheckIn(j, { mood: 4, energy: 4, connection: 4 }, at(4), 'b1');
    expect(checkinsFor(j, 'personal').map((c) => c.id)).toEqual(['p1']);
    expect(checkinsFor(j, 'bewell').map((c) => c.id)).toEqual(['b1']);
    expect(journalFor(j, 'bewell')).toHaveLength(0);
    expect(gemBalance(j, 'personal')).toBe(3);
    expect(gemBalance(j, 'bewell')).toBe(2);
  });
});

describe('Guided first steps', () => {
  it('rewards 5 gems to Personal once, even when completed in Be Well, and never on replay', () => {
    let j = onboarded('bewell');
    let rewardedCount = 0;
    for (const l of LESSON_IDS) {
      const r = ops.completeLesson(j, l, at(1));
      j = r.journey;
      if (r.rewarded) rewardedCount++;
    }
    expect(rewardedCount).toBe(1);
    expect(gemBalance(j, 'personal')).toBe(5);
    expect(gemBalance(j, 'bewell')).toBe(0);
    expect(guideProgress(j).complete).toBe(true);
    const firstTime = j.guide.completed.today;
    for (const l of LESSON_IDS) {
      const r = ops.completeLesson(j, l, at(60));
      j = r.journey;
      expect(r.rewarded).toBe(false);
    }
    expect(j.guide.completed.today).toBe(firstTime);
    expect(gemBalance(j, 'personal')).toBe(5);
  });
  it('practice never creates real history', () => {
    let j = onboarded();
    j = ops.setPractice(j, { checkin: { mood: 2, energy: 3, connection: 4, saved: true }, journalText: 'practice', journalSaved: true }, at(1));
    expect(j.checkins).toHaveLength(0);
    expect(j.journal).toHaveLength(0);
    expect(j.gems).toHaveLength(0);
  });
});

describe('Direction (rule-based)', () => {
  it('weights chosen directions and Journey areas transparently', () => {
    let j = onboarded(); // chose center (+3)
    expect(computeDirection(j).current).toBe('center');
    j = ops.addArea(j, { name: 'f1', impact: 5, difficulty: 3, direction: 'focus' }, at(1));
    j = ops.addArea(j, { name: 'f2', impact: 4, difficulty: 3, direction: 'focus' }, at(2));
    const r = computeDirection(j);
    expect(r.scores.find((s) => s.id === 'focus')?.total).toBe(4);
    expect(r.current).toBe('focus');
  });
  it('returns null when nothing points anywhere', () => {
    const j = ops.completeOnboarding(ops.emptyJourney(T0), { name: 'x', ageBracket: '35-44', spaceId: 'personal', directions: [] }, T0);
    expect(computeDirection(j).current).toBeNull();
  });
});

describe('Merge (sync + account restore)', () => {
  it('keeps distinct events from two devices and never duplicates gems', () => {
    const base = onboarded();
    const phone = ops.addCheckIn(base, { mood: 2, energy: 2, connection: 2 }, at(1), 'phone1');
    const web = ops.addJournal(base, 'from the laptop', undefined, at(2), 'web1');
    const m1 = mergeJourneys(phone, web);
    const m2 = mergeJourneys(m1, web); // re-merge is idempotent
    expect(m2.checkins.map((c) => c.id)).toEqual(['phone1']);
    expect(m2.journal.map((c) => c.id)).toEqual(['web1']);
    expect(gemBalance(m2, 'personal')).toBe(3);
  });
  it('later edit wins; a delete is not resurrected by an older copy', () => {
    let a = ops.addJournal(onboarded(), 'v1', undefined, at(1), 'j1');
    const b = ops.editJournal(a, 'j1', 'v2 from other device', at(5));
    a = ops.deleteJournal(a, 'j1', at(3));
    const merged = mergeJourneys(a, b);
    // b edited later than a deleted → edit wins (last-writer-wins by updatedAt)
    expect(merged.journal[0].text).toBe('v2 from other device');
    const c = ops.deleteJournal(b, 'j1', at(9));
    expect(mergeJourneys(c, b).journal[0].deletedAt).toBeTruthy();
    expect(mergeJourneys(b, c).journal[0].deletedAt).toBeTruthy();
  });
  it('guide reward is kept once across devices', () => {
    let a = onboarded();
    let b = onboarded();
    for (const l of LESSON_IDS) a = ops.completeLesson(a, l, at(1)).journey;
    for (const l of LESSON_IDS) b = ops.completeLesson(b, l, at(2)).journey;
    const m = mergeJourneys(a, b);
    expect(m.gems.filter((g) => g.reason === 'guide-complete')).toHaveLength(1);
    expect(gemBalance(m, 'personal')).toBe(5);
  });
});

describe('Backup and restore validation', () => {
  it('round-trips a full journey', () => {
    let j = onboarded();
    j = ops.addCheckIn(j, { mood: 3, energy: 4, connection: 2, note: 'n' }, at(1));
    j = ops.addArea(j, { name: 'x', impact: 4, difficulty: 2, direction: 'focus' }, at(2), 'a1');
    j = ops.addEvidence(j, { areaId: 'a1', kind: 'observation', text: 'saw it' }, at(3));
    j = ops.addHarmony(j, defaultRatings(), undefined, at(4));
    j = ops.addJournal(j, 'entry', undefined, at(5));
    const text = JSON.stringify(makeBackup(j, at(6)));
    const r = checkBackupText(text);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.counts).toMatchObject({ checkins: 1, areas: 1, evidence: 1, harmony: 1, journal: 1, gems: 6 });
      expect(r.journey).toEqual(j);
    }
  });
  it('rejects invalid JSON, foreign files and bad records with readable errors', () => {
    expect(checkBackupText('not json').ok).toBe(false);
    expect(checkBackupText('{"hello":1}').ok).toBe(false);
    const j = ops.addCheckIn(onboarded(), { mood: 3, energy: 3, connection: 3 }, at(1));
    const bad = JSON.parse(JSON.stringify(makeBackup(j)));
    bad.journey.checkins[0].mood = 109;
    bad.journey.evidence = [{ id: 'e', areaId: 'missing', kind: 'win', text: 'x', createdAt: at(1).toISOString() }];
    const r = checkBackup(bad);
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.errors.join(' ')).toMatch(/0 to 100/);
      expect(r.errors.join(' ')).toMatch(/area that isn't in the file/);
    }
  });
  it('drops unknown fields rather than trusting them', () => {
    const j = ops.addCheckIn(onboarded(), { mood: 3, energy: 3, connection: 3 }, at(1));
    const raw = JSON.parse(JSON.stringify(makeBackup(j)));
    raw.journey.checkins[0].evil = '<script>';
    raw.journey.extra = 'x';
    const r = checkBackup(raw);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect((r.journey.checkins[0] as any).evil).toBeUndefined();
      expect((r.journey as any).extra).toBeUndefined();
    }
  });
  it('rejects duplicate ids', () => {
    const j = ops.addCheckIn(onboarded(), { mood: 3, energy: 3, connection: 3 }, at(1), 'dup');
    const raw = JSON.parse(JSON.stringify(makeBackup(j)));
    raw.journey.checkins.push({ ...raw.journey.checkins[0] });
    expect(checkBackup(raw).ok).toBe(false);
  });
});

describe('Feeling sliders: colour and sound follow the reading', () => {
  it('interpolates each feeling from its low colour to its high colour', () => {
    expect(feelColor('mood', 0)).toBe('#66707F');
    expect(feelColor('mood', 50)).toBe('#A88E66');
    expect(feelColor('mood', 100)).toBe('#E2A21E');
    expect(feelColor('energy', 100)).toBe('#EE6A2A');
    expect(feelColor('connection', 0)).toBe('#7B8997');
    expect(feelColor('connection', 150)).toBe(feelColor('connection', 100));
    expect(mix('#000000', '#FFFFFF', 0.5)).toBe('#808080');
  });
  it('mood rises in pitch, turns from a minor to a major third, and brightens', () => {
    const lo = moodParams(0), hi = moodParams(1);
    expect(hi.freq).toBeGreaterThan(lo.freq * 3.9);
    expect(lo.third / lo.freq).toBeCloseTo(Math.pow(2, 3 / 12), 5);
    expect(hi.third / hi.freq).toBeCloseTo(Math.pow(2, 4 / 12), 5);
    expect(hi.cutoff).toBeGreaterThan(lo.cutoff * 10);
  });
  it('energy pulses faster, higher and with more edge as it charges', () => {
    const a = energyParams(0), b = energyParams(0.5), c = energyParams(1);
    expect(a.lfoRate).toBeLessThan(b.lfoRate);
    expect(b.lfoRate).toBeLessThan(c.lfoRate);
    expect(c.freq).toBeCloseTo(a.freq * 4, 5);
    expect(c.edge).toBeGreaterThan(a.edge);
  });
  it('connection brings two voices into tune and to the centre, then fills out the chord', () => {
    const iso = connectionParams(0), con = connectionParams(1);
    expect(iso.partner / iso.root).not.toBeCloseTo(1.5, 2);
    expect(con.partner / con.root).toBeCloseTo(1.5, 10);
    expect(iso.spread).toBeGreaterThan(0.5);
    expect(con.spread).toBe(0);
    expect(iso.octaveGain).toBe(0);
    expect(con.thirdGain).toBeGreaterThan(0);
  });
});

describe('Age ranges and reflection mode', () => {
  const start = (ageBracket: any, spaceId: 'personal' | 'bewell' = 'bewell') => ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_age'), { name: 'Sam', ageBracket, spaceId, directions: [] }, T0);
  it('requires an age range; "adult" is only for journeys made before ranges existed', () => {
    expect(() => start(undefined)).toThrow();
    expect(() => start('adult')).toThrow();
    expect(start('25-34').profile!.ageBracket).toBe('25-34');
  });
  it('under 18 stays in Personal and cannot switch to Be Well', () => {
    const j = start('under18');
    expect(isAdult(j)).toBe(false);
    expect(j.activeSpaceId).toBe('personal');
    expect(() => ops.setActiveSpace(j, 'bewell')).toThrow(/adults/);
    expect(isAdult(start('18-24'))).toBe(true);
  });
  it('changing to under 18 moves to Personal and keeps Be Well entries', () => {
    let j = start('25-34');
    j = ops.addCheckIn(j, { mood: 50, energy: 50, connection: 50 }, at(1), 'bw');
    j = ops.updateProfile(j, { ageBracket: 'under18' }, at(2));
    expect(j.activeSpaceId).toBe('personal');
    expect(j.checkins.find((c) => c.id === 'bw')?.spaceId).toBe('bewell');
  });
  it('reads older journeys with only the 18+ confirmation as "adult", and refuses a profile with neither', () => {
    const j = start('25-34');
    const raw = JSON.parse(JSON.stringify(makeBackup(j)));
    delete raw.journey.profile.ageBracket;
    raw.journey.profile.ageConfirmed = true;
    const r = checkBackup(raw);
    expect(r.ok && r.journey.profile!.ageBracket).toBe('adult');
    expect(r.ok && isAdult(r.journey)).toBe(true);
    delete raw.journey.profile.ageConfirmed;
    expect(checkBackup(raw).ok).toBe(false);
  });
});

describe('Safety & Path intake (placeholder)', () => {
  it('counts major cautions, other cautions and the support answer separately', () => {
    const r = evaluateIntake({ answers: { lithium: 'yes', pregnancy: 'no', heart: 'yes', maoi: 'skip', crisis_now: 'no' }, completedAt: T0.toISOString(), version: INTAKE_VERSION, updatedAt: T0.toISOString() });
    expect(r).toMatchObject({ answered: 5, majorCount: 1, cautionCount: 1, supportNow: false, complete: true, needsReview: false });
    expect(intakeSummary(r)).toMatch(/2 factors worth discussing with a clinician, 1 of them a major caution/);
    expect(evaluateIntake({ answers: { crisis_now: 'yes' }, updatedAt: '' }).supportNow).toBe(true);
  });
  it('asks for a review when answers were given to an older question set', () => {
    const r = evaluateIntake({ answers: { meds_mood: 'yes', heart: 'no' }, completedAt: T0.toISOString(), updatedAt: T0.toISOString() });
    expect(r.needsReview).toBe(true);
    expect(intakeSummary(r)).toMatch(/new since you answered/);
  });
  it('saves experience and the question-set version, and drops answers to questions that no longer exist', () => {
    const j = ops.saveIntake(onboarded(), { meds_mood: 'yes', lithium: 'no' }, true, at(1), 'some');
    expect(j.intake).toMatchObject({ answers: { lithium: 'no' }, experience: 'some', version: INTAKE_VERSION });
    const r = checkBackup(JSON.parse(JSON.stringify(makeBackup(j))));
    expect(r.ok && r.journey.intake).toMatchObject({ experience: 'some', version: INTAKE_VERSION });
  });
});

describe('Protocols and rhythm (step 2)', () => {
  const adult = () => onboarded();
  const input = (over: any = {}) => ({ presetId: 'one-two', name: 'One day on, two days off', pattern: { type: 'cycle', on: 1, off: 2 }, startDate: '2026-09-30', ...over });
  it('lists the common schedules, including three on / two off', () => {
    expect(PROTOCOL_PRESETS.map((p) => p.id)).toEqual(['one-two', 'four-three', 'three-two', 'every-other', 'two-a-week']);
    expect(describePattern({ type: 'cycle', on: 3, off: 2 })).toBe('Three days on, two days off');
    expect(describePattern({ type: 'cycle', on: 1, off: 2 })).toBe('One day on, two days off');
    expect(describePattern({ type: 'weekdays', days: [4, 1] })).toBe('Activation on Mon, Thu');
  });
  it('counts activation and integration days from the start date', () => {
    const j = ops.startProtocol(adult(), input(), at(1), 'p1');
    const p = currentProtocol(j)!;
    expect(upcoming(p, '2026-09-29', 5).map((d) => d.kind)).toEqual(['upcoming', 'activation', 'integration', 'integration', 'activation']);
    expect(dayFor(p, '2026-10-02')).toMatchObject({ kind: 'integration', index: 2, of: 2 });
    expect(nextActivation(p, '2026-10-01')).toBe('2026-10-03');
    const three = currentProtocol(ops.startProtocol(adult(), input({ presetId: 'three-two', pattern: { type: 'cycle', on: 3, off: 2 } }), at(1)))!;
    expect(upcoming(three, '2026-09-30', 6).map((d) => d.kind[0])).toEqual(['a', 'a', 'a', 'i', 'i', 'a']);
  });
  it('supports chosen weekdays, and practice weeks followed by rest weeks', () => {
    const wk = currentProtocol(ops.startProtocol(adult(), input({ presetId: 'two-a-week', pattern: { type: 'weekdays', days: [1, 4] } }), at(1)))!;
    expect(dayFor(wk, '2026-10-01').kind).toBe('activation'); // Thursday
    expect(dayFor(wk, '2026-10-03').kind).toBe('integration'); // Saturday
    expect(dayFor(wk, '2026-10-05').kind).toBe('activation'); // Monday
    const cyc = currentProtocol(ops.startProtocol(adult(), input({ cycleWeeks: 4, restWeeks: 2 }), at(1)))!;
    expect(dayFor(cyc, addDays('2026-09-30', 27)).kind).not.toBe('rest');
    expect(dayFor(cyc, addDays('2026-09-30', 28))).toMatchObject({ kind: 'rest', index: 1, of: 14 });
    expect(dayFor(cyc, addDays('2026-09-30', 42))).toMatchObject({ kind: 'activation', index: 1 });
  });
  it('counts calendar days, so daylight saving never shifts the rhythm', () => {
    expect(daysBetween('2026-10-31', '2026-11-01')).toBe(1);
    expect(daysBetween('2026-11-01', '2026-11-02')).toBe(1);
    expect(daysBetween('2026-03-07', '2026-03-09')).toBe(2);
  });
  it('rejects rhythms without integration days, and half-set cycles', () => {
    expect(patternProblem({ type: 'cycle', on: 0, off: 2 })).toBeTruthy();
    expect(patternProblem({ type: 'weekdays', days: [0, 1, 2, 3, 4, 5] })).toMatch(/two integration days/);
    expect(() => ops.startProtocol(adult(), input({ pattern: { type: 'cycle', on: 2, off: 0 } }), at(1))).toThrow();
    expect(() => ops.startProtocol(adult(), input({ cycleWeeks: 4 }), at(1))).toThrow(/Rest weeks/);
    expect(() => ops.startProtocol(adult(), input({ startDate: '2026-02-30' }), at(1))).toThrow(/start date/);
  });
  it('is for adults only, and support comes first after a crisis answer', () => {
    const minor = ops.completeOnboarding(ops.emptyJourney(T0), { name: 'Sam', ageBracket: 'under18', spaceId: 'personal', directions: [] }, T0);
    expect(() => ops.startProtocol(minor, input(), at(1))).toThrow(/adults/);
    const crisis = ops.saveIntake(adult(), { crisis_now: 'yes' }, true, at(1));
    expect(() => ops.startProtocol(crisis, input(), at(2))).toThrow(/Support comes first/);
  });
  it('keeps one current protocol; pausing, resuming, ending and removing work as expected', () => {
    let j = ops.startProtocol(adult(), input({ amount: '  2 drops ', substance: 'Harmony', level: 'micro' }), at(1), 'p1');
    expect(currentProtocol(j)).toMatchObject({ id: 'p1', amount: '2 drops', level: 'micro' });
    j = ops.startProtocol(j, input({ presetId: 'four-three', pattern: { type: 'cycle', on: 4, off: 3 } }), at(2), 'p2');
    expect(currentProtocol(j)!.id).toBe('p2');
    expect(pastProtocols(j).map((p) => p.id)).toEqual(['p1']);
    j = ops.pauseProtocol(j, 'p2', at(3));
    expect(dayFor(currentProtocol(j)!, '2026-10-01').kind).toBe('paused');
    j = ops.resumeProtocol(j, 'p2', '2026-10-10', at(4));
    expect(currentProtocol(j)).toMatchObject({ status: 'active', startDate: '2026-10-10' });
    j = ops.endProtocol(j, 'p2', at(5));
    expect(currentProtocol(j)).toBeNull();
    j = ops.deleteProtocol(j, 'p1', at(6));
    expect(pastProtocols(j).map((p) => p.id)).toEqual(['p2']);
    expect(j.protocols.find((p) => p.id === 'p1')).toMatchObject({ amount: undefined, substance: undefined });
    expect(gemBalance(j, 'personal')).toBe(0); // choosing or following a protocol is never rewarded
  });
  it('round-trips through a backup and merges across devices', () => {
    const a = ops.startProtocol(adult(), input({ amount: '1 cap' }), at(1), 'pa');
    const r = checkBackup(JSON.parse(JSON.stringify(makeBackup(a))));
    expect(r.ok && r.journey.protocols[0]).toMatchObject({ id: 'pa', amount: '1 cap', pattern: { type: 'cycle', on: 1, off: 2 } });
    const b = ops.startProtocol(adult(), input({ presetId: 'every-other', pattern: { type: 'cycle', on: 1, off: 1 } }), at(5), 'pb');
    const merged = mergeJourneys(a, b);
    expect(merged.protocols.map((p) => p.id).sort()).toEqual(['pa', 'pb']);
    expect(currentProtocol(merged)!.id).toBe('pb');
    const old = JSON.parse(JSON.stringify(makeBackup(adult())));
    delete old.journey.protocols;
    expect(checkBackup(old).ok).toBe(true);
  });
});

describe('Dashboard: timeline and the last seven days', () => {
  const build = () => {
    let j = onboarded();
    j = ops.addCheckIn(j, { mood: 40, energy: 60, connection: 80, note: 'first' }, at(1), 'c1');
    j = ops.addCheckIn(j, { mood: 60, energy: 40, connection: 20 }, at(2), 'c2');
    j = ops.addJournal(j, 'A small thing that went well', undefined, at(3), 'j1');
    j = ops.addArea(j, { name: 'Sleep', impact: 5, difficulty: 2 }, at(4), 'a1');
    j = ops.addEvidence(j, { areaId: 'a1', kind: 'win', text: 'Lights out by 11' }, at(5), 'e1');
    j = ops.startProtocol(j, { presetId: 'one-two', name: 'One day on, two days off', pattern: { type: 'cycle', on: 1, off: 2 }, startDate: '2026-09-29' }, at(6), 'p1');
    return j;
  };
  it('puts everything in one feed, newest first, and leaves out deleted entries and other Spaces', () => {
    let j = build();
    j = ops.setActiveSpace(j, 'bewell', at(7));
    j = ops.addCheckIn(j, { mood: 10, energy: 10, connection: 10 }, at(8), 'bw');
    j = ops.setActiveSpace(j, 'personal', at(9));
    j = ops.deleteCheckIn(j, 'c2', at(10));
    const t = timeline(j, 'personal');
    expect(t.map((i) => i.id)).toEqual(['p:p1:start', 'e:e1', 'a:a1', 'j:j1', 'c:c1']);
    expect(t[0].detail).toBe('One day on, two days off'); // the name already says the rhythm
    expect(t.find((i) => i.id === 'c:c1')).toMatchObject({ kind: 'checkin', quote: 'first' });
    expect(t.find((i) => i.id === 'e:e1')!.title).toBe('Win · Sleep');
    expect(byDay(t).length).toBe(1);
  });
  it('shows no protocol events under 18', () => {
    const j = { ...build(), profile: { ...build().profile!, ageBracket: 'under18' as const } };
    expect(timeline(j, 'personal').some((i) => i.kind === 'protocol')).toBe(false);
  });
  it('averages each day and leaves days without a check-in empty', () => {
    const j = build();
    const today = localDayKey(at(2));
    const w = weekFeelings(j, 'personal', today);
    expect(w).toHaveLength(7);
    expect(w[6]).toMatchObject({ day: today, count: 2, mood: 50, energy: 50, connection: 50 });
    expect(w[0]).toEqual({ day: w[0].day, count: 0 });
    expect(weekCounts(j, 'personal', today)).toEqual({ checkins: 2, journal: 1, harmony: 0, wins: 1, observations: 0, setbacks: 0 });
  });
});

describe('Compass: what the numbers mean', () => {
  const r = (p: number, res: number) => ({ pressure: p, resource: res }) as any;
  const ratings = (fire: any, air: any, water: any, earth: any) => ({ fire, air, water, earth });
  it('reads matched elements as equilibrium and names the overall and spread plainly', () => {
    const s = equilibriumOf({ ratings: defaultRatings() });
    expect(s).toMatchObject({ overall: 50, spread: 0, word: 'In equilibrium' });
    const low = equilibriumOf({ ratings: ratings(r(5, 3), r(5, 3), r(5, 3), r(5, 3)) });
    expect(low).toMatchObject({ overall: 25, spread: 0, word: 'Evenly stretched' });
  });
  it('grows from nearly balanced to discord as the spread widens, naming the lowest and highest', () => {
    expect(equilibriumOf({ ratings: ratings(r(3, 3), r(3, 3), r(3, 3), r(4, 3)) }).word).toBe('In equilibrium'); // a 12-point gap is still in step
    expect(equilibriumOf({ ratings: ratings(r(3, 3), r(3, 3), r(3, 3), r(5, 3)) }).word).toBe('Nearly balanced');
    const some = equilibriumOf({ ratings: ratings(r(3, 5), r(3, 3), r(3, 3), r(4, 3)) });
    expect(some).toMatchObject({ spread: 37, highest: 'fire', lowest: 'earth', word: 'Some discord' });
    const far = equilibriumOf({ ratings: ratings(r(1, 5), r(3, 3), r(3, 3), r(5, 1)) });
    expect(far).toMatchObject({ word: 'In discord', lowest: 'earth', highest: 'fire', spread: 100 });
    expect(far.sentence).toContain('Begin with Earth');
  });
  it('suggests restoring the lowest element and drawing on a well-resourced one', () => {
    const far = equilibriumOf({ ratings: ratings(r(1, 5), r(3, 3), r(3, 3), r(5, 1)) });
    const { begin, draw } = suggestions(far);
    expect(begin).toMatchObject({ element: 'earth', need: 'restore' });
    expect(begin.practices).toEqual(PRACTICES.earth.restore);
    expect(draw).toMatchObject({ element: 'fire', need: 'share' });
    const even = suggestions(equilibriumOf({ ratings: defaultRatings() }));
    expect(even.begin.need).toBe('sustain');
    expect(even.draw).toBeUndefined();
  });
  it('builds the trend oldest first in the Space, without deleted readings', () => {
    let j = onboarded();
    j = ops.addHarmony(j, ratings(r(5, 3), r(3, 3), r(3, 3), r(3, 3)), undefined, at(1), 'h1');
    j = ops.addHarmony(j, defaultRatings(), undefined, at(2), 'h2');
    j = ops.addHarmony(j, ratings(r(3, 5), r(3, 4), r(3, 3), r(3, 3)), undefined, at(3), 'h3');
    j = ops.deleteHarmony(j, 'h2', at(4));
    j = ops.setActiveSpace(j, 'bewell', at(5));
    j = ops.addHarmony(j, defaultRatings(), undefined, at(6), 'other');
    const t = trend(j, 'personal');
    expect(t.map((p) => p.id)).toEqual(['h1', 'h3']);
    expect(t[0]).toMatchObject({ overall: 44, spread: 25 });
    expect(trendChange(t)).toMatchObject({ overall: t[1].overall - 44, values: { fire: 50, air: t[1].values.air - 50, water: 0, earth: 0 } });
    expect(t[1].values.fire).toBe(75);
    expect(trendChange(t.slice(0, 1))).toBeNull();
  });
});

describe('Day notes (rhythm on Home)', () => {
  it('saves one note per day, keeps an amount only when taken, and replaces on edit', () => {
    let j = ops.startProtocol(onboarded(), { presetId: 'one-two', name: 'One day on, two days off', pattern: { type: 'cycle', on: 1, off: 2 }, startDate: '2026-09-29', substance: 'Test tincture', amount: '2 drops' } as any, at(1), 'p1');
    j = ops.saveDayNote(j, { day: '2026-09-29', status: 'taken', protocolId: 'p1', substance: ' Test tincture ', amount: '2 drops', note: 'Calm afternoon' }, at(2));
    expect(j.dayNotes).toHaveLength(1);
    expect(j.dayNotes[0]).toMatchObject({ id: 'day:2026-09-29', status: 'taken', substance: 'Test tincture', amount: '2 drops', note: 'Calm afternoon' });
    j = ops.saveDayNote(j, { day: '2026-09-29', status: 'skipped', amount: '2 drops', note: 'Changed my mind' }, at(3));
    expect(j.dayNotes).toHaveLength(1);
    expect(j.dayNotes[0]).toMatchObject({ status: 'skipped', amount: undefined, note: 'Changed my mind' });
    expect(j.dayNotes[0].createdAt).toBe(at(2).toISOString());
    expect(gemBalance(j, 'personal')).toBe(gemBalance(onboarded(), 'personal'));
  });
  it('is for adults only and rejects a bad day or status', () => {
    const minor = ops.completeOnboarding(ops.emptyJourney(T0, 'jrn_m'), { name: 'Young', ageBracket: 'under18', spaceId: 'personal', directions: ['center'] }, T0);
    expect(() => ops.saveDayNote(minor, { day: '2026-09-29', status: 'off' }, at(1))).toThrow(/18/);
    expect(() => ops.saveDayNote(onboarded(), { day: '29/09', status: 'off' }, at(1))).toThrow();
    expect(() => ops.saveDayNote(onboarded(), { day: '2026-09-29', status: 'maybe' as any }, at(1))).toThrow();
  });
  it('deletes with a tombstone, survives backup and merge, and shows in the timeline', () => {
    let j = ops.saveDayNote(onboarded(), { day: '2026-09-29', status: 'off', note: 'Long walk' }, at(1));
    j = ops.saveDayNote(j, { day: '2026-09-30', status: 'taken', amount: '1 drop' }, at(2));
    const items = timeline(j, 'personal').filter((i) => i.title.startsWith('Day note'));
    expect(items.map((i) => i.title)).toEqual(['Day note · Taken', 'Day note · Integration day']);
    const back = checkBackupText(JSON.stringify(makeBackup(j)));
    expect(back.ok && back.journey.dayNotes.length).toBe(2);
    const removed = ops.deleteDayNote(j, '2026-09-29', at(3));
    expect(removed.dayNotes.find((n) => n.id === 'day:2026-09-29')!.deletedAt).toBeTruthy();
    expect(timeline(removed, 'personal').filter((i) => i.title.startsWith('Day note'))).toHaveLength(1);
    const merged = mergeJourneys(j, removed);
    expect(merged.dayNotes.find((n) => n.id === 'day:2026-09-29')!.deletedAt).toBeTruthy();
    expect(ops.deleteDayNote(removed, '2026-09-29', at(4))).toBe(removed);
  });
});
