import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

// Equilibrium is written in US English. This catches British spellings in the app's words
// (and comments) before they ship. Add a word here if another one slips through.
const BRITISH: [RegExp, string][] = [
  [/\bpractis(e|es|ed|ing)\b/i, 'practice / practiced / practicing'],
  [/\bcolour(s|ed|ful|ing)?\b/i, 'color'],
  [/\b(savour|flavour|favour|honour|behaviour|neighbour|labour|humour|rumour|endeavour)(s|ed|ing|ite|able)?\b/i, '-or'],
  [/\b(centre|metre|litre|fibre|theatre|calibre)s?\b/i, '-er'],
  [/\b(labell|cancell|travell|modell|levell|signall|fuell|diall|counsell)(ed|ing|er)\b/i, 'single l (labeled, canceled …)'],
  [/\b(organis|recognis|realis|apologis|prioritis|minimis|summaris|customis|personalis|visualis|synchronis|authoris|utilis|emphasis)(e|es|ed|ing|ation)\b/i, '-ize'],
  [/\b(analys)(e|es|ed|ing)\b/i, 'analyze'],
  [/\b(catalogue|licence|defence|offence|programme|cheque|grey|whilst|amongst|learnt|ageing|judgement|enquir\w*)\b/i, 'US form'],
];

function files(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const p = join(dir, name);
    return statSync(p).isDirectory() ? files(p) : /\.(tsx?|html)$/.test(name) ? [p] : [];
  });
}

describe('Spelling', () => {
  it('uses US English throughout the app', () => {
    const found: string[] = [];
    for (const f of [...files('src'), 'public/index.html']) {
      readFileSync(f, 'utf8')
        .split('\n')
        .forEach((line, i) => {
          for (const [re, use] of BRITISH) {
            const m = line.match(re);
            if (m) found.push(`${f}:${i + 1} "${m[0]}" → use ${use}`);
          }
        });
    }
    expect(found).toEqual([]);
  });
});
