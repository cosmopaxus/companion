import { defineConfig } from '@playwright/test';

// Screenshots for each phase's handoff (not part of the test suite): `npx playwright test -c playwright.shots.config.ts`.
export default defineConfig({
  testDir: './shots',
  timeout: 90_000,
  workers: 2,
  reporter: [['line']],
  use: { baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:8081' },
  projects: [
    { name: 'phone', use: { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true } },
    { name: 'desktop', use: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 } },
  ],
  webServer: process.env.E2E_BASE_URL ? undefined : { command: 'npx serve -s dist -l 8081', port: 8081, reuseExistingServer: true, timeout: 30_000 },
});
