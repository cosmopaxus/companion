import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

// Piece 1 of the painted academy: Home and the four hall windows. Not part of the test suite.
const OUT = process.env.SHOTS_DIR ?? 'painted-shots';

function journey(hall?: 'fire' | 'air' | 'water' | 'earth'): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 5 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_paint'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n < 4; n++) j = ops.addCheckIn(j, { mood: 55 + n * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(2));
  j = ops.addJournal(j, 'A steadier morning. The walk helped more than I expected.', undefined, at(3), 'jnl_1');
  if (hall) j = ops.setPrefs(j, { hall }, at(1));
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(1200);
}

test('home day', async ({ page }, info) => {
  await open(page, journey());
  await page.screenshot({ path: `${OUT}/p1-home-day-${info.project.name}.png` });
});
test('home night', async ({ page }, info) => {
  await open(page, journey(), 'night');
  await page.screenshot({ path: `${OUT}/p1-home-night-${info.project.name}.png` });
});
for (const hall of ['fire', 'air', 'water', 'earth'] as const) {
  test(`hall ${hall}`, async ({ page }, info) => {
    await open(page, journey(hall));
    await page.getByTestId('tab-journal').click();
    await page.waitForTimeout(1200);
    await page.screenshot({ path: `${OUT}/p1-hall-${hall}-${info.project.name}.png` });
  });
}
test('hall water night', async ({ page }, info) => {
  await open(page, journey('water'), 'night');
  await page.getByTestId('tab-journal').click();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/p1-hall-water-night-${info.project.name}.png` });
});
