import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

const OUT = process.env.SHOTS_DIR ?? 'companion-v3-screenshots';

function journey(hall?: 'fire' | 'air' | 'water' | 'earth'): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 6 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number, m = 0) => new Date(start.getTime() + n * DAY + m * 60000);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_shots'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  for (let n = 0; n < 6; n++) j = ops.addCheckIn(j, { mood: 40 + n * 6, energy: 55, connection: 60 }, at(n), `chk_${n}`);
  j = ops.addArea(j, { name: 'A steadier sleep rhythm', impact: 4, difficulty: 2 }, at(1), 'area_1');
  j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: 'Lights out by 11' }, at(2), 'ev_1');
  j = ops.dismissGuideCard(j, at(1));
  if (hall) j = ops.setPrefs(j, { hall }, at(1));
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(
    ([v, t]) => {
      localStorage.setItem('companion.v2.journey.guest', v);
      localStorage.setItem('companion.v2.theme', t);
    },
    [JSON.stringify(j), theme] as [string, string],
  );
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(400);
}

test('home · earth · day', async ({ page }, info) => {
  await open(page, journey());
  await page.screenshot({ path: `${OUT}/41-home-earth-day-${info.project.name}.png` });
});

test('home · night', async ({ page }, info) => {
  await open(page, journey(), 'night');
  await page.screenshot({ path: `${OUT}/42-home-earth-night-${info.project.name}.png` });
});

test('check-in · fire', async ({ page }, info) => {
  await open(page, journey('fire'));
  await page.getByTestId('checkin-card').scrollIntoViewIfNeeded();
  await page.getByTestId('checkin-card').screenshot({ path: `${OUT}/43-checkin-fire-${info.project.name}.png` });
});

for (const hall of ['fire', 'air', 'water', 'earth'] as const) {
  test(`hero · ${hall}`, async ({ page }, info) => {
    test.skip(info.project.name !== 'phone');
    for (const theme of ['day', 'night'] as const) {
      const ctx = await page.context().browser()!.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
      const p = await ctx.newPage();
      await open(p, journey(hall), theme);
      await p.getByTestId('hall-hero').screenshot({ path: `${OUT}/44-hero-${hall}-${theme}.png` });
      await ctx.close();
    }
  });
}

test('you · hall choice', async ({ page }, info) => {
  await open(page, journey('water'));
  await page.getByTestId('tab-you').click();
  await page.getByTestId('hall-choice').scrollIntoViewIfNeeded();
  await page.getByTestId('hall-choice').screenshot({ path: `${OUT}/45-you-hall-choice-${info.project.name}.png` });
});
