import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

// Piece 3 follow-up: Home like mockup 04, Compass like 07, Rest with sound like 10. Not part of the suite.
const OUT = process.env.SHOTS_DIR ?? 'painted-shots3b';

function journey(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 9 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_paint'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n <= 9; n++) j = ops.addCheckIn(j, { mood: 55 + (n % 4) * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(8));
  j = ops.addJournal(j, 'A steadier morning. The walk helped more than I expected.', undefined, at(8), 'jnl_1');
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(1200);
}

for (const theme of ['day', 'night'] as const) {
  test(`p3b ${theme}`, async ({ page }, info) => {
    await open(page, journey(), theme);
    const shot = async (n: string, tall = true) => {
      await page.screenshot({ path: `${OUT}/${n}-${theme}-${info.project.name}.png` });
      if (!tall) return;
      const vp = page.viewportSize()!;
      await page.setViewportSize({ width: vp.width, height: 2400 });
      await page.waitForTimeout(400);
      await page.screenshot({ path: `${OUT}/${n}-${theme}-${info.project.name}-tall.png` });
      await page.setViewportSize(vp);
      await page.waitForTimeout(200);
    };
    await shot('home');
    await page.getByTestId('equilibrium-open').first().click();
    await page.waitForTimeout(900);
    await shot('compass');
    await page.getByRole('button', { name: 'Back' }).first().click();
    await page.waitForTimeout(500);
    await page.getByTestId('rest-open').click();
    await page.waitForTimeout(2500);
    await shot('rest', false);
    await page.getByTestId('rest-finish').click();
    await page.getByTestId('tab-journal').click();
    await page.waitForTimeout(900);
    await shot('journal', false);
  });
}
