import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
const OUT = process.env.SHOTS_DIR ?? 'painted-shots4';
function journey(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 5 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_p4'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n < 4; n++) j = ops.addCheckIn(j, { mood: 55 + n * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(2));
  j = ops.setPrefs(j, { hall: 'fire' }, at(1));
  return j;
}
async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(900);
}
test('p4 frame', async ({ page }, info) => {
  await open(page, journey());
  const n = info.project.name;
  const shot = async (k: string) => { await page.waitForTimeout(900); await page.screenshot({ path: `${OUT}/f-${k}-${n}.png` }); };
  await shot('home');
  await page.getByTestId('checkin-open').click();
  for (const [d, v] of [['mood', 68], ['energy', 46], ['connection', 82]] as const) {
    const s = page.getByTestId(`checkin-${d}`);
    await s.focus(); await page.keyboard.press('Home');
    for (let i = 0; i < Math.floor(v / 10); i++) await page.keyboard.press('Shift+ArrowRight');
    for (let i = 0; i < v % 10; i++) await page.keyboard.press('ArrowRight');
  }
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  await page.getByTestId('screen-checkin').evaluate((el) => el.scrollTo({ top: 0 }));
  await shot('checkin');
  await page.getByTestId('back-chip').filter({ visible: true }).last().click();
  await page.getByTestId('equilibrium-open').first().click();
  await shot('compass');
  await page.getByTestId('back-chip').filter({ visible: true }).last().click();
  await page.getByTestId('tab-journal').click();
  await shot('journal');
  await page.getByTestId('tab-journey').click();
  await shot('journey');
  await page.getByRole('button', { name: /You are here/ }).click();
  await shot('lesson');
  await page.getByTestId('back-chip').filter({ visible: true }).last().click();
  await page.getByTestId('map-sanctuary').click();
  await page.waitForTimeout(1500);
  await shot('rest');
  await page.getByTestId('back-chip').filter({ visible: true }).last().click();
  await page.getByTestId('tab-you').click();
  await shot('you');
});
