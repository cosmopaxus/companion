import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

// Piece 1 of the painted academy: Home and the four hall windows. Not part of the test suite.
const OUT = process.env.SHOTS_DIR ?? 'painted-shots2';

function journey(hall?: 'fire' | 'air' | 'water' | 'earth'): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 5 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_paint'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n < 4; n++) j = ops.addCheckIn(j, { mood: 55 + n * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(2));
  j = ops.addJournal(j, 'A steadier morning. The walk helped more than I expected.', undefined, at(3), 'jnl_1');
  if (hall) j = ops.setPrefs(j, { hall }, at(1));
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(1200);
}

for (const [name, hall] of [['fire','fire'],['air','air'],['water','water'],['earth','earth']] as const) {
  test(`p2 ${name}`, async ({ page }, info) => {
    await open(page, journey(hall));
    const shot = async (n: string) => {
      await page.screenshot({ path: `${OUT}/p2-${n}-${hall}-${info.project.name}.png` });
      const vp = page.viewportSize()!;
      await page.setViewportSize({ width: vp.width, height: 2600 });
      await page.waitForTimeout(400);
      await page.screenshot({ path: `${OUT}/p2-${n}-${hall}-${info.project.name}-tall.png` });
      await page.setViewportSize(vp);
      await page.waitForTimeout(200);
    };
    await shot('home');
    await page.getByTestId('equilibrium-open').first().click();
    await page.waitForTimeout(900);
    await shot('compass');
    await page.getByRole('button', { name: 'Back' }).first().click();
    await page.waitForTimeout(400);
    await page.getByTestId('tab-journal').click();
    await page.waitForTimeout(900);
    await shot('journal');
    await page.getByTestId('tab-journey').click();
    await page.getByRole('button', { name: /You are here/ }).click();
    await page.waitForTimeout(900);
    await shot('lesson');
  });
}


test('p2 night water', async ({ page }, info) => {
  await open(page, journey('water'), 'night');
  const shot = async (n: string) => {
    const vp = page.viewportSize()!;
    await page.setViewportSize({ width: vp.width, height: 2600 });
    await page.waitForTimeout(500);
    await page.screenshot({ path: `${OUT}/p2-${n}-water-night-${info.project.name}-tall.png` });
    await page.setViewportSize(vp);
    await page.waitForTimeout(200);
  };
  await shot('home');
  await page.getByTestId('equilibrium-open').first().click();
  await page.waitForTimeout(900);
  await shot('compass');
  await page.getByRole('button', { name: 'Back' }).first().click();
  await page.getByTestId('tab-journal').click();
  await page.waitForTimeout(900);
  await shot('journal');
  await page.getByTestId('tab-journey').click();
  await page.getByRole('button', { name: /You are here/ }).click();
  await page.waitForTimeout(900);
  await shot('lesson');
});

test('p2 checkin filled', async ({ page }, info) => {
  await open(page, journey('fire'));
  await page.getByTestId('checkin-open').click();
  await page.waitForTimeout(600);
  for (const [d, v] of [['mood', 68], ['energy', 46], ['connection', 82]] as const) {
    const s = page.getByTestId(`checkin-${d}`);
    await s.focus();
    await page.keyboard.press('Home');
    for (let i = 0; i < Math.floor(v / 10); i++) await page.keyboard.press('Shift+ArrowRight');
    for (let i = 0; i < v % 10; i++) await page.keyboard.press('ArrowRight');
  }
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  await page.getByTestId('screen-checkin').evaluate((el) => el.scrollTo({ top: 0 }));
  const vp = page.viewportSize()!;
  await page.setViewportSize({ width: vp.width, height: 2600 });
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/p2-checkin-water-${info.project.name}-tall.png` });
});
