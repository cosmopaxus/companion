import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
import { localDayKey } from '../src/domain/time';

const OUT = process.env.SHOTS_DIR ?? 'companion-v3-screenshots';
const DAY = 86400000;

/** Foundation underway: two lessons mastered, an open quest. */
function underway(): Journey {
  const start = new Date(Date.now() - 9 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number, m = 0) => new Date(start.getTime() + n * DAY + m * 60000);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_map'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  for (let n = 0; n < 9; n++) j = ops.addCheckIn(j, { mood: 55, energy: 55, connection: 60 }, at(n), `chk_${n}`);
  j = ops.addArea(j, { name: 'A steadier sleep rhythm', impact: 4, difficulty: 2 }, at(1), 'area_1');
  j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: 'Lights out by 11' }, at(2), 'ev_1');
  j = ops.addGoal(j, { title: 'Walk every morning', element: 'earth' }, at(3), 'goal_1');
  j = ops.dismissGuideCard(j, at(1));
  return j;
}

/** A sincere seeker who opened Acolyte; the current lesson trains Air. */
function seeker(): Journey {
  let j = underway();
  j = ops.openTier(j, 'acolyte', 'seeker', 'Drawn to the inner work', localDayKey(new Date()), new Date());
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(
    ([v, t]) => {
      localStorage.setItem('companion.v2.journey.guest', v);
      localStorage.setItem('companion.v2.theme', t);
    },
    [JSON.stringify(j), theme] as [string, string],
  );
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.getByTestId('tab-journey').click();
  await page.getByTestId('path-map').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(400);
}

test('path map · foundation · day', async ({ page }, info) => {
  await open(page, underway());
  await page.getByTestId('region-foundation').scrollIntoViewIfNeeded();
  await page.screenshot({ path: `${OUT}/51-pathmap-foundation-day-${info.project.name}.png`, fullPage: false });
  await page.getByTestId('region-foundation').screenshot({ path: `${OUT}/52-region-foundation-day-${info.project.name}.png` });
});

test('path map · seeker on acolyte · night', async ({ page }, info) => {
  await open(page, seeker(), 'night');
  await page.getByTestId('path-map').scrollIntoViewIfNeeded();
  await page.screenshot({ path: `${OUT}/53-pathmap-acolyte-night-${info.project.name}.png` });
  await page.getByTestId('region-acolyte').screenshot({ path: `${OUT}/54-region-acolyte-night-${info.project.name}.png` });
});
