import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

const OUT = process.env.SHOTS_DIR ?? 'companion-v3-screenshots';

function journey(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 4 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_names'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(1));
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 3, resource: 4 }, water: { pressure: 3, resource: 4 }, earth: { pressure: 3, resource: 4 } }, undefined, at(3));
  return j;
}

async function open(page: Page) {
  await page.addInitScript((v) => localStorage.setItem('companion.v2.journey.guest', v), JSON.stringify(journey()));
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
}

test('names · Compass page and app bar', async ({ page }, info) => {
  await open(page);
  await page.screenshot({ path: `${OUT}/71-names-home-${info.project.name}.png`, clip: { x: 0, y: 0, width: page.viewportSize()!.width, height: Math.min(520, page.viewportSize()!.height) } });
  await page.getByTestId('equilibrium-open').first().click();
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/72-names-compass-${info.project.name}.png` });
});
