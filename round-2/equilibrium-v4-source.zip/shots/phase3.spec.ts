import { test, Page } from '@playwright/test';

const OUT = process.env.SHOTS_DIR ?? 'companion-v3-screenshots';

async function onboard(page: Page, theme: 'day' | 'night' = 'day') {
  await page.addInitScript((t) => localStorage.setItem('companion.v2.theme', t), theme);
  await page.goto('/');
  await page.getByTestId('onboarding-begin').click();
  await page.getByTestId('onboarding-name-input').fill('Cosmo');
  await page.getByTestId('onboarding-age-35-44').click();
  await page.getByTestId('onboarding-continue-1').click();
  await page.getByTestId('onboarding-continue-2').click();
  await page.getByTestId('onboarding-continue-3').click();
  await page.getByTestId('onboarding-finish').click();
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
}

for (const theme of ['day', 'night'] as const) {
  test(`celebration · ${theme}`, async ({ page }, info) => {
    await onboard(page, theme);
    for (const d of ['mood', 'energy', 'connection']) {
      const s = page.getByTestId(`checkin-${d}`);
      await s.scrollIntoViewIfNeeded();
      await s.focus();
      await page.keyboard.press('End');
    }
    await page.getByTestId('checkin-save').click();
    await page.getByTestId('celebration').waitFor();
    await page.waitForTimeout(650); // mid-burst
    await page.screenshot({ path: `${OUT}/61-celebration-${theme}-${info.project.name}.png` });
  });
}

test('ambience and pulse', async ({ page }, info) => {
  await onboard(page);
  await page.waitForTimeout(3200); // motes in flight, light mid-breath
  await page.getByTestId('hall-hero').screenshot({ path: `${OUT}/62-hero-ambience-${info.project.name}.png` });
  await page.getByTestId('tab-journey').click();
  await page.getByTestId('here-pulse').waitFor();
  await page.waitForTimeout(900);
  await page.getByTestId('region-foundation').screenshot({ path: `${OUT}/63-here-pulse-${info.project.name}.png` });
});
