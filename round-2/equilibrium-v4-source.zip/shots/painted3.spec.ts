import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';

// Piece 3 of the painted academy: rest, path map and invitations. Not part of the test suite.
const OUT = process.env.SHOTS_DIR ?? 'painted-shots3';

function journey(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 5 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_p3'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n < 4; n++) j = ops.addCheckIn(j, { mood: 55 + n * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.setPrefs(j, { hall: 'water' }, at(1));
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(800);
}

for (const theme of ['day', 'night'] as const) {
  test(`p3 ${theme}`, async ({ page }, info) => {
    await open(page, journey(), theme);
    const n = `${theme}-${info.project.name}`;
    await page.screenshot({ path: `${OUT}/p3-home-${n}.png` });
    await page.getByTestId('rest-open').click();
    await page.waitForTimeout(2500);
    await page.screenshot({ path: `${OUT}/p3-rest-${n}.png` });
    await page.getByTestId('back-chip').filter({ visible: true }).last().click();
    await page.getByTestId('tab-journey').click();
    await page.waitForTimeout(800);
    await page.getByTestId('grounds-map').scrollIntoViewIfNeeded();
    await page.waitForTimeout(600);
    await page.getByTestId('grounds-map').screenshot({ path: `${OUT}/p3-map-${n}.png` });
    await page.screenshot({ path: `${OUT}/p3-journey-${n}.png` });
    await page.getByTestId('map-next-tier').click();
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${OUT}/p3-tier-${n}.png` });
  });
}

import { LESSON_BY_ID } from '../src/domain/paths';
import { LOOKBACK_PROMPT } from '../src/domain/lookback';
function ready(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 15 * DAY);
  start.setHours(12, 0, 0, 0);
  const at = (n: number, m = 0) => new Date(start.getTime() + n * DAY + m * 60000);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_ready'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: [] }, at(0));
  for (let n = 0; n < 16; n++) j = ops.addCheckIn(j, { mood: 50, energy: 50, connection: 50 }, at(n), `chk_${n}`);
  j = ops.addArea(j, { name: 'Sleep', impact: 4, difficulty: 2 }, at(1), 'area_1');
  for (let i = 0; i < 3; i++) j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: `Win ${i}` }, at(2, i), `ev_${i}`);
  j = ops.addGoal(j, { title: 'Walk daily' }, at(3), 'goal_1');
  j = ops.addGoal(j, { title: 'Call home' }, at(3, 5), 'goal_2');
  j = ops.reachGoal(j, 'goal_1', undefined, at(5));
  j = ops.reachGoal(j, 'goal_2', undefined, at(8));
  j = ops.addJournal(j, 'Strengths and habits.', (LESSON_BY_ID['f-honest-inventory'].measure as any).prompt, at(4), 'jnl_1');
  j = ops.addJournal(j, 'Steadier.', LOOKBACK_PROMPT, at(9), 'jnl_2');
  return j;
}
for (const theme of ['day', 'night'] as const) {
  test(`p3 invitation ${theme}`, async ({ page }, info) => {
    await open(page, ready(), theme);
    await page.getByTestId('tab-journey').click();
    await page.getByTestId('teacher-invitation').click();
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/p3-invitation-${theme}-${info.project.name}.png` });
  });
}
