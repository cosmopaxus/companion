import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StoreProvider } from './src/state/store';
import { NavProvider } from './src/state/nav';
import { AccountProvider } from './src/sync/account';
import { AppShell } from './src/AppShell';
import { installWebStyles } from './src/platform/webStyles';

installWebStyles();

export default function App() {
  return (
    <SafeAreaProvider>
      <StoreProvider>
        <AccountProvider>
          <NavProvider>
            <StatusBar style="dark" />
            <AppShell />
          </NavProvider>
        </AccountProvider>
      </StoreProvider>
    </SafeAreaProvider>
  );
}
