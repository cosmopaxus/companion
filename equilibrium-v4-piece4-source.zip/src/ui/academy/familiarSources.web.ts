// Web: relative addresses, so the app works at any address (see paintingSources.web.ts).
import type { ImageSourcePropType } from 'react-native';
import type { ElementId } from '../../domain/types';

export const FAMILIAR_FACE: Record<ElementId, ImageSourcePropType> = {
  fire: { uri: 'art/familiars/familiar-fire-salamander-head.jpg' },
  air: { uri: 'art/familiars/familiar-air-sylph-head.jpg' },
  water: { uri: 'art/familiars/familiar-water-undine-head.jpg' },
  earth: { uri: 'art/familiars/familiar-earth-gnome-head.jpg' },
};

export const SEAL: Record<ElementId, ImageSourcePropType> = {
  fire: { uri: 'art/seals/seal-fire.jpg' },
  air: { uri: 'art/seals/seal-air.jpg' },
  water: { uri: 'art/seals/seal-water.jpg' },
  earth: { uri: 'art/seals/seal-earth.jpg' },
};
