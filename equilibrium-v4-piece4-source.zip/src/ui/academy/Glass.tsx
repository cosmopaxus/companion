// "Window into glass" (Oct 14 art treatment): clear hall art at the top of a text-heavy screen,
// melting into frosted glass, with a halo behind the title and dark-glass chips on the art.
// All of it is decoration except the chips' text; text never sits directly on raw art.

import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { radius, space } from '../../theme/tokens';
import { BUILDINGS, HALLS, HallId } from '../../theme/academy';
import { CHIP_GLASS, chipBackground, HALL_PAINTING, HOME_PAINTING, WindowKind } from '../../theme/paintings';
import { practiceStreak, TIERS, todayKey } from '../../domain/paths';
import { Gem, HallMark, Icon } from '../Icon';
import { useStore } from '../../state/store';
import { useArtOverlay } from '../../state/artChrome';
import { useNav } from '../../state/nav';
import { gemBalance } from '../../domain/selectors';
import { SPACE_NAME } from '../../domain/spaces';
import { PaintedBackdrop } from './Painted';
import { useHall } from './hall';
import { Seal } from './Familiars';

/** Fills the screen behind its content: the painting at the top, melting into frosted glass below. */
export function GlassBackdrop({ kind = 'hall', hall: fixed, testID = 'hall-hero' }: { kind?: WindowKind; hall?: HallId; testID?: string }) {
  const current = useHall().hall;
  const hall = fixed ?? current;
  return <PaintedBackdrop painting={kind === 'home' ? HOME_PAINTING : HALL_PAINTING[hall]} kind={kind} testID={testID} />;
}

/**
 * Wraps a glass screen's title block. Its readability comes from the title veil in the wash
 * behind it (theme/paintings.ts → pageWashAt): a full-width band of the canvas at HALO_CORE.
 */
export function TitleHalo({ children, testID }: { children: React.ReactNode; testID?: string }) {
  return <View testID={testID}>{children}</View>;
}

/** The hall's name on a dark-glass chip, on the art. */
export function HallChip({ hall: fixed }: { hall?: HallId } = {}) {
  const current = useHall().hall;
  const overlay = useArtOverlay();
  const hall = fixed ?? current;
  return (
    <View style={st.chip}>
      <Seal element={hall} size={24} />
      <Text style={st.chipText} testID="hero-hall">
        {/* With the top bar floating on the art (phones), the chip shows only the hall's name; the element is still read aloud. */}
        <Text style={overlay ? st.srOnly : null}>{HALLS[hall].element} · </Text>
        {HALLS[hall].name}
      </Text>
    </View>
  );
}

/** Home's chips (decided Oct 14): the tier someone is on, and the hall they stand in. */
export function AcademyChip() {
  const { building } = useHall();
  const tier = TIERS[building]?.name ?? BUILDINGS[building].tier;
  return (
    <View style={st.chip} aria-label={`The Academy · ${tier} path`}>
      <Icon name="crest" size={17} color={GOLD} />
      <Text style={st.chipText} testID="hero-place">
        {tier}
      </Text>
    </View>
  );
}

export function HomeHallChip() {
  const { hall } = useHall();
  return (
    <View style={st.chip} aria-label={`Your hall: ${HALLS[hall].element} · ${HALLS[hall].name}`}>
      <Seal element={hall} size={24} />
      <Text style={st.chipText} testID="home-hall">
        {HALLS[hall].name.replace(/^The /, '')}
      </Text>
    </View>
  );
}

/** Days in a row with any practice (mockup 04's flame chip). Shown from the first day. */
export function StreakChip() {
  const store = useStore();
  const n = practiceStreak(store.journey, todayKey());
  if (n < 1) return null;
  return (
    <View style={st.chip} aria-label={`${n} day${n === 1 ? '' : 's'} in a row`} testID="streak-chip">
      <HallMark element="fire" size={15} color="#FFB066" />
      <Text style={[st.chipText, { fontSize: 14, fontWeight: '800' }]}>{n}</Text>
    </View>
  );
}

/** Gems on the art (decided Oct 14: in the app bar and here). Opens the ledger, like the app bar's. */
export function GemChip() {
  const store = useStore();
  const nav = useNav();
  const sp = store.journey.activeSpaceId;
  const n = gemBalance(store.journey, sp);
  return (
    <Pressable role="button" aria-label={`${n} gem${n === 1 ? '' : 's'} in ${SPACE_NAME[sp]}. Open gem ledger`} onPress={() => nav.push({ name: 'gems' })} hitSlop={6} style={(s: any) => [st.chip, st.gems, (s.hovered || s.pressed) && { backgroundColor: 'rgba(24,17,46,0.82)' }]} testID="art-gems">
      <Gem size={15} tone="light" />
      <Text style={[st.chipText, { fontSize: 14, fontWeight: '800' }]}>{n}</Text>
    </Pressable>
  );
}

/** A back button on a round dark-glass chip, for glass screens (mockups 05–07). Its name is read aloud. */
export function BackChip({ label, onPress, innerRef }: { label: string; onPress: () => void; innerRef?: React.Ref<any> }) {
  return (
    <Pressable ref={innerRef} role="button" aria-label={label} onPress={onPress} hitSlop={6} style={(s: any) => [st.chip, st.back, (s.hovered || s.pressed) && { backgroundColor: 'rgba(24,17,46,0.82)' }]} testID="back-chip">
      <Icon name="back" size={20} color={CHIP_GLASS.text} strokeWidth={2.4} />
    </Pressable>
  );
}

const GOLD = '#F3D88E';

const st = StyleSheet.create({
  chip: { flexDirection: 'row', alignItems: 'center', gap: 7, alignSelf: 'flex-start', minHeight: 36, paddingLeft: 10, paddingRight: 13, borderRadius: radius.pill, backgroundColor: chipBackground(), borderWidth: 1, borderColor: CHIP_GLASS.edge },
  back: { width: 44, height: 44, paddingLeft: 0, paddingRight: 0, justifyContent: 'center' },
  gems: { marginLeft: 'auto', minHeight: 36 },
  srOnly: { position: 'absolute', width: 1, height: 1, overflow: 'hidden', opacity: 0 },
  chipText: { color: CHIP_GLASS.text, fontSize: 13, lineHeight: 18, fontWeight: '700' },
});

export const glassSpace = { chipRow: 44, gapAfterChips: space.sm } as const;
