// Piece 4 art files: the four familiars' faces and the four element seals (from the build library's
// 03-art). Phones bundle them; the web serves them from public/art (familiarSources.web.ts).
import type { ImageSourcePropType } from 'react-native';
import type { ElementId } from '../../domain/types';

export const FAMILIAR_FACE: Record<ElementId, ImageSourcePropType> = {
  fire: require('../../../public/art/familiars/familiar-fire-salamander-head.jpg'),
  air: require('../../../public/art/familiars/familiar-air-sylph-head.jpg'),
  water: require('../../../public/art/familiars/familiar-water-undine-head.jpg'),
  earth: require('../../../public/art/familiars/familiar-earth-gnome-head.jpg'),
};

export const SEAL: Record<ElementId, ImageSourcePropType> = {
  fire: require('../../../public/art/seals/seal-fire.jpg'),
  air: require('../../../public/art/seals/seal-air.jpg'),
  water: require('../../../public/art/seals/seal-water.jpg'),
  earth: require('../../../public/art/seals/seal-earth.jpg'),
};
