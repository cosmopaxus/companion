// Piece 4 · familiars and seals (mockups 04–08, 11). Both are decoration: the familiar's name and the
// element's name are always written beside them, so nothing is carried by the picture alone.

import React from 'react';
import { Animated, Image, StyleSheet, View } from 'react-native';
import type { ElementId } from '../../domain/types';
import { FAMILIARS } from '../../theme/familiars';
import { color, isNight } from '../../theme/tokens';
import { HALL_INK } from '../../theme/paintings';
import { useReducedMotion } from '../../state/motion';
import { FAMILIAR_FACE, SEAL } from './familiarSources';
import { useBreath } from './Motion';

/** An element's seal medallion: the painted coin, in a thin gold ring. */
export function Seal({ element, size = 40, testID }: { element: ElementId; size?: number; testID?: string }) {
  return (
    <View style={[st.ring, { width: size, height: size, borderRadius: size / 2, borderColor: color.goldDeco, borderWidth: size >= 40 ? 1.5 : 1 }]} aria-hidden testID={testID ?? `seal-${element}`}>
      <Image source={SEAL[element]} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
    </View>
  );
}

/**
 * A familiar's round portrait, ringed in its element's color. With motion on it bobs gently
 * (2 px, 4 s); under reduced motion it holds still.
 */
export function FamiliarFace({ element, size = 52, bob = true, testID }: { element: ElementId; size?: number; bob?: boolean; testID?: string }) {
  const reduced = useReducedMotion();
  const v = useBreath(4200, bob && !reduced);
  const lift = v.interpolate({ inputRange: [0, 1], outputRange: [0, -2] });
  const ring = Math.max(2, Math.round(size / 20));
  return (
    <Animated.View
      style={[st.face, { width: size, height: size, borderRadius: size / 2, borderWidth: ring, borderColor: HALL_INK[element][isNight ? 'night' : 'day'], transform: [{ translateY: lift }] }]}
      aria-hidden
      aria-label={FAMILIARS[element].name}
      testID={testID ?? `familiar-${element}`}
    >
      <Image source={FAMILIAR_FACE[element]} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
    </Animated.View>
  );
}

const st = StyleSheet.create({
  ring: { overflow: 'hidden', backgroundColor: '#3A2A14', flexShrink: 0 },
  face: { overflow: 'hidden', backgroundColor: color.paperStrong, flexShrink: 0 },
});
