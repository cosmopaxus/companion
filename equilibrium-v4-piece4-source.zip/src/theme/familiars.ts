// Piece 4 · familiars and seals. Decided Oct 14: the familiar follows the element — a lesson's
// familiar is its element's (Fire lesson → Salamander), and each hall is home to its own (the Gnome
// in the Herb Garden). No setting and no saved data: it is worked out from what's already there.
import type { ElementId } from '../domain/types';

export interface Familiar {
  element: ElementId;
  name: string;
  /** What this guide helps with (mockup 12). */
  gift: string;
}

export const FAMILIARS: Record<ElementId, Familiar> = {
  fire: { element: 'fire', name: 'Salamander', gift: 'Courage and willpower' },
  air: { element: 'air', name: 'Sylph', gift: 'Clarity and curiosity' },
  water: { element: 'water', name: 'Undine', gift: 'Feeling and flow' },
  earth: { element: 'earth', name: 'Gnome', gift: 'Steadiness and habit' },
};

/** The familiar for a lesson: its own element, or the hall it's taught in when it has none. */
export function familiarFor(lessonElement: ElementId | undefined, hall: ElementId): Familiar {
  return FAMILIARS[lessonElement ?? hall];
}
