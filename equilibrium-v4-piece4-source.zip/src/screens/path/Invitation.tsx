// An invitation to the next path, in the Hall of Ascension (painted academy, mockup 11).
// Full-screen art; the reading sits on a near-solid panel. "Enter" opens the path exactly as the
// teacher's card does (openTier, 'invited'); "Stay" is the teacher's "Not yet" (deferInvitation).

import React from 'react';
import { Text, View } from 'react-native';
import type { TierId } from '../../domain/types';
import { ELEMENT_IDS } from '../../domain/types';
import { deferInvitation, openTier } from '../../domain/ops';
import { previousTier, teacherNote, TIERS, todayKey } from '../../domain/paths';
import { useStore } from '../../state/store';
import { useNav } from '../../state/nav';
import { useToast } from '../../state/toast';
import { successFeedback } from '../../platform/haptics';
import { color, space, type } from '../../theme/tokens';
import { BUILDINGS, BuildingId } from '../../theme/academy';
import { ArtButton, ArtChip, FullArtScreen } from '../../ui/academy/FullArt';
import { Button, Notice } from '../../ui/primitives';
import { Seal } from '../../ui/academy/Familiars';

export function InvitationScreen({ tier }: { tier: TierId }) {
  const store = useStore();
  const nav = useNav();
  const toast = useToast();
  const today = todayKey();
  const note = teacherNote(store.journey, today);
  const offered = (note.kind === 'invite' || note.kind === 'resting') && note.tier === tier;
  const prev = previousTier(tier);
  const name = TIERS[tier].name;

  const enter = () => {
    const r = store.apply((j) => openTier(j, tier, 'invited', undefined, today));
    if (!r.ok) return toast.show(r.error, { tone: 'caution' });
    successFeedback();
    toast.show(`The ${name} path is open`);
    nav.pop();
  };
  const stay = () => {
    if (note.kind === 'invite') store.apply((j) => deferInvitation(j, tier));
    nav.pop();
  };

  return (
    <FullArtScreen
      painting="hall-of-ascension"
      testID="screen-invitation"
      top={
        <>
          <View style={{ flex: 1 }} />
          <ArtChip icon="sparkle" label="Hall of Ascension" testID="invitation-place" />
          <View style={{ flex: 1, alignItems: 'flex-end' }}>
            <ArtButton icon="close" label="Close" onPress={nav.pop} testID="invitation-close" />
          </View>
        </>
      }
    >
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: space.sm }} aria-hidden>
        {ELEMENT_IDS.map((e) => (
          <Seal key={e} element={e} size={48} />
        ))}
      </View>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <Text style={[type.eyebrow, { color: color.goldPressed }]}>An invitation</Text>
        <Text role="heading" aria-level={1} style={[type.display, { textAlign: 'center' }]} testID="invitation-title">
          {offered ? `The ${name} path is open to you` : `The ${name} path`}
        </Text>
        <Text style={[type.bodySoft, { textAlign: 'center' }]}>
          {offered && prev ? `You’ve mastered the ${TIERS[prev].name}. ${BUILDINGS[tier as BuildingId].name} awaits whenever you’re ready.` : TIERS[tier].intro}
        </Text>
      </View>
      {offered ? (
        <View style={{ gap: space.sm }}>
          <Button label={`Enter the ${name} path`} full onPress={enter} testID="invitation-enter" />
          <Button label={prev ? `Stay in ${TIERS[prev].name} for now` : 'Not now'} kind="quiet" full onPress={stay} testID="invitation-stay" />
        </View>
      ) : (
        <Notice icon="leaf">Your teacher offers this path when your practice is steady and your goals are met. A sincere seeker can also open it from the path’s page.</Notice>
      )}
    </FullArtScreen>
  );
}
