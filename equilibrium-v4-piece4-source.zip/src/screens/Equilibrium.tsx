import React, { useRef, useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import type { ElementId, HarmonySnapshot } from '../domain/types';
import { ELEMENT_IDS } from '../domain/types';
import { balances, BAND_LABEL, bandFor, bandSentence, ELEMENTS, PRESSURE_ANCHORS, RESOURCE_ANCHORS } from '../domain/harmony';
import { equilibriumOf, NEED_TITLE, spreadWord, suggestions, Suggestion, trend } from '../domain/equilibrium';
import { harmonyFor } from '../domain/selectors';
import { SPACE_NAME } from '../domain/spaces';
import { formatDayHeading, formatRelative, formatTime } from '../domain/time';
import { useStore } from '../state/store';
import { useNav } from '../state/nav';
import { color, elementText, elementWash, radius, space, type } from '../theme/tokens';
import { Screen } from '../ui/layout';
import { Button, Card, Eyebrow, focusRing } from '../ui/primitives';
import { EquilibriumOrb } from '../ui/EquilibriumOrb';
import { EquilibriumTrend } from '../ui/EquilibriumTrend';
import { ElementGlyph, Icon } from '../ui/Icon';
import { CompassEmblem, ElementBars, hallInk } from '../ui/academy/GlassParts';
import { Seal } from '../ui/academy/Familiars';
import { SHARP } from '../ui/academy/paintingSources';
import { HALLS, HallId } from '../theme/academy';
import { HALL_PAINTING } from '../theme/paintings';

const EVEN = { fire: 50, air: 50, water: 50, earth: 50 };

const JOURNAL_PROMPT: Record<Suggestion['need'], (lens: string) => string> = {
  restore: (lens) => `What's asking something of my ${lens} right now?`,
  sustain: (lens) => `What keeps my ${lens} steady?`,
  share: (lens) => `Where could my ${lens} be of use today?`,
};

/** The Compass home: where you are now, where to begin, how it's moving, and what the numbers mean. */
export function EquilibriumScreen() {
  const store = useStore();
  const nav = useNav();
  const j = store.journey;
  const sp = j.activeSpaceId;
  const history = harmonyFor(j, sp); // newest first
  const latest = history[0];
  const points = trend(j, sp);
  const [meaningOpen, setMeaningOpen] = useState(!latest);
  const { width } = useWindowDimensions();
  const wide = width >= 1180 && !!latest;
  const scrollRef = useRef<ScrollView>(null);
  const beginY = useRef(0);

  const nowBlock = (
    <>
      {latest ? <NowCard onSuggested={() => scrollRef.current?.scrollTo({ y: Math.max(0, beginY.current - 24), animated: true })} /> : (
        <Card style={{ gap: space.md, alignItems: 'center' }} testID="eq-empty">
          <EquilibriumOrb values={EVEN} size={240} />
          <Text style={[type.bodySoft, { textAlign: 'center' }]}>A two-minute reading of pressure and resource in four parts of life. Your orb takes the shape of what you report.</Text>
          <Button label="Take your first reading" icon="compass" onPress={() => nav.push({ name: 'harmony' })} testID="harmony-open" />
        </Card>
      )}
    </>
  );
  const beginBlock = (
    <>
      {latest ? (
        <View onLayout={(e) => (beginY.current = e.nativeEvent.layout.y)}>
          <BeginCard />
        </View>
      ) : null}
    </>
  );
  const trendBlock = (
    <>
      {latest ? (
        <Card style={{ gap: space.md }} testID="eq-trend">
          <View style={{ gap: 2 }}>
            <Eyebrow heading>Your trend</Eyebrow>
            <Text style={type.small}>How your balance has shifted from reading to reading.</Text>
          </View>
          {points.length >= 2 ? (
            <EquilibriumTrend points={points} testID="eq-trend-chart" />
          ) : (
            <Text style={type.bodySoft} testID="eq-trend-empty">
              Take another reading on another day and your trend begins here.
            </Text>
          )}
        </Card>
      ) : null}
    </>
  );
  const meaningBlock = (
    <>
      <View style={{ gap: space.sm }}>
        <Pressable role="button" aria-expanded={meaningOpen} onPress={() => setMeaningOpen((v) => !v)} style={(s: any) => [st.how, focusRing(s)]} testID="eq-meaning-toggle">
          <Icon name="info" size={18} color={color.sage2} />
          <Text style={[type.label, { flex: 1 }]}>What the numbers mean</Text>
          <Icon name={meaningOpen ? 'chevronDown' : 'chevron'} size={16} color={color.inkSoft} />
        </Pressable>
        {meaningOpen ? <MeaningCard /> : null}
      </View>
    </>
  );
  const readingsBlock = (
    <>
      {history.length ? (
        <View style={{ gap: space.sm }} testID="harmony-history">
          <Eyebrow heading>Readings in {SPACE_NAME[sp]}</Eyebrow>
          <Card padded={false}>
            {history.slice(0, 12).map((h, i) => {
              const s = equilibriumOf(h);
              return (
                <Pressable key={h.id} role="button" aria-label={`Reading from ${formatDayHeading(h.createdAt)} at ${formatTime(h.createdAt)}: ${s.word}. Open`} onPress={() => nav.push({ name: 'harmonyReading', id: h.id })} style={(st2: any) => [st.histRow, i < Math.min(history.length, 12) - 1 && st.rowBorder, (st2.hovered || st2.pressed) && { backgroundColor: color.canvas }, focusRing(st2)]}>
                  <EquilibriumOrb values={s.values} size={58} labels={false} animate={false} />
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={type.label}>
                      {formatDayHeading(h.createdAt)} · {formatTime(h.createdAt)}
                    </Text>
                    <Text style={type.small}>
                      {s.word} · overall {s.overall} · spread {s.spread}
                    </Text>
                  </View>
                  <Icon name="chevron" size={18} color={color.inkSoft} />
                </Pressable>
              );
            })}
          </Card>
        </View>
      ) : null}
    </>
  );

  return (
    <Screen scrollRef={scrollRef} back glass hall="air" eyebrow={`Compass · elemental reading · ${SPACE_NAME[sp]}`} title={latest ? equilibriumOf(latest).word : 'Compass'} titleTestID={latest ? 'eq-word' : undefined} subtitle={latest ? undefined : "How what you have meets what's asked of you, across will, mind, feeling and form."} maxWidth={wide ? 1120 : undefined} testID="screen-equilibrium">
      {wide ? (
        <View style={{ flexDirection: 'row', gap: space.xl, alignItems: 'flex-start' }}>
          <View style={{ flex: 1, gap: space.xl }}>
            {nowBlock}
            {meaningBlock}
            {readingsBlock}
          </View>
          <View style={{ flex: 1, gap: space.xl }}>
            {beginBlock}
            {trendBlock}
          </View>
        </View>
      ) : (
        <>
          {nowBlock}
          {beginBlock}
          {trendBlock}
          {meaningBlock}
          {readingsBlock}
        </>
      )}
    </Screen>
  );
}

function NowCard({ onSuggested }: { onSuggested?: () => void }) {
  const store = useStore();
  const nav = useNav();
  const j = store.journey;
  const history = harmonyFor(j, j.activeSpaceId);
  const latest = history[0];
  const s = equilibriumOf(latest);
  const { begin } = suggestions(s);
  const lowest = ELEMENTS[begin.element];
  const hallOf: Record<ElementId, HallId> = { fire: 'fire', air: 'air', water: 'water', earth: 'earth' };
  return (
    <>
      {/* Mockup 07: the emblem beside the numbers and where to begin. */}
      <Card style={{ gap: space.md }} testID="eq-now">
        <View style={st.nowRow}>
          <CompassEmblem values={s.values} size={112} />
          <View style={{ flex: 1, minWidth: 150, gap: 4 }}>
            <Text style={st.figLine}>
              <Text testID="eq-overall">
                Overall <Text style={st.figNum}>{s.overall}</Text>
                <Text style={st.srOnly}> · {BAND_LABEL[bandFor(s.overall)]}</Text>
              </Text>
              {' · '}
              <Text testID="eq-spread">
                spread <Text style={st.figNum}>{s.spread}</Text>
                <Text style={st.srOnly}> · {spreadWord(s.spread)}</Text>
              </Text>
            </Text>
            <Text style={[type.label, { fontSize: 16.5, lineHeight: 22, fontWeight: '800' }]} testID="eq-begin-line">
              {s.spread < 15 ? `Nearly even. Tend ${lowest.name}, your lowest.` : `${lowest.name} is lowest, so begin there.`}
            </Text>
            <Text style={[type.small, { fontSize: 12.5 }]}>Last reading {formatRelative(latest.createdAt)}</Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
          <Button label="Take a new reading" icon="compass" small onPress={() => nav.push({ name: 'harmony' })} testID="harmony-open" />
          <Button label="See this reading" kind="quiet" small onPress={() => nav.push({ name: 'harmonyReading', id: latest.id })} />
        </View>
      </Card>
      <Card style={{ gap: space.md }} testID="eq-elements-card">
        <ElementBars values={s.values} testID="eq-elements" />
      </Card>
      <Pressable role="button" aria-label={`Suggested today: ${/^[AEIOU]/.test(lowest.name) ? 'an' : 'a'} ${lowest.name} practice in ${HALLS[hallOf[begin.element]].name}. Show practices`} onPress={onSuggested} style={(p: any) => [st.suggest, (p.hovered || p.pressed) && { opacity: 0.92 }, focusRing(p)]} testID="eq-suggested">
        <Image source={SHARP[HALL_PAINTING[hallOf[begin.element]]]} style={st.suggestThumb} resizeMode="cover" aria-hidden />
        <View style={{ flex: 1 }}>
          <Text style={st.suggestEyebrow}>Suggested today</Text>
          <Text style={st.suggestTitle}>
            {/^[AEIOU]/.test(lowest.name) ? 'An' : 'A'} {lowest.name} practice · {HALLS[hallOf[begin.element]].name.replace(/^The /, '')}
          </Text>
        </View>
        <Icon name="chevron" size={18} color={color.sage} />
      </Pressable>
      <Text style={type.bodySoft}>{s.sentence}</Text>
    </>
  );
}

export function BeginCard({ snap, title = 'Where to begin' }: { snap?: HarmonySnapshot; title?: string }) {
  const store = useStore();
  const j = store.journey;
  const latest = snap ?? harmonyFor(j, j.activeSpaceId)[0];
  const s = equilibriumOf(latest);
  const { begin, draw } = suggestions(s);
  return (
    <Card style={{ gap: space.lg }} testID="eq-begin">
      <View style={{ gap: 2 }}>
        <Eyebrow heading>{title}</Eyebrow>
        <Text style={type.small}>Small practices for where you are. Pick one; that's enough.</Text>
      </View>
      <SuggestionBlock s={begin} values={s.values} lead={s.spread < 15 ? 'Tend' : 'Begin with'} testID="eq-begin-main" />
      {draw ? <SuggestionBlock s={draw} values={s.values} lead="Draw on" testID="eq-begin-draw" /> : null}
    </Card>
  );
}

function SuggestionBlock({ s, values, lead, testID }: { s: Suggestion; values: Record<ElementId, number>; lead: string; testID?: string }) {
  const nav = useNav();
  const info = ELEMENTS[s.element];
  const b = values[s.element];
  return (
    <View style={{ gap: space.sm }} testID={testID}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View style={[st.glyph, { backgroundColor: elementWash[s.element] }]}>
          <ElementGlyph element={s.element} size={20} color={elementText[s.element]} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={type.heading}>
            {lead} {info.name} <Text style={{ color: elementText[s.element] }}>· {info.lens}</Text>
          </Text>
          <Text style={type.small}>
            {b} · {BAND_LABEL[bandFor(b)]}. {bandSentence(s.element, b)}
          </Text>
        </View>
      </View>
      <Text style={[type.label, { fontSize: 14 }]}>{NEED_TITLE[s.need]}</Text>
      {s.practices.map((p) => (
        <View key={p} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
          <Icon name="leaf" size={16} color={color.sage} />
          <Text style={[type.small, { color: color.ink, flex: 1 }]}>{p}</Text>
        </View>
      ))}
      <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' }}>
        <Button label="Practice it in Journey" small kind="secondary" icon="plus" onPress={() => nav.openSheet({ name: 'areaEditor', presetName: s.practices[0].replace(/\.$/, '') })} />
        <Button
          label="Write about it"
          small
          kind="quiet"
          icon="journal"
          onPress={() => {
            nav.reset();
            nav.requestFocus(`journal:${JOURNAL_PROMPT[s.need](info.lens.toLowerCase())}`);
            nav.setTab('journal');
          }}
        />
      </View>
    </View>
  );
}

function MeaningCard() {
  const store = useStore();
  const latest = harmonyFor(store.journey, store.journey.activeSpaceId)[0];
  return (
    <Card tone="strong" style={{ gap: space.md }} testID="eq-meaning">
      <Text style={type.body}>
        Each element's number is its <Text style={{ fontWeight: '700' }}>balance</Text>, from 0 to 100: how what you have to draw on (<Text style={{ fontWeight: '700' }}>resource</Text>) meets what is being asked of you (<Text style={{ fontWeight: '700' }}>pressure</Text>).
      </Text>
      <View style={{ gap: 6 }}>
        {[
          ['50 is even', 'What you have matches what is asked.'],
          ['Above 50', 'More to draw on than is needed. Room to give, build or rest.'],
          ['Below 50', 'More is asked than you have right now. This is where care helps most.'],
          ['Overall', 'The plain average of your four elements.'],
          ['Spread', 'The gap between your highest and lowest element. Small means your elements move together; large means one part of life is carrying more than the others. That gap is what discord looks like here.'],
        ].map(([k, v]) => (
          <Text key={k} style={type.small}>
            <Text style={{ fontWeight: '700', color: color.ink }}>{k}: </Text>
            {v}
          </Text>
        ))}
      </View>
      {latest ? (
        <View style={{ gap: 6 }} testID="eq-meaning-elements">
          <Text style={type.label}>In your latest reading</Text>
          {ELEMENT_IDS.map((el) => {
            const r = latest.ratings[el];
            const b = balances(latest.ratings)[el];
            return (
              <Text key={el} style={type.small}>
                <Text style={{ fontWeight: '700', color: elementText[el] }}>
                  {ELEMENTS[el].name} · {ELEMENTS[el].lens}:{' '}
                </Text>
                pressure {PRESSURE_ANCHORS[r.pressure].toLowerCase()}, resource {RESOURCE_ANCHORS[r.resource].toLowerCase()} → {b}, {BAND_LABEL[bandFor(b)].toLowerCase()}.
              </Text>
            );
          })}
        </View>
      ) : null}
      <Text style={type.small}>This is what you report, a reflective signal. It isn't a measurement of your body or brain, and it isn't a score to improve.</Text>
    </Card>
  );
}

/** The compact version for Home. */
export function EquilibriumCard() {
  const store = useStore();
  const nav = useNav();
  const j = store.journey;
  const history = harmonyFor(j, j.activeSpaceId);
  const latest = history[0];
  if (!latest) {
    return (
      <Card style={{ gap: space.md }} testID="harmony-card">
        <Eyebrow heading>Compass</Eyebrow>
        <View style={{ flexDirection: 'row', gap: space.lg, alignItems: 'center' }}>
          <EquilibriumOrb values={EVEN} size={120} labels={false} />
          <Text style={[type.bodySoft, { flex: 1 }]}>A two-minute reading of pressure and resource across will, mind, feeling and form. A reflection, not a measurement.</Text>
        </View>
        <Button label="Take your first reading" kind="secondary" small icon="compass" onPress={() => nav.push({ name: 'harmony' })} testID="harmony-open" style={{ alignSelf: 'flex-start' }} />
      </Card>
    );
  }
  const s = equilibriumOf(latest);
  const { begin } = suggestions(s);
  // Mockup 04: one compact row — the reading's word and numbers, the four elements, a chevron.
  return (
    <Card padded={false} testID="harmony-card">
      <Pressable role="button" aria-label={`Compass: ${s.word}. Overall ${s.overall}, spread ${s.spread}. ${s.spread < 15 ? 'Tend' : 'Begin with'} ${ELEMENTS[begin.element].name}. Open Compass`} onPress={() => nav.push({ name: 'equilibrium' })} style={(p: any) => [st.homeRow, (p.hovered || p.pressed) && { backgroundColor: color.actionWash }, focusRing(p)]} testID="equilibrium-open">
        <View style={{ flex: 1, minWidth: 130, gap: 1 }}>
          <Eyebrow tone={color.inkSoft}>Compass</Eyebrow>
          <Text style={type.heading} testID="home-eq-word">
            {s.word}
          </Text>
          <Text style={[type.small, { fontSize: 13, lineHeight: 17 }]}>
            Overall {s.overall} · spread {s.spread}
          </Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }} aria-hidden>
          {ELEMENT_IDS.map((e) => (
            <View key={e} style={{ alignItems: 'center', gap: 2 }}>
              <Seal element={e} size={32} />
              <Text style={[st.homeVal, { color: hallInk(e as HallId) }]}>{s.values[e]}</Text>
            </View>
          ))}
          <Icon name="chevron" size={18} color={color.actionText} />
        </View>
      </Pressable>
    </Card>
  );
}

const st = StyleSheet.create({
  homeRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, flexWrap: 'wrap', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 22 },
  homeVal: { fontSize: 12, lineHeight: 15, fontWeight: '800', fontVariant: ['tabular-nums'] },
  srOnly: { position: 'absolute', width: 1, height: 1, overflow: 'hidden', opacity: 0 },
  suggest: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: 10, paddingRight: space.md, borderRadius: 20, backgroundColor: color.sageWash, borderWidth: 1, borderColor: color.sageBorder },
  suggestThumb: { width: 52, height: 52, borderRadius: 14 },
  suggestEyebrow: { ...type.eyebrow, color: color.sage },
  suggestTitle: { fontSize: 16, lineHeight: 21, fontWeight: '800', color: color.sage },
  nowRow: { flexDirection: 'row', alignItems: 'center', gap: space.lg, flexWrap: 'wrap' },
  figLine: { ...type.body, fontSize: 15, lineHeight: 21, color: color.inkSoft },
  figNum: { fontWeight: '800', color: color.ink, fontVariant: ['tabular-nums'] },
  how: { flexDirection: 'row', alignItems: 'center', gap: space.sm, paddingVertical: 12, paddingHorizontal: space.lg, backgroundColor: color.paper, borderRadius: radius.md, borderWidth: 1, borderColor: color.border, minHeight: 48 },
  glyph: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  histRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.md, paddingRight: space.lg },
  rowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.border },
});
