import { test, Page } from '@playwright/test';
import * as ops from '../src/domain/ops';
import type { Journey } from '../src/domain/types';
import { LESSON_BY_ID } from '../src/domain/paths';
import { LOOKBACK_PROMPT } from '../src/domain/lookback';

// Piece 4 of the painted academy: familiars and seals. Not part of the test suite.
const OUT = process.env.SHOTS_DIR ?? 'painted-shots4';

function journey(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 9 * DAY);
  start.setHours(9, 0, 0, 0);
  const at = (n: number) => new Date(start.getTime() + n * DAY);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_p4'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: ['center'] }, at(0));
  j = ops.dismissGuideCard(j, at(0));
  for (let n = 0; n <= 9; n++) j = ops.addCheckIn(j, { mood: 55 + (n % 4) * 5, energy: 60, connection: 62 }, at(n), `chk_${n}`);
  j = ops.addHarmony(j, { fire: { pressure: 3, resource: 4 }, air: { pressure: 4, resource: 3 }, water: { pressure: 2, resource: 4 }, earth: { pressure: 3, resource: 3 } }, undefined, at(8));
  j = ops.addJournal(j, 'A steadier morning. The walk helped more than I expected.', undefined, at(8), 'jnl_1');
  return j;
}

function ready(): Journey {
  const DAY = 86400000;
  const start = new Date(Date.now() - 15 * DAY);
  start.setHours(12, 0, 0, 0);
  const at = (n: number, m = 0) => new Date(start.getTime() + n * DAY + m * 60000);
  let j = ops.completeOnboarding(ops.emptyJourney(at(0), 'jrn_ready'), { name: 'Cosmo', ageBracket: '35-44', spaceId: 'personal', directions: [] }, at(0));
  for (let n = 0; n < 16; n++) j = ops.addCheckIn(j, { mood: 50, energy: 50, connection: 50 }, at(n), `chk_${n}`);
  j = ops.addArea(j, { name: 'Sleep', impact: 4, difficulty: 2 }, at(1), 'area_1');
  for (let i = 0; i < 3; i++) j = ops.addEvidence(j, { areaId: 'area_1', kind: 'win', text: `Win ${i}` }, at(2, i), `ev_${i}`);
  j = ops.addGoal(j, { title: 'Walk daily' }, at(3), 'goal_1');
  j = ops.addGoal(j, { title: 'Call home' }, at(3, 5), 'goal_2');
  j = ops.reachGoal(j, 'goal_1', undefined, at(5));
  j = ops.reachGoal(j, 'goal_2', undefined, at(8));
  j = ops.addJournal(j, 'Strengths and habits.', (LESSON_BY_ID['f-honest-inventory'].measure as any).prompt, at(4), 'jnl_1');
  j = ops.addJournal(j, 'Steadier.', LOOKBACK_PROMPT, at(9), 'jnl_2');
  return j;
}

async function open(page: Page, j: Journey, theme: 'day' | 'night' = 'day') {
  await page.addInitScript(([v, t]) => { localStorage.setItem('companion.v2.journey.guest', v); localStorage.setItem('companion.v2.theme', t); }, [JSON.stringify(j), theme] as [string, string]);
  await page.goto('/');
  await page.getByTestId('screen-today').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(1200);
}

for (const theme of ['day', 'night'] as const) {
  test(`p4 ${theme}`, async ({ page }, info) => {
    await open(page, journey(), theme);
    const n = `${theme}-${info.project.name}`;
    await page.screenshot({ path: `${OUT}/p4-home-${n}.png` });
    await page.getByTestId('home-teacher-open-lesson').click();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: `${OUT}/p4-lesson-${n}.png` });
    await page.getByTestId('back-chip').filter({ visible: true }).last().click();
    await page.waitForTimeout(500);
    await page.getByTestId('equilibrium-open').first().click();
    await page.waitForTimeout(900);
    await page.getByTestId('eq-elements').scrollIntoViewIfNeeded();
    await page.waitForTimeout(400);
    await page.screenshot({ path: `${OUT}/p4-compass-${n}.png` });
    await page.getByRole('button', { name: 'Back' }).first().click();
    await page.waitForTimeout(500);
    await page.getByTestId('tab-journal').click();
    await page.getByTestId('journal-prompts').getByRole('button').nth(1).click();
    await page.waitForTimeout(900);
    await page.screenshot({ path: `${OUT}/p4-journal-${n}.png` });
  });
  test(`p4 invitation ${theme}`, async ({ page }, info) => {
    await open(page, ready(), theme);
    await page.getByTestId('tab-journey').click();
    await page.getByTestId('teacher-invitation').click();
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/p4-invitation-${theme}-${info.project.name}.png` });
  });
}
